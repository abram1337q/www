<template>
  <header class="app-header">
    <div class="container">
      <div class="header-content">
        <div class="logo">
          <span class="logo-icon">💕</span>
          <h1 class="logo-text gradient-text">Эмма</h1>
        </div>

        <div class="relationship-indicator">
          <span class="relationship-label">Близость</span>
          <div class="relationship-bar">
            <div
              class="relationship-fill"
              :style="{ width: `${sessionStore.relationshipLevel}%` }"
            />
            <div class="relationship-glow" :style="{ width: `${sessionStore.relationshipLevel}%` }" />
          </div>
          <span class="relationship-value">
            {{ Math.round(sessionStore.relationshipLevel) }}%
          </span>
        </div>
      </div>
    </div>
  </header>
</template>

<script setup lang="ts">
import { useSessionStore } from '@/stores/session'

const sessionStore = useSessionStore()
</script>

<style scoped>
.app-header {
  position: sticky;
  top: 0;
  z-index: 100;
  background: rgba(10, 10, 15, 0.8);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--border-color);
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3);
}

.header-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.5rem 0;
  gap: 2rem;
}

.logo {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  animation: slideIn 0.5s ease;
}

.logo-icon {
  font-size: 2rem;
  animation: pulse 2s ease-in-out infinite;
}

.logo-text {
  font-size: 1.75rem;
  font-weight: 700;
  letter-spacing: -0.02em;
}

.relationship-indicator {
  display: flex;
  align-items: center;
  gap: 1rem;
  animation: slideIn 0.5s ease 0.1s backwards;
}

.relationship-label {
  color: var(--text-secondary);
  font-size: 0.875rem;
  font-weight: 500;
  white-space: nowrap;
}

.relationship-bar {
  position: relative;
  width: 180px;
  height: 10px;
  background: var(--bg-tertiary);
  border-radius: 100px;
  overflow: hidden;
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.3);
}

.relationship-fill {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  background: var(--gradient-primary);
  border-radius: 100px;
  transition: width 0.5s cubic-bezier(0.4, 0, 0.2, 1);
}

.relationship-glow {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  background: var(--gradient-primary);
  border-radius: 100px;
  filter: blur(8px);
  opacity: 0.5;
  transition: width 0.5s cubic-bezier(0.4, 0, 0.2, 1);
}

.relationship-value {
  color: var(--text-primary);
  font-size: 0.875rem;
  font-weight: 600;
  min-width: 45px;
  text-align: right;
  font-variant-numeric: tabular-nums;
}

@media (max-width: 768px) {
  .header-content {
    flex-direction: column;
    align-items: flex-start;
    gap: 1rem;
    padding: 1rem 0;
  }

  .relationship-indicator {
    width: 100%;
  }

  .relationship-bar {
    flex: 1;
  }

  .logo-text {
    font-size: 1.5rem;
  }
}

@media (max-width: 480px) {
  .relationship-label {
    display: none;
  }

  .relationship-bar {
    width: 100%;
  }
}
</style>
