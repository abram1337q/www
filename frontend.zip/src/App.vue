<script setup lang="ts">
import { onMounted } from 'vue'
import { useSessionStore } from './stores/session'
import { useChatStore } from './stores/chat'
import { useStoryStore } from './stores/story'
import AppHeader from './components/AppHeader.vue'
import ModeSelection from './components/ModeSelection.vue'
import ChatInterface from './components/ChatInterface.vue'

const sessionStore = useSessionStore()
const chatStore = useChatStore()
const storyStore = useStoryStore()

onMounted(async () => {
  await sessionStore.initSession()
  await storyStore.loadArcs()
})

function handleStartChat() {
  // Chat started, view will switch automatically via reactive currentMode
}

function handleBack() {
  chatStore.resetChat()
  storyStore.loadArcs()
}
</script>

<template>
  <div id="app">
    <AppHeader />

    <main class="container main-content">
      <Transition name="fade" mode="out-in">
        <ModeSelection v-if="!chatStore.currentMode" @start-chat="handleStartChat" />
        <ChatInterface v-else @back="handleBack" />
      </Transition>
    </main>
  </div>
</template>

<style scoped>
.main-content {
  padding: 2rem 1rem;
  min-height: calc(100vh - 120px);
}

@media (max-width: 768px) {
  .main-content {
    padding: 1rem 0.5rem;
  }
}
</style>
