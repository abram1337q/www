-- Создание базы данных (если не существует)
CREATE DATABASE IF NOT EXISTS fitnes_miniapp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE fitnes_miniapp;

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    telegram_id BIGINT UNIQUE,
    yclients_client_id INT,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    username VARCHAR(255),
    phone VARCHAR(20),
    email VARCHAR(255),
    photo_url TEXT,
    balance INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_telegram_id (telegram_id),
    INDEX idx_phone (phone),
    INDEX idx_yclients_client_id (yclients_client_id)
);

-- Таблица уведомлений
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    title VARCHAR(255) NOT NULL,
    text TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at),
    INDEX idx_is_read (is_read)
);

-- Таблица бронирований
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    activity_id INT NOT NULL,
    record_id INT,
    service_title VARCHAR(255) NOT NULL,
    service_price DECIMAL(10, 2) NOT NULL,
    datetime DATETIME NOT NULL,
    paid TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_activity_id (activity_id),
    INDEX idx_paid (paid),
    INDEX idx_datetime (datetime)
);

-- Вставка тестового пользователя
INSERT INTO users (
    telegram_id, 
    first_name, 
    last_name, 
    phone, 
    email, 
    balance
) VALUES (
    123456789,
    'Тестовый',
    'Пользователь',
    '+7(999)999-99-99',
    'test@example.com',
    5000
) ON DUPLICATE KEY UPDATE 
    first_name = VALUES(first_name),
    last_name = VALUES(last_name),
    phone = VALUES(phone),
    email = VALUES(email);

-- Вставка тестовых уведомлений
INSERT INTO notifications (user_id, title, text, is_read) VALUES
    (1, 'Добро пожаловать!', 'Добро пожаловать в наш фитнес-клуб! Мы рады видеть вас среди наших клиентов.', FALSE),
    (1, 'Новая тренировка', 'Завтра в 10:00 у вас тренировка Yoga с тренером Петровой Марией', FALSE),
    (1, 'Специальное предложение', 'Скидка 20% на абонемент Full при покупке до конца недели', FALSE),
    (1, 'Изменение в расписании', 'Тренировка Cycle перенесена на 15:00', TRUE)
ON DUPLICATE KEY UPDATE 
    title = VALUES(title),
    text = VALUES(text);
