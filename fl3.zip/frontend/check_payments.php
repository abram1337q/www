<?php
/**
 * Скрипт проверки статуса платежей без webhook (polling)
 * Использование: https://fitness.dev.relight.com.ru/frontend/check_payments.php
 */

require_once 'api/config.php';
require_once 'api/tkassa_api.php';
require_once 'api/orders.php';
require_once 'api/balance.php';
require_once 'api/notifications.php';

// Функция для проверки и обработки платежей
function checkPendingPayments() {
    $ordersAPI = new OrdersAPI();
    $tkassaAPI = new TKassaAPI();
    $balanceAPI = new BalanceAPI();
    $notificationsAPI = new NotificationsAPI();
    
    // Получаем все pending платежи за последние 24 часа
    $pendingOrders = $ordersAPI->getPendingOrders(24); // hours
    
    echo "<h3>Найдено pending заказов: " . count($pendingOrders) . "</h3>\n";
    
    foreach ($pendingOrders as $order) {
        // В таблице orders: id = OrderId, payment_id = T-Kassa PaymentId
        $orderId = $order['id'];
        $paymentId = $order['payment_id'];
        
        echo "<hr><h4>Проверяем заказ: $orderId</h4>\n";
        echo "<p>User ID: {$order['user_id']}, Amount: {$order['amount']} ₽, PaymentId: $paymentId</p>\n";
        
        // Проверяем наличие payment_id
        if (empty($paymentId)) {
            echo "<p style='color: red;'>❌ PaymentId отсутствует для этого заказа (старый заказ)</p>\n";
            error_log("Order $orderId has no payment_id");
            continue;
        }
        
        // Запрашиваем статус у T-Kassa по PaymentId
        $paymentStatus = $tkassaAPI->getPaymentStatus($paymentId);
        
        if (!$paymentStatus) {
            error_log("Failed to get payment status for order: $orderId");
            echo "<p style='color: red;'>❌ Не удалось получить статус</p>\n";
            continue;
        }
        
        $status = $paymentStatus['Status'] ?? null;
        echo "<p>Статус: <strong>$status</strong></p>\n";
        
        // Обрабатываем статус
        switch ($status) {
            case 'CONFIRMED':
            case 'AUTHORIZED':
                // Успешный платеж - пополняем баланс
                $userId = $order['user_id'];
                $amount = $order['amount'];
                
                echo "<p style='color: green;'> Платеж подтвержден! Обрабатываем...</p>\n";
                
                try {
                    $balanceAPI->rechargeBalance($userId, (int)$amount);
                    echo "<p style='color: green;'> Баланс пополнен на $amount ₽</p>\n";
                    
                    $ordersAPI->updateOrderStatus($order['id'], 'completed');
                    echo "<p style='color: green;'> Статус заказа обновлен</p>\n";
                    
                    // Отправляем уведомление
                    $notificationsAPI->createNotification(
                        $userId,
                        'Баланс пополнен',
                        "Ваш баланс успешно пополнен на $amount ₽",
                        'balance'
                    );
                    echo "<p style='color: green;'> Уведомление создано</p>\n";
                    
                    echo "<p style='color: green;'><strong>🎉 Заказ $orderId успешно обработан!</strong></p>\n";
                    error_log(" Order $orderId completed");
                    
                } catch (Exception $e) {
                    echo "<p style='color: red;'>❌ Ошибка: " . $e->getMessage() . "</p>\n";
                    error_log("❌ Failed to process order $orderId: " . $e->getMessage());
                }
                break;
                
            case 'CANCELED':
            case 'REJECTED':
            case 'REVERSED':
            case 'DEADLINE_EXPIRED':
                // Неудачный платеж
                $ordersAPI->updateOrderStatus($order['id'], 'failed');
                echo "<p style='color: red;'>❌ Заказ $orderId отклонен (статус: $status)</p>\n";
                error_log("❌ Order $orderId failed with status: $status");
                break;
                
            case 'NEW':
            case 'FORM_SHOWED':
            case 'AUTHORIZING':
                // Платеж еще в процессе
                echo "<p style='color: orange;'>⏳ Заказ $orderId еще в обработке (статус: $status)</p>\n";
                error_log("⏳ Order $orderId still pending with status: $status");
                break;
                
            default:
                echo "<p style='color: orange;'>⚠️ Неизвестный статус: $status</p>\n";
                error_log("⚠️ Unknown status for order $orderId: $status");
        }
    }
}

// Запускаем проверку
echo "<h2>🔍 Проверка pending платежей</h2>\n";
error_log("=== Check Payments Script Started ===");

checkPendingPayments();

echo "<hr><h3 style='color: green;'> Проверка завершена</h3>\n";
echo "<p><a href='check_payments.php'>Запустить проверку снова</a></p>\n";

error_log("=== Check Payments Script Completed ===");
?>

