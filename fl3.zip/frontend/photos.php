<?php
require_once 'api/config.php';

// Проверка авторизации с поддержкой Telegram
$user = requireAuth();

// Check if this is a Telegram WebApp
$isTelegramWebApp = isset($_GET['tgWebAppData']) || isset($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN']);

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Фото | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --background-color: #ffffff;
        }

        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: var(--background-color);
            overflow-y: auto;
            overflow-x: hidden;
        }

        @supports (-webkit-touch-callout: none) {
            html, body {
                height: -webkit-fill-available;
            }
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .wrap {
            width: 100%;
            max-width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .app {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        /* Header */
        .header {
            padding: 20px 24px 0 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 44px;
        }

        .back-arrow {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transform: rotate(180deg);
        }

        .back-arrow svg {
            width: 20px;
            height: 20px;
        }

        .page-title {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
            line-height: 20px;
        }

        /* Photo grid */
        .photo-grid {
            padding: 0 24px;
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }

        .photo-item {
            width: 100%;
            height: 120px;
            border-radius: 4px;
            object-fit: cover;
            background-color: #e8e8e8;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <!-- Header -->
            <div class="header">
                <div class="back-arrow" onclick="history.back()">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.5 15L2.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M2.5 10H17.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <div class="page-title">Фото</div>
            </div>

            <!-- Photo grid -->
            <div class="photo-grid">
                <img src="Images/gym-banner.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/trainer.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/gym-banner.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/trainer.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/gym-banner.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/trainer.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/gym-banner.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/trainer.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/gym-banner.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/trainer.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/gym-banner.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/trainer.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/gym-banner.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/trainer.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/gym-banner.jpg" alt="Фото клуба" class="photo-item">
                <img src="Images/trainer.jpg" alt="Фото клуба" class="photo-item">
            </div>
        </div>
    </div>

    <?php if ($isTelegramWebApp): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Telegram WebApp
            const tg = window.Telegram.WebApp;
            tg.expand();
            tg.ready();
        });
    </script>
    <?php endif; ?>
</body>
</html>
