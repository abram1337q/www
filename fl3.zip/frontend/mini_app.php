<?php
require_once 'api/config.php';

// Получаем данные инициализации от Telegram Mini App
$initData = isset($_GET['tgWebAppData']) ? $_GET['tgWebAppData'] : '';
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// Попытка авторизации через Telegram
$user = null;
if ($initData) {
    require_once 'api/telegram_auth.php';
    $user = TelegramAuth::authenticateUser($initData);
}

// Если не удалось авторизоваться через Telegram, создаем тестового пользователя
// только для локальной разработки
if (!$user) {
    // Проверяем, это localhost или продакшн
    $isLocalhost = isset($_SERVER['HTTP_HOST']) && (
        $_SERVER['HTTP_HOST'] === 'localhost' ||
        $_SERVER['HTTP_HOST'] === '127.0.0.1' ||
        strpos($_SERVER['HTTP_HOST'], 'localhost') !== false
    );

    if ($isLocalhost) {
        // Только на localhost создаем тестового пользователя
        $user = login();
    }
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Фитнес-клуб</title>
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--tg-theme-bg-color, #fff);
            color: var(--tg-theme-text-color, #000);
        }

        .container {
            max-width: 100%;
            padding: 20px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px;
            margin-bottom: 10px;
            background-color: var(--tg-theme-secondary-bg-color, #f5f5f5);
            border-radius: 10px;
            cursor: pointer;
            color: var(--tg-theme-text-color, #000);
            text-decoration: none;
        }

        .menu-item:hover {
            background-color: var(--tg-theme-hint-color, #eee);
        }

        .menu-icon {
            margin-right: 15px;
            font-size: 24px;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="profile.php" class="menu-item">
            <div class="menu-icon">👤</div>
            <div>Мой профиль</div>
        </a>
        <a href="calendar.php" class="menu-item">
            <div class="menu-icon">📅</div>
            <div>Расписание</div>
        </a>
        <a href="shop.php" class="menu-item">
            <div class="menu-icon">🎫</div>
            <div>Тарифы</div>
        </a>
        <a href="trainers.php" class="menu-item">
            <div class="menu-icon">💪</div>
            <div>Тренеры</div>
        </a>
        <a href="notifications.php" class="menu-item">
            <div class="menu-icon">🔔</div>
            <div>Уведомления</div>
        </a>
        <a href="club.php" class="menu-item">
            <div class="menu-icon">🏋️‍♂️</div>
            <div>О клубе</div>
        </a>
    </div>

    <script>
        // Инициализация Telegram Mini App
        let tg = window.Telegram.WebApp;
        tg.expand(); // Раскрываем на всю высоту
        tg.enableClosingConfirmation(); // Подтверждение закрытия
        
        // Устанавливаем основной цвет
        tg.setHeaderColor('secondary_bg_color');

        // Обработка клика по пунктам меню
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                let href = item.getAttribute('href');

                // В Telegram Mini App добавляем initData в URL
                if (tg.initData) {
                    const separator = href.includes('?') ? '&' : '?';
                    href += separator + 'tgWebAppData=' + encodeURIComponent(tg.initData);
                }

                window.location.href = href;
            });
        });
    </script>
</body>
</html>
