<?php
require_once '../api/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('../login.php');
}

// Get current user
$user = getCurrentUser();
if (!$user) {
    logout();
    redirect('../login.php');
}

// Handle form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = isset($_POST['first_name']) ? trim($_POST['first_name']) : '';
    $lastName = isset($_POST['last_name']) ? trim($_POST['last_name']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';

    // Clean phone number for database storage (digits only)
    $cleanPhone = cleanPhoneNumber($phone);

    // Basic validation
    if (empty($firstName)) {
        $message = 'Введите имя';
        $messageType = 'error';
    } elseif (empty($lastName)) {
        $message = 'Введите фамилию';
        $messageType = 'error';
    } elseif (empty($phone) || strlen($cleanPhone) !== 11 || !preg_match('/^7\d{10}$/', $cleanPhone)) {
        $message = 'Введите корректный номер телефона в формате +7 (XXX) XXX-XX-XX';
        $messageType = 'error';
    } elseif (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Введите корректный email адрес';
        $messageType = 'error';
    } else {
        // Update user data in database
        $userData = [
            'first_name' => $firstName,
            'last_name' => $lastName,
            'phone' => $cleanPhone, // Store clean phone number in database
            'email' => $email
        ];

        $updatedUser = updateUser($user['id'], $userData);

        if ($updatedUser) {
            $message = 'Личные данные успешно сохранены';
            $messageType = 'success';

            // Update session data with fresh data from database
            // Format phone number for display in session
            $updatedUser['phone'] = formatPhoneNumber($updatedUser['phone']);
            $_SESSION['user'] = $updatedUser;

            // Refresh user data
            $user = getCurrentUser();
        } else {
            $message = 'Ошибка при сохранении данных. Попробуйте еще раз.';
            $messageType = 'error';
        }
    }
}

// Format phone number for display is already available from config.php
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Личные данные | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            /* background-color: #f9f9f9; */
        }

        body {
            font-family: "Inter", sans-serif;
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        a {
            text-decoration: none;
        }

        .clear {
            clear: both;
        }

        .wrap {
            width: 100%;
        }

        .app {
            padding: 0 15px;
            margin: 0 auto;
            max-width: 400px;
        }

        /* Personal Data Page */
        .personal-page {
            padding: 20px 0 90px;
        }

        .personal-header {
            display: flex;
            align-items: center;
            margin-bottom: 40px;
        }

        .personal-back {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: #f5f5f5;
            border-radius: 50%;
            cursor: pointer;
            margin-right: 20px;
        }

        .personal-title {
            font-size: 16px;
            font-weight: 500;
            color: #333;
        }

        .personal-avatar-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 30px;
        }

        .personal-avatar {
            width: 84px;
            height: 84px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 2px solid #7171dc;
        }

        .personal-avatar-placeholder {
            width: 84px;
            height: 84px;
            border-radius: 50%;
            background: #f5f5f5;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
            border: 2px solid #7171dc;
        }

        .personal-avatar-placeholder-icon {
            font-size: 32px;
            color: #7171dc;
        }

        .personal-change-avatar {
            font-size: 14px;
            color: #7a7a7a;
            cursor: pointer;
        }

        .personal-change-avatar:hover {
            color: #7171dc;
        }

        .personal-form {
            margin-bottom: 30px;
        }

        .personal-field {
            margin-bottom: 20px;
        }

        .personal-input {
            width: 100%;
            height: 52px;
            border: 1px solid #e8e8e8;
            border-radius: 4px;
            padding: 0 16px;
            font-size: 14px;
            font-family: "Inter", sans-serif;
            color: #333;
            background: white;
            box-sizing: border-box;
        }

        .personal-input::placeholder {
            color: #7a7a7a;
        }

        .personal-input:focus {
            outline: none;
            border-color: #7171dc;
        }

        .personal-input:invalid {
            border-color: #ff4d4d;
        }

        .personal-submit-btn {
            width: 100%;
            height: 52px;
            background: #7171dc;
            color: white;
            border: none;
            border-radius: 13px;
            font-size: 14px;
            font-weight: bold;
            font-family: "Inter", sans-serif;
            cursor: pointer;
        }

        .personal-submit-btn:hover {
            background: #5a5ac7;
        }

        .personal-submit-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }

        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }

        .error {
            text-align: center;
            padding: 20px;
            color: #ff4d4d;
        }

        /* Hidden file input */
        .personal-avatar-input {
            display: none;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="personal-page">
                <div class="personal-header">
                    <a href="../profile.php" class="personal-back">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M19 12H5M12 19L5 12L12 5" stroke="#333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </a>
                    <h1 class="personal-title">Личные данные</h1>
                </div>

                <?php if (!empty($message)): ?>
                    <div class="message <?php echo $messageType; ?>">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>

                <div class="personal-avatar-section">
                    <?php if (!empty($user['photo_url'])): ?>
                        <img src="<?php echo htmlspecialchars($user['photo_url']); ?>" alt="Фото профиля" class="personal-avatar">
                    <?php else: ?>
                        <div class="personal-avatar-placeholder">
                            <span class="personal-avatar-placeholder-icon"></span>
                        </div>
                    <?php endif; ?>
                    <span class="personal-change-avatar" onclick="alert('Функция изменения фото будет реализована позже')">Изменить</span>
                </div>

                <form method="POST" class="personal-form">
                    <div class="personal-field">
                        <input type="text" name="first_name" class="personal-input" placeholder="Имя" value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>" required>
                    </div>

                    <div class="personal-field">
                        <input type="text" name="last_name" class="personal-input" placeholder="Фамилия" value="<?php echo htmlspecialchars($user['last_name'] ?? ''); ?>" required>
                    </div>

                    <div class="personal-field">
                        <input type="tel" name="phone" class="personal-input" placeholder="Телефон" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" pattern="\+7\s?\(\d{3}\)\s?\d{3}-\d{2}-\d{2}" required>
                    </div>

                    <div class="personal-field">
                        <input type="email" name="email" class="personal-input" placeholder="Email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                    </div>

                    <button type="submit" class="personal-submit-btn">
                        Сохранить
                    </button>
                </form>
            </div>
        </div>

        <?php $activePage = 'profile'; include '../components/navigation.php'; ?>
    </div>

    <script>
        // Format phone number input
        document.querySelector('input[name="phone"]').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');

            if (value.length > 11) {
                value = value.substr(0, 11);
            }

            if (value.length >= 1) {
                if (value[0] !== '7') {
                    value = '7' + value;
                }

                let formatted = '+7 ';
                if (value.length >= 4) {
                    formatted += '(' + value.substr(1, 3) + ') ';
                } else if (value.length > 1) {
                    formatted += '(' + value.substr(1) + ') ';
                }

                if (value.length >= 7) {
                    formatted += value.substr(4, 3) + '-';
                } else if (value.length >= 4) {
                    formatted += value.substr(4) + '-';
                }

                if (value.length >= 9) {
                    formatted += value.substr(7, 2) + '-';
                } else if (value.length >= 7) {
                    formatted += value.substr(7) + '-';
                }

                if (value.length >= 11) {
                    formatted += value.substr(9, 2);
                } else if (value.length >= 9) {
                    formatted += value.substr(9);
                }

                e.target.value = formatted;
            } else {
                e.target.value = '';
            }
        });

        // Auto-capitalize names
        document.querySelectorAll('input[name="first_name"], input[name="last_name"]').forEach(function(input) {
            input.addEventListener('input', function(e) {
                e.target.value = e.target.value.replace(/\b\w/g, function(l) { return l.toUpperCase(); });
            });
        });
    </script>
</body>
</html>
