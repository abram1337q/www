<?php
require_once '../api/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('../login.php');
}

// Get current user
$user = getCurrentUser();
if (!$user) {
    logout();
    redirect('../login.php');
}

// Добавляем баланс, если его нет
if (!isset($user['balance'])) {
    $user['balance'] = 0; // Баланс пользователя
}

// Mock данные для истории транзакций
$transactions = [

];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Баланс | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            /* background-color: #f9f9f9; */
        }

        body {
            font-family: "Inter", sans-serif;
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        a {
            text-decoration: none;
        }

        .clear {
            clear: both;
        }

        .wrap {
            width: 100%;
        }

        .app {
            padding: 0 15px;
            margin: 0 auto;
            max-width: 400px;
        }

        /* Balance Page */
        .balance-page {
            padding: 20px 0 90px;
        }

        .balance-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 30px;
        }

        .balance-back {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: #f5f5f5;
            border-radius: 50%;
            cursor: pointer;
        }

        .balance-title-section {
            flex: 1;
            text-align: center;
            margin: 0 20px;
        }

        .balance-title {
            font-size: 16px;
            font-weight: 500;
            color: #333;
            margin-bottom: 5px;
        }

        .balance-amount {
            font-size: 28px;
            font-weight: 400;
            color: #7171dc;
        }

        .balance-replenish-btn-link {
            display: block;
            margin-bottom: 30px;
            text-decoration: none;
        }

        .balance-replenish-btn {
            background: #7171dc;
            color: white;
            border: none;
            border-radius: 13px;
            padding: 15px 0;
            font-size: 14px;
            font-weight: bold;
            width: 100%;
            cursor: pointer;
            display: block;
        }

        .balance-history-title {
            font-size: 14px;
            font-weight: 500;
            color: #333;
            margin-bottom: 15px;
        }

        .balance-history-line {
            height: 1px;
            background: #f0f0f0;
            margin-bottom: 15px;
        }

        .balance-transactions {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .balance-transaction {
            display: flex;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #f0f0f0;
            position: relative;
        }

        .balance-transaction:last-child {
            border-bottom: none;
        }

        .balance-transaction-date {
            font-size: 14px;
            color: #333;
            width: 60px;
            flex-shrink: 0;
        }

        .balance-transaction-info {
            flex: 1;
            margin: 0 15px;
        }

        .balance-transaction-description {
            font-size: 14px;
            color: #7a7a7a;
            margin-bottom: 2px;
        }

        .balance-transaction-amount {
            font-size: 16px;
            font-weight: 400;
            position: absolute;
            right: 25px;
            top: 50%;
            transform: translateY(-50%);
        }

        .balance-transaction-amount.income {
            color: #333;
        }

        .balance-transaction-amount.expense {
            color: #7a7a7a;
        }

        .balance-transaction-status {
            position: absolute;
            right: 0;
            top: 15px;
            width: 20px;
            height: 20px;
        }

        .balance-transaction-status.completed {
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%237171dc" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20,6 9,17 4,12"></polyline></svg>') no-repeat center;
            background-size: 16px;
        }

        .balance-transaction-status.pending {
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%23ffa500" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12,6 12,12 16,14"></polyline></svg>') no-repeat center;
            background-size: 16px;
        }

        .balance-transaction-status.failed {
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%23ff4d4d" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>') no-repeat center;
            background-size: 16px;
        }

        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }

        .error {
            text-align: center;
            padding: 20px;
            color: #ff4d4d;
        }

        .no-data {
            text-align: center;
            padding: 20px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="balance-page">
                <div class="balance-header">
                    <a href="../profile.php" class="balance-back">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M19 12H5M12 19L5 12L12 5" stroke="#333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </a>
                    <div class="balance-title-section">
                        <h1 class="balance-title">Баланс</h1>
                        <div class="balance-amount"><?php echo number_format($user['balance'], 0, '.', ' '); ?> ₽</div>
                    </div>
                    <div style="width: 40px;"></div> <!-- Пустой блок для центрирования -->
                </div>

                <a href="replenish.php" class="balance-replenish-btn-link">
                    <button class="balance-replenish-btn">
                        Пополнить
                    </button>
                </a>

                <h2 class="balance-history-title">История</h2>
                <div class="balance-history-line"></div>

                <?php if (empty($transactions)): ?>
                    <div class="no-data">История транзакций пуста</div>
                <?php else: ?>
                    <ul class="balance-transactions">
                        <?php foreach ($transactions as $transaction): ?>
                            <li class="balance-transaction">
                                <div class="balance-transaction-date"><?php echo htmlspecialchars($transaction['date']); ?></div>
                                <div class="balance-transaction-info">
                                    <div class="balance-transaction-description"><?php echo htmlspecialchars($transaction['description']); ?></div>
                                </div>
                                <div class="balance-transaction-amount <?php echo $transaction['type']; ?>">
                                    <?php echo ($transaction['type'] === 'income' ? '+' : '-') . number_format($transaction['amount'], 0, '.', ' '); ?> ₽
                                </div>
                                <div class="balance-transaction-status <?php echo $transaction['status']; ?>"></div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <?php $activePage = 'profile'; include '../components/navigation.php'; ?>
    </div>
</body>
</html>
