<?php
require_once 'api/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Get current user
$user = getCurrentUser();
if (!$user) {
    logout();
    redirect('login.php');
}

// Handle form submission
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $firstName = trim($_POST['first_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    
    // Validate form data
    if (empty($firstName)) {
        $error = 'Имя обязательно для заполнения';
    } else {
        // Update user data
        $userData = [
            'first_name' => $firstName,
            'last_name' => $lastName,
            'phone' => $phone,
            'email' => $email
        ];
        
        $updatedUser = updateUser($user['id'], $userData);
        
        if ($updatedUser) {
            $message = 'Данные успешно обновлены';
            $user = $updatedUser; // Update local user variable
        } else {
            $error = 'Ошибка при обновлении данных';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Настройки | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        body {
            font-family: "Inter", sans-serif;
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        a {
            text-decoration: none;
        }

        .clear {
            clear: both;
        }

        .wrap {
            width: 100%;
        }

        .app {
            padding: 0 15px;
            margin: 0 auto;
            max-width: 400px;
        }

        /* Settings Page */
        .settings-page {
            padding: 20px 0 90px;
        }

        .settings-header {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .settings-back {
            margin-right: 15px;
            color: #7171dc;
            cursor: pointer;
        }

        .settings-title {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin: 0;
        }

        .settings-form {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.05);
        }

        .settings-form-group {
            margin-bottom: 20px;
        }

        .settings-form-label {
            display: block;
            font-size: 14px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }

        .settings-form-input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box;
            font-family: "Inter", sans-serif;
        }

        .settings-form-button {
            background: #7171dc;
            color: #fff;
            border: none;
            text-align: center;
            line-height: 14px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            margin: 0;
            border-radius: 30px;
            width: 100%;
            box-sizing: border-box;
            padding: 15px 0;
        }

        .settings-message {
            background: #e6f7e6;
            color: #2e7d32;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .settings-error {
            background: #ffebee;
            color: #c62828;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

            color: #7171dc;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="settings-page">
                <div class="settings-header">
                    <a href="profile.php" class="settings-back">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M19 12H5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12 19L5 12L12 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </a>
                    <h1 class="settings-title">Настройки</h1>
                </div>

                <?php if (!empty($message)): ?>
                    <div class="settings-message"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="settings-error"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="settings-form">
                    <form method="post" action="settings.php">
                        <div class="settings-form-group">
                            <label for="first_name" class="settings-form-label">Имя</label>
                            <input type="text" i  class="settings-form-label">Имя</label>
                            <input type="text" id="first_name" name="first_name" class="settings-form-input" value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
                        </div>
                        
                        <div class="settings-form-group">
                            <label for="last_name" class="settings-form-label">Фамилия</label>
                            <input type="text" id="last_name" name="last_name" class="settings-form-input" value="<?php echo htmlspecialchars($user['last_name']); ?>">
                        </div>
                        
                        <div class="settings-form-group">
                            <label for="phone" class="settings-form-label">Телефон</label>
                            <input type="tel" id="phone" name="phone" class="settings-form-input" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                        </div>
                        
                        <div class="settings-form-group">
                            <label for="email" class="settings-form-label">Email</label>
                            <input type="email" id="email" name="email" class="settings-form-input" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>">
                        </div>
                        
                        <button type="submit" class="settings-form-button">Сохранить</button>
                    </form>
                </div>
            </div>
        </div>
        
        <?php $activePage = 'profile'; $navType = 'notifications'; include 'components/navigation.php'; ?>
    </div>
</body>
</html>
