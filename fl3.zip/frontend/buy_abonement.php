<?php
require_once 'api/config.php';
require_once 'api/abonements.php';

// Проверка авторизации
$user = requireAuth();

// Обработка покупки
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'purchase') {
    $type = $_POST['type'] ?? '';
    
    if (in_array($type, ['single', 'monthly'])) {
        $abonementsAPI = new AbonementsAPI();
        $result = $abonementsAPI->purchaseAbonement($user['id'], $type);
        
        if ($result['success']) {
            $message = $result['message'];
            $messageType = 'success';
            // Обновляем данные пользователя
            $user = getCurrentUser();
        } else {
            $message = $result['message'];
            $messageType = 'error';
            
            if (isset($result['required']) && isset($result['current'])) {
                $message .= " (Требуется: {$result['required']}₽, Доступно: {$result['current']}₽)";
            }
        }
    }
}

// Получаем абонементы пользователя
$abonementsAPI = new AbonementsAPI();
$abonements = $abonementsAPI->getUserAbonements($user['id']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Купить абонемент | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: "Inter", sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .wrap {
            padding: 20px 15px 90px 15px;
            max-width: 600px;
            margin: 0 auto;
        }

        .page-header {
            margin-bottom: 20px;
        }

        .page-title {
            font-size: 24px;
            font-weight: 700;
            color: #333;
            margin: 0 0 10px 0;
        }

        .balance-info {
            background: #9B9FE8;
            color: white;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .balance-label {
            font-size: 14px;
            opacity: 0.9;
            margin-bottom: 5px;
        }

        .balance-amount {
            font-size: 32px;
            font-weight: 700;
        }

        .message {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .message-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .abonement-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .abonement-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .abonement-title {
            font-size: 20px;
            font-weight: 700;
            color: #333;
        }

        .abonement-price {
            font-size: 24px;
            font-weight: 700;
            color: #667eea;
        }

        .abonement-features {
            list-style: none;
            padding: 0;
            margin: 0 0 20px 0;
        }

        .abonement-features li {
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            align-items: center;
        }

        .abonement-features li:last-child {
            border-bottom: none;
        }

        .abonement-features li::before {
            content: "✓";
            color: #667eea;
            font-weight: bold;
            margin-right: 10px;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            text-decoration: none;
        }

        .btn-primary {
            background: #9B9FE8;
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-primary:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }

        .btn-secondary {
            background: #f0f0f0;
            color: #666;
        }

        .active-abonements {
            margin-bottom: 30px;
        }

        .active-abonement {
            background: #7ED9C8;
            color: white;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        .active-abonement-title {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .active-abonement-info {
            font-size: 14px;
            opacity: 0.9;
        }

        .section-title {
            font-size: 18px;
            font-weight: 700;
            margin: 0 0 15px 0;
        }
    </style>
</head>
<body>
    <?php include 'components/back_button.php'; ?>
    
    <div class="wrap">
        <div class="page-header">
            <h1 class="page-title">Купить абонемент</h1>
        </div>

        <!-- Баланс -->
        <div class="balance-info">
            <div class="balance-label">Ваш баланс</div>
            <div class="balance-amount"><?php echo number_format($user['balance'], 0, '.', ' '); ?> ₽</div>
        </div>

        <!-- Сообщения -->
        <?php if ($message): ?>
            <div class="message message-<?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Активные абонементы -->
        <?php if (!empty($abonements)): ?>
            <div class="active-abonements">
                <h2 class="section-title">Ваши абонементы</h2>
                <?php foreach ($abonements as $abonement): ?>
                    <?php if ($abonement['is_active']): ?>
                        <div class="active-abonement">
                            <div class="active-abonement-title"><?php echo $abonement['type_name']; ?></div>
                            <div class="active-abonement-info">
                                <?php if ($abonement['abonement_type'] === 'single'): ?>
                                    Осталось посещений: <?php echo $abonement['balance']; ?>
                                <?php else: ?>
                                    Действует до: <?php echo $abonement['expires_at'] ?? 'Безлимит'; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <h2 class="section-title">Выберите абонемент</h2>

        <!-- Разовое посещение -->
        <div class="abonement-card">
            <div class="abonement-header">
                <div class="abonement-title">Разовое посещение</div>
                <div class="abonement-price"><?php echo ABONEMENT_SINGLE_PRICE; ?> ₽</div>
            </div>
            <ul class="abonement-features">
                <li>1 посещение любой тренировки</li>
                <li>Действует 30 дней</li>
                <li>Все групповые занятия</li>
            </ul>
            <form method="POST">
                <input type="hidden" name="action" value="purchase">
                <input type="hidden" name="type" value="single">
                <button type="submit" class="btn btn-primary" 
                        <?php echo ($user['balance'] < ABONEMENT_SINGLE_PRICE) ? 'disabled' : ''; ?>>
                    <?php if ($user['balance'] >= ABONEMENT_SINGLE_PRICE): ?>
                        Купить
                    <?php else: ?>
                        Недостаточно средств
                    <?php endif; ?>
                </button>
            </form>
        </div>

        <!-- Месячный абонемент -->
        <div class="abonement-card">
            <div class="abonement-header">
                <div class="abonement-title">Месячный безлимит</div>
                <div class="abonement-price"><?php echo ABONEMENT_MONTHLY_PRICE; ?> ₽</div>
            </div>
            <ul class="abonement-features">
                <li>Безлимитные посещения</li>
                <li>Действует 30 дней</li>
                <li>Все групповые занятия</li>
                <li>Экономия до 83%</li>
            </ul>
            <form method="POST">
                <input type="hidden" name="action" value="purchase">
                <input type="hidden" name="type" value="monthly">
                <button type="submit" class="btn btn-primary"
                        <?php echo ($user['balance'] < ABONEMENT_MONTHLY_PRICE) ? 'disabled' : ''; ?>>
                    <?php if ($user['balance'] >= ABONEMENT_MONTHLY_PRICE): ?>
                        Купить
                    <?php else: ?>
                        Недостаточно средств
                    <?php endif; ?>
                </button>
            </form>
        </div>

        <?php if ($user['balance'] < ABONEMENT_SINGLE_PRICE): ?>
            <a href="balance.php" class="btn btn-secondary" style="margin-top: 20px;">
                Пополнить баланс
            </a>
        <?php endif; ?>
    </div>

    <?php include 'components/navigation.php'; ?>
</body>
</html>

