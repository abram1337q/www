<?php
require_once 'api/config.php';
require_once 'components/back_button.php';

// Проверка авторизации
$user = requireAuth();

// Получаем ID товара из URL
$productId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$productId) {
    redirect('shop.php');
}

// Получаем все товары для поиска нужного товара
$shop_data = getShopItems('all', 1, 100);
$special_offers = getSpecialOffers();

$all_items = array_merge($special_offers, $shop_data['items']);

// Ищем товар по ID
$currentProduct = null;
foreach ($all_items as $item) {
    $itemId = $item['id'] ?? $item['good_id'] ?? null;
    if ($itemId == $productId) {
        $currentProduct = $item;
        break;
    }
}

// Если товар не найден, перенаправляем в магазин
if (!$currentProduct) {
    redirect('shop.php');
}

// Определяем, является ли товар абонементом
// Для этого получаем полные данные из YClients API
$isAbonement = false;
$quantity = 1;
global $yclients;

try {
    $url = "https://api.yclients.com/api/v1/goods/" . YCLIENTS_COMPANY_ID . "/?page=1&count=100";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $yclients->getPublicHeaders());
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 200) {
        $data = json_decode($response, true);
        if (isset($data['success']) && $data['success'] && !empty($data['data'])) {
            foreach ($data['data'] as $item) {
                if ($item['good_id'] == $productId) {
                    $isAbonement = !empty($item['loyalty_abonement_type_id']);
                    
                    // Извлекаем количество из названия
                    if (preg_match('/(\d+)\s*(шт|штук)/ui', $item['title'], $matches)) {
                        $quantity = (int)$matches[1];
                    }
                    break;
                }
            }
        }
    }
} catch (Exception $e) {
    error_log("Error checking if product is abonement: " . $e->getMessage());
}

// Обработка покупки товара
$message = '';
$messageType = '';
$isAjaxRequest = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'purchase') {
    $price = $currentProduct['price'] ?? $currentProduct['cost'] ?? 0;
    
    // Проверяем баланс пользователя
    if ($user['balance'] < $price) {
        $messageType = 'error';
        $message = 'Недостаточно средств на балансе';
        
        if ($isAjaxRequest) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'error' => $message,
                'balance' => $user['balance'],
                'required' => $price
            ]);
            exit;
        }
    } else {
        // Определяем тип покупки
        if ($isAbonement) {
            // Покупка товарного абонемента
            require_once 'api/product_abonements.php';
            $productAbonementsAPI = new ProductAbonementsAPI();
            
            $purchaseResult = $productAbonementsAPI->purchaseProductAbonement($user['id'], $productId);
            
            if ($purchaseResult['success']) {
                $messageType = 'success';
                $message = $purchaseResult['message'];
                
                // Обновляем баланс пользователя
                $user = getCurrentUser();
                
                if ($isAjaxRequest) {
                    header('Content-Type: application/json');
                    echo json_encode([
                        'success' => true,
                        'message' => $message,
                        'new_balance' => $user['balance'],
                        'quantity' => $purchaseResult['quantity'] ?? 1,
                        'abonement_balance' => $purchaseResult['new_balance'] ?? 0
                    ]);
                    exit;
                }
            } else {
                $messageType = 'error';
                $message = $purchaseResult['message'] ?? 'Ошибка при покупке товара';
                
                if ($isAjaxRequest) {
                    header('Content-Type: application/json');
                    echo json_encode([
                        'success' => false,
                        'error' => $message
                    ]);
                    exit;
                }
            }
        } else {
            // Обычная покупка товара
            require_once 'api/balance.php';
            $balanceAPI = new BalanceAPI();
            
            // Списываем стоимость товара
            $deductResult = $balanceAPI->deductBalance($user['id'], $price, 'Покупка: ' . $currentProduct['title']);
            
            if ($deductResult['success']) {
                $messageType = 'success';
                $message = 'Товар успешно приобретен!';
                
                // Обновляем баланс пользователя
                $user = getCurrentUser();
                
                if ($isAjaxRequest) {
                    header('Content-Type: application/json');
                    echo json_encode([
                        'success' => true,
                        'message' => $message,
                        'new_balance' => $user['balance']
                    ]);
                    exit;
                }
            } else {
                $messageType = 'error';
                $message = $deductResult['message'] ?? 'Ошибка при покупке товара';
                
                if ($isAjaxRequest) {
                    header('Content-Type: application/json');
                    echo json_encode([
                        'success' => false,
                        'error' => $message
                    ]);
                    exit;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title><?php echo htmlspecialchars($currentProduct['title']); ?> | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <style>
        :root {
            --primary-color: #7171dc;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --border-radius: 13px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            min-height: 100vh;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: #ffffff;
            overflow-y: auto;
            overflow-x: hidden;
        }

        .wrap {
            width: 100%;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        /* Header */
        .product-header {
            display: flex;
            align-items: center;
            padding: 24px;
            gap: 12px;
        }

        .back-button {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transform: rotate(180deg);
        }

        .product-header-title {
            font-size: 14px;
            font-weight: 500;
            line-height: 20px;
            color: var(--text-color);
        }

        /* Product Image */
        .product-image-container {
            padding: 0 24px;
            margin-bottom: 27px;
        }

        .product-image {
            width: 100%;
            height: 295px;
            object-fit: cover;
            border-radius: 4px;
            background-color: #e8e8e8;
        }

        /* Product Title Below Image */
        .product-title-below {
            padding: 0 24px;
            margin-bottom: 20px;
        }

        .product-title-below h2 {
            font-size: 20px;
            font-weight: 600;
            line-height: 28px;
            color: var(--text-color);
            margin: 0;
        }

        /* Product Description */
        .product-description {
            padding: 0 25px;
            font-size: 14px;
            font-weight: 400;
            line-height: 20px;
            color: var(--text-color);
            margin-bottom: 80px;
        }

        /* Buy Button */
        .buy-button {
            position: fixed;
            bottom: 24px;
            left: 24px;
            right: 24px;
            height: 52px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: "Inter", sans-serif;
            transition: all 0.3s ease;
        }

        .buy-button:hover {
            opacity: 0.9;
        }

        .buy-button:active {
            transform: scale(0.98);
        }

        .buy-button:disabled {
            background: #e5e5e5;
            color: #999;
            cursor: not-allowed;
        }

        .buy-button.loading {
            position: relative;
            color: transparent;
        }

        .buy-button.loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            border: 2px solid #fff;
            border-top: 2px solid transparent;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: translate(-50%, -50%) rotate(0deg); }
            100% { transform: translate(-50%, -50%) rotate(360deg); }
        }

        /* Messages */
        .message {
            margin: 0 24px 20px;
            padding: 12px;
            border-radius: 8px;
            text-align: center;
            font-size: 14px;
        }

        .message.success {
            background: #4CAF50;
            color: white;
        }

        .message.error {
            background: #f44336;
            color: white;
        }

        .message.info {
            background: var(--border-color);
            color: var(--text-color);
        }

        /* Balance info in message */
        .balance-info {
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px solid rgba(255,255,255,0.3);
            font-size: 13px;
        }

        .replenish-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 16px;
            background: white;
            color: var(--primary-color);
            text-decoration: none;
            border-radius: 6px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <!-- Header -->
        <div class="product-header">
            <a href="shop.php" class="back-button">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </a>
            <h1 class="product-header-title"><?php echo htmlspecialchars($currentProduct['title']); ?></h1>
        </div>

        <!-- Messages -->
        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>" id="message">
                <?php echo htmlspecialchars($message); ?>
                
                <?php if ($messageType === 'error' && $user['balance'] < ($currentProduct['price'] ?? $currentProduct['cost'] ?? 0)): ?>
                    <div class="balance-info">
                        Ваш баланс: <?php echo number_format($user['balance'], 0, '.', ' '); ?> ₽<br>
                        Требуется: <?php echo number_format($currentProduct['price'] ?? $currentProduct['cost'] ?? 0, 0, '.', ' '); ?> ₽
                        <br>
                        <a href="profile/replenish.php" class="replenish-link">Пополнить баланс</a>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Product Image -->
        <div class="product-image-container">
            <img src="<?php echo htmlspecialchars($currentProduct['image'] ?? $currentProduct['image_url'] ?? 'Images/gym-banner.jpg'); ?>"
                 alt="<?php echo htmlspecialchars($currentProduct['title']); ?>"
                 class="product-image"
                 onerror="this.src='Images/gym-banner.jpg'">
        </div>

        <!-- Product Title Below Image -->
        <div class="product-title-below">
            <h2><?php echo htmlspecialchars($currentProduct['title']); ?></h2>
        </div>

        <!-- Product Description -->
        <div class="product-description">
            <?php 
            $description = $currentProduct['description'] ?? $currentProduct['comment'] ?? 'Товар для фитнеса - всё что нужно для покупки';
            echo nl2br(htmlspecialchars($description)); 
            ?>
            
            <?php if ($isAbonement && $quantity > 1): ?>
                <div class="abonement-info" style="margin-top: 20px; padding: 15px; background: #f0f8ff; border-radius: 12px;">
                    <div style="font-size: 14px; color: #666; margin-bottom: 5px;">📦 Пополняемый товар</div>
                    <div style="font-size: 16px; font-weight: 600; color: var(--primary-color);">+<?php echo $quantity; ?> шт</div>
                    <div style="font-size: 13px; color: #888; margin-top: 5px;">Добавится на ваш баланс товаров</div>
                </div>
            <?php elseif ($isAbonement): ?>
                <div class="abonement-info" style="margin-top: 20px; padding: 15px; background: #f0f8ff; border-radius: 12px;">
                    <div style="font-size: 14px; color: #666;">📦 Пополняемый товар</div>
                    <div style="font-size: 13px; color: #888; margin-top: 5px;">Добавится на ваш баланс товаров</div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Buy Button -->
        <form method="POST" action="" id="purchaseForm">
            <input type="hidden" name="action" value="purchase">
            <button type="button" class="buy-button" onclick="handlePurchase(event)">
                <?php echo $isAbonement ? 'Добавить в баланс товаров' : 'Купить'; ?>
            </button>
        </form>
    </div>

    <script>
        // Initialize Telegram WebApp
        if (window.Telegram && window.Telegram.WebApp) {
            const tg = window.Telegram.WebApp;
            tg.ready();
            tg.expand();
        }

        // Handle purchase
        function handlePurchase(event) {
            event.preventDefault();
            
            const button = document.querySelector('.buy-button');
            button.classList.add('loading');
            button.disabled = true;

            const formData = new FormData();
            formData.append('action', 'purchase');

            fetch('', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage(data.message, 'success');
                    // Обновляем баланс в интерфейсе, если нужно
                    setTimeout(() => {
                        window.location.href = 'shop.php';
                    }, 2000);
                } else {
                    showMessage(data.error || 'Ошибка при покупке', 'error');
                    
                    // Если недостаточно средств, показываем информацию
                    if (data.balance !== undefined && data.required !== undefined) {
                        const balanceInfo = `
                            <div class="balance-info">
                                Ваш баланс: ${formatNumber(data.balance)} ₽<br>
                                Требуется: ${formatNumber(data.required)} ₽
                                <br>
                                <a href="profile/replenish.php" class="replenish-link">Пополнить баланс</a>
                            </div>
                        `;
                        document.querySelector('.message').innerHTML += balanceInfo;
                    }
                }
            })
            .catch(error => {
                console.error('Purchase error:', error);
                showMessage('Ошибка при покупке товара', 'error');
            })
            .finally(() => {
                button.classList.remove('loading');
                button.disabled = false;
            });
        }

        // Show message
        function showMessage(text, type = 'info') {
            const existingMessage = document.getElementById('message');
            if (existingMessage) {
                existingMessage.remove();
            }

            const message = document.createElement('div');
            message.id = 'message';
            message.className = `message ${type}`;
            message.textContent = text;

            const wrap = document.querySelector('.wrap');
            wrap.insertBefore(message, wrap.children[1]);

            // Auto-hide after 5 seconds for success messages
            if (type === 'success') {
                setTimeout(() => {
                    message.remove();
                }, 5000);
            }
        }

        // Format number
        function formatNumber(num) {
            return new Intl.NumberFormat('ru-RU').format(num);
        }

        // Auto-hide initial message after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const message = document.getElementById('message');
            if (message && message.classList.contains('success')) {
                setTimeout(() => {
                    message.remove();
                }, 5000);
            }
        });
    </script>
</body>
</html>

