<?php
require_once 'api/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Get current user
$user = getCurrentUser();
if (!$user) {
    logout();
    redirect('login.php');
}

// Get trainers
$trainers = getStaff();

// Get trainer ID from URL if viewing a specific trainer
$trainerId = isset($_GET['id']) ? intval($_GET['id']) : null;
$selectedTrainer = null;

// Find the selected trainer
if ($trainerId) {
    foreach ($trainers as $trainer) {
        if ($trainer['id'] == $trainerId) {
            $selectedTrainer = $trainer;
            break;
        }
    }
}

// Filter trainers by type if specified
$trainerType = isset($_GET['type']) ? $_GET['type'] : 'all';
$filteredTrainers = [];

if ($trainerType === 'individual') {
    foreach ($trainers as $trainer) {
        if (strpos(strtolower($trainer['specialization']), 'индивидуальн') !== false) {
            $filteredTrainers[] = $trainer;
        }
    }
} elseif ($trainerType === 'group') {
    foreach ($trainers as $trainer) {
        if (strpos(strtolower($trainer['specialization']), 'групп') !== false) {
            $filteredTrainers[] = $trainer;
        }
    }
} else {
    $filteredTrainers = $trainers;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Тренеры | Фитнес-клуб</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        html, body {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: "Inter", sans-serif;
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        a {
            text-decoration: none;
        }

        .clear {
            clear: both;
        }

        .wrap {
            width: 100%;
        }

        .app {
            /* padding: 0 40px; */
            /* margin: 0 auto; */
            /* max-width: 360px; */
        }

        /* Trainers Page */
        .trainers-page {
            position: relative;
            min-height: 720px;
            background-color: #ffffff;
            width: 100%;
            /* padding-bottom: 70px; */
        }

        .trainers-title {
            position: absolute;
            left: 56px;
            top: 24px;
            font-size: 14px;
            font-weight: 500;
            color: #000000;
            margin: 0;
            line-height: 20px;
        }

        .trainers-back {
            position: absolute;
            left: 24px;
            top: 24px;
            width: 20px;
            height: 20px;
            cursor: pointer;
            transform: rotate(180deg);
        }

        .trainers-tabs {
            position: absolute;
            top: 68px;
            left: 0;
            right: 0;
            display: flex;
            justify-content: center;
            gap: 60px;
        }

        .trainers-tab {
            background: none;
            border: none;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            color: #7a7a7a;
            font-weight: 400;
            line-height: 20px;
        }

        .trainers-tab.active {
            color: #7171dc;
            font-weight: 500;
        }

        .trainers-grid {
            display: grid;
            grid-template-columns: repeat(2, 40vw);
            gap: 16px;
            position: absolute;
            top: 112px;
            left: 50%;
            transform: translateX(-50%);
        }

        .trainer-card {
            width: 150px;
            height: 132px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
            overflow: hidden;
        }

        .trainer-photo {
            width: 20vw;
            height: 20vw;
            border-radius: 30vw;
            object-fit: cover;
        }

        .trainer-name {
            font-size: 14px;
            font-weight: 500;
            color: #000000;
            margin: 0;
            line-height: 20px;
            text-align: center;
        }

        /* Trainer Detail */
        .trainer-detail {
            position: relative;
            min-height: 720px;
            background-color: #ffffff;
            height: 100vh;
            width: 100%;
        }

        .trainer-detail-back-arrow {
            position: absolute;
            left: 24px;
            top: 24px;
            width: 20px;
            height: 20px;
            cursor: pointer;
            transform: rotate(180deg);
        }

        .trainer-detail-photo {
            position: absolute;
            left: 50%;
            top: 24px;
            transform: translateX(-50%);
            width: 120px;
            height: 120px;
            border-radius: 60px;
            object-fit: cover;
        }

        .trainer-detail-name {
            position: absolute;
            left: 50%;
            top: 168px;
            transform: translateX(-50%);
            font-size: 16px;
            font-weight: 500;
            color: #000000;
            text-align: center;
            margin: 0;
            line-height: 20px;
        }

        .trainer-detail-description {
            position: absolute;
            left: 50%;
            top: 232px;
            transform: translateX(-50%);
            width: 85vw;
            font-size: 14px;
            line-height: 20px;
            color: #000000;
            margin: 0;
            text-align: left;
        }

        .trainer-detail-button {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            width: 85vw;
            height: 52px;
            background: #7171dc;
            color: #fff;
            border: none;
            border-radius: 13px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .trainer-detail-button.write {
            bottom: 88px;
        }

        .trainer-detail-button.groups {
            bottom: 24px;
            background: #7171dc;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <?php if ($selectedTrainer): ?>
                <div class="trainer-detail">
                        <div class="trainer-detail-back-arrow" onclick="history.back()">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.5 15L2.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M2.5 10H17.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        <img src="<?php echo htmlspecialchars($selectedTrainer['photo']); ?>" alt="<?php echo htmlspecialchars($selectedTrainer['name']); ?>" class="trainer-detail-photo">
                        <h2 class="trainer-detail-name"><?php echo htmlspecialchars($selectedTrainer['name']); ?></h2>
                        <p class="trainer-detail-description">
                            Фитнес-клуб — место, сочетающее в себе спортивный зал для проведения групповых и индивидуальных программ, спортивный зал для игровых видов спорта, тренажерный зал, кардиозону, залы аэробики, студии сайкла, студии пилатеса на большом оборудовании, студии единоборств, студии йоги.
                        </p>
                        <button class="trainer-detail-button write">Написать</button>
                        <button class="trainer-detail-button groups">Группы</button>
                    </div>
            <?php else: ?>
                <div class="trainers-page">
                    <div class="trainers-back">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M7.5 15L2.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M2.5 10H17.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h1 class="trainers-title">Тренеры</h1>

                    <div class="trainers-tabs">
                        <a href="trainers.php" class="trainers-tab <?php echo $trainerType === 'all' ? 'active' : ''; ?>">
                            Индивидуальные
                        </a>
                        <a href="trainers.php?type=group" class="trainers-tab <?php echo $trainerType === 'group' ? 'active' : ''; ?>">
                            Групповые
                        </a>
                    </div>

                    <div class="trainers-grid">
                        <?php foreach ($filteredTrainers as $trainer): ?>
                            <a href="trainers.php?id=<?php echo $trainer['id']; ?>" class="trainer-card">
                                <img src="<?php echo htmlspecialchars($trainer['photo']); ?>" alt="<?php echo htmlspecialchars($trainer['name']); ?>" class="trainer-photo">
                                <p class="trainer-name"><?php echo htmlspecialchars($trainer['name']); ?></p>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
    </div>
</body>
</html>
