<?php
require_once 'api/config.php';
require_once 'api/balance.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Get current user
$user = getCurrentUser();
if (!$user) {
    logout();
    redirect('login.php');
}

// Handle form submission and payment processing
$message = '';
$error = '';
$paymentUrl = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = isset($_POST['amount']) ? (float)$_POST['amount'] : 0;

    if ($amount <= 0) {
        $error = 'Сумма должна быть больше нуля';
    } else {
        // Process payment through T-Kassa
        $balanceAPI = new BalanceAPI();
        $tkassaAPI = null;

        // Check if payment creation is requested
        if (isset($_POST['create_payment'])) {
            // Create payment through T-Kassa API
            require_once 'api/tkassa_api.php';
            require_once 'api/orders.php';
            
            $tkassaAPI = new TKassaAPI();
            $ordersAPI = new OrdersAPI();
            
            // Генерируем уникальный Order ID
            $orderId = $tkassaAPI->generateOrderId($user['id']);
            
            // Сохраняем заказ в БД перед созданием платежа
            $orderData = [
                'order_id' => $orderId,
                'user_id' => $user['id'],
                'amount' => $amount,
                'status' => 'pending',
                'description' => 'Пополнение баланса фитнес-клуба',
                'payment_method' => 'tkassa'
            ];
            
            $orderCreated = $ordersAPI->createOrder($orderData);
            
            if (!$orderCreated) {
                $error = 'Ошибка при создании заказа. Попробуйте еще раз.';
            } else {
                // Формируем Telegram deep links для возврата в бота
                // Формат: https://t.me/bot_username?start=payment_success_orderid
                // или через tg:// протокол для лучшей интеграции
                
                $botUsername = TELEGRAM_BOT_USERNAME; // relight_dev_test_bot
                
                // Success URL - возврат в бота с параметром успеха
                $successUrl = "https://t.me/{$botUsername}?start=payment_success_{$orderId}";
                
                // Fail URL - возврат в бота с параметром ошибки
                $failUrl = "https://t.me/{$botUsername}?start=payment_failed_{$orderId}";
                
                // NotificationURL - webhook для сервера (если нужен)
                $baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                $notificationUrl = $baseUrl . '/webhook_tkassa.php';
                
                // Создаем платеж с правильными URL
                $payment = $tkassaAPI->createPayment(
                    $amount, 
                    $orderId, 
                    'Пополнение баланса фитнес-клуба',
                    $successUrl,
                    $failUrl,
                    $notificationUrl
                );

                if ($payment && $payment['success']) {
                    // Сохраняем информацию о платеже в сессии (для fallback)
                    $_SESSION['tkassa_payment_' . $orderId] = [
                        'order_id' => $orderId,
                        'amount' => $amount,
                        'user_id' => $user['id'],
                        'created_at' => time()
                    ];
                    
                    // Redirect to payment page
                    header('Location: ' . $payment['paymentUrl']);
                    exit;
                } else {
                    $error = 'Ошибка при создании платежа. Пожалуйста, попробуйте еще раз.';
                    // Удаляем заказ, если платеж не создался
                    $ordersAPI->updateOrderStatus($orderId, 'failed');
                }
            }
        } else {
            // Legacy direct balance recharge (for testing purposes)
            $updatedUser = $balanceAPI->rechargeBalance($user['id'], (int)$amount);

            if ($updatedUser) {
                $message = 'Баланс успешно пополнен на ' . number_format($amount, 0, '.', ' ') . ' ₽';
                $user = $updatedUser; // Update local user variable
            } else {
                $error = 'Ошибка при пополнении баланса';
            }
        }
    }
}

// Handle payment success/failure redirects
if (isset($_GET['payment_success']) && isset($_GET['order_id'])) {
    $orderId = $_GET['order_id'];
    $message = 'Платеж обрабатывается. Баланс будет пополнен после подтверждения платежа.';
    
    // Проверяем статус заказа в БД
    require_once 'api/orders.php';
    $ordersAPI = new OrdersAPI();
    $order = $ordersAPI->getOrderByOrderId($orderId);
    
    if ($order && $order['status'] === 'completed') {
        $message = 'Баланс успешно пополнен на ' . number_format($order['amount'], 0, '.', ' ') . ' ₽!';
        // Обновляем информацию о пользователе
        $user = getCurrentUser();
    }
}

if (isset($_GET['payment_error']) && isset($_GET['order_id'])) {
    $orderId = $_GET['order_id'];
    $error = 'Ошибка при оплате. Пожалуйста, попробуйте еще раз.';
    
    // Обновляем статус заказа
    require_once 'api/orders.php';
    $ordersAPI = new OrdersAPI();
    $ordersAPI->updateOrderStatus($orderId, 'failed');
}

if (isset($_GET['success']) && isset($_GET['order'])) {
    $orderId = $_GET['order'];
    $message = 'Платеж успешно завершен! Баланс будет пополнен в ближайшее время.';

    // Check if payment was actually completed and process it
    require_once 'api/tkassa_api.php';
    $tkassaAPI = new TKassaAPI();
    $paymentInfo = $_SESSION['tkassa_payment_' . $orderId] ?? null;

    if ($paymentInfo) {
        $status = $tkassaAPI->getPaymentStatus($orderId);

        if ($status && isset($status['OrderStatus']) && $status['OrderStatus'] == 2) { // 2 = CONFIRMED
            $balanceAPI = new BalanceAPI();
            $updatedUser = $balanceAPI->rechargeBalance($paymentInfo['user_id'], (int)$paymentInfo['amount']);

            if ($updatedUser) {
                $message = 'Баланс успешно пополнен на ' . number_format($paymentInfo['amount'], 0, '.', ' ') . ' ₽';
                $user = $updatedUser;
                // Clean up session data
                unset($_SESSION['tkassa_payment_' . $orderId]);
            }
        }
    }
} elseif (isset($_GET['error'])) {
    if (isset($_GET['order'])) {
        $error = 'Платеж был отменен или произошла ошибка при оплате.';
    } else {
        $error = $_GET['error'];
    }
}

// Get balance history using Balance API
$balanceAPI = new BalanceAPI();
$balanceHistory = $balanceAPI->getBalanceHistory($user['id'], 10);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Баланс | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        body {
            font-family: "Inter", sans-serif;
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        a {
            text-decoration: none;
        }

        .clear {
            clear: both;
        }

        .wrap {
            width: 100%;
        }

        .app {
            padding: 0 15px;
            margin: 0 auto;
            max-width: 400px;
        }

        /* Balance Page */
        .balance-page {
            padding: 20px 0 90px;
        }

        .balance-header {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .balance-back {
            margin-right: 15px;
            color: #7171dc;
            cursor: pointer;
        }

        .balance-title {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin: 0;
        }

        .balance-info {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.05);
            text-align: center;
        }

        .balance-amount {
            font-size: 32px;
            font-weight: bold;
            color: #7171dc;
            margin: 0 0 10px 0;
        }

        .balance-text {
            font-size: 14px;
            color: #666;
            margin: 0;
        }

        .balance-form {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.05);
        }

        .balance-form-title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin: 0 0 15px 0;
        }

        .balance-form-group {
            margin-bottom: 20px;
        }

        .balance-form-label {
            display: block;
            font-size: 14px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }

        .balance-form-input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box;
            font-family: "Inter", sans-serif;
        }

        .balance-form-button {
            background: #7171dc;
            color: #fff;
            border: none;
            text-align: center;
            line-height: 14px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            margin: 0;
            border-radius: 30px;
            width: 100%;
            box-sizing: border-box;
            padding: 15px 0;
        }

        .balance-message {
            background: #e6f7e6;
            color: #2e7d32;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .balance-error {
            background: #ffebee;
            color: #c62828;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .balance-history {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.05);
        }

        .balance-history-title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin: 0 0 15px 0;
        }

        .balance-history-list {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .balance-history-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .balance-history-info {
            flex: 1;
        }

        .balance-history-description {
            font-size: 14px;
            color: #333;
            margin: 0 0 5px 0;
        }

        .balance-history-date {
            font-size: 12px;
            color: #999;
            margin: 0;
        }

        .balance-history-amount {
            font-size: 16px;
            font-weight: bold;
            color: #7171dc;
        }

        .balance-history-amount.negative {
            color: #ff4d4d;
        }

        /* Payment Methods */
        .payment-methods {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .payment-method {
            flex: 1;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            background: #fff;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .payment-method.active {
            border-color: #7171dc;
            background: #f8f9ff;
        }

        .payment-method:hover {
            border-color: #7171dc;
            background: #f8f9ff;
        }

        .payment-method-icon {
            font-size: 24px;
        }

        .payment-method-info {
            flex: 1;
        }

        .payment-method-title {
            font-size: 14px;
            font-weight: 600;
            color: #333;
            margin-bottom: 2px;
        }

        .payment-method-desc {
            font-size: 12px;
            color: #666;
        }

        .balance-form-button:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        .balance-form-button.loading {
            position: relative;
            color: transparent;
        }

        .balance-form-button.loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            border: 2px solid #fff;
            border-top: 2px solid transparent;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: translate(-50%, -50%) rotate(0deg); }
            100% { transform: translate(-50%, -50%) rotate(360deg); }
        }

        .payment-info {
            background: #e3f2fd;
            color: #1565c0;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .payment-info.error {
            background: #ffebee;
            color: #c62828;
        }

        /* Mobile responsive */
        @media (max-width: 480px) {
            .payment-methods {
                flex-direction: column;
            }

            .payment-method {
                justify-content: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="balance-page">
                <div class="balance-header">
                    <a href="profile.php" class="balance-back">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M19 12H5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12 19L5 12L12 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </a>
                    <h1 class="balance-title">Баланс</h1>
                </div>

                <div class="balance-info">
                    <div class="balance-amount"><?php echo number_format($user['balance'], 0, '.', ' '); ?> ₽</div>
                    <p class="balance-text">Текущий баланс</p>
                </div>

                <?php if (!empty($message)): ?>
                    <div class="balance-message"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="balance-error"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="balance-form">
                    <h2 class="balance-form-title">Пополнить баланс</h2>
                    <form id="payment-form" method="get" action="api/tkassa_api.php" target="_blank">
                        <div class="balance-form-group">
                            <label for="amount" class="balance-form-label">Сумма (₽)</label>
                            <input type="number" id="amount" name="amount" class="balance-form-input" min="100" step="100" value="1000" required>
                        </div>

                        <div class="balance-form-group">
                            <div class="payment-methods">
                                <div class="payment-method active" data-method="tkassa">
                                    <div class="payment-method-icon">💳</div>
                                    <div class="payment-method-info">
                                        <div class="payment-method-title">Банковской картой</div>
                                        <div class="payment-method-desc">Visa, Mastercard, МИР</div>
                                    </div>
                                </div>
                                <div class="payment-method" data-method="sbp">
                                    <!-- <div class="payment-method-icon">🏦</div> -->
                                    <div class="payment-method-info">
                                        <div class="payment-method-title">Система быстрых платежей</div>
                                        <div class="payment-method-desc">По QR коду или в приложении банка</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button type="button" class="balance-form-button" onclick="createPayment(event)">Оплатить</button>
                        <button type="button" class="balance-form-button" onclick="checkPendingPayments()" style="background: #6c757d; margin-top: 10px;">
                            🔄 Проверить платежи
                        </button>
                        <input type="hidden" name="create_payment" value="1">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    </form>
                </div>

                <div class="balance-history">
                    <h2 class="balance-history-title">История операций</h2>
                    
                    <?php if (empty($balanceHistory)): ?>
                        <p>История операций пуста</p>
                    <?php else: ?>
                        <ul class="balance-history-list">
                            <?php foreach ($balanceHistory as $item): ?>
                                <li class="balance-history-item">
                                    <div class="balance-history-info">
                                        <div class="balance-history-description"><?php echo htmlspecialchars($item['description']); ?></div>
                                        <div class="balance-history-date"><?php echo date('d.m.Y H:i', strtotime($item['created_at'])); ?></div>
                                    </div>
                                    <div class="balance-history-amount <?php echo $item['amount'] < 0 ? 'negative' : ''; ?>">
                                        <?php echo ($item['amount'] > 0 ? '+' : '') . number_format($item['amount'], 0, '.', ' '); ?> ₽
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <?php $activePage = 'profile'; $navType = 'notifications'; include 'components/navigation.php'; ?>

        <script>
            // Payment method selection
            document.querySelectorAll('.payment-method').forEach(method => {
                method.addEventListener('click', function() {
                    // Remove active class from all methods
                    document.querySelectorAll('.payment-method').forEach(m => m.classList.remove('active'));
                    // Add active class to clicked method
                    this.classList.add('active');
                });
            });

            // Payment creation function
            function createPayment(event) {
                event.preventDefault();

                const amount = parseFloat(document.getElementById('amount').value);
                const button = document.querySelector('.balance-form-button');

                if (!amount || amount < 100) {
                    showPaymentInfo('Минимальная сумма платежа - 100 ₽', 'error');
                    return;
                }

                // Show loading state
                button.classList.add('loading');
                button.disabled = true;

                // Submit form directly to create payment and redirect
                const form = document.getElementById('payment-form');
                form.submit();
            }

            // Show payment info
            function showPaymentInfo(message, type = 'info') {
                const existingInfo = document.querySelector('.payment-info');
                if (existingInfo) {
                    existingInfo.remove();
                }

                const infoDiv = document.createElement('div');
                infoDiv.className = `payment-info ${type}`;
                infoDiv.textContent = message;

                const form = document.querySelector('.balance-form');
                form.parentNode.insertBefore(infoDiv, form);

                // Auto-hide after 5 seconds
                setTimeout(() => {
                    if (infoDiv.parentNode) {
                        infoDiv.remove();
                    }
                }, 5000);
            }

            // Функция проверки pending платежей
            async function checkPendingPayments() {
                const button = event.target;
                button.disabled = true;
                button.textContent = '🔄 Проверяем...';
                
                showPaymentInfo('Проверяем статус всех pending платежей...', 'info');
                
                try {
                    const response = await fetch('check_payments.php');
                    const text = await response.text();
                    
                    // Проверяем, завершилась ли проверка
                    if (text.includes('Проверка завершена') || text.includes('pending заказов: 0')) {
                        showPaymentInfo(' Проверка завершена! Обновите страницу для просмотра баланса.', 'success');
                        // Перезагружаем страницу через 2 секунды
                        setTimeout(() => {
                            window.location.reload();
                        }, 2000);
                    } else {
                        showPaymentInfo('⚠️ Pending платежи не найдены или еще не подтверждены', 'info');
                    }
                } catch (error) {
                    console.error('Error checking payments:', error);
                    showPaymentInfo('❌ Ошибка при проверке платежей', 'error');
                } finally {
                    button.disabled = false;
                    button.textContent = '🔄 Проверить платежи';
                }
            }

            // Check URL parameters on page load
            document.addEventListener('DOMContentLoaded', function() {
                const urlParams = new URLSearchParams(window.location.search);
                
                // Ajax Polling для проверки статуса платежа
                if (urlParams.has('payment_success') && urlParams.has('order_id')) {
                    const orderId = urlParams.get('order_id');
                    showPaymentInfo('Проверяем статус платежа...', 'info');
                    checkPaymentStatus(orderId);
                } else if (urlParams.has('success')) {
                    showPaymentInfo('Платеж успешно завершен! Баланс будет пополнен в ближайшее время.');
                } else if (urlParams.has('error') || urlParams.has('payment_error')) {
                    showPaymentInfo('Платеж был отменен или произошла ошибка при оплате.', 'error');
                }

                // Clean URL parameters for better UX
                if (urlParams.has('success') || urlParams.has('error') || urlParams.has('order') || urlParams.has('payment_success')) {
                    const newUrl = window.location.pathname;
                    window.history.replaceState({}, document.title, newUrl);
                }
            });
            
            // Функция проверки статуса платежа
            let checkAttempts = 0;
            const maxAttempts = 60; // 5 минут (каждые 5 секунд)
            
            function checkPaymentStatus(orderId) {
                if (checkAttempts >= maxAttempts) {
                    showPaymentInfo('Время ожидания истекло. Пожалуйста, обновите страницу позже.', 'error');
                    return;
                }
                
                fetch(`/api/check_payment_status.php?order_id=${orderId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'completed') {
                            // Платеж завершен!
                            showPaymentInfo(` Платеж успешно завершен! Баланс пополнен на ${data.amount} ₽`, 'success');
                            setTimeout(() => {
                                location.reload(); // Перезагружаем страницу через 2 секунды
                            }, 2000);
                        } else if (data.status === 'failed') {
                            // Платеж провалился
                            showPaymentInfo('❌ Платеж отклонен. Попробуйте еще раз.', 'error');
                        } else {
                            // Еще pending - проверяем снова через 5 секунд
                            checkAttempts++;
                            showPaymentInfo(`⏳ ${data.message} (попытка ${checkAttempts}/${maxAttempts})`, 'info');
                            setTimeout(() => checkPaymentStatus(orderId), 5000);
                        }
                    })
                    .catch(error => {
                        console.error('Error checking payment:', error);
                        checkAttempts++;
                        if (checkAttempts < maxAttempts) {
                            setTimeout(() => checkPaymentStatus(orderId), 5000);
                        }
                    });
            }
            
            // Ручная проверка статуса (кнопка)
            function manualCheckPayment() {
                const urlParams = new URLSearchParams(window.location.search);
                const orderId = urlParams.get('order_id');
                if (orderId) {
                    checkAttempts = 0;
                    checkPaymentStatus(orderId);
                }
            }
        </script>
    </div>
</body>
</html>
