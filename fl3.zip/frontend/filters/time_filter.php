<?php
require_once '../api/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Check if this is a Telegram WebApp
$isTelegramWebApp = isset($_GET['tgWebAppData']) || isset($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN']);

// Available time slots
$timeSlots = [
    '10:00', '10:15', '10:30', '10:45',
    '11:00', '11:15', '11:30', '11:45',
    '12:00', '12:15', '12:30', '12:45'
];

// Get current selected time from session
$currentFilters = $_SESSION['filters'] ?? [];
$selectedTime = $currentFilters['time'] ?? '11:00';

// Handle time selection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_time'])) {
    $newTime = $_POST['selected_time'];
    
    // Update filters in session
    if (!isset($_SESSION['filters'])) {
        $_SESSION['filters'] = [];
    }
    $_SESSION['filters']['time'] = $newTime;
    
    // Redirect back to filter page
    redirect('./filter.php');
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Время начала | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php if ($isTelegramWebApp): ?>
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <?php endif; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --secondary-color: #f4f4f4;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --danger-color: #ff4d4d;
            --success-color: #4CAF50;
            --border-radius: 16px;
            --button-radius: 13px;
            --shadow: 0px 2px 10px rgba(0, 0, 0, 0.05);
        }

        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: #ffffff;
            overflow-y: auto;
            overflow-x: hidden;
        }

        @supports (-webkit-touch-callout: none) {
            html, body {
                height: -webkit-fill-available;
            }
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .wrap {
            width: 100%;
            max-width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .app {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .back-button {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            cursor: pointer;
            color: var(--text-color);
            transform: rotate(180deg);
        }

        .back-arrow {
            width: 20px;
            height: 20px;
        }

        .header-title {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
            margin: 0;
        }

        /* Content */
        .content {
            flex: 1;
            padding: 24px;
            padding-bottom: 100px; /* Space for navigation */
        }

        /* Separator line */
        .separator-line {
            height: 1px;
            background-color: var(--border-color);
            margin: 16px 0;
        }

        /* Time items */
        .time-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 0;
            border-bottom: 1px solid var(--border-color);
            cursor: pointer;
            position: relative;
        }

        .time-item:last-child {
            border-bottom: none;
        }

        .time-label {
            font-size: 14px;
            font-weight: 400;
            color: var(--text-color);
        }

        .time-item.selected .time-label {
            color: var(--primary-color);
        }

        .time-check {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.2s ease;
        }

        .time-item.selected .time-check {
            opacity: 1;
        }

        .check-icon {
            width: 20px;
            height: 20px;
            color: var(--primary-color);
        }

        /* Arrow SVG */
        .arrow-svg {
            width: 20px;
            height: 20px;
            fill: none;
            stroke: currentColor;
            stroke-width: 2;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        /* Form styling */
        .time-form {
            width: 100%;
        }

        .time-form input[type="radio"] {
            display: none;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <!-- Header -->
            <?php
            require_once '../components/back_button.php';
            renderBackButton("./filter.php", "Время начала", true, 'filters');
            ?>

            <!-- Content -->
            <div class="content">
                <!-- Separator line after header -->
                <div class="separator-line"></div>

                <form method="POST" action="" class="time-form">
                    <?php foreach ($timeSlots as $time): ?>
                        <div class="time-item <?php echo ($time === $selectedTime) ? 'selected' : ''; ?>" 
                             onclick="selectTime('<?php echo $time; ?>')">
                            <span class="time-label"><?php echo $time; ?></span>
                            <div class="time-check">
                                <svg class="check-icon" viewBox="0 0 24 24">
                                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" fill="none"/>
                                </svg>
                            </div>
                            <input type="radio" name="selected_time" value="<?php echo $time; ?>" 
                                   <?php echo ($time === $selectedTime) ? 'checked' : ''; ?>>
                        </div>
                    <?php endforeach; ?>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Telegram WebApp integration
        <?php if ($isTelegramWebApp): ?>
        if (window.Telegram && window.Telegram.WebApp) {
            window.Telegram.WebApp.ready();
            window.Telegram.WebApp.expand();
        }
        <?php endif; ?>

        function selectTime(time) {
            // Remove selected class from all items
            document.querySelectorAll('.time-item').forEach(item => {
                item.classList.remove('selected');
            });

            // Add selected class to clicked item
            event.currentTarget.classList.add('selected');

            // Check the radio button
            const radio = event.currentTarget.querySelector('input[type="radio"]');
            radio.checked = true;

            // Submit form automatically
            setTimeout(() => {
                document.querySelector('.time-form').submit();
            }, 200);
        }

        // Handle click events
        document.querySelectorAll('.time-item').forEach(item => {
            item.addEventListener('click', function() {
                const time = this.querySelector('input[type="radio"]').value;
                selectTime(time);
            });
        });
    </script>
</body>
</html>
