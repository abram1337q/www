<?php
require_once '../api/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Check if this is a Telegram WebApp
$isTelegramWebApp = isset($_GET['tgWebAppData']) || isset($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN']);

// Handle filter application
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action === 'apply_filters') {
            // Process filter application
            $timeFilter = $_POST['time_filter'] ?? '';
            $trainerFilter = $_POST['trainer_filter'] ?? '';
            $categoryFilter = $_POST['category_filter'] ?? '';
            $activityFilter = $_POST['activity_filter'] ?? '';
            $freeSpotsOnly = isset($_POST['free_spots_only']) ? 1 : 0;

            // Store filters in session or redirect back to calendar with filters
            $_SESSION['filters'] = [
                'time' => $timeFilter,
                'trainer' => $trainerFilter,
                'category' => $categoryFilter,
                'activity' => $activityFilter,
                'free_spots_only' => $freeSpotsOnly
            ];

            redirect('../calendar.php');
        } elseif ($action === 'reset_filters') {
            // Reset all filters
            unset($_SESSION['filters']);
            redirect('../calendar.php');
        }
    }
}

// Get current filters from session
$currentFilters = $_SESSION['filters'] ?? [];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Фильтр | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php if ($isTelegramWebApp): ?>
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <?php endif; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --secondary-color: #f4f4f4;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --danger-color: #ff4d4d;
            --success-color: #4CAF50;
            --border-radius: 16px;
            --button-radius: 13px;
            --shadow: 0px 2px 10px rgba(0, 0, 0, 0.05);
        }

        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: #ffffff;
            overflow-y: auto;
            overflow-x: hidden;
        }

        @supports (-webkit-touch-callout: none) {
            html, body {
                height: -webkit-fill-available;
            }
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .wrap {
            width: 100%;
            max-width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .app {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .header-title {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
            margin: 0;
        }

        /* Content */
        .content {
            flex: 1;
            padding: 24px;
            padding-bottom: 100px; /* Space for navigation */
        }

        /* Filter items */
        .filter-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 0;
            border-bottom: 1px solid var(--border-color);
            cursor: pointer;
        }

        .filter-item:last-child {
            border-bottom: none;
        }

        .filter-label {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
        }

        .filter-value {
            font-size: 14px;
            font-weight: 400;
            color: var(--text-color);
        }

        .filter-arrow {
            width: 20px;
            height: 20px;
            color: var(--light-text);
        }

        /* Switch */
        .switch-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 0;
            border-bottom: 1px solid var(--border-color);
        }

        .switch {
            position: relative;
            display: inline-block;
            width: 32px;
            height: 20px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #e8e8e8;
            transition: .4s;
            border-radius: 10px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 12px;
            width: 12px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        input:checked + .slider {
            background-color: var(--primary-color);
        }

        input:checked + .slider:before {
            transform: translateX(12px);
        }

        /* Buttons */
        .button-container {
            position: fixed;
            bottom: 80px; /* Above navigation */
            left: 24px;
            right: 24px;
            background: white;
            padding: 16px 0;
            border-top: 1px solid var(--border-color);
        }

        .primary-button {
            width: 100%;
            height: 43px;
            background: var(--primary-color);
            border: none;
            border-radius: var(--button-radius);
            color: white;
            font-size: 14px;
            font-weight: 700;
            font-family: "Inter", sans-serif;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
        }

        .reset-link {
            display: block;
            text-align: center;
            font-size: 14px;
            font-weight: 400;
            color: var(--light-text);
            text-decoration: none;
        }

        /* Navigation spacing */
        .navigation-spacer {
            height: 80px;
        }

        /* Arrow SVG */
        .arrow-svg {
            width: 20px;
            height: 20px;
            fill: none;
            stroke: currentColor;
            stroke-width: 2;
            stroke-linecap: round;
            stroke-linejoin: round;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <!-- Header -->
            <?php
            require_once '../components/back_button.php';
            renderBackButton("../calendar.php", "Фильтр", true, 'filters');
            ?>

            <!-- Content -->
            <div class="content">
                <form method="POST" action="">
                    <!-- Time filter -->
                    <a href="time_filter.php" class="filter-item" style="text-decoration: none; color: inherit;">
                        <span class="filter-label">Время начала</span>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span class="filter-value"><?php echo $currentFilters['time'] ?? '11:00'; ?></span>
                            <svg class="filter-arrow arrow-svg" viewBox="0 0 24 24">
                                <path d="M9 18L15 12L9 6"/>
                            </svg>
                        </div>
                    </a>

                    <!-- Trainer filter -->
                    <a href="trainer_filter.php" class="filter-item" style="text-decoration: none; color: inherit;">
                        <span class="filter-label">Тренеры</span>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span class="filter-value"><?php echo $currentFilters['trainer_count'] ?? '1'; ?></span>
                            <svg class="filter-arrow arrow-svg" viewBox="0 0 24 24">
                                <path d="M9 18L15 12L9 6"/>
                            </svg>
                        </div>
                    </a>

                    <!-- Category filter -->
                    <a href="category_filter.php" class="filter-item" style="text-decoration: none; color: inherit;">
                        <span class="filter-label">Категории</span>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span class="filter-value"><?php echo $currentFilters['category_count'] ?? '3'; ?></span>
                            <svg class="filter-arrow arrow-svg" viewBox="0 0 24 24">
                                <path d="M9 18L15 12L9 6"/>
                            </svg>
                        </div>
                    </a>

                    <!-- Activity filter -->
                    <a href="activity_filter.php" class="filter-item" style="text-decoration: none; color: inherit;">
                        <span class="filter-label">Занятия</span>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <svg class="filter-arrow arrow-svg" viewBox="0 0 24 24">
                                <path d="M9 18L15 12L9 6"/>
                            </svg>
                        </div>
                    </a>

                    <!-- Free spots switch -->
                    <div class="switch-container">
                        <span class="filter-label">Свободные места</span>
                        <label class="switch">
                            <input type="checkbox" name="free_spots_only" <?php echo ($currentFilters['free_spots_only'] ?? 0) ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                    </div>

                    <!-- Buttons -->
                    <div class="button-container">
                        <button type="submit" name="action" value="apply_filters" class="primary-button">
                            Применить
                        </button>
                        <a href="#" onclick="document.querySelector('form').action.value='reset_filters'; document.querySelector('form').submit();" class="reset-link">
                            Сбросить
                        </a>
                    </div>
                </form>
            </div>

        </div>
    </div>

    <script>
        // Telegram WebApp integration
        <?php if ($isTelegramWebApp): ?>
        if (window.Telegram && window.Telegram.WebApp) {
            window.Telegram.WebApp.ready();
            window.Telegram.WebApp.expand();
        }
        <?php endif; ?>

        // Handle reset link
        document.querySelector('.reset-link').addEventListener('click', function(e) {
            e.preventDefault();
            const form = document.querySelector('form');
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'reset_filters';
            form.appendChild(actionInput);
            form.submit();
        });
    </script>
</body>
</html>
