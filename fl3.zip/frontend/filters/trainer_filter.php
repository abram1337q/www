<?php
require_once '../api/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Check if this is a Telegram WebApp
$isTelegramWebApp = isset($_GET['tgWebAppData']) || isset($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN']);

// Get trainers from API
$trainers = getStaff();

// Get current selected trainers from session
$currentFilters = $_SESSION['filters'] ?? [];
$selectedTrainers = $currentFilters['trainers'] ?? [];

// Handle trainer selection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_trainers'])) {
    $newTrainers = $_POST['selected_trainers'];
    
    // Update filters in session
    if (!isset($_SESSION['filters'])) {
        $_SESSION['filters'] = [];
    }
    $_SESSION['filters']['trainers'] = $newTrainers;
    $_SESSION['filters']['trainer_count'] = count($newTrainers);
    
    // Redirect back to filter page
    redirect('./filter.php');
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Тренеры | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php if ($isTelegramWebApp): ?>
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <?php endif; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --secondary-color: #f4f4f4;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --danger-color: #ff4d4d;
            --success-color: #4CAF50;
            --border-radius: 16px;
            --button-radius: 13px;
            --shadow: 0px 2px 10px rgba(0, 0, 0, 0.05);
        }

        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: #ffffff;
            overflow-y: auto;
            overflow-x: hidden;
        }

        @supports (-webkit-touch-callout: none) {
            html, body {
                height: -webkit-fill-available;
            }
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .wrap {
            width: 100%;
            max-width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .app {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .back-button {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            cursor: pointer;
            color: var(--text-color);
            transform: rotate(180deg);
        }

        .back-arrow {
            width: 20px;
            height: 20px;
        }

        .header-title {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
            margin: 0;
        }

        /* Content */
        .content {
            flex: 1;
            padding: 24px;
            padding-bottom: 100px; /* Space for navigation */
        }

        /* Trainers grid */
        .trainers-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            margin-top: 20px;
        }

        .trainer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            position: relative;
            padding: 0;
            background: none;
            border: none;
            font-family: inherit;
        }

        .trainer-photo {
            width: 84px;
            height: 84px;
            border-radius: 42px;
            object-fit: cover;
            margin-bottom: 8px;
            position: relative;
            border: 2px solid transparent;
            transition: border-color 0.2s ease;
        }

        .trainer-item.selected .trainer-photo {
            border-color: var(--primary-color);
        }

        .trainer-name {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
            text-align: center;
            line-height: 20px;
            margin: 0;
        }

        .trainer-check {
            position: absolute;
            top: 0;
            right: 17px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 1;
            transition: all 0.2s ease;
            border: 1px solid #e8e8e8;
            z-index: 2;
        }

        .trainer-item.selected .trainer-check {
            opacity: 1;
            background: var(--primary-color);
            border-color: var(--primary-color);
        }

        .trainer-item:not(.selected) .trainer-check {
            background: rgba(255, 255, 255, 0.9);
            border-color: #e8e8e8;
        }

        .trainer-item:not(.selected) .check-icon {
            display: none;
        }

        .check-icon {
            width: 12px;
            height: 12px;
            color: white;
        }

        /* Arrow SVG */
        .arrow-svg {
            width: 20px;
            height: 20px;
            fill: none;
            stroke: currentColor;
            stroke-width: 2;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        /* Form styling */
        .trainer-form {
            width: 100%;
        }

        .trainer-form input[type="checkbox"] {
            display: none;
        }

        /* Apply button */
        .apply-button {
            position: fixed;
            bottom: 24px;
            left: 24px;
            right: 24px;
            height: 43px;
            background: var(--primary-color);
            border: none;
            border-radius: var(--button-radius);
            color: white;
            font-size: 14px;
            font-weight: 700;
            font-family: "Inter", sans-serif;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <!-- Header -->
            <?php
            require_once '../components/back_button.php';
            renderBackButton("./filter.php", "Тренеры", true, 'filters');
            ?>

            <!-- Content -->
            <div class="content">
                <form method="POST" action="" class="trainer-form" id="trainerForm">
                    <div class="trainers-grid">
                        <?php foreach ($trainers as $trainer): ?>
                            <div class="trainer-item <?php echo in_array($trainer['id'], $selectedTrainers) ? 'selected' : ''; ?>">
                                <img src="<?php echo htmlspecialchars($trainer['photo']); ?>" 
                                     alt="<?php echo htmlspecialchars($trainer['name']); ?>" 
                                     class="trainer-photo"
                                     onerror="this.src='Images/trainer.jpg'">
                                <div class="trainer-check">
                                    <svg class="check-icon" viewBox="0 0 24 24">
                                        <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" fill="none"/>
                                    </svg>
                                </div>
                                <p class="trainer-name">
                                    <?php 
                                    $nameParts = explode(' ', $trainer['name']);
                                    if (count($nameParts) >= 2) {
                                        echo htmlspecialchars($nameParts[0]) . '<br>' . htmlspecialchars($nameParts[1]);
                                    } else {
                                        echo htmlspecialchars($trainer['name']);
                                    }
                                    ?>
                                </p>
                                <input type="checkbox" 
                                       name="selected_trainers[]" 
                                       value="<?php echo $trainer['id']; ?>" 
                                       <?php echo in_array($trainer['id'], $selectedTrainers) ? 'checked' : ''; ?>>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <button type="submit" class="apply-button">
                        Применить
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Telegram WebApp integration
        <?php if ($isTelegramWebApp): ?>
        if (window.Telegram && window.Telegram.WebApp) {
            window.Telegram.WebApp.ready();
            window.Telegram.WebApp.expand();
        }
        <?php endif; ?>

        function toggleTrainer(trainerId, element) {
            const item = element;
            const checkbox = item.querySelector('input[type="checkbox"]');
            
            // Toggle selection
            if (item.classList.contains('selected')) {
                item.classList.remove('selected');
                checkbox.checked = false;
            } else {
                item.classList.add('selected');
                checkbox.checked = true;
            }
        }

        // Handle click events
        document.querySelectorAll('.trainer-item').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const trainerId = this.querySelector('input[type="checkbox"]').value;
                toggleTrainer(trainerId, this);
            });
        });
    </script>
</body>
</html>
