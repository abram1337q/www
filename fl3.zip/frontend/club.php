<?php
require_once 'api/config.php';

// Проверка авторизации с поддержкой Telegram
$user = requireAuth();

// Check if this is a Telegram WebApp
$isTelegramWebApp = isset($_GET['tgWebAppData']) || isset($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN']);

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>О клубе | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --background-color: #ffffff;
        }
        
        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: var(--background-color);
            overflow-y: auto;
            overflow-x: hidden;
        }
        
        @supports (-webkit-touch-callout: none) {
            html, body {
                height: -webkit-fill-available;
            }
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .wrap {
            width: 100%;
            max-width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .app {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }


        /* Main content */
        .main-content {
            padding: 20px 24px 20px 24px;
            flex: 1;
        }

        .main-image {
            width: 100%;
            height: 20vh;
            border-radius: 5px;
            object-fit: cover;
            margin-bottom: 24px;
            background-color: #e8e8e8;
        }

        .description {
            font-size: 14px;
            font-weight: 400;
            line-height: 20px;
            color: var(--text-color);
            margin-bottom: 32px;
        }

        /* Photo section */
        .photo-section {
            margin-bottom: 32px;
        }

        .photo-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }

        .photo-title {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
            line-height: 20px;
        }

        .photo-all-link {
            font-size: 14px;
            font-weight: 400;
            color: var(--primary-color);
            line-height: 20px;
            cursor: pointer;
        }

        .photo-grid {
            display: flex;
            gap: 12px;
        }

        .photo-item {
            width: 40vw;
            height: 30vw;
            border-radius: 4px;
            object-fit: cover;
            background-color: #e8e8e8;
        }

        /* Contact info */
        .contact-info {
            margin-bottom: 32px;
        }

        .contact-item {
            font-size: 14px;
            font-weight: 400;
            line-height: 20px;
            color: var(--text-color);
            margin-bottom: 16px;
        }

        .contact-item:last-child {
            margin-bottom: 0;
        }

        /* Social links */
        .social-links {
            display: flex;
            gap: 12px;
        }

        .social-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            cursor: pointer;
            background-color: var(--primary-color);
        }

        .social-link.telegram {
            background-color: var(--primary-color);
        }

        .social-link.vk {
            /* background-color: #000000; */
            
        }

        .social-link.instagram {
            /* background-color: #000000; */
        }

        .social-link svg {
            width: 20px;
            height: 20px;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <!-- Header -->
            <?php
            require_once 'components/back_button.php';
            renderBackButton("home.php", "Название", false, 'default');
            ?>

            <!-- Main content -->
            <div class="main-content">
                <!-- Main image -->
                <img src="Images/gym-banner.jpg" alt="Фитнес клуб" class="main-image">

                <!-- Description -->
                <div class="description">
                    Фи́тнес-клуб — место, сочетающее в себе спортивный зал для проведения групповых и танцевальных программ, спортивный зал для игровых видов спорта, тренажёрный зал, плавательный бассейн, кардио-зону, залы аэробики, студии сайкла, студии пилатеса на большом оборудовании, студии единоборств, студии йоги.
                </div>

                <!-- Photo section -->
                <div class="photo-section">
                    <div class="photo-header">
                        <div class="photo-title">Фото</div>
                        <a href="photos.php" class="photo-all-link">Все</a>
                    </div>
                    <div class="photo-grid">
                        <img src="Images/trainer.jpg" alt="Фото клуба" class="photo-item">
                        <img src="Images/gym-banner.jpg" alt="Фото клуба" class="photo-item">
                    </div>
                </div>

                <!-- Contact info -->
                <div class="contact-info">
                    <div class="contact-item">+7 800 700 60 50</div>
                    <div class="contact-item">г. Москва, ул. Ленина, д.32а</div>
                    <div class="contact-item">Ежедневно c 10:00 до 16:00</div>
                    <div class="contact-item">name@mail.com</div>
                </div>

                <!-- Social links -->
                <div class="social-links">
                    <a href="#" class="social-link telegram">
                        <img src="svg/TG.svg" alt="Telegram" width="20" height="20">
                    </a>
                    <a href="#" class="social-link vk">
                        <img src="svg/VK.svg" alt="VK" width="20" height="20">
                    </a>
                    <a href="#" class="social-link instagram">
                        <img src="svg/instagram.svg" alt="Instagram" width="20" height="20">
                    </a>
                </div>
            </div>
        </div>
        
        <!-- <?php $activePage = 'club'; include 'components/navigation.php'; ?> -->
    </div>

    <?php if ($isTelegramWebApp): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Telegram WebApp
            const tg = window.Telegram.WebApp;
            tg.expand();
            tg.ready();
        });
    </script>
    <?php endif; ?>
</body>
</html>
