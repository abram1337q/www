<?php
require_once 'api/config.php';
require_once 'api/orders.php';
require_once 'api/balance.php';
require_once 'api/user.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Get current user
$user = getCurrentUser();
if (!$user) {
    logout();
    redirect('login.php');
}

// Тинькофф API параметры (в реальном приложении должны быть в конфиге)
define('TINKOFF_TERMINAL_KEY', 'YOUR_TERMINAL_KEY');
define('TINKOFF_SECRET_KEY', 'YOUR_SECRET_KEY');
define('TINKOFF_API_URL', 'https://securepay.tinkoff.ru/v2/');

// Обработка запроса на создание платежа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_payment') {
    $amount = isset($_POST['amount']) ? (int)$_POST['amount'] : 0;
    
    if ($amount <= 0) {
        $error = 'Сумма должна быть больше нуля';
    } else {
        // Создаем платеж в Тинькофф
        $paymentData = createTinkoffPayment($user, $amount);
        
        if ($paymentData && isset($paymentData['PaymentURL'])) {
            // Перенаправляем пользователя на страницу оплаты
            header('Location: ' . $paymentData['PaymentURL']);
            exit;
        } else {
            $error = 'Ошибка при создании платежа';
        }
    }
}

// Обработка уведомления от Тинькофф (callback)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['TerminalKey']) && $_POST['TerminalKey'] === TINKOFF_TERMINAL_KEY) {
    // Проверяем подпись
    if (checkTinkoffSignature($_POST)) {
        $orderId = $_POST['OrderId'] ?? '';
        $status = $_POST['Status'] ?? '';

        // Если платеж успешен
        if ($status === 'CONFIRMED') {
            // Получаем данные заказа через Orders API
            $ordersAPI = new OrdersAPI();
            $orderData = $ordersAPI->getOrderById($orderId);

            if ($orderData) {
                $userId = $orderData['user_id'];
                $amount = $orderData['amount'];

                // Получаем пользователя через User API
                $userAPI = new UserAPI();
                $orderUser = $userAPI->getUserById($userId);

                if ($orderUser && $orderUser['yclients_client_id']) {
                    // Создаем транзакцию в YCLIENTS
                    $transaction = createYClientsTransaction(
                        $orderUser['yclients_client_id'],
                        $amount,
                        'Пополнение баланса через Тинькофф',
                        'payment'
                    );

                    if ($transaction) {
                        // Синхронизируем баланс
                        syncUserBalance($userId);

                        // Обновляем статус заказа через Orders API
                        $ordersAPI->updateOrderStatus($orderId, 'completed');

                        // Добавляем запись в историю баланса через Balance API
                        $balanceAPI = new BalanceAPI();
                        $balanceAPI->addBalanceHistory($userId, $amount, 'Пополнение баланса через Тинькофф');
                    }
                } else {
                    // Если клиент не привязан к YCLIENTS, просто обновляем баланс через User API
                    $balanceAPI = new BalanceAPI();
                    $updatedUser = $balanceAPI->rechargeBalance($userId, $amount);

                    if ($updatedUser) {
                        // Обновляем статус заказа через Orders API
                        $ordersAPI->updateOrderStatus($orderId, 'completed');
                    }
                }
            }
        }

        // Отвечаем Тинькофф, что все ок
        echo json_encode(['success' => true]);
        exit;
    }
}

// Функция для создания платежа в Тинькофф
function createTinkoffPayment($user, $amount) {
    // Создаем заказ через Orders API
    $ordersAPI = new OrdersAPI();
    $orderId = $ordersAPI->createOrder($user['id'], $amount, 'pending', 'tinkoff');

    if (!$orderId) {
        return false;
    }
    
    // Формируем данные для запроса к Тинькофф
    $requestData = [
        'TerminalKey' => TINKOFF_TERMINAL_KEY,
        'Amount' => $amount * 100, // Сумма в копейках
        'OrderId' => $orderId,
        'Description' => 'Пополнение баланса в ' . APP_NAME,
        'DATA' => [
            'Phone' => $user['phone'] ?? '',
            'Email' => $user['email'] ?? ''
        ],
        'NotificationURL' => WEBSITE_URL . '/payment.php', // URL для уведомлений
        'SuccessURL' => WEBSITE_URL . '/balance.php?payment_success=1', // URL при успешной оплате
        'FailURL' => WEBSITE_URL . '/balance.php?payment_error=1' // URL при ошибке оплаты
    ];
    
    // Добавляем подпись
    $requestData['Token'] = generateTinkoffToken($requestData);
    
    // Отправляем запрос к API Тинькофф
    $ch = curl_init(TINKOFF_API_URL . 'Init');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

// Функция для генерации токена для запроса к Тинькофф
function generateTinkoffToken($requestData) {
    // Удаляем ненужные поля
    unset($requestData['DATA']);
    unset($requestData['Receipt']);
    unset($requestData['Token']);
    
    // Сортируем по ключам
    ksort($requestData);
    
    // Формируем строку для подписи
    $signString = '';
    foreach ($requestData as $key => $value) {
        $signString .= $value;
    }
    
    // Добавляем секретный ключ
    $signString .= TINKOFF_SECRET_KEY;
    
    // Возвращаем SHA-256 хеш
    return hash('sha256', $signString);
}

// Функция для проверки подписи от Тинькофф
function checkTinkoffSignature($data) {
    // Получаем токен из данных
    $token = $data['Token'] ?? '';
    
    // Удаляем ненужные поля
    $checkData = $data;
    unset($checkData['Token']);
    unset($checkData['DATA']);
    unset($checkData['Receipt']);
    
    // Сортируем по ключам
    ksort($checkData);
    
    // Формируем строку для проверки
    $signString = '';
    foreach ($checkData as $key => $value) {
        $signString .= $value;
    }
    
    // Добавляем секретный ключ
    $signString .= TINKOFF_SECRET_KEY;
    
    // Вычисляем хеш
    $calculatedToken = hash('sha256', $signString);
    
    // Сравниваем с полученным токеном
    return $token === $calculatedToken;
}

// Функция для получения заказа по ID (использует Orders API)
function getOrderById($orderId) {
    $ordersAPI = new OrdersAPI();
    return $ordersAPI->getOrderById($orderId);
}

// Функция для обновления статуса заказа (использует Orders API)
function updateOrderStatus($orderId, $status) {
    $ordersAPI = new OrdersAPI();
    return $ordersAPI->updateOrderStatus($orderId, $status);
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Оплата | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        body {
            font-family: "Inter", sans-serif;
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        a {
            text-decoration: none;
        }

        .clear {
            clear: both;
        }

        .wrap {
            width: 100%;
        }

        .app {
            padding: 0 15px;
            margin: 0 auto;
            max-width: 400px;
        }

        /* Payment Page */
        .payment-page {
            padding: 20px 0 90px;
        }

        .payment-header {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .payment-back {
            margin-right: 15px;
            color: #7171dc;
            cursor: pointer;
        }

        .payment-title {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin: 0;
        }

        .payment-form {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.05);
        }

        .payment-form-title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin: 0 0 15px 0;
        }

        .payment-form-group {
            margin-bottom: 20px;
        }

        .payment-form-label {
            display: block;
            font-size: 14px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }

        .payment-form-input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box;
            font-family: "Inter", sans-serif;
        }

        .payment-form-button {
            background: #7171dc;
            color: #fff;
            border: none;
            text-align: center;
            line-height: 14px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            margin: 0;
            border-radius: 30px;
            width: 100%;
            box-sizing: border-box;
            padding: 15px 0;
        }

        .payment-message {
            background: #e6f7e6;
            color: #2e7d32;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .payment-error {
            background: #ffebee;
            color: #c62828;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

            color: #7171dc;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="payment-page">
                <div class="payment-header">
                    <a href="balance.php" class="payment-back">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M19 12H5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12 19L5 12L12 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </a>
                    <h1 class="payment-title">Оплата</h1>
                </div>

                <?php if (isset($error)): ?>
                    <div class="payment-error"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="payment-form">
                    <h2 class="payment-form-title">Пополнение баланса</h2>
                    <form method="post" action="payment.php">
                        <input type="hidden" name="action" value="create_payment">
                        <div class="payment-form-group">
                            <label for="amount" class="payment-form-label">Сумма</label>
                            <input type="number" id="amount" name="amount" class="payment-form-input" min="100" step="100" value="1000" required>
                        </div>
                        
                        <button type="submit" class="payment-form-button">Перейти к оплате</button>
                    </form>
                </div>
            </div>
        </div>
        
        <?php $activePage = 'profile'; $navType = 'notifications'; include 'components/navigation.php'; ?>
    </div>
</body>
</html>
