<?php
require_once 'api/config.php';
require_once 'api/product_abonements.php';

// Проверка авторизации
$user = requireAuth();

// Получаем товарные абонементы пользователя
$productAbonementsAPI = new ProductAbonementsAPI();
$abonements = $productAbonementsAPI->getUserProductAbonements($user['id'], AUTO_SYNC_ABONEMENT_BALANCE);

// Разделяем на активные и истекшие
$activeAbonements = [];
$expiredAbonements = [];

foreach ($abonements as $abonement) {
    if ($abonement['is_expired']) {
        $expiredAbonements[] = $abonement;
    } else {
        $activeAbonements[] = $abonement;
    }
}

// Подсчет общего баланса товаров
$totalBalance = 0;
foreach ($activeAbonements as $abonement) {
    $totalBalance += $abonement['balance'];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Мои товары | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: "Inter", sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .wrap {
            padding: 20px 15px 90px 15px;
            max-width: 600px;
            margin: 0 auto;
        }

        .page-header {
            margin-bottom: 20px;
        }

        .page-title {
            font-size: 24px;
            font-weight: 700;
            color: #333;
            margin: 0 0 10px 0;
        }

        .page-subtitle {
            font-size: 14px;
            color: #666;
            margin: 0;
        }

        .total-balance {
            background: linear-gradient(135deg, #9B9FE8 0%, #667eea 100%);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 25px;
            color: white;
        }

        .total-balance-label {
            font-size: 14px;
            opacity: 0.9;
            margin-bottom: 5px;
        }

        .total-balance-value {
            font-size: 36px;
            font-weight: 800;
        }

        .section {
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 700;
            margin: 0 0 15px 0;
            color: #333;
        }

        .product-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: relative;
        }

        .product-card.active {
            border: 2px solid #667eea;
        }

        .product-card.expired {
            opacity: 0.6;
            border: 2px solid #ddd;
        }

        .product-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .product-title {
            font-size: 18px;
            font-weight: 700;
            color: #333;
            flex: 1;
        }

        .product-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }

        .status-active {
            background: #d4edda;
            color: #155724;
        }

        .status-expired {
            background: #f8d7da;
            color: #721c24;
        }

        .product-balance {
            display: flex;
            align-items: baseline;
            margin-bottom: 15px;
        }

        .balance-label {
            font-size: 14px;
            color: #666;
            margin-right: 10px;
        }

        .balance-value {
            font-size: 32px;
            font-weight: 800;
            color: #667eea;
        }

        .balance-unit {
            font-size: 16px;
            color: #999;
            margin-left: 5px;
        }

        .product-info {
            margin-bottom: 10px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
            font-size: 14px;
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-label {
            color: #666;
        }

        .info-value {
            font-weight: 600;
            color: #333;
        }

        .usage-note {
            background: #f8f9fa;
            border-left: 4px solid #9B9FE8;
            padding: 12px 15px;
            border-radius: 8px;
            font-size: 13px;
            color: #555;
            margin-top: 15px;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #666;
        }

        .empty-state-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            text-decoration: none;
            background: #9B9FE8;
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
    </style>
</head>
<body>
    <?php include 'components/back_button.php'; ?>
    
    <div class="wrap">
        <div class="page-header">
            <h1 class="page-title">Мои товары</h1>
            <p class="page-subtitle">Товары используются администратором при выдаче</p>
        </div>

        <?php if (!empty($activeAbonements)): ?>
            <!-- Общий баланс -->
            <div class="total-balance">
                <div class="total-balance-label">Всего товаров</div>
                <div class="total-balance-value"><?php echo $totalBalance; ?> шт</div>
            </div>
        <?php endif; ?>

        <!-- Активные товары -->
        <div class="section">
            <h2 class="section-title">Активные</h2>
            
            <?php if (empty($activeAbonements)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">📦</div>
                    <p>У вас пока нет активных товаров</p>
                    <a href="shop.php" class="btn">Перейти в магазин</a>
                </div>
            <?php else: ?>
                <?php foreach ($activeAbonements as $abonement): ?>
                    <div class="product-card active">
                        <div class="product-header">
                            <div class="product-title"><?php echo htmlspecialchars($abonement['product_title']); ?></div>
                            <div class="product-status status-active">Активен</div>
                        </div>

                        <div class="product-balance">
                            <span class="balance-label">Баланс:</span>
                            <span class="balance-value"><?php echo $abonement['balance']; ?></span>
                            <span class="balance-unit">шт</span>
                        </div>

                        <div class="product-info">
                            <div class="info-row">
                                <span class="info-label">Дата покупки</span>
                                <span class="info-value">
                                    <?php echo date('d.m.Y', strtotime($abonement['purchased_at'])); ?>
                                </span>
                            </div>
                            
                            <?php if ($abonement['expires_at']): ?>
                                <div class="info-row">
                                    <span class="info-label">Действует до</span>
                                    <span class="info-value">
                                        <?php echo date('d.m.Y', strtotime($abonement['expires_at'])); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($abonement['last_synced_at']): ?>
                                <div class="info-row">
                                    <span class="info-label">Обновлено</span>
                                    <span class="info-value">
                                        <?php echo date('d.m.Y H:i', strtotime($abonement['last_synced_at'])); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="usage-note">
                            Товары списываются администратором при выдаче через интерфейс YClients
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Истекшие товары -->
        <?php if (!empty($expiredAbonements)): ?>
            <div class="section">
                <h2 class="section-title">Истекшие</h2>
                
                <?php foreach ($expiredAbonements as $abonement): ?>
                    <div class="product-card expired">
                        <div class="product-header">
                            <div class="product-title"><?php echo htmlspecialchars($abonement['product_title']); ?></div>
                            <div class="product-status status-expired">Истек</div>
                        </div>

                        <div class="product-balance">
                            <span class="balance-label">Баланс:</span>
                            <span class="balance-value"><?php echo $abonement['balance']; ?></span>
                            <span class="balance-unit">шт</span>
                        </div>

                        <div class="product-info">
                            <div class="info-row">
                                <span class="info-label">Дата покупки</span>
                                <span class="info-value">
                                    <?php echo date('d.m.Y', strtotime($abonement['purchased_at'])); ?>
                                </span>
                            </div>
                            
                            <?php if ($abonement['expires_at']): ?>
                                <div class="info-row">
                                    <span class="info-label">Истек</span>
                                    <span class="info-value">
                                        <?php echo date('d.m.Y', strtotime($abonement['expires_at'])); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php 
    $activePage = 'products';
    include 'components/navigation.php'; 
    ?>
</body>
</html>

