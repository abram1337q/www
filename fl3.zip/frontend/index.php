<?php
require_once 'api/config.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title><?php echo APP_NAME; ?></title>
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--tg-theme-bg-color, #fff);
            color: var(--tg-theme-text-color, #000);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .loader {
            text-align: center;
        }
        
        .spinner {
            border: 4px solid rgba(0, 0, 0, 0.1);
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border-left-color: #7171dc;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .loader-text {
            font-size: 16px;
            color: var(--tg-theme-hint-color, #999);
        }
    </style>
</head>
<body>
    <div class="loader">
        <div class="spinner"></div>
        <div class="loader-text">Загрузка...</div>
    </div>

    <script>
        // Инициализация Telegram WebApp
        const tg = window.Telegram.WebApp;
        tg.ready();
        tg.expand();
        
        // Функция для авторизации через Telegram
        async function authenticateWithTelegram() {
            try {
                console.log('=== Telegram Authentication Start ===');
                console.log('Telegram WebApp available:', !!window.Telegram?.WebApp);
                
                let initData = tg.initData;
                
                // Если initData пустой, пробуем извлечь из URL
                if (!initData || initData.length === 0) {
                    const hash = window.location.hash.substring(1);
                    if (hash) {
                        const match = hash.match(/tgWebAppData=([^&]*)/);
                        if (match && match[1]) {
                            initData = match[1];
                            console.log('InitData extracted from URL hash');
                        }
                    }
                }
                
                console.log('InitData length:', initData ? initData.length : 0);
                console.log('InitData preview:', initData ? initData.substring(0, 50) + '...' : 'EMPTY');
                
                // Получаем данные пользователя для отладки
                const user = tg.initDataUnsafe?.user;
                if (user) {
                    console.log('User from Telegram:', {
                        id: user.id,
                        first_name: user.first_name,
                        last_name: user.last_name,
                        username: user.username
                    });
                }
                
                if (!initData) {
                    console.warn('⚠️ No initData available, redirecting to login');
                    window.location.href = 'login.php';
                    return;
                }
                
                console.log('📤 Sending initData to server...');
                
                // Отправляем initData на сервер для валидации
                const formData = new FormData();
                formData.append('action', 'telegram_auth');
                formData.append('initData', initData);
                
                const response = await fetch('api/telegram_auth.php', {
                    method: 'POST',
                    body: formData
                });
                
                console.log('📥 Server response status:', response.status);
                
                let data;
                try {
                    const responseText = await response.text();
                    console.log('📥 Server response (raw):', responseText.substring(0, 200));
                    data = JSON.parse(responseText);
                    console.log('📥 Server response data:', data);
                } catch (parseError) {
                    console.error('❌ Failed to parse server response:', parseError);
                    throw new Error('Invalid server response format');
                }
                
                if (data.success) {
                    console.log(' Authentication successful!');
                    console.log('User data:', data.user);
                    window.location.href = 'home.php';
                } else {
                    console.error('❌ Authentication failed:', data.error);
                    // Даем время посмотреть логи
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 2000);
                }
            } catch (error) {
                console.error('❌ Authentication error:', error);
                // Даем время посмотреть логи
                setTimeout(() => {
                    window.location.href = 'login.php';
                }, 2000);
            }
        }
        
        // Проверяем, запущено ли приложение в Telegram
        if (window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.initData) {
            // Запускаем авторизацию через Telegram
            authenticateWithTelegram();
        } else {
            // Если не в Telegram, используем стандартную проверку PHP
            <?php
            if (isLoggedIn()) {
                echo "window.location.href = 'home.php';";
            } else {
                echo "window.location.href = 'login.php';";
            }
            ?>
        }
    </script>
</body>
</html>
