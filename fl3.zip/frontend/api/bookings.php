<?php
require_once 'config.php';
require_once 'database.php';

class BookingsAPI {
    private $conn;
    private $database;

    public function __construct() {
        $this->conn = getDbConnection();
        $this->ensureTableExists();
    }

    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }

    /**
     * Get Database instance (lazy initialization)
     */
    private function getDatabase() {
        if (!$this->database) {
            $this->database = new Database();
        }
        return $this->database;
    }

    /**
     * Убеждаемся, что таблица бронирований существует
     */
    private function ensureTableExists() {
        $database = $this->getDatabase();
        $database->createBookingsTable();
    }

    /**
     * Создание записи о бронировании
     * 
     * @param int $userId ID пользователя
     * @param int $activityId ID активности в YClients
     * @param int|null $recordId ID записи в YClients
     * @param string $serviceTitle Название услуги
     * @param float $servicePrice Цена услуги
     * @param string $datetime Дата и время активности (YYYY-MM-DD HH:MM:SS)
     * @return int|false ID созданного бронирования или false при ошибке
     */
    public function createBooking($userId, $activityId, $recordId, $serviceTitle, $servicePrice, $datetime) {
        // Проверяем, не существует ли уже такое бронирование
        $existing = $this->getBookingByActivity($userId, $activityId);
        if ($existing) {
            error_log("Booking already exists for user {$userId} and activity {$activityId}");
            return $existing['id'];
        }

        $stmt = $this->conn->prepare("INSERT INTO bookings (user_id, activity_id, record_id, visit_id, service_title, service_price, datetime, paid) VALUES (?, ?, ?, NULL, ?, ?, ?, 0)");
        $stmt->bind_param("iiisds", $userId, $activityId, $recordId, $serviceTitle, $servicePrice, $datetime);
        $result = $stmt->execute();
        $bookingId = $stmt->insert_id;
        $stmt->close();

        if ($result) {
            error_log("Created booking {$bookingId} for user {$userId}, activity {$activityId}, price {$servicePrice}");
            return $bookingId;
        }

        error_log("Failed to create booking for user {$userId}, activity {$activityId}");
        return false;
    }

    /**
     * Обновить visit_id для бронирования
     * 
     * @param int $bookingId ID бронирования
     * @param int $visitId ID визита из YClients
     * @return bool Успех операции
     */
    public function updateVisitId($bookingId, $visitId) {
        $stmt = $this->conn->prepare("UPDATE bookings SET visit_id = ? WHERE id = ?");
        $stmt->bind_param("ii", $visitId, $bookingId);
        $success = $stmt->execute();
        $stmt->close();

        if ($success) {
            error_log("Updated visit_id to {$visitId} for booking {$bookingId}");
        } else {
            error_log("Failed to update visit_id for booking {$bookingId}");
        }

        return $success;
    }

    /**
     * Синхронизировать visit_id для бронирований пользователя
     * Проверяет записи в YClients и обновляет visit_id если визит состоялся
     * 
     * @param int $userId ID пользователя
     * @return int Количество обновленных записей
     */
    public function syncVisitIds($userId) {
        global $yclients;
        
        // Получаем все неоплаченные бронирования без visit_id
        $stmt = $this->conn->prepare("SELECT * FROM bookings WHERE user_id = ? AND visit_id IS NULL AND paid = 0 AND record_id IS NOT NULL");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $bookings = [];
        while ($row = $result->fetch_assoc()) {
            $bookings[] = $row;
        }
        $stmt->close();

        $updated = 0;
        foreach ($bookings as $booking) {
            try {
                $recordDetails = $yclients->getRecordDetails($booking['record_id']);
                if ($recordDetails && isset($recordDetails['visit_id']) && $recordDetails['visit_id']) {
                    if ($this->updateVisitId($booking['id'], $recordDetails['visit_id'])) {
                        $updated++;
                    }
                }
            } catch (Exception $e) {
                error_log("Error syncing visit_id for booking {$booking['id']}: " . $e->getMessage());
            }
        }

        error_log("Synced visit_ids for user {$userId}: {$updated} bookings updated");
        return $updated;
    }

    /**
     * Получение бронирования по ID
     * 
     * @param int $bookingId ID бронирования
     * @return array|null Данные бронирования или null
     */
    public function getBookingById($bookingId) {
        $stmt = $this->conn->prepare("SELECT * FROM bookings WHERE id = ?");
        $stmt->bind_param("i", $bookingId);
        $stmt->execute();
        $result = $stmt->get_result();
        $booking = $result->fetch_assoc();
        $stmt->close();

        return $booking;
    }

    /**
     * Получение бронирования по активности
     * 
     * @param int $userId ID пользователя
     * @param int $activityId ID активности
     * @return array|null Данные бронирования или null
     */
    public function getBookingByActivity($userId, $activityId) {
        $stmt = $this->conn->prepare("SELECT * FROM bookings WHERE user_id = ? AND activity_id = ? LIMIT 1");
        $stmt->bind_param("ii", $userId, $activityId);
        $stmt->execute();
        $result = $stmt->get_result();
        $booking = $result->fetch_assoc();
        $stmt->close();

        return $booking;
    }

    /**
     * Получение всех бронирований пользователя
     * 
     * @param int $userId ID пользователя
     * @param int|null $paidStatus Статус оплаты (0 - не оплачено, 1 - оплачено, null - все)
     * @param int $limit Лимит записей
     * @return array Массив бронирований
     */
    public function getUserBookings($userId, $paidStatus = null, $limit = 50) {
        if ($paidStatus !== null) {
            $stmt = $this->conn->prepare("SELECT * FROM bookings WHERE user_id = ? AND paid = ? ORDER BY datetime DESC LIMIT ?");
            $stmt->bind_param("iii", $userId, $paidStatus, $limit);
        } else {
            $stmt = $this->conn->prepare("SELECT * FROM bookings WHERE user_id = ? ORDER BY datetime DESC LIMIT ?");
            $stmt->bind_param("ii", $userId, $limit);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $bookings = [];
        while ($row = $result->fetch_assoc()) {
            $bookings[] = $row;
        }
        $stmt->close();

        return $bookings;
    }

    /**
     * Получить неоплаченные бронирования
     * 
     * @param int $userId ID пользователя
     * @return array Массив неоплаченных бронирований
     */
    public function getUnpaidBookings($userId) {
        return $this->getUserBookings($userId, 0);
    }

    /**
     * Пометить бронирование как оплаченное
     * 
     * @param int $bookingId ID бронирования
     * @param int $userId ID пользователя (для проверки владельца)
     * @return bool Успех операции
     */
    public function markBookingAsPaid($bookingId, $userId) {
        // Проверяем что бронирование принадлежит пользователю
        $booking = $this->getBookingById($bookingId);
        if (!$booking || $booking['user_id'] != $userId) {
            error_log("Booking {$bookingId} not found or doesn't belong to user {$userId}");
            return false;
        }

        // Проверяем что бронирование еще не оплачено
        if ($booking['paid'] == 1) {
            error_log("Booking {$bookingId} is already paid");
            return false;
        }

        $stmt = $this->conn->prepare("UPDATE bookings SET paid = 1 WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $bookingId, $userId);
        $result = $stmt->execute();
        $stmt->close();

        if ($result) {
            error_log("Marked booking {$bookingId} as paid for user {$userId}");
        }

        return $result;
    }

    /**
     * Оплатить бронирование с карты лояльности
     * Оплата возможна только после посещения (когда visit_id заполнен)
     * 
     * @param int $bookingId ID бронирования
     * @param int $userId ID пользователя
     * @return array Результат операции ['success' => bool, 'message' => string, 'balance' => float]
     */
    public function payBooking($bookingId, $userId) {
        // Получаем бронирование
        $booking = $this->getBookingById($bookingId);
        if (!$booking) {
            return ['success' => false, 'message' => 'Бронирование не найдено'];
        }

        // Проверяем владельца
        if ($booking['user_id'] != $userId) {
            return ['success' => false, 'message' => 'Бронирование не принадлежит пользователю'];
        }

        // Проверяем статус оплаты
        if ($booking['paid'] == 1) {
            return ['success' => false, 'message' => 'Бронирование уже оплачено'];
        }

        // ВАЖНО: Проверяем наличие visit_id (визит должен состояться)
        if (empty($booking['visit_id'])) {
            return [
                'success' => false,
                'message' => 'Оплата возможна только после посещения занятия',
                'needs_visit' => true
            ];
        }

        // Получаем пользователя и карту лояльности
        require_once __DIR__ . '/user.php';
        $userAPI = new UserAPI();
        $user = $userAPI->getUserById($userId);
        
        if (!$user || !$user['yclients_client_id']) {
            return ['success' => false, 'message' => 'Пользователь не найден в YClients'];
        }

        // Получаем ID карты лояльности
        $cardId = $userAPI->getUserLoyaltyCardId($userId);
        if (!$cardId) {
            return ['success' => false, 'message' => 'У вас нет карты лояльности'];
        }

        // Проверяем баланс карты
        $cardBalance = $userAPI->getUserLoyaltyBalance($userId);
        $price = (float)$booking['service_price'];

        if ($cardBalance === null || $cardBalance < $price) {
            return [
                'success' => false,
                'message' => 'Недостаточно средств на карте',
                'required' => $price,
                'current' => $cardBalance ?? 0
            ];
        }

        // Оплачиваем визит через YClients API
        global $yclients;
        $description = 'Оплата: ' . $booking['service_title'];
        
        try {
            // Используем специальный метод для оплаты визита
            $payResult = $yclients->payVisitWithLoyaltyCard(
                $cardId,
                $booking['record_id'],
                $booking['visit_id'],
                $price
            );

            if (!$payResult) {
                return ['success' => false, 'message' => 'Ошибка оплаты визита в YClients'];
            }

            // Помечаем как оплаченное
            $markResult = $this->markBookingAsPaid($bookingId, $userId);

            if (!$markResult) {
                error_log("Failed to mark booking {$bookingId} as paid after successful YClients payment");
                return ['success' => false, 'message' => 'Оплата прошла, но статус не обновлен. Обратитесь к администратору.'];
            }

            // Добавляем запись в историю баланса
            require_once __DIR__ . '/balance.php';
            $balanceAPI = new BalanceAPI();
            $balanceAPI->addBalanceHistory($userId, -$price, $description);

            // Получаем новый баланс
            $newBalance = $userAPI->getUserLoyaltyBalance($userId);

            return [
                'success' => true,
                'message' => 'Занятие успешно оплачено',
                'balance' => $newBalance,
                'paid_amount' => $price
            ];

        } catch (Exception $e) {
            error_log("Payment error for booking {$bookingId}: " . $e->getMessage());
            return ['success' => false, 'message' => 'Ошибка оплаты: ' . $e->getMessage()];
        }
    }

    /**
     * Удалить бронирование
     * 
     * @param int $bookingId ID бронирования
     * @param int $userId ID пользователя
     * @return bool Успех операции
     */
    public function deleteBooking($bookingId, $userId) {
        // Проверяем что бронирование принадлежит пользователю
        $booking = $this->getBookingById($bookingId);
        if (!$booking || $booking['user_id'] != $userId) {
            return false;
        }

        $stmt = $this->conn->prepare("DELETE FROM bookings WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $bookingId, $userId);
        $result = $stmt->execute();
        $stmt->close();

        return $result;
    }

    /**
     * Удалить старые бронирования (прошедшие более N дней назад)
     * 
     * @param int $days Количество дней
     * @return int Количество удаленных записей
     */
    public function deleteOldBookings($days = 30) {
        $stmt = $this->conn->prepare("DELETE FROM bookings WHERE datetime < DATE_SUB(NOW(), INTERVAL ? DAY)");
        $stmt->bind_param("i", $days);
        $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();

        return $affected;
    }
}

// Handle API requests ONLY if this file is called directly, not included
if (basename($_SERVER['PHP_SELF']) === 'bookings.php') {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? '';
        
        // Проверка авторизации
        if (!isLoggedIn()) {
            http_response_code(401);
            jsonResponse(['success' => false, 'error' => 'Unauthorized']);
            exit;
        }

        $user = getCurrentUser();
        $bookingsAPI = new BookingsAPI();

        switch ($action) {
            case 'getUserBookings':
                $paidStatus = isset($_GET['paid']) ? (int)$_GET['paid'] : null;
                $bookings = $bookingsAPI->getUserBookings($user['id'], $paidStatus);
                jsonResponse(['success' => true, 'bookings' => $bookings]);
                break;

            case 'getUnpaidBookings':
                $bookings = $bookingsAPI->getUnpaidBookings($user['id']);
                jsonResponse(['success' => true, 'bookings' => $bookings]);
                break;

            case 'getBooking':
                if (isset($_GET['id'])) {
                    $booking = $bookingsAPI->getBookingById((int)$_GET['id']);
                    if ($booking && $booking['user_id'] == $user['id']) {
                        jsonResponse(['success' => true, 'booking' => $booking]);
                    } else {
                        jsonResponse(['success' => false, 'error' => 'Booking not found']);
                    }
                }
                break;

            default:
                jsonResponse(['success' => false, 'error' => 'Unknown action']);
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        // Проверка авторизации
        if (!isLoggedIn()) {
            http_response_code(401);
            jsonResponse(['success' => false, 'error' => 'Unauthorized']);
            exit;
        }

        $user = getCurrentUser();
        $bookingsAPI = new BookingsAPI();

        switch ($action) {
            case 'createBooking':
                if (isset($_POST['activity_id']) && isset($_POST['service_title']) && isset($_POST['service_price']) && isset($_POST['datetime'])) {
                    $bookingId = $bookingsAPI->createBooking(
                        $user['id'],
                        (int)$_POST['activity_id'],
                        isset($_POST['record_id']) ? (int)$_POST['record_id'] : null,
                        $_POST['service_title'],
                        (float)$_POST['service_price'],
                        $_POST['datetime']
                    );
                    jsonResponse(['success' => $bookingId !== false, 'booking_id' => $bookingId]);
                } else {
                    jsonResponse(['success' => false, 'error' => 'Missing required parameters']);
                }
                break;

            case 'payBooking':
                if (isset($_POST['booking_id'])) {
                    $result = $bookingsAPI->payBooking((int)$_POST['booking_id'], $user['id']);
                    jsonResponse($result);
                } else {
                    jsonResponse(['success' => false, 'error' => 'Missing booking_id']);
                }
                break;

            case 'deleteBooking':
                if (isset($_POST['booking_id'])) {
                    $result = $bookingsAPI->deleteBooking((int)$_POST['booking_id'], $user['id']);
                    jsonResponse(['success' => $result]);
                } else {
                    jsonResponse(['success' => false, 'error' => 'Missing booking_id']);
                }
                break;

            default:
                jsonResponse(['success' => false, 'error' => 'Unknown action']);
        }
    }
}
?>

