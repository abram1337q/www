<?php
// Настройка обработки ошибок
error_reporting(E_ALL);
ini_set('display_errors', 0); // Не выводим ошибки на экран (только в лог)
ini_set('log_errors', 1);

// Логируем начало выполнения
error_log("=== T-Kassa API called at " . date('Y-m-d H:i:s') . " ===");
error_log("Request URI: " . $_SERVER['REQUEST_URI']);
error_log("GET params: " . print_r($_GET, true));

// Подключаем файлы с обработкой ошибок (config.php уже запускает сессию)
try {
    require_once __DIR__ . '/config.php';
    error_log("config.php loaded");
} catch (Exception $e) {
    error_log("Failed to load config.php: " . $e->getMessage());
    die("Configuration error");
}

try {
    require_once __DIR__ . '/database.php';
    error_log("database.php loaded");
} catch (Exception $e) {
    error_log("Failed to load database.php: " . $e->getMessage());
}

try {
    require_once __DIR__ . '/orders.php';
    error_log("orders.php loaded");
} catch (Exception $e) {
    error_log("Failed to load orders.php: " . $e->getMessage());
}

try {
    require_once __DIR__ . '/balance.php';
    error_log("balance.php loaded");
} catch (Exception $e) {
    error_log("Failed to load balance.php: " . $e->getMessage());
}

class TKassaAPI {
    private $terminalId;
    private $password;
    private $merchantName;
    private $merchantId;
    private $terminalIdNumeric;
    private $sbpMerchantId;
    private $token;

    public function __construct() {
        $this->terminalId = TKASSA_TERMINAL;
        $this->password = TKASSA_PASSWORD;
        $this->merchantName = TKASSA_MERCHANT_NAME;
        $this->merchantId = TKASSA_MERCHANT_ID;
        $this->terminalIdNumeric = TKASSA_TERMINAL_ID;
        $this->sbpMerchantId = TKASSA_SBP_MERCHANT_ID;
        $this->token = TKASSA_TOKEN ?? ''; // Токен для аутентификации (если требуется)
    }

    /**
     * Генерация токена для Tinkoff API согласно документации
     * https://www.tinkoff.ru/kassa/develop/api/payments/init-request/
     */
    private function generateToken($params) {
        // Добавляем пароль в параметры
        $params['Password'] = $this->password;

        // Сортируем по ключам в алфавитном порядке
        ksort($params);

        // Конкатенируем только значения в одну строку
        $tokenString = '';
        foreach ($params as $value) {
            $tokenString .= $value;
        }

        // Вычисляем SHA-256 хэш
        return hash('sha256', $tokenString);
    }

    /**
     * Создание платежа через T-Kassa API (Tinkoff)
     */
    public function createPayment($amount, $orderId, $description = 'Пополнение баланса', $successUrl = '', $failUrl = '', $notificationUrl = '') {
        // Базовый URL для Tinkoff API
        $apiUrl = 'https://securepay.tinkoff.ru/v2/';

        // Подготовка данных для запроса согласно документации T-Bank API v2
        $data = [
            'TerminalKey' => $this->terminalId,
            'Amount' => $amount * 100, // Сумма в копейках
            'OrderId' => $orderId,
            'Description' => $description
        ];

        // Добавляем опциональные параметры
        if (!empty($successUrl)) {
            $data['SuccessURL'] = $successUrl;
        }
        if (!empty($failUrl)) {
            $data['FailURL'] = $failUrl;
        }
        if (!empty($notificationUrl)) {
            $data['NotificationURL'] = $notificationUrl;
        }
        
        $data['PayType'] = 'O'; // O - одностадийная оплата, T - двухстадийная

        // Генерируем токен согласно алгоритму Tinkoff
        $token = $this->generateToken($data);
        $data['Token'] = $token;

        error_log('T-Kassa request data: ' . print_r($data, true));

        // Инициализация cURL для JSON API
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl . 'Init');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            error_log('T-Kassa API Error: HTTP ' . $httpCode . ' - ' . $response);
            return false;
        }

        $result = json_decode($response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('T-Kassa API JSON Error: ' . json_last_error_msg() . ' - ' . $response);
            return false;
        }

        // Логируем ответ T-Kassa для отладки
        error_log('T-Kassa API Response: ' . print_r($result, true));

        // Проверяем успешность запроса
        if (!isset($result['Success']) || !$result['Success']) {
            error_log('T-Kassa API Payment Creation Failed: ' . print_r($result, true));
            return false;
        }

        // Получаем платежную ссылку согласно документации T-Bank API v2
        $paymentUrl = $result['PaymentURL'] ?? null;

        return [
            'paymentId' => $result['PaymentId'] ?? $orderId,
            'paymentUrl' => $paymentUrl,
            'success' => true,
            'raw_response' => $result // Для отладки
        ];
    }

    /**
     * Получение статуса платежа по PaymentId
     * @param string $paymentId - PaymentId из T-Kassa (не OrderId!)
     */
    public function getPaymentStatus($paymentId) {
        $apiUrl = 'https://securepay.tinkoff.ru/v2/';

        $data = [
            'TerminalKey' => $this->terminalId,
            'PaymentId' => $paymentId  // Используем PaymentId!
        ];

        error_log("T-Kassa GetState request for PaymentId: $paymentId");

        // Генерируем токен для запроса статуса
        $token = $this->generateToken($data);
        $data['Token'] = $token;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl . 'GetState');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        error_log("T-Kassa GetState response (HTTP $httpCode): $response");

        if ($httpCode !== 200) {
            error_log('T-Kassa GetState API Error: HTTP ' . $httpCode . ' - ' . $response);
            return false;
        }

        $result = json_decode($response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('T-Kassa GetState API JSON Error: ' . json_last_error_msg() . ' - ' . $response);
            return false;
        }

        error_log('T-Kassa GetState parsed result: ' . print_r($result, true));

        return $result;
    }

    /**
     * Генерация уникального номера заказа
     */
    public function generateOrderId($userId) {
        return time() . $userId . rand(100, 999);
    }

    /**
     * Валидация суммы платежа
     */
    public function validateAmount($amount) {
        return is_numeric($amount) && $amount > 0 && $amount <= 100000;
    }
}

// Обработчик API запросов для T-Kassa
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    error_log("Processing GET request");
    
    // Поддержка обоих форматов: action=create_payment или create_payment=1
    $action = $_GET['action'] ?? '';
    if (isset($_GET['create_payment'])) {
        $action = 'create_payment';
    }
    
    error_log("Action determined: '$action'");

    $tkassaAPI = new TKassaAPI();
    error_log("TKassaAPI instance created");

    switch ($action) {
        case 'create_payment':
            error_log('=== CASE create_payment START ===');
            error_log('T-Kassa create_payment called with GET params: ' . print_r($_GET, true));
            
            if (isset($_GET['amount']) && isset($_GET['user_id'])) {
                $amount = (float)$_GET['amount'];
                $userId = (int)$_GET['user_id'];
                $description = $_GET['description'] ?? 'Пополнение баланса фитнес-клуба';
                error_log("Creating payment: amount=$amount, user_id=$userId, description=$description");

                if (!$tkassaAPI->validateAmount($amount)) {
                    $error = 'Неверная сумма платежа';
                    $referer = $_SERVER['HTTP_REFERER'] ?? '../balance.php';
                    $baseUrl = dirname($referer);
                    header('Location: ' . $baseUrl . '?error=' . urlencode($error));
                    exit;
                }

                $orderId = $tkassaAPI->generateOrderId($userId);
                
                // Формируем Telegram deep links вместо старых URL
                $botUsername = TELEGRAM_BOT_USERNAME; // relight_dev_test_bot
                $successUrl = "https://t.me/{$botUsername}?start=payment_success_{$orderId}";
                $failUrl = "https://t.me/{$botUsername}?start=payment_failed_{$orderId}";
                
                // NotificationURL для webhook
                $baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                $notificationUrl = $baseUrl . '/frontend/webhook_tkassa.php';

                error_log("Calling createPayment with orderId=$orderId, successUrl=$successUrl, failUrl=$failUrl");
                $payment = $tkassaAPI->createPayment($amount, $orderId, $description, $successUrl, $failUrl, $notificationUrl);

                error_log('Payment creation result: ' . print_r($payment, true));

                if ($payment && $payment['success']) {
                    // Сохраняем заказ в базу данных
                    try {
                        $ordersAPI = new OrdersAPI();
                        $orderData = [
                            'user_id' => $userId,
                            'order_id' => $orderId,
                            'amount' => $amount,
                            'status' => 'pending',
                            'payment_method' => 'tkassa',
                            'description' => $description,
                            'payment_id' => $payment['paymentId'] ?? null  // Исправлено: paymentId вместо payment_id
                        ];
                        $ordersAPI->createOrder($orderData);
                        error_log("Order saved to database: orderId=$orderId, amount=$amount, paymentId=" . ($payment['paymentId'] ?? 'NULL'));
                    } catch (Exception $e) {
                        error_log("Failed to save order to database: " . $e->getMessage());
                    }

                    $paymentUrl = $payment['paymentUrl'];
                    error_log("Payment URL received: $paymentUrl");

                    if (empty($paymentUrl)) {
                        error_log('Payment URL is empty! Raw response: ' . print_r($payment['raw_response'], true));
                        $error = 'Ошибка создания платежа: пустая ссылка на оплату. Проверьте настройки терминала.';
                        $referer = $_SERVER['HTTP_REFERER'] ?? '../balance.php';
                        $baseUrl = dirname($referer);
                        header('Location: ' . $baseUrl . '?error=' . urlencode($error));
                        exit;
                    }

                    // Сохраняем информацию о платеже в сессии для отслеживания
                    $_SESSION['tkassa_payment_' . $orderId] = [
                        'order_id' => $orderId,
                        'amount' => $amount,
                        'user_id' => $userId,
                        'created_at' => time()
                    ];

                    error_log("Redirecting to payment URL: $paymentUrl");
                    // Редиректим на страницу оплаты T-Kassa
                    header('Location: ' . $paymentUrl);
                    exit;
                } else {
                    error_log('Payment creation failed: ' . print_r($payment, true));
                    $error = 'Ошибка создания платежа. Пожалуйста, попробуйте еще раз.';
                    $referer = $_SERVER['HTTP_REFERER'] ?? '../balance.php';
                    $baseUrl = dirname($referer);
                    header('Location: ' . $baseUrl . '?error=' . urlencode($error));
                    exit;
                }
            }
            break;

        case 'check_payment':
            if (isset($_GET['order_id'])) {
                $orderId = $_GET['order_id'];
                $status = $tkassaAPI->getPaymentStatus($orderId);

                if ($status) {
                    jsonResponse([
                        'success' => true,
                        'status' => $status['Status'] ?? 'unknown',
                        'amount' => $status['Amount'] ?? 0
                    ]);
                } else {
                    jsonResponse(['success' => false, 'error' => 'Ошибка получения статуса платежа']);
                }
            }
            break;
    }
}
?>
