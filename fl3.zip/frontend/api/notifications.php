<?php
require_once 'config.php';
require_once 'database.php';

class NotificationsAPI {
    private $conn;
    private $database;

    public function __construct() {
        $this->conn = getDbConnection();
        // Database will be created lazily to avoid circular dependencies
    }

    /**
     * Get Database instance (lazy initialization)
     */
    private function getDatabase() {
        if (!$this->database) {
            require_once 'database.php';
            $this->database = new Database();
        }
        return $this->database;
    }

    /**
     * Убеждаемся, что необходимые таблицы существуют
     */
    private function ensureTablesExist() {
        $this->getDatabase()->createUsersTable();
        $this->getDatabase()->createNotificationsTable();
    }

    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }

    /**
     * Получить уведомления пользователя
     */
    public function getUserNotifications($userId) {
        $stmt = $this->conn->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $notifications = [];
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }
        $stmt->close();

        // If no notifications in database, return mock data
        if (empty($notifications)) {
            return [
                [
                    'id' => 1,
                    'title' => 'Новая тренировка',
                    'text' => 'Завтра в 10:00 у вас тренировка Yoga',
                    'is_read' => false,
                    'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))
                ],
                [
                    'id' => 2,
                    'title' => 'Специальное предложение',
                    'text' => 'Скидка 20% на абонемент Full при покупке до конца недели',
                    'is_read' => false,
                    'created_at' => date('Y-m-d H:i:s', strtotime('-3 days'))
                ],
                [
                    'id' => 3,
                    'title' => 'Изменение в расписании',
                    'text' => 'Тренировка Cycle перенесена на 15:00',
                    'is_read' => true,
                    'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))
                ]
            ];
        }

        return $notifications;
    }

    /**
     * Отметить уведомление как прочитанное
     */
    public function markNotificationAsRead($notificationId) {
        $stmt = $this->conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
        $stmt->bind_param("i", $notificationId);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
    }

    /**
     * Добавить новое уведомление
     */
    public function addNotification($userId, $title, $text) {
        $stmt = $this->conn->prepare("INSERT INTO notifications (user_id, title, text) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $userId, $title, $text);
        $result = $stmt->execute();
        $notificationId = $stmt->insert_id;
        $stmt->close();
        return $notificationId;
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';

    $notificationsAPI = new NotificationsAPI();

    switch ($action) {
        case 'getUserNotifications':
            if (isset($_GET['user_id'])) {
                $notifications = $notificationsAPI->getUserNotifications((int)$_GET['user_id']);
                jsonResponse($notifications);
            }
            break;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    $notificationsAPI = new NotificationsAPI();

    switch ($action) {
        case 'markAsRead':
            if (isset($_POST['notification_id'])) {
                $result = $notificationsAPI->markNotificationAsRead((int)$_POST['notification_id']);
                jsonResponse(['success' => $result]);
            }
            break;

        case 'add':
            if (isset($_POST['user_id']) && isset($_POST['title']) && isset($_POST['text'])) {
                $notificationId = $notificationsAPI->addNotification(
                    (int)$_POST['user_id'],
                    $_POST['title'],
                    $_POST['text']
                );
                jsonResponse(['success' => true, 'notification_id' => $notificationId]);
            }
            break;
    }
}
?>
