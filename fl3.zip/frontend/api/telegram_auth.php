<?php
require_once 'config.php';

/**
 * Класс для работы с Telegram Mini App авторизацией
 */
class TelegramAuth {
    
    /**
     * Валидация initData от Telegram
     * 
     * @param string $initData - строка initData от Telegram WebApp
     * @param string $botToken - токен бота Telegram
     * @return bool - true если данные валидны
     */
    public static function validateInitData($initData, $botToken) {
        if (empty($initData)) {
            return false;
        }

        // Парсим данные
        parse_str($initData, $data);
        
        if (!isset($data['hash'])) {
            return false;
        }
        
        $checkHash = $data['hash'];
        unset($data['hash']);
        
        // Сортируем данные и создаем строку для проверки
        ksort($data);
        $dataCheckArray = [];
        foreach ($data as $key => $value) {
            $dataCheckArray[] = $key . '=' . $value;
        }
        $dataCheckString = implode("\n", $dataCheckArray);
        
        // Создаем секретный ключ
        $secretKey = hash_hmac('sha256', $botToken, 'WebAppData', true);
        
        // Вычисляем хеш
        $hash = bin2hex(hash_hmac('sha256', $dataCheckString, $secretKey, true));
        
        // Сравниваем хеши
        return hash_equals($hash, $checkHash);
    }
    
    /**
     * Извлечение данных пользователя из initData
     * 
     * @param string $initData - строка initData от Telegram WebApp
     * @return array|null - массив с данными пользователя или null
     */
    public static function extractUserData($initData) {
        if (empty($initData)) {
            return null;
        }
        
        parse_str($initData, $data);
        
        if (!isset($data['user'])) {
            return null;
        }
        
        $userData = json_decode($data['user'], true);
        
        if (!$userData || !isset($userData['id'])) {
            return null;
        }
        
        return [
            'telegram_id' => $userData['id'],
            'first_name' => $userData['first_name'] ?? '',
            'last_name' => $userData['last_name'] ?? '',
            'username' => $userData['username'] ?? '',
            'language_code' => $userData['language_code'] ?? 'ru',
            'photo_url' => $userData['photo_url'] ?? '',
            'auth_date' => $data['auth_date'] ?? time()
        ];
    }
    
    /**
     * Авторизация пользователя через Telegram initData
     * Создает пользователя если не существует, иначе обновляет данные
     * 
     * @param string $initData - строка initData от Telegram WebApp
     * @return array|null - данные пользователя или null если ошибка
     */
    public static function authenticateUser($initData) {
        error_log('=== Telegram Auth Start ===');
        error_log('InitData received: ' . substr($initData, 0, 100) . '...');
        
        // Валидация данных
        if (!self::validateInitData($initData, TELEGRAM_BOT_TOKEN)) {
            error_log('❌ Telegram initData validation FAILED');
            error_log('Bot Token: ' . substr(TELEGRAM_BOT_TOKEN, 0, 10) . '...');
            return null;
        }
        
        error_log(' InitData validation SUCCESS');
        
        // Извлечение данных пользователя
        $userData = self::extractUserData($initData);
        
        if (!$userData) {
            error_log('❌ Failed to extract user data from initData');
            return null;
        }
        
        error_log(' User data extracted: ' . json_encode($userData));
        
        // Проверяем существует ли пользователь
        $existingUser = getUserByTelegramId($userData['telegram_id']);
        
        if ($existingUser) {
            error_log(' Existing user found: ID=' . $existingUser['id']);
            // Если у пользователя нет yclients_client_id, попробуем найти по телефону
            if (empty($existingUser['yclients_client_id']) && !empty($existingUser['phone'])) {
                global $yclients;
                $yclientsClient = $yclients->findClientByPhone($existingUser['phone']);
                if ($yclientsClient) {
                    $existingUser['yclients_client_id'] = $yclientsClient['id'];
                    updateUser($existingUser['id'], ['yclients_client_id' => $yclientsClient['id']]);
                    error_log(' Found and linked YClients client ID: ' . $yclientsClient['id']);
                }
            }

            // Обновляем данные пользователя
            $updatedUser = updateUser($existingUser['id'], [
                'first_name' => $userData['first_name'],
                'last_name' => $userData['last_name'],
                'username' => $userData['username'],
                'photo_url' => $userData['photo_url']
            ]);
            
            // Устанавливаем сессию
            login($existingUser['id']);
            error_log(' Session set for user ID: ' . $existingUser['id']);
            
            return $updatedUser;
        } else {
            error_log('ℹ️ New user, creating...');
            
            // Создаем нового пользователя
            $newUserData = [
                'telegram_id' => $userData['telegram_id'],
                'first_name' => $userData['first_name'],
                'last_name' => $userData['last_name'],
                'username' => $userData['username'],
                'phone' => '',
                'photo_url' => $userData['photo_url'],
                'balance' => 0
            ];
            
            error_log('Creating user with data: ' . json_encode($newUserData));
            
            $newUser = createUser($newUserData);
            
            if ($newUser) {
                error_log(' User created: ID=' . $newUser['id']);
                
                // Устанавливаем сессию
                login($newUser['id']);
                error_log(' Session set for new user ID: ' . $newUser['id']);
                
                // Создаем приветственное уведомление
                try {
                    addNotification(
                        $newUser['id'],
                        'Добро пожаловать!',
                        'Спасибо за регистрацию в нашем фитнес-клубе!'
                    );
                } catch (Exception $e) {
                    error_log('Warning: Failed to create notification: ' . $e->getMessage());
                }
                
                return $newUser;
            } else {
                error_log('❌ Failed to create user in database');
            }
            
            return null;
        }
    }
    
    /**
     * Проверка что запрос идет из Telegram Mini App
     * 
     * @return bool
     */
    public static function isTelegramWebApp() {
        // Проверяем наличие специальных заголовков или параметров
        return isset($_GET['tgWebAppData']) || 
               isset($_POST['tgWebAppData']) ||
               isset($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN']);
    }
}

// Обработка AJAX запросов на авторизацию
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'telegram_auth') {
    header('Content-Type: application/json');
    
    $initData = $_POST['initData'] ?? '';
    
    if (empty($initData)) {
        echo json_encode([
            'success' => false,
            'error' => 'InitData is required'
        ]);
        exit;
    }
    
    $user = TelegramAuth::authenticateUser($initData);
    
    if ($user) {
        echo json_encode([
            'success' => true,
            'user' => $user
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Authentication failed'
        ]);
    }
    exit;
}
?>

