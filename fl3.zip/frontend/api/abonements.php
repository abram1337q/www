<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/user.php';
require_once __DIR__ . '/balance.php';

class AbonementsAPI {
    private $conn;
    private $database;
    private $userAPI;
    private $balanceAPI;

    public function __construct() {
        $this->database = new Database();
        $this->conn = $this->database->getConnection();
        $this->userAPI = new UserAPI();
        $this->balanceAPI = new BalanceAPI();
    }

    /**
     * Купить абонемент (списывает с карты-кошелька, создает запись в локальной БД)
     *
     * @param int $userId ID пользователя
     * @param string $abonementType 'single' или 'monthly'
     * @return array Результат операции
     */
    public function purchaseAbonement($userId, $abonementType) {
        global $yclients;
        
        $user = $this->userAPI->getUserById($userId);
        
        if (!$user || !$user['yclients_client_id']) {
            return ['success' => false, 'message' => 'Пользователь не найден в YClients'];
        }
        
        // Определяем цену, баланс визитов и срок действия
        if ($abonementType === 'single') {
            $price = ABONEMENT_SINGLE_PRICE;
            $visits = ABONEMENT_SINGLE_VISITS;
            $expiresAt = null;
            $typeName = 'Разовое посещение';
        } elseif ($abonementType === 'monthly') {
            $price = ABONEMENT_MONTHLY_PRICE;
            $visits = ABONEMENT_MONTHLY_VISITS;
            $expiresAt = date('Y-m-d H:i:s', strtotime('+' . ABONEMENT_MONTHLY_DAYS . ' days'));
            $typeName = 'Месячный абонемент';
        } else {
            return ['success' => false, 'message' => 'Неверный тип абонемента'];
        }
        
        // Проверяем баланс карты-кошелька
        $balance = $this->userAPI->getUserLoyaltyBalance($userId);
        if ($balance === null || $balance < $price) {
            return [
                'success' => false,
                'message' => 'Недостаточно средств на балансе',
                'required' => $price,
                'current' => $balance ?? 0
            ];
        }
        
        // Проверяем нет ли уже активного абонемента этого типа
        $existingAbonement = $this->getActiveAbonement($userId, $abonementType);
        if ($existingAbonement) {
            return [
                'success' => false,
                'message' => 'У вас уже есть активный абонемент этого типа'
            ];
        }
        
        try {
            // Списываем с карты-кошелька
            $walletCardId = $this->userAPI->getUserLoyaltyCardId($userId);
            if (!$walletCardId) {
                return ['success' => false, 'message' => 'Карта лояльности не найдена'];
            }
            
            $deductResult = $yclients->modifyLoyaltyCardBalance(
                $walletCardId,
                -$price,
                'Покупка: ' . $typeName
            );
            
            if (!$deductResult) {
                return ['success' => false, 'message' => 'Ошибка списания средств'];
            }
            
            // Создаем запись об абонементе в локальной БД
            $stmt = $this->conn->prepare(
                "INSERT INTO user_abonements (user_id, abonement_type, balance, expires_at, is_active) 
                 VALUES (?, ?, ?, ?, TRUE)"
            );
            $stmt->bind_param("isis", $userId, $abonementType, $visits, $expiresAt);
            $createResult = $stmt->execute();
            $abonementId = $stmt->insert_id;
            $stmt->close();
            
            if (!$createResult) {
                // Откатываем списание
                $yclients->modifyLoyaltyCardBalance($walletCardId, $price, 'Отмена: ' . $typeName);
                return ['success' => false, 'message' => 'Ошибка создания абонемента'];
            }
            
            // Сохраняем в историю баланса
            $this->balanceAPI->addBalanceHistory($userId, -$price, 'Покупка: ' . $typeName);
            
            error_log("User {$userId} purchased abonement {$typeName}, abonement ID: {$abonementId}");
            
            // Получаем созданный абонемент
            $abonement = $this->getAbonementById($abonementId);
            
            return [
                'success' => true,
                'message' => 'Абонемент успешно приобретен',
                'abonement' => $abonement,
                'new_balance' => $balance - $price,
                'type' => $abonementType
            ];
            
        } catch (Exception $e) {
            error_log("Abonement purchase error for user {$userId}: " . $e->getMessage());
            // Попытка отката
            if (isset($deductResult) && $deductResult && isset($walletCardId)) {
                $yclients->modifyLoyaltyCardBalance($walletCardId, $price, 'Отмена (ошибка): ' . $typeName);
            }
            return ['success' => false, 'message' => 'Ошибка покупки: ' . $e->getMessage()];
        }
    }

    /**
     * Получить абонемент по ID
     *
     * @param int $abonementId ID абонемента
     * @return array|null Абонемент или null
     */
    public function getAbonementById($abonementId) {
        $stmt = $this->conn->prepare(
            "SELECT * FROM user_abonements WHERE id = ?"
        );
        $stmt->bind_param("i", $abonementId);
        $stmt->execute();
        $result = $stmt->get_result();
        $abonement = $result->fetch_assoc();
        $stmt->close();
        
        if ($abonement) {
            $abonement = $this->enrichAbonementData($abonement);
        }
        
        return $abonement;
    }

    /**
     * Получить активный абонемент пользователя
     *
     * @param int $userId ID пользователя
     * @param string|null $abonementType Тип абонемента или null для любого
     * @return array|null Активный абонемент или null
     */
    public function getActiveAbonement($userId, $abonementType = null) {
        $sql = "SELECT * FROM user_abonements 
                WHERE user_id = ? 
                AND is_active = TRUE 
                AND balance > 0 
                AND (expires_at IS NULL OR expires_at > NOW())";
        
        if ($abonementType) {
            $sql .= " AND abonement_type = ?";
        }
        
        $sql .= " ORDER BY purchased_at DESC LIMIT 1";
        
        $stmt = $this->conn->prepare($sql);
        
        if ($abonementType) {
            $stmt->bind_param("is", $userId, $abonementType);
        } else {
            $stmt->bind_param("i", $userId);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $abonement = $result->fetch_assoc();
        $stmt->close();
        
        if ($abonement) {
            $abonement = $this->enrichAbonementData($abonement);
        }
        
        return $abonement;
    }

    /**
     * Получить все абонементы пользователя
     *
     * @param int $userId ID пользователя
     * @return array Массив абонементов
     */
    public function getUserAbonements($userId) {
        $stmt = $this->conn->prepare(
            "SELECT * FROM user_abonements 
             WHERE user_id = ? 
             ORDER BY is_active DESC, purchased_at DESC"
        );
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $abonements = [];
        while ($row = $result->fetch_assoc()) {
            $abonements[] = $this->enrichAbonementData($row);
        }
        
        $stmt->close();
        return $abonements;
    }

    /**
     * Обогатить данные абонемента
     *
     * @param array $abonement Абонемент из БД
     * @return array Обогащенный абонемент
     */
    private function enrichAbonementData($abonement) {
        $type = $abonement['abonement_type'];
        
        if ($type === 'single') {
            $abonement['type_name'] = 'Разовое посещение';
        } elseif ($type === 'monthly') {
            $abonement['type_name'] = 'Месячный абонемент';
        }
        
        // Проверяем активность
        $isExpired = $abonement['expires_at'] && strtotime($abonement['expires_at']) < time();
        $abonement['is_actually_active'] = $abonement['is_active'] && $abonement['balance'] > 0 && !$isExpired;
        
        return $abonement;
    }

    /**
     * Проверить можно ли записаться на тренировку
     *
     * @param int $userId ID пользователя
     * @return array Результат проверки
     */
    public function canBookTraining($userId) {
        $user = $this->userAPI->getUserById($userId);
        
        if (!$user || !$user['yclients_client_id']) {
            return [
                'can_book' => false,
                'reason' => 'Пользователь не найден в YClients'
            ];
        }
        
        try {
            // Проверяем наличие активных абонементов (любого типа)
            $activeAbonement = $this->getActiveAbonement($userId);
            
            if ($activeAbonement && $activeAbonement['is_actually_active']) {
                return [
                    'can_book' => true,
                    'abonement' => $activeAbonement,
                    'abonement_type' => $activeAbonement['abonement_type'],
                    'type_name' => $activeAbonement['type_name']
                ];
            }
            
            return [
                'can_book' => false,
                'reason' => 'Для записи необходимо купить абонемент'
            ];
            
        } catch (Exception $e) {
            error_log("Error checking can book for user {$userId}: " . $e->getMessage());
            return [
                'can_book' => false,
                'reason' => 'Ошибка проверки абонемента'
            ];
        }
    }

    /**
     * Списать посещение с абонемента
     *
     * @param int $userId ID пользователя
     * @param int $recordId ID записи в YClients (для логирования)
     * @return array Результат операции
     */
    public function deductVisit($userId, $recordId = null) {
        // Получаем активный абонемент
        $abonement = $this->getActiveAbonement($userId);
        
        if (!$abonement || !$abonement['is_actually_active']) {
            return [
                'success' => false,
                'message' => 'Нет активного абонемента'
            ];
        }
        
        // Списываем 1 визит
        $stmt = $this->conn->prepare(
            "UPDATE user_abonements 
             SET balance = balance - 1 
             WHERE id = ? AND balance > 0"
        );
        $stmt->bind_param("i", $abonement['id']);
        $success = $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();
        
        if ($success && $affected > 0) {
            error_log("Deducted 1 visit from abonement {$abonement['id']} for user {$userId}, record {$recordId}");
            return [
                'success' => true,
                'message' => 'Визит списан с абонемента',
                'remaining_balance' => $abonement['balance'] - 1
            ];
        }
        
        return [
            'success' => false,
            'message' => 'Не удалось списать визит'
        ];
    }
}

// API handler
if (basename($_SERVER['PHP_SELF']) === 'abonements.php') {
    require_once __DIR__ . '/../components/telegram_init.php';
    require_once __DIR__ . '/database.php';

    if (!isLoggedIn()) {
        http_response_code(401);
        jsonResponse(['success' => false, 'error' => 'Unauthorized']);
        exit;
    }

    $user = getCurrentUser();
    $abonementsAPI = new AbonementsAPI();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';

        switch ($action) {
            case 'purchase':
                $abonementType = $_POST['abonement_type'] ?? '';
                $result = $abonementsAPI->purchaseAbonement($user['id'], $abonementType);
                jsonResponse($result);
                break;
            default:
                jsonResponse(['success' => false, 'error' => 'Unknown action']);
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? '';

        switch ($action) {
            case 'getUserAbonements':
                $abonements = $abonementsAPI->getUserAbonements($user['id']);
                jsonResponse(['success' => true, 'abonements' => $abonements]);
                break;
            case 'canBookTraining':
                $result = $abonementsAPI->canBookTraining($user['id']);
                jsonResponse(['success' => true, 'can_book' => $result['can_book'], 'reason' => $result['reason'] ?? '']);
                break;
            default:
                jsonResponse(['success' => false, 'error' => 'Unknown action']);
        }
    }
}
?>
