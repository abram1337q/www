<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/user.php';
require_once __DIR__ . '/balance.php';

class ProductAbonementsAPI {
    private $conn;
    private $database;
    private $userAPI;
    private $balanceAPI;

    public function __construct() {
        $this->database = new Database();
        $this->conn = $this->database->getConnection();
        $this->userAPI = new UserAPI();
        $this->balanceAPI = new BalanceAPI();
    }

    /**
     * Извлечь количество штук из товара
     * Парсит название и описание товара для определения количества
     * 
     * @param array $product Товар из YClients API
     * @return int Количество штук (по умолчанию 1)
     */
    private function extractQuantityFromProduct($product) {
        $title = $product['title'] ?? '';
        $description = $product['description'] ?? $product['comment'] ?? '';
        
        // Паттерны для поиска количества
        $patterns = [
            '/(\d+)\s*шт/ui',           // "10 шт", "5шт"
            '/(\d+)\s*штук/ui',         // "10 штук"
            '/(\d+)\s*батончик/ui',     // "10 батончиков"
            '/(\d+)\s*напитк/ui',       // "5 напитков"
            '/(\d+)\s*x\s*/ui',         // "10 x"
            '/абонемент.*?(\d+)/ui',    // "Абонемент 10"
        ];
        
        // Проверяем название
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $title, $matches)) {
                $quantity = (int)$matches[1];
                if ($quantity > 0 && $quantity <= 1000) { // Разумный лимит
                    error_log("Extracted quantity {$quantity} from title: {$title}");
                    return $quantity;
                }
            }
        }
        
        // Проверяем описание
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $description, $matches)) {
                $quantity = (int)$matches[1];
                if ($quantity > 0 && $quantity <= 1000) {
                    error_log("Extracted quantity {$quantity} from description: {$description}");
                    return $quantity;
                }
            }
        }
        
        // По умолчанию 1 штука
        error_log("No quantity found in product, defaulting to 1: {$title}");
        return 1;
    }

    /**
     * Найти существующую карту товарного абонемента
     * 
     * @param int $userId ID пользователя
     * @param int $abonementTypeId ID типа абонемента из YClients
     * @return array|null Данные абонемента или null
     */
    private function findExistingCard($userId, $abonementTypeId) {
        $stmt = $this->conn->prepare(
            "SELECT * FROM user_product_abonements 
             WHERE user_id = ? AND abonement_type_id = ? AND is_active = TRUE"
        );
        $stmt->bind_param("ii", $userId, $abonementTypeId);
        $stmt->execute();
        $result = $stmt->get_result();
        $card = $result->fetch_assoc();
        $stmt->close();
        
        return $card ?: null;
    }

    /**
     * Купить товарный абонемент (или пополнить существующий)
     * 
     * @param int $userId ID пользователя
     * @param int $productId ID товара из YClients
     * @return array Результат операции
     */
    public function purchaseProductAbonement($userId, $productId) {
        global $yclients;
        
        $user = $this->userAPI->getUserById($userId);
        
        if (!$user || !$user['yclients_client_id']) {
            return ['success' => false, 'message' => 'Пользователь не найден в YClients'];
        }
        
        // Получить товар из YClients API
        $shopData = getShopItems('all', 1, 100);
        $product = null;
        
        foreach ($shopData['items'] as $item) {
            if ($item['id'] == $productId) {
                $product = $item;
                break;
            }
        }
        
        if (!$product) {
            return ['success' => false, 'message' => 'Товар не найден'];
        }
        
        // Получить полные данные товара из YClients (включая loyalty_abonement_type_id)
        $fullProduct = $this->getFullProductData($productId);
        
        if (!$fullProduct || empty($fullProduct['loyalty_abonement_type_id'])) {
            return ['success' => false, 'message' => 'Товар не является абонементом'];
        }
        
        $typeId = $fullProduct['loyalty_abonement_type_id'];
        $price = $product['price'];
        $quantity = $this->extractQuantityFromProduct($fullProduct);
        $typeName = $product['title'];
        
        // Проверить баланс кошелька
        $balance = $this->userAPI->getUserLoyaltyBalance($userId);
        if ($balance === null || $balance < $price) {
            return [
                'success' => false,
                'message' => 'Недостаточно средств на балансе',
                'required' => $price,
                'current' => $balance ?? 0
            ];
        }
        
        try {
            // Найти существующую карту
            $existingCard = $this->findExistingCard($userId, $typeId);
            
            if ($existingCard) {
                // Пополнить существующую карту
                error_log("Found existing card {$existingCard['yclients_card_id']} for user {$userId}, type {$typeId}");
                
                $result = $yclients->modifyLoyaltyCardBalance(
                    $existingCard['yclients_card_id'],
                    $quantity,  // Пополнить на +N штук
                    "Докупка: {$typeName}"
                );
                
                if (!$result) {
                    return ['success' => false, 'message' => 'Ошибка пополнения абонемента в YClients'];
                }
                
                // Обновить баланс в локальной БД
                $stmt = $this->conn->prepare(
                    "UPDATE user_product_abonements 
                     SET balance = balance + ?, last_synced_at = NOW()
                     WHERE id = ?"
                );
                $stmt->bind_param("ii", $quantity, $existingCard['id']);
                $stmt->execute();
                $stmt->close();
                
                $newBalance = $existingCard['balance'] + $quantity;
                $abonementId = $existingCard['id'];
                
            } else {
                // Создать новую карту абонемента
                error_log("Creating new card for user {$userId}, type {$typeId}");
                
                $cardData = $yclients->createLoyaltyCard($typeId, $user['phone']);
                
                if (!$cardData || !isset($cardData['id'])) {
                    return ['success' => false, 'message' => 'Ошибка создания карты абонемента в YClients'];
                }
                
                $yClientsCardId = $cardData['id'];
                
                // Пополнить новую карту на N штук
                $result = $yclients->modifyLoyaltyCardBalance(
                    $yClientsCardId,
                    $quantity,
                    "Покупка: {$typeName}"
                );
                
                if (!$result) {
                    return ['success' => false, 'message' => 'Ошибка пополнения новой карты'];
                }
                
                // Сохранить в локальную БД
                $expiresAt = null;
                if (defined('PRODUCT_ABONEMENT_DEFAULT_DAYS') && PRODUCT_ABONEMENT_DEFAULT_DAYS > 0) {
                    $expiresAt = date('Y-m-d H:i:s', strtotime('+' . PRODUCT_ABONEMENT_DEFAULT_DAYS . ' days'));
                }
                
                $stmt = $this->conn->prepare(
                    "INSERT INTO user_product_abonements 
                     (user_id, yclients_card_id, abonement_type_id, product_title, balance, last_synced_at, expires_at, is_active) 
                     VALUES (?, ?, ?, ?, ?, NOW(), ?, TRUE)"
                );
                $stmt->bind_param("iiisis", $userId, $yClientsCardId, $typeId, $typeName, $quantity, $expiresAt);
                $stmt->execute();
                $abonementId = $stmt->insert_id;
                $stmt->close();
                
                $newBalance = $quantity;
            }
            
            // Списать деньги с кошелька
            $walletCardId = $this->userAPI->getUserLoyaltyCardId($userId);
            if (!$walletCardId) {
                return ['success' => false, 'message' => 'Карта-кошелек не найдена'];
            }
            
            $deductResult = $yclients->modifyLoyaltyCardBalance(
                $walletCardId,
                -$price,
                "Покупка: {$typeName}"
            );
            
            if (!$deductResult) {
                return ['success' => false, 'message' => 'Ошибка списания средств'];
            }
            
            // Сохранить в историю баланса
            $this->balanceAPI->addBalanceHistory($userId, -$price, "Покупка: {$typeName}");
            
            error_log("User {$userId} purchased product abonement {$typeName}, quantity: {$quantity}, new balance: {$newBalance}");
            
            return [
                'success' => true,
                'message' => 'Товар успешно добавлен',
                'abonement_id' => $abonementId,
                'quantity' => $quantity,
                'new_balance' => $newBalance,
                'new_wallet_balance' => $balance - $price
            ];
            
        } catch (Exception $e) {
            error_log("Error purchasing product abonement: " . $e->getMessage());
            return ['success' => false, 'message' => 'Ошибка при покупке: ' . $e->getMessage()];
        }
    }

    /**
     * Получить полные данные товара из YClients
     * 
     * @param int $productId ID товара
     * @return array|null Данные товара
     */
    private function getFullProductData($productId) {
        global $yclients;
        
        try {
            $url = "https://api.yclients.com/api/v1/goods/" . YCLIENTS_COMPANY_ID . "/?page=1&count=100";
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $yclients->getPublicHeaders());
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode == 200) {
                $data = json_decode($response, true);
                if (isset($data['success']) && $data['success'] && !empty($data['data'])) {
                    foreach ($data['data'] as $item) {
                        if ($item['good_id'] == $productId) {
                            return $item;
                        }
                    }
                }
            }
        } catch (Exception $e) {
            error_log("Error getting full product data: " . $e->getMessage());
        }
        
        return null;
    }

    /**
     * Получить список товарных абонементов пользователя
     * 
     * @param int $userId ID пользователя
     * @param bool $syncWithYClients Синхронизировать с YClients перед возвратом
     * @return array Список абонементов
     */
    public function getUserProductAbonements($userId, $syncWithYClients = true) {
        if ($syncWithYClients) {
            $this->syncAllAbonements($userId);
        }
        
        $stmt = $this->conn->prepare(
            "SELECT * FROM user_product_abonements 
             WHERE user_id = ? AND is_active = TRUE
             ORDER BY purchased_at DESC"
        );
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $abonements = [];
        while ($row = $result->fetch_assoc()) {
            // Проверить срок действия
            if ($row['expires_at'] && strtotime($row['expires_at']) < time()) {
                $row['is_expired'] = true;
            } else {
                $row['is_expired'] = false;
            }
            
            $abonements[] = $row;
        }
        
        $stmt->close();
        return $abonements;
    }

    /**
     * Синхронизировать все абонементы пользователя с YClients
     * 
     * @param int $userId ID пользователя
     * @return bool Успех операции
     */
    private function syncAllAbonements($userId) {
        global $yclients;
        
        $user = $this->userAPI->getUserById($userId);
        if (!$user || !$user['yclients_client_id']) {
            return false;
        }
        
        try {
            // Получить все карты клиента из YClients
            $cards = $yclients->getClientLoyaltyCards($user['yclients_client_id']);
            
            if (empty($cards)) {
                return false;
            }
            
            // Обновить баланс для каждой карты-абонемента
            foreach ($cards as $card) {
                // Пропустить карту-кошелек
                if ($card['type_id'] == LOYALTY_CARD_TYPE_ID) {
                    continue;
                }
                
                // Найти соответствующую запись в БД
                $stmt = $this->conn->prepare(
                    "UPDATE user_product_abonements 
                     SET balance = ?, last_synced_at = NOW()
                     WHERE user_id = ? AND yclients_card_id = ?"
                );
                $balance = $card['balance'] ?? 0;
                $cardId = $card['id'];
                $stmt->bind_param("iii", $balance, $userId, $cardId);
                $stmt->execute();
                $stmt->close();
            }
            
            return true;
            
        } catch (Exception $e) {
            error_log("Error syncing abonements: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Синхронизировать конкретный абонемент с YClients
     * 
     * @param int $userId ID пользователя
     * @param int $cardId ID карты в YClients
     * @return bool Успех операции
     */
    public function syncAbonementBalance($userId, $cardId) {
        global $yclients;
        
        $user = $this->userAPI->getUserById($userId);
        if (!$user || !$user['yclients_client_id']) {
            return false;
        }
        
        try {
            $cards = $yclients->getClientLoyaltyCards($user['yclients_client_id']);
            
            foreach ($cards as $card) {
                if ($card['id'] == $cardId) {
                    $stmt = $this->conn->prepare(
                        "UPDATE user_product_abonements 
                         SET balance = ?, last_synced_at = NOW()
                         WHERE user_id = ? AND yclients_card_id = ?"
                    );
                    $balance = $card['balance'] ?? 0;
                    $stmt->bind_param("iii", $balance, $userId, $cardId);
                    $stmt->execute();
                    $stmt->close();
                    
                    return true;
                }
            }
            
        } catch (Exception $e) {
            error_log("Error syncing single abonement: " . $e->getMessage());
        }
        
        return false;
    }
}



