<?php
require_once 'config.php';
require_once 'database.php';

class BalanceAPI {
    private $conn;
    private $userAPI;
    private $database;

    public function __construct() {
        $this->conn = getDbConnection();
        // Database will be created lazily to avoid circular dependencies
        $this->ensureTablesExist();
        // UserAPI will be created lazily to avoid circular dependencies
    }

    /**
     * Get Database instance (lazy initialization)
     */
    private function getDatabase() {
        if (!$this->database) {
            $this->database = new Database();
        }
        return $this->database;
    }

    /**
     * Get UserAPI instance (lazy initialization)
     */
    private function getUserAPI() {
        if (!$this->userAPI) {
            require_once 'user.php';
            $this->userAPI = new UserAPI();
        }
        return $this->userAPI;
    }

    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }

    /**
     * Убеждаемся, что необходимые таблицы существуют
     */
    private function ensureTablesExist() {
        $database = $this->getDatabase();
        $database->createUsersTable();
        $database->createBalanceHistoryTable();
    }

    /**
     * Получить историю баланса пользователя
     */
    public function getBalanceHistory($userId, $limit = 10) {
        $stmt = $this->conn->prepare("SELECT * FROM balance_history WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
        $stmt->bind_param("ii", $userId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        $history = [];
        while ($row = $result->fetch_assoc()) {
            $history[] = $row;
        }
        $stmt->close();
        return $history;
    }

    /**
     * Добавить запись в историю баланса
     */
    public function addBalanceHistory($userId, $amount, $description = 'Пополнение баланса') {
        $stmt = $this->conn->prepare("INSERT INTO balance_history (user_id, amount, description) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $userId, $amount, $description);
        $result = $stmt->execute();
        $historyId = $stmt->insert_id;
        $stmt->close();
        return $result ? $historyId : false;
    }

    /**
     * Пополнить баланс пользователя (теперь пополняет карту лояльности YClients)
     * 
     * @param int $userId ID пользователя
     * @param float $amount Сумма пополнения
     * @param string $description Описание транзакции
     * @return bool Успех операции
     */
    public function rechargeBalance($userId, $amount, $description = 'Пополнение баланса') {
        // Получить пользователя
        $userAPI = $this->getUserAPI();
        $user = $userAPI->getUserById($userId);
        
        if (!$user) {
            error_log("User {$userId} not found");
            return false;
        }

        if (!$user['yclients_client_id']) {
            error_log("User {$userId} has no YClients client ID");
            return false;
        }

        // Получить ID карты лояльности
        $cardId = $userAPI->getUserLoyaltyCardId($userId);
        
        if (!$cardId) {
            error_log("Loyalty card not found for user {$userId}");
            return false;
        }

        // Пополнить карту лояльности через YClients API
        global $yclients;
        try {
            $success = $yclients->modifyLoyaltyCardBalance($cardId, $amount, $description);
            
            if ($success) {
                // Добавить запись в историю для отслеживания
                $this->addBalanceHistory($userId, $amount, $description);
                error_log("Recharged {$amount} to loyalty card {$cardId} for user {$userId}");
                return true;
            } else {
                error_log("Failed to recharge loyalty card {$cardId} for user {$userId}");
                return false;
            }
        } catch (Exception $e) {
            error_log("Error recharging balance: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Списать средства с баланса (теперь списывает с карты лояльности YClients)
     * 
     * @param int $userId ID пользователя
     * @param float $amount Сумма списания
     * @param string $description Описание транзакции
     * @return bool Успех операции
     */
    public function deductBalance($userId, $amount, $description = 'Списание с баланса') {
        // Получить пользователя
        $userAPI = $this->getUserAPI();
        $user = $userAPI->getUserById($userId);
        
        if (!$user) {
            error_log("User {$userId} not found");
            return ['success' => false, 'message' => 'Пользователь не найден'];
        }

        if (!$user['yclients_client_id']) {
            error_log("User {$userId} has no YClients client ID");
            return ['success' => false, 'message' => 'Карта лояльности не найдена'];
        }

        // Получить ID карты лояльности и текущий баланс
        $cardId = $userAPI->getUserLoyaltyCardId($userId);
        
        if (!$cardId) {
            error_log("Loyalty card not found for user {$userId}");
            return ['success' => false, 'message' => 'Карта лояльности не найдена'];
        }

        // Проверить баланс
        $currentBalance = $userAPI->getUserLoyaltyBalance($userId);
        if ($currentBalance === null || $currentBalance < $amount) {
            error_log("Insufficient balance for user {$userId}: {$currentBalance} < {$amount}");
            return ['success' => false, 'message' => 'Недостаточно средств на балансе'];
        }

        // Списать с карты лояльности через YClients API (отрицательная сумма)
        global $yclients;
        try {
            $success = $yclients->modifyLoyaltyCardBalance($cardId, -$amount, $description);
            
            if ($success) {
                // Добавить запись в историю для отслеживания (отрицательная сумма)
                $this->addBalanceHistory($userId, -$amount, $description);
                error_log("Deducted {$amount} from loyalty card {$cardId} for user {$userId}");
                return ['success' => true, 'message' => 'Успешно списано'];
            } else {
                error_log("Failed to deduct from loyalty card {$cardId} for user {$userId}");
                return ['success' => false, 'message' => 'Ошибка при списании'];
            }
        } catch (Exception $e) {
            error_log("Error deducting balance: " . $e->getMessage());
            return ['success' => false, 'message' => 'Ошибка при списании: ' . $e->getMessage()];
        }
    }

    /**
     * Получить текущий баланс пользователя (из карты лояльности YClients)
     * 
     * @param int $userId ID пользователя
     * @return float Баланс пользователя
     */
    public function getUserBalance($userId) {
        $userAPI = $this->getUserAPI();
        $balance = $userAPI->getUserLoyaltyBalance($userId);
        
        // Если не удалось получить баланс из YClients, возвращаем 0
        return $balance !== null ? $balance : 0;
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';

    $balanceAPI = new BalanceAPI();

    switch ($action) {
        case 'getHistory':
            if (isset($_GET['user_id'])) {
                $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
                $history = $balanceAPI->getBalanceHistory((int)$_GET['user_id'], $limit);
                jsonResponse($history);
            }
            break;

        case 'getBalance':
            if (isset($_GET['user_id'])) {
                $balance = $balanceAPI->getUserBalance((int)$_GET['user_id']);
                jsonResponse(['balance' => $balance]);
            }
            break;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    $balanceAPI = new BalanceAPI();

    switch ($action) {
        case 'recharge':
            if (isset($_POST['user_id']) && isset($_POST['amount'])) {
                $user = $balanceAPI->rechargeBalance((int)$_POST['user_id'], (int)$_POST['amount']);
                jsonResponse(['success' => $user !== false, 'user' => $user]);
            }
            break;

        case 'deduct':
            if (isset($_POST['user_id']) && isset($_POST['amount'])) {
                $description = $_POST['description'] ?? 'Списание с баланса';
                $user = $balanceAPI->deductBalance((int)$_POST['user_id'], (int)$_POST['amount'], $description);
                jsonResponse(['success' => $user !== false, 'user' => $user]);
            }
            break;

        case 'addHistory':
            if (isset($_POST['user_id']) && isset($_POST['amount'])) {
                $description = $_POST['description'] ?? 'Пополнение баланса';
                $historyId = $balanceAPI->addBalanceHistory((int)$_POST['user_id'], (int)$_POST['amount'], $description);
                jsonResponse(['success' => $historyId !== false, 'history_id' => $historyId]);
            }
            break;
    }
}
?>
