<?php
require_once 'config.php';

class Database {
    private $conn;

    public function __construct() {
        $this->conn = getDbConnection();
    }

    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }

    /**
     * Получить соединение с БД
     */
    public function getConnection() {
        return $this->conn;
    }

    /**
     * Создание базы данных если она не существует
     */
    public function createDatabase() {
        $sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
        $result = $this->conn->query($sql);
        if ($result) {
            // Выбираем базу данных
            $this->conn->select_db(DB_NAME);
        }
        return $result;
    }

    /**
     * Создание таблицы пользователей
     */
    public function createUsersTable() {
        $sql = "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            telegram_id BIGINT UNIQUE,
            yclients_client_id INT,
            first_name VARCHAR(255),
            last_name VARCHAR(255),
            username VARCHAR(255),
            phone VARCHAR(20),
            email VARCHAR(255),
            photo_url TEXT,
            balance INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_telegram_id (telegram_id),
            INDEX idx_phone (phone),
            INDEX idx_yclients_client_id (yclients_client_id)
        )";
        return $this->conn->query($sql);
    }

    /**
     * Создание таблицы уведомлений
     */
    public function createNotificationsTable() {
        $sql = "CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            title VARCHAR(255) NOT NULL,
            text TEXT NOT NULL,
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_id (user_id),
            INDEX idx_created_at (created_at),
            INDEX idx_is_read (is_read)
        )";
        return $this->conn->query($sql);
    }

    /**
     * Создание таблицы истории баланса
     */
    public function createBalanceHistoryTable() {
        $sql = "CREATE TABLE IF NOT EXISTS balance_history (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            amount INT NOT NULL,
            description VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_id (user_id),
            INDEX idx_created_at (created_at)
        )";
        return $this->conn->query($sql);
    }

    /**
     * Создание таблицы заказов
     */
    public function createOrdersTable() {
        $sql = "CREATE TABLE IF NOT EXISTS orders (
            id VARCHAR(50) PRIMARY KEY,
            user_id INT NOT NULL,
            amount INT NOT NULL,
            status ENUM('pending', 'completed', 'cancelled') DEFAULT 'pending',
            payment_method VARCHAR(50) DEFAULT 'tinkoff',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_id (user_id),
            INDEX idx_status (status),
            INDEX idx_created_at (created_at)
        )";
        return $this->conn->query($sql);
    }

    /**
     * Создание таблицы бронирований
     */
    public function createBookingsTable() {
        $sql = "CREATE TABLE IF NOT EXISTS bookings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            activity_id INT NOT NULL,
            record_id INT,
            service_title VARCHAR(255) NOT NULL,
            service_price DECIMAL(10, 2) NOT NULL,
            datetime DATETIME NOT NULL,
            paid TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_id (user_id),
            INDEX idx_activity_id (activity_id),
            INDEX idx_paid (paid),
            INDEX idx_datetime (datetime)
        )";
        return $this->conn->query($sql);
    }

    /**
     * Инициализация всей базы данных
     */
    public function initialize() {
        $this->createDatabase();
        $this->createUsersTable();
        $this->createNotificationsTable();
        $this->createBalanceHistoryTable();
        $this->createOrdersTable();
        $this->createBookingsTable();

        return true;
    }

    /**
     * Проверка существования таблицы
     */
    public function tableExists($tableName) {
        $result = $this->conn->query("SHOW TABLES LIKE '$tableName'");
        return $result && $result->num_rows > 0;
    }

    /**
     * Получение списка всех таблиц
     */
    public function getTables() {
        $tables = [];
        $result = $this->conn->query("SHOW TABLES");
        if ($result) {
            while ($row = $result->fetch_array()) {
                $tables[] = $row[0];
            }
        }
        return $tables;
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    $database = new Database();

    switch ($action) {
        case 'initialize':
            $result = $database->initialize();
            jsonResponse(['success' => $result, 'message' => $result ? 'Database initialized successfully' : 'Failed to initialize database']);
            break;

        case 'createDatabase':
            $result = $database->createDatabase();
            jsonResponse(['success' => $result, 'message' => $result ? 'Database created successfully' : 'Failed to create database']);
            break;

        case 'getTables':
            $tables = $database->getTables();
            jsonResponse(['tables' => $tables]);
            break;
    }
}
?>
