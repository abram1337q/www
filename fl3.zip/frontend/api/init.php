<?php
/**
 * Инициализация базы данных и заполнение начальными данными
 *
 * Использование:
 * - Через веб: POST запросы к этому файлу
 * - Через CLI: php api/init.php [init|seed|refresh]
 */

require_once 'config.php';
require_once 'database.php';
require_once 'seed.php';

header('Content-Type: application/json');

// Handle web requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'init';

    $database = new Database();
    $seeder = new DatabaseSeeder();

    try {
        switch ($action) {
            case 'init':
                // Инициализация структуры БД
                $result = $database->initialize();
                $message = $result ? 'Database structure initialized successfully' : 'Failed to initialize database structure';
                jsonResponse(['success' => $result, 'message' => $message]);
                break;

            case 'seed':
                // Заполнение тестовыми данными
                $results = $seeder->seed();
                jsonResponse([
                    'success' => true,
                    'message' => 'Database seeded successfully',
                    'results' => $results
                ]);
                break;

            case 'refresh':
                // Полная перезагрузка (очистка + заполнение)
                $results = $seeder->refresh();
                jsonResponse([
                    'success' => true,
                    'message' => 'Database refreshed successfully',
                    'results' => $results
                ]);
                break;

            case 'status':
                // Проверка статуса БД
                $tables = $database->getTables();
                jsonResponse([
                    'success' => true,
                    'tables' => $tables,
                    'tables_count' => count($tables)
                ]);
                break;

            default:
                jsonResponse(['success' => false, 'message' => 'Unknown action']);
        }
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
    exit;
}

// CLI interface
if (php_sapi_name() === 'cli') {
    $action = $argv[1] ?? 'help';

    $database = new Database();
    $seeder = new DatabaseSeeder();

    try {
        switch ($action) {
            case 'init':
                echo "Initializing database structure...\n";
                $result = $database->initialize();
                if ($result) {
                    echo "✓ Database structure initialized successfully\n";
                } else {
                    echo "✗ Failed to initialize database structure\n";
                    exit(1);
                }
                break;

            case 'seed':
                echo "Seeding database with test data...\n";
                $results = $seeder->seed();
                echo "✓ Database seeded successfully\n";
                echo "- Users: {$results['users']}\n";
                echo "- Notifications: {$results['notifications']}\n";
                break;

            case 'refresh':
                echo "Refreshing database (truncate + seed)...\n";
                $results = $seeder->refresh();
                echo "✓ Database refreshed successfully\n";
                echo "- Users: {$results['users']}\n";
                echo "- Notifications: {$results['notifications']}\n";
                break;

            case 'status':
                echo "Database status:\n";
                $tables = $database->getTables();
                echo "- Tables count: " . count($tables) . "\n";
                if (!empty($tables)) {
                    echo "- Tables: " . implode(', ', $tables) . "\n";
                }
                break;

            default:
                echo "Fitness Club Database Initialization Tool\n\n";
                echo "Usage: php api/init.php [command]\n\n";
                echo "Commands:\n";
                echo "  init     - Create database tables if they don't exist\n";
                echo "  seed     - Add test data to existing database\n";
                echo "  refresh  - Truncate all data and reseed database\n";
                echo "  status   - Show database status and tables\n";
                echo "  help     - Show this help message\n\n";
                echo "Web interface available at: /api/init.php\n";
                echo "Supported POST actions: init, seed, refresh, status\n";
                break;
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage() . "\n";
        exit(1);
    }

    exit(0);
}

// If accessed directly via browser without POST
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Инициализация базы данных | <?php echo APP_NAME; ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .container { max-width: 600px; margin: 0 auto; }
        .button {
            background: #7171dc;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
        }
        .button:hover { background: #5a5acc; }
        .result { margin-top: 20px; padding: 10px; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Инициализация базы данных</h1>
        <p>Инструмент для настройки и заполнения базы данных фитнес-клуба.</p>

        <h2>Действия</h2>
        <button class="button" onclick="runAction('init')">Инициализировать структуру БД</button>
        <button class="button" onclick="runAction('seed')">Заполнить тестовыми данными</button>
        <button class="button" onclick="runAction('refresh')">Перезагрузить БД</button>
        <button class="button" onclick="runAction('status')">Показать статус</button>

        <div id="result"></div>
    </div>

    <script>
        async function runAction(action) {
            const resultDiv = document.getElementById('result');
            resultDiv.innerHTML = '<p>Выполнение...</p>';

            try {
                const response = await fetch('init.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=' + action
                });

                const data = await response.json();

                if (data.success) {
                    resultDiv.innerHTML = '<div class="result success"><pre>' + JSON.stringify(data, null, 2) + '</pre></div>';
                } else {
                    resultDiv.innerHTML = '<div class="result error"><pre>' + JSON.stringify(data, null, 2) + '</pre></div>';
                }
            } catch (error) {
                resultDiv.innerHTML = '<div class="result error">Ошибка: ' + error.message + '</div>';
            }
        }
    </script>
</body>
</html>
