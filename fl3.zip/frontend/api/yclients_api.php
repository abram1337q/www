<?php

class YClientsService {
    private $partnerToken;
    private $userToken;
    private $companyId;

    public function __construct($partnerToken, $userToken, $companyId) {
        $this->partnerToken = $partnerToken;
        $this->userToken = $userToken;
        $this->companyId = $companyId;
    }

    private function getHeaders() {
        return [
            'Content-Type: application/json',
            'Accept: application/vnd.yclients.v2+json',
            'Authorization: Bearer ' . $this->partnerToken . ', User ' . $this->userToken
        ];
    }

    /**
     * Публичный метод для получения заголовков (для тестирования)
     */
    public function getPublicHeaders() {
        return $this->getHeaders();
    }

    public function getSpecialOffers() {
        // Используем эндпоинт товаров магазина и фильтруем товары со скидками
        $ch = curl_init('https://api.yclients.com/api/v1/goods/' . $this->companyId . '/?page=1&count=50');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        error_log('YClients API Response (getSpecialOffers): ' . $response);

        $data = json_decode($response, true);

        if ($httpCode == 200 && isset($data['success']) && $data['success'] && !empty($data['data'])) {
            // Фильтруем товары со скидками (actual_cost меньше cost)
            $specialOffers = [];
            foreach ($data['data'] as $item) {
                if (isset($item['actual_cost']) && isset($item['cost']) && 
                    $item['actual_cost'] > 0 && $item['actual_cost'] < $item['cost']) {
                    $specialOffers[] = [
                        'id' => $item['good_id'],
                        'title' => $item['title'],
                        'description' => $item['comment'] ?? '',
                        'price' => $item['actual_cost'],
                        'original_price' => $item['cost'],
                        'discount_percent' => round((($item['cost'] - $item['actual_cost']) / $item['cost']) * 100),
                        'image_url' => 'Images/gym-banner.jpg', // Заглушка для изображения
                        'category' => $item['category'] ?? '',
                        'unit_format' => $item['unit_actual_cost_format'] ?? ''
                    ];
                }
            }
            
            return [
                'success' => true,
                'data' => $specialOffers
            ];
        } else {
            error_log('Failed to get special offers: ' . print_r($data, true));
            return ['success' => false, 'data' => []];
        }
    }

    // Add more methods as needed based on usage in the application
    public function getShopItems($filter = 'all', $page = 1, $count = 50) {
        $queryParams = [
            'page' => $page,
            'count' => $count
        ];

        // Add category filter if specified
        if ($filter !== 'all' && is_numeric($filter)) {
            $queryParams['category_id'] = $filter;
        }

        $queryString = http_build_query($queryParams);
        $url = 'https://api.yclients.com/api/v1/goods/' . $this->companyId . '/?' . $queryString;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        error_log('YClients API Response (getShopItems): ' . $response);

        $data = json_decode($response, true);

        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            return $data;
        } else {
            error_log('Failed to get shop items: ' . print_r($data, true));
            return ['success' => false, 'data' => []];
        }
    }

    public function findClientByPhone($phone) {
        // Format phone number: remove non-digits and ensure it starts with 7
        $formattedPhone = preg_replace('/\D/', '', $phone);
        $formattedPhone = preg_replace('/^8/', '7', $formattedPhone);

        $ch = curl_init('https://api.yclients.com/api/v1/clients/' . $this->companyId . '?phone=' . $formattedPhone);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);

        if ($httpCode == 200 && isset($data['data']) && is_array($data['data']) && !empty($data['data'])) {
            return $data['data'][0];
        }

        return null;
    }

    public function createClient($userData) {
        $phone = isset($userData['phone']) ? $userData['phone'] : $userData['telegram_id'];
        if ($phone) {
            // Format phone number: remove non-digits and ensure it starts with 7
            $phone = preg_replace('/\D/', '', $phone);
            $phone = preg_replace('/^8/', '7', $phone);
        }

        $clientData = [
            'name' => $userData['first_name'] ?? 'Новый клиент',
            'surname' => $userData['last_name'] ?? '',
            'phone' => $phone,
            'email' => $userData['email'] ?? '',
            'comment' => 'telegram_id:' . ($userData['telegram_id'] ?? ''),
            'custom_fields' => [
                'telegram_id' => $userData['telegram_id'] ?? '',
            ]
        ];

        $ch = curl_init('https://api.yclients.com/api/v1/clients/' . $this->companyId);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($clientData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);

        if ($httpCode == 201 && isset($data['data']['id'])) {
            return $data['data'];
        }

        error_log('Failed to create YClients client: ' . print_r($data, true));
        return null;
    }

    /**
     * Получение расписания групповых активностей
     * 
     * @param int $staffId ID сотрудника (0 для всех сотрудников)
     * @param string $startDate Начальная дата (YYYY-MM-DD)
     * @param string $endDate Конечная дата (YYYY-MM-DD)
     * @return array Массив активностей в формате seances
     * @throws Exception при серверных ошибках (5xx)
     */
    public function getSchedule($staffId, $startDate, $endDate) {
        // Используем новый API для поиска групповых активностей
        $url = "https://api.yclients.com/api/v1/activity/{$this->companyId}/search/";
        
        $queryParams = [
            'from' => $startDate,
            'till' => $endDate,
            'page' => 1,
            'count' => 200
        ];
        
        if ($staffId && $staffId !== 0) {
            $queryParams['staff_id'] = $staffId;
        }
        
        $url .= '?' . http_build_query($queryParams);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        error_log("Activity API request: {$url}");
        error_log("Activity API response: HTTP {$httpCode}, Body: {$response}");

        $data = json_decode($response, true);

        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            error_log("Activity API data received: " . count($data['data']) . " activities");

            if (!empty($data['data'])) {
                // Конвертируем активности в формат сеансов для совместимости
                return $this->convertActivitiesToSeances($data['data']);
            } else {
                // Нет активностей на выбранную дату
                error_log("No activities found for date range {$startDate} - {$endDate}");
                return [];
            }
        }

        // Возвращаем пустой массив при любых ошибках (кроме 5xx)
        if ($httpCode >= 500) {
            error_log("Server error (5xx) from Activity API: HTTP {$httpCode}");
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }

        error_log("Activity API error: HTTP {$httpCode}, Response: " . print_r($data, true));
        return [];
    }

    /**
     * Преобразование активностей в формат сеансов для совместимости с фронтендом
     * 
     * @param array $activities Массив активностей из API
     * @return array Массив в формате staff -> seances
     */
    private function convertActivitiesToSeances($activities) {
        $staffActivities = [];
        
        foreach ($activities as $activity) {
            $staffId = $activity['staff']['id'] ?? 0;
            
            if (!isset($staffActivities[$staffId])) {
                $staffActivities[$staffId] = [
                    'staff' => [
                        'id' => $staffId,
                        'name' => $activity['staff']['name'] ?? 'Тренер',
                        'avatar_big' => $activity['staff']['avatar_big'] ?? 'Images/trainer.jpg'
                    ],
                    'seances' => []
                ];
            }
            
            // Используем records_count для расчета занятых мест
            $recordsCount = $activity['records_count'] ?? 0;
            $records = [];
            for ($i = 1; $i <= $recordsCount; $i++) {
                $records[] = ['id' => $i];
            }
            
            // Получаем цену услуги из service
            $price = $activity['service']['price_min'] ?? 0;
            
            $seance = [
                'id' => $activity['id'],
                'service' => [
                    'title' => $activity['service']['title'] ?? 'Групповая активность',
                    'price' => $price
                ],
                'date' => $activity['date'], // Уже в правильном формате YYYY-MM-DD HH:MM:SS
                'length' => $activity['length'] ?? 3600, // Default 1 hour
                'capacity' => $activity['capacity'] ?? 10,
                'records' => $records, // Создаем массив записей на основе records_count
                'price' => $price // Добавляем цену на верхний уровень для удобства
            ];
            
            $staffActivities[$staffId]['seances'][] = $seance;
        }
        
        return array_values($staffActivities);
    }


    /**
     * Получение списка сотрудников компании
     * 
     * @return array Массив сотрудников
     * @throws Exception при серверных ошибках (5xx)
     */
    public function getStaff() {
        $url = "https://api.yclients.com/api/v1/staff/{$this->companyId}";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        error_log("Staff API request: {$url}");
        error_log("Staff API response: HTTP {$httpCode}, Body: " . substr($response, 0, 1000));

        $data = json_decode($response, true);

        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            $staffList = [];
            
            if (!empty($data['data'])) {
                foreach ($data['data'] as $staff) {
                    // Включаем только активных сотрудников
                    if (isset($staff['fired']) && $staff['fired'] == 1) {
                        continue;
                    }
                    
                    $staffList[] = [
                        'id' => $staff['id'],
                        'name' => $staff['name'] ?? 'Сотрудник',
                        'photo' => $staff['avatar_big'] ?? $staff['avatar'] ?? 'Images/trainer.jpg',
                        'specialization' => $staff['specialization'] ?? 'Тренер'
                    ];
                }
            }
            
            error_log("Staff list found: " . count($staffList) . " active employees");
            return $staffList;
        }

        // Возвращаем пустой массив при любых ошибках (кроме 5xx)
        if ($httpCode >= 500) {
            error_log("Server error (5xx) from Staff API: HTTP {$httpCode}");
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }

        error_log("Staff API error: HTTP {$httpCode}, Response: " . print_r($data, true));
        return [];
    }

    /**
     * Получение записей клиента (включая групповые активности)
     * 
     * @param int $clientId ID клиента в YClients
     * @return array Массив записей клиента
     * @throws Exception при серверных ошибках (5xx)
     */
    public function getClientBookings($clientId) {
        // Используем правильный эндпоинт для получения записей клиента
        // Получаем записи за последние 30 дней и на 90 дней вперед
        $startDate = date('Y-m-d', strtotime('-30 days'));
        $endDate = date('Y-m-d', strtotime('+90 days'));
        
        $url = "https://api.yclients.com/api/v1/records/{$this->companyId}";
        $queryParams = [
            'client_id' => $clientId,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'count' => 300
        ];
        
        $url .= '?' . http_build_query($queryParams);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        error_log("Client bookings API request: {$url}");
        error_log("Client bookings API response: HTTP {$httpCode}, Body: " . substr($response, 0, 500));

        $data = json_decode($response, true);

        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            if (!empty($data['data'])) {
                // Фильтруем только активные записи (не удаленные, не отмененные)
                $bookings = [];
                foreach ($data['data'] as $record) {
                    // Пропускаем удаленные и отмененные записи
                    if (isset($record['deleted']) && $record['deleted']) {
                        continue;
                    }
                    
                    // Для групповых активностей используем activity_id
                    $activityId = $record['activity_id'] ?? null;
                    
                    if ($activityId) {
                        // Это запись на групповую активность
                        $bookings[] = [
                            'id' => $activityId,
                            'record_id' => $record['id'],
                            'seance' => [
                                'id' => $activityId
                            ],
                            'service' => [
                                'title' => $record['services'][0]['title'] ?? 'Активность'
                            ],
                            'date' => $record['datetime'],
                            'type' => 'activity'
                        ];
                    }
                }
                error_log("Client bookings found: " . count($bookings) . " (filtered from " . count($data['data']) . " total records)");
                return $bookings;
            } else {
                error_log("No bookings found for client {$clientId}");
                return [];
            }
        }

        // Возвращаем пустой массив при любых ошибках (кроме 5xx)
        if ($httpCode >= 500) {
            error_log("Server error (5xx) from Client Bookings API: HTTP {$httpCode}");
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }

        error_log("Client bookings API error: HTTP {$httpCode}, Response: " . print_r($data, true));
        return [];
    }


    public function getClientLoyaltyAbonements($clientId) {
        $url = "https://api.yclients.com/api/v1/loyalty/abonements/{$this->companyId}?client_id={$clientId}";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);

        if ($httpCode == 200 && is_array($data)) {
            return $data;
        }

        error_log("Failed to get client loyalty abonements for client {$clientId}: " . print_r($data, true));
        return [];
    }

    /**
     * Запись клиента на групповую активность
     * 
     * @param int $activityId ID активности
     * @param array $clientData Данные клиента (name, phone, email)
     * @return mixed true при успехе, массив с деталями ошибки при неудаче
     * @throws Exception при серверных ошибках (5xx)
     */
    public function bookActivity($activityId, $clientData) {
        // Правильный URL для записи на групповую активность
        $url = "https://api.yclients.com/api/v1/activity/{$this->companyId}/{$activityId}/book";
        
        // Форматируем номер телефона согласно примеру в документации (79161502239)
        $phone = $clientData['phone'] ?? '';
        if ($phone) {
            // Удаляем все нецифровые символы
            $phone = preg_replace('/\D/', '', $phone);
            // Заменяем 8 на 7 для российских номеров
            $phone = preg_replace('/^8/', '7', $phone);
            // Если номер начинается не с 7 и имеет 10 цифр, добавляем 7
            if (!preg_match('/^7/', $phone) && strlen($phone) == 10) {
                $phone = '7' . $phone;
            }
        }
        
        // Структура данных согласно документации API
        $bookingData = [
            'fullname' => $clientData['name'] ?? 'Клиент',
            'phone' => $phone,
            'email' => $clientData['email'] ?? '',
            'comment' => $clientData['comment'] ?? '',
            'notify_by_sms' => 0,    // Не отправлять SMS уведомления
            'notify_by_email' => 0   // Не отправлять email уведомления
        ];
        
        // Добавляем код подтверждения если есть
        if (isset($clientData['code'])) {
            $bookingData['code'] = $clientData['code'];
        }
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($bookingData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Activity booking request: {$url}");
        error_log("Activity booking data: " . json_encode($bookingData));
        error_log("Activity booking response: HTTP {$httpCode}, Body: {$response}");
        
        $data = json_decode($response, true);
        
        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            error_log("Activity booking successful for activity {$activityId}");
            return $data['data'] ?? true;
        }
        
        // Возвращаем ошибку при любых проблемах (кроме 5xx)
        if ($httpCode >= 500) {
            error_log("Server error (5xx) from Activity Booking API: HTTP {$httpCode}");
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Activity booking failed: HTTP {$httpCode}, Response: " . print_r($data, true));
        
        // Возвращаем детальную информацию об ошибке
        $errorDetails = [
            'http_code' => $httpCode,
            'response' => $data,
            'url' => $url,
            'request_data' => $bookingData
        ];
        
        return $errorDetails;
    }

    /**
     * Получение детальной информации о конкретном групповом событии
     * 
     * @param int $activityId ID активности
     * @return array|null Данные активности или null при ошибке
     * @throws Exception при серверных ошибках (5xx)
     */
    public function getActivityDetails($activityId) {
        $url = "https://api.yclients.com/api/v1/activity/{$this->companyId}/{$activityId}";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Activity details request: {$url}");
        error_log("Activity details response: HTTP {$httpCode}, Body: {$response}");
        
        $data = json_decode($response, true);
        
        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            return $data['data'] ?? null;
        }
        
        if ($httpCode >= 500) {
            error_log("Server error (5xx) from Activity Details API: HTTP {$httpCode}");
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Activity details API error: HTTP {$httpCode}, Response: " . print_r($data, true));
        return null;
    }

    /**
     * Поиск дат с групповыми событиями (для календарей и виджетов)
     * 
     * @param string $startDate Начальная дата (YYYY-MM-DD)
     * @param string $endDate Конечная дата (YYYY-MM-DD)
     * @param int|null $staffId ID сотрудника (опционально)
     * @return array Массив дат с событиями
     * @throws Exception при серверных ошибках (5xx)
     */
    public function getActivityDates($startDate, $endDate, $staffId = null) {
        // Используем основной поиск активностей и извлекаем уникальные даты
        $url = "https://api.yclients.com/api/v1/activity/{$this->companyId}/search/";
        
        $queryParams = [
            'date_from' => $startDate,
            'date_to' => $endDate,
            'page' => 1,
            'count' => 200
        ];
        
        if ($staffId) {
            $queryParams['staff_id'] = $staffId;
        }
        
        $url .= '?' . http_build_query($queryParams);
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Activity dates request: {$url}");
        error_log("Activity dates response: HTTP {$httpCode}, Body: {$response}");
        
        $data = json_decode($response, true);
        
        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            // Извлекаем уникальные даты из активностей
            $dates = [];
            if (!empty($data['data'])) {
                foreach ($data['data'] as $activity) {
                    $activityDate = substr($activity['date'], 0, 10); // Извлекаем только дату (YYYY-MM-DD)
                    if (!in_array($activityDate, $dates)) {
                        $dates[] = $activityDate;
                    }
                }
                sort($dates); // Сортируем даты по возрастанию
            }
            return $dates;
        }
        
        if ($httpCode >= 500) {
            error_log("Server error (5xx) from Activity Dates API: HTTP {$httpCode}");
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Activity dates API error: HTTP {$httpCode}, Response: " . print_r($data, true));
        return [];
    }

    /**
     * Создание нового группового события
     * 
     * @param array $eventData Данные события (service_id, staff_id, date, length, capacity, etc.)
     * @return array|null Данные созданного события или null при ошибке
     * @throws Exception при серверных ошибках (5xx)
     */
    public function createActivity($eventData) {
        $url = "https://api.yclients.com/api/v1/activity/{$this->companyId}";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($eventData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Activity creation request: {$url}");
        error_log("Activity creation data: " . json_encode($eventData));
        error_log("Activity creation response: HTTP {$httpCode}, Body: {$response}");
        
        $data = json_decode($response, true);
        
        if ($httpCode == 201 && isset($data['success']) && $data['success']) {
            error_log("Activity created successfully");
            return $data['data'] ?? null;
        }
        
        if ($httpCode >= 500) {
            error_log("Server error (5xx) from Activity Creation API: HTTP {$httpCode}");
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Activity creation failed: HTTP {$httpCode}, Response: " . print_r($data, true));
        return null;
    }

    /**
     * Обновление группового события
     * 
     * @param int $activityId ID активности
     * @param array $eventData Данные для обновления
     * @return array|null Обновленные данные события или null при ошибке
     * @throws Exception при серверных ошибках (5xx)
     */
    public function updateActivity($activityId, $eventData) {
        $url = "https://api.yclients.com/api/v1/activity/{$this->companyId}/{$activityId}";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($eventData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Activity update request: {$url}");
        error_log("Activity update data: " . json_encode($eventData));
        error_log("Activity update response: HTTP {$httpCode}, Body: {$response}");
        
        $data = json_decode($response, true);
        
        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            error_log("Activity updated successfully");
            return $data['data'] ?? null;
        }
        
        if ($httpCode >= 500) {
            error_log("Server error (5xx) from Activity Update API: HTTP {$httpCode}");
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Activity update failed: HTTP {$httpCode}, Response: " . print_r($data, true));
        return null;
    }

    /**
     * Удаление группового события
     * 
     * @param int $activityId ID активности
     * @return bool true при успешном удалении, false при ошибке
     * @throws Exception при серверных ошибках (5xx)
     */
    public function deleteActivity($activityId) {
        $url = "https://api.yclients.com/api/v1/activity/{$this->companyId}/{$activityId}";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Activity deletion request: {$url}");
        error_log("Activity deletion response: HTTP {$httpCode}, Body: {$response}");
        
        $data = json_decode($response, true);
        
        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            error_log("Activity deleted successfully");
            return true;
        }
        
        if ($httpCode >= 500) {
            error_log("Server error (5xx) from Activity Deletion API: HTTP {$httpCode}");
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Activity deletion failed: HTTP {$httpCode}, Response: " . print_r($data, true));
        return false;
    }

    /**
     * ===========================================
     * МЕТОДЫ ДЛЯ РАБОТЫ С КАРТАМИ ЛОЯЛЬНОСТИ
     * ===========================================
     */

    /**
     * Получить детали записи (record) по ID
     * 
     * @param int $recordId ID записи
     * @return array|null Данные записи включая visit_id или null при ошибке
     */
    public function getRecordDetails($recordId) {
        $url = "https://api.yclients.com/api/v1/record/{$this->companyId}/{$recordId}";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Get record details request for record {$recordId}: {$url}");
        error_log("Get record details response: HTTP {$httpCode}, Body: " . substr($response, 0, 500));
        
        $data = json_decode($response, true);
        
        if ($httpCode == 200 && isset($data['data'])) {
            return $data['data'];
        }
        
        if ($httpCode >= 500) {
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Failed to get record details: HTTP {$httpCode}, Response: " . print_r($data, true));
        return null;
    }

    /**
     * Оплатить визит с карты лояльности
     * 
     * @param int $cardId ID карты лояльности
     * @param int $recordId ID записи
     * @param int $visitId ID визита
     * @param float $amount Сумма для списания
     * @return array|null Результат оплаты или null при ошибке
     */
    public function payVisitWithLoyaltyCard($cardId, $recordId, $visitId, $amount) {
        $url = "https://api.yclients.com/api/v1/visit/loyalty/apply_card_withdrawal/{$this->companyId}/{$cardId}";
        
        $postData = [
            'record_id' => $recordId,
            'visit_id' => $visitId,
            'amount' => $amount
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array_merge(
            $this->getHeaders(),
            ['Content-Type: application/json']
        ));
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Pay visit with loyalty card request: {$url}");
        error_log("Pay visit with loyalty card data: " . json_encode($postData));
        error_log("Pay visit with loyalty card response: HTTP {$httpCode}, Body: {$response}");
        
        $data = json_decode($response, true);
        
        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            return $data;
        }
        
        if ($httpCode >= 500) {
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Failed to pay visit: HTTP {$httpCode}, Response: " . print_r($data, true));
        return null;
    }

    /**
     * ===========================================
     * МЕТОДЫ ДЛЯ РАБОТЫ С КАРТАМИ ЛОЯЛЬНОСТИ
     * ===========================================
     */

    /**
     * Получить список карт лояльности клиента
     * 
     * @param int $clientId ID клиента в YClients
     * @return array|null Массив карт или null при ошибке
     */
    public function getClientLoyaltyCards($clientId) {
        $url = "https://api.yclients.com/api/v1/loyalty/client_cards/{$clientId}";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Get loyalty cards request for client {$clientId}: {$url}");
        error_log("Get loyalty cards response: HTTP {$httpCode}, Body: {$response}");
        
        $data = json_decode($response, true);
        
        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            return $data['data'] ?? [];
        }
        
        if ($httpCode >= 500) {
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Failed to get loyalty cards: HTTP {$httpCode}, Response: " . print_r($data, true));
        return null;
    }

    /**
     * Создать карту лояльности для клиента
     * 
     * @param mixed $phoneOrTypeId Номер телефона в формате 70001234567 (старый API) или ID типа карты (новый API)
     * @param string $cardNumber Номер карты (опционально для нового API)
     * @param int $cardTypeId ID типа карты лояльности (для старого API) 
     * @return array|null Данные созданной карты или null при ошибке
     */
    public function createLoyaltyCard($phoneOrTypeId, $cardNumber = null, $cardTypeId = null) {
        $url = "https://api.yclients.com/api/v1/loyalty/cards/{$this->companyId}";
        
        // Новый API: только cardTypeId и phone
        if (is_numeric($phoneOrTypeId) && $phoneOrTypeId > 1000 && $cardNumber !== null && $cardTypeId === null) {
            // Это новый формат: createLoyaltyCard($cardTypeId, $phone)
            $postData = [
                'loyalty_card_type_id' => (string)$phoneOrTypeId,
                'phone' => $cardNumber  // На самом деле это phone
            ];
        } else {
            // Старый формат: createLoyaltyCard($phone, $cardNumber, $cardTypeId)
            $postData = [
                'phone' => $phoneOrTypeId,
                'loyalty_card_number' => $cardNumber,
                'loyalty_card_type_id' => (string)$cardTypeId
            ];
        }
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Create loyalty card request: {$url}");
        error_log("Create loyalty card data: " . json_encode($postData));
        error_log("Create loyalty card response: HTTP {$httpCode}, Body: {$response}");
        
        $data = json_decode($response, true);
        
        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            return $data['data'] ?? $data;
        }
        
        if ($httpCode >= 500) {
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Failed to create loyalty card: HTTP {$httpCode}, Response: " . print_r($data, true));
        return null;
    }

    /**
     * Пополнить или списать баланс карты лояльности вручную
     * 
     * @param int $cardId ID карты лояльности
     * @param float $amount Сумма (положительная для пополнения, отрицательная для списания)
     * @param string $title Примечание к транзакции
     * @return bool Успех операции
     */
    public function modifyLoyaltyCardBalance($cardId, $amount, $title = '') {
        $url = "https://api.yclients.com/api/v1/company/{$this->companyId}/loyalty/cards/{$cardId}/manual_transaction";
        
        $postData = [
            'amount' => $amount,
            'title' => $title
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Modify loyalty card balance request: {$url}");
        error_log("Modify loyalty card balance data: " . json_encode($postData));
        error_log("Modify loyalty card balance response: HTTP {$httpCode}, Body: {$response}");
        
        $data = json_decode($response, true);
        
        if ($httpCode == 200 && isset($data['success']) && $data['success']) {
            return true;
        }
        
        if ($httpCode >= 500) {
            throw new Exception("YClients API server error: HTTP {$httpCode}");
        }
        
        error_log("Failed to modify loyalty card balance: HTTP {$httpCode}, Response: " . print_r($data, true));
        return false;
    }

    /**
     * Получить баланс карты лояльности клиента
     * 
     * @param int $clientId ID клиента в YClients
     * @return float|null Баланс карты или null если карта не найдена
     */
    public function getClientLoyaltyBalance($clientId) {
        $cards = $this->getClientLoyaltyCards($clientId);
        
        if ($cards && !empty($cards)) {
            // Берем первую карту клиента
            $card = $cards[0];
            return isset($card['balance']) ? (float)$card['balance'] : 0;
        }
        
        return null;
    }

    /**
     * Получить ID карты лояльности клиента
     * 
     * @param int $clientId ID клиента в YClients
     * @return int|null ID карты или null если карта не найдена
     */
    public function getClientLoyaltyCardId($clientId) {
        $cards = $this->getClientLoyaltyCards($clientId);
        
        if ($cards && !empty($cards)) {
            // Берем первую карту клиента
            $card = $cards[0];
            return isset($card['id']) ? (int)$card['id'] : null;
        }
        
        return null;
    }
}

?>
