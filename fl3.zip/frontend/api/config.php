<?php
require_once 'yclients_api.php';

// Database configuration
define('DB_HOST', 'e0812747d613b6f887f535bb.twc1.net');
define('DB_USER', 'gym_boss');
define('DB_PASS', '123qwe123qwe');
define('DB_NAME', 'gym');

// YCLIENTS API configuration
define('YCLIENTS_PARTNER_TOKEN', 'xknsyb4rz9jtsuh9ct3e');
define('YCLIENTS_USER_TOKEN', '54712fd1e469f220e6d95375ad796a05');
define('YCLIENTS_COMPANY_ID', '1223269');

// YCLIENTS Loyalty Cards configuration
define('LOYALTY_CARD_TYPE_ID', 95115); // ID типа карты лояльности (для баланса/кошелька)
define('LOYALTY_CARD_PREFIX', 'APP'); // Префикс для номеров карт
define('AUTO_CREATE_LOYALTY_CARDS', true); // Автоматически создавать карты при регистрации

// YCLIENTS Abonements configuration (хранятся локально в БД)
define('ABONEMENT_SINGLE_PRICE', 500);   // Цена разового посещения (₽)
define('ABONEMENT_MONTHLY_PRICE', 3000); // Цена месячного абонемента (₽)
define('ABONEMENT_SINGLE_VISITS', 1);    // Количество визитов для разового
define('ABONEMENT_MONTHLY_VISITS', 999); // Количество визитов для месячного (неограниченно)
define('ABONEMENT_MONTHLY_DAYS', 30);    // Срок действия месячного абонемента (дней)

// Product Abonements configuration (товарные абонементы)
define('PRODUCT_ABONEMENT_DEFAULT_DAYS', 60); // Срок действия по умолчанию (дней)
define('AUTO_SYNC_ABONEMENT_BALANCE', true);  // Автосинхронизация с YClients при просмотре

// YCLIENTS API functions
function getYClientsUserToken() {
    // Просто возвращаем сохраненный токен пользователя
    return YCLIENTS_USER_TOKEN;
}

$yclients = new YClientsService(YCLIENTS_PARTNER_TOKEN, YCLIENTS_USER_TOKEN, YCLIENTS_COMPANY_ID);

// App configuration
define('APP_NAME', 'Фитнес-клуб');
define('APP_ADDRESS', 'Лесная, 17');
define('APP_PHONE', '+7 (495) 123-45-67');
define('APP_EMAIL', 'info@fitmassive.ru');

// T-Kassa configuration
// Продакшн данные (закомментированы):
define('TKASSA_TERMINAL', '1747823051140');
define('TKASSA_PASSWORD', 'E$MM3CcC$rQp^Q2_');

// Демо данные:
// define('TKASSA_TERMINAL', '1747823051118DEMO');
// define('TKASSA_PASSWORD', '5ZG0aA#rYT5U$ZwG');
define('TKASSA_MERCHANT_NAME', 'MYGYM');
define('TKASSA_MERCHANT_ID', '200000001602402');
define('TKASSA_TERMINAL_ID', '25706773');
define('TKASSA_SBP_MERCHANT_ID', 'MA0004759842');
define('TKASSA_TOKEN', 'your_api_token_here'); // API Token для T-Bank API v2 - получите в личном кабинете T-Бизнес

define('TELEGRAM_BOT_TOKEN', '8358208069:AAG05RGdoPli0oBQ4os0tqLLrg291YEkjJo');
define('TELEGRAM_BOT_USERNAME', 'relight_dev_test_bot'); // Username бота без @
define('WEBSITE_URL', 'https://t.me/relight_dev_test_bot');

// Session lifetime in seconds (30 days)
define('SESSION_LIFETIME', 60 * 60 * 24 * 30);

// Start session
session_start();

// Database connection
function getDbConnection() {
    $conn = mysqli_init();

    // Configure SSL connection
    $ssl_ca = __DIR__ . '/../ca.crt';
    
    // Проверяем существование файла сертификата
    if (file_exists($ssl_ca)) {
        $conn->ssl_set(NULL, NULL, $ssl_ca, NULL, NULL);
        // Connect with SSL
        $conn->real_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, NULL, NULL, MYSQLI_CLIENT_SSL);
    } else {
        // Подключение без SSL если сертификат не найден
        error_log('SSL certificate not found at: ' . $ssl_ca . ', connecting without SSL');
        $conn->real_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    }

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");
    return $conn;
}

// Special functions

function getStaff() {
    global $yclients;
    
    $cache_key = "staff_list";
    $cache_dir = __DIR__ . '/../cache';
    $cache_file = $cache_dir . '/' . $cache_key . '.json';
    $cache_time = 3600; // 1 час

    if (!is_dir($cache_dir)) {
        mkdir($cache_dir, 0777, true);
    }

    // Проверяем кэш
    if (file_exists($cache_file) && (time() - filemtime($cache_file)) < $cache_time) {
        $cached_data = file_get_contents($cache_file);
        $staffList = json_decode($cached_data, true);
        if (!empty($staffList)) {
            return $staffList;
        }
    }

    // Получаем список сотрудников напрямую через API
    try {
        $staffList = $yclients->getStaff();
        
        // Кэшируем результат, только если получили данные
        if (!empty($staffList)) {
            file_put_contents($cache_file, json_encode($staffList));
        }
        
        return $staffList;
    } catch (Exception $e) {
        error_log("Error fetching staff: " . $e->getMessage());
        
        // Возвращаем старый кэш если есть, даже если он устарел
        if (file_exists($cache_file)) {
            $cached_data = file_get_contents($cache_file);
            $staffList = json_decode($cached_data, true);
            if (!empty($staffList)) {
                return $staffList;
            }
        }
        
        return [];
    }
}

function getShopItems($filter = 'all', $page = 1, $count = 100) {
    global $yclients;

    $cache_key = "shop_items_{$filter}_{$page}_{$count}";
    $cache_dir = __DIR__ . '/../cache';
    $cache_file = $cache_dir . '/' . $cache_key . '.json';
    $cache_time = 3600; // 1 час

    if (!is_dir($cache_dir)) {
        mkdir($cache_dir, 0777, true);
    }

    if (file_exists($cache_file) && (time() - filemtime($cache_file)) < $cache_time) {
        $cached_data = file_get_contents($cache_file);
        return json_decode($cached_data, true);
    }

    $response = $yclients->getShopItems($filter, $page, $count);

    if ($response['success'] && !empty($response['data'])) {
        $items = [];
        $categories = [];
        
        foreach ($response['data'] as $item) {
            $items[] = [
                'id' => $item['good_id'],
                'title' => $item['title'],
                'price' => $item['cost'],
                'description' => $item['comment'] ?? '',
                'category' => $item['category'],
                'category_id' => $item['category_id'],
                'image' => $item['image_url'] ?? 'images/gym-banner.jpg'
            ];
            if (!isset($categories[$item['category_id']])) {
                $categories[$item['category_id']] = $item['category'];
            }
        }
        
        // Сортируем категории по ключу (ID)
        ksort($categories);

        $result = ['items' => $items, 'categories' => $categories];

        file_put_contents($cache_file, json_encode($result));

        return $result;
    }

    return ['items' => [], 'categories' => []];
}


function getSpecialOffers() {
    global $yclients;

    $cache_key = "special_offers";
    $cache_dir = __DIR__ . '/../cache';
    $cache_file = $cache_dir . '/' . $cache_key . '.json';
    $cache_time = 3600; // 1 час

    if (!is_dir($cache_dir)) {
        mkdir($cache_dir, 0777, true);
    }

    if (file_exists($cache_file) && (time() - filemtime($cache_file)) < $cache_time) {
        $cached_data = file_get_contents($cache_file);
        return json_decode($cached_data, true);
    }

    $response = $yclients->getSpecialOffers();

    if (isset($response['success']) && $response['success'] && !empty($response['data'])) {
        $offers = [];
        foreach ($response['data'] as $item) {
            $offers[] = [
                'id' => $item['id'],
                'title' => $item['title'],
                'description' => $item['description'] ?? '',
                'price' => $item['price'] ?? 0,
                'original_price' => $item['original_price'] ?? $item['price'],
                'discount_percent' => $item['discount_percent'] ?? 0,
                'image' => $item['image_url'] ?? 'Images/gym-banner.jpg',
                'category' => $item['category'] ?? '',
                'unit_format' => $item['unit_format'] ?? ''
            ];
        }
        file_put_contents($cache_file, json_encode($offers));
        return $offers;
    }

    return [];
}

// Get notifications for user (использует Notifications API)
function getUserNotifications($userId) {
    require_once 'notifications.php';
    $notificationsAPI = new NotificationsAPI();
    return $notificationsAPI->getUserNotifications($userId);
}

// Mark notification as read (использует Notifications API)
function markNotificationAsRead($notificationId) {
    require_once 'notifications.php';
    $notificationsAPI = new NotificationsAPI();
    return $notificationsAPI->markNotificationAsRead($notificationId);
}

// Add notification for user (использует Notifications API)
function addNotification($userId, $title, $text) {
    require_once 'notifications.php';
    $notificationsAPI = new NotificationsAPI();
    return $notificationsAPI->addNotification($userId, $title, $text);
}

// User functions (используют User API)
function getUserByTelegramId($telegramId) {
    require_once 'user.php';
    $userAPI = new UserAPI();
    return $userAPI->getUserByTelegramId($telegramId);
}

function getUserByPhone($phone) {
    require_once 'user.php';
    $userAPI = new UserAPI();
    return $userAPI->getUserByPhone($phone);
}

function getUserById($id) {
    require_once 'user.php';
    $userAPI = new UserAPI();
    return $userAPI->getUserById($id);
}

function createUser($userData) {
    require_once 'user.php';
    $userAPI = new UserAPI();
    return $userAPI->createUser($userData);
}

function updateUser($userId, $userData) {
    require_once 'user.php';
    $userAPI = new UserAPI();
    return $userAPI->updateUser($userId, $userData);
}

// Authentication functions
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    $user = getUserById($_SESSION['user_id']);
    
    // If user doesn't exist in database, logout
    if (!$user) {
        logout();
        return null;
    }
    
    // Получить актуальный баланс из карты лояльности YClients
    if ($user['yclients_client_id']) {
        require_once __DIR__ . '/user.php';
        $userAPI = new UserAPI();
        $loyaltyBalance = $userAPI->getUserLoyaltyBalance($user['id']);
        
        // Обновляем баланс в массиве пользователя
        if ($loyaltyBalance !== null) {
            $user['balance'] = $loyaltyBalance;
        }
    }
    
    return $user;
}

function login($userId = null) {
    // If no userId provided, create a test user or use default
    if ($userId === null) {
        // Check if we already have a test user in session
        if (isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
        } else {
            // Create a test user with ID 1 for demo purposes
            $userId = 1;
        }
    }

    $_SESSION['user_id'] = $userId;
    $_SESSION['last_activity'] = time();
    
    // Регенерируем ID сессии для безопасности
    session_regenerate_id(true);
}

function logout() {
    $_SESSION = array();
    
    // Уничтожаем cookie сессии
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-3600, '/');
    }
    
    session_destroy();
}

/**
 * Попытка автоматической авторизации через Telegram
 * Используется на страницах, где нужна авторизация
 */
function tryTelegramAutoAuth() {
    // Если уже авторизован, ничего не делаем
    if (isLoggedIn()) {
        return true;
    }
    
    // Проверяем наличие Telegram initData в заголовках или параметрах
    $initData = null;
    
    if (isset($_GET['tgWebAppData'])) {
        $initData = $_GET['tgWebAppData'];
    } elseif (isset($_POST['tgWebAppData'])) {
        $initData = $_POST['tgWebAppData'];
    } elseif (isset($_SERVER['HTTP_X_TELEGRAM_INIT_DATA'])) {
        $initData = $_SERVER['HTTP_X_TELEGRAM_INIT_DATA'];
    }
    
    if ($initData) {
        require_once __DIR__ . '/telegram_auth.php';
        $user = TelegramAuth::authenticateUser($initData);
        return $user !== null;
    }
    
    return false;
}

/**
 * Проверить авторизацию с поддержкой Telegram WebApp
 * Показывает экран загрузки для Telegram, редиректит для обычных браузеров
 */
function requireAuth() {
    // Попытка авто-авторизации через Telegram
    tryTelegramAutoAuth();
    
    // Check if user is logged in
    if (!isLoggedIn()) {
        // Проверяем, это Telegram WebApp или обычный браузер
        $isTelegramWebApp = isset($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN']) || 
                           isset($_GET['tgWebAppData']) || 
                           isset($_POST['tgWebAppData']) ||
                           (isset($_SERVER['HTTP_USER_AGENT']) && strpos($_SERVER['HTTP_USER_AGENT'], 'Telegram') !== false);
        
        if ($isTelegramWebApp) {
            // Показываем экран загрузки и даем время JS для авторизации
            showTelegramAuthScreen();
            exit;
        } else {
            // Обычный браузер - редиректим на index.php
            redirect('index.php');
        }
    }
    
    // Get current user
    $user = getCurrentUser();
    if (!$user) {
        logout();
        redirect('index.php');
    }
    
    return $user;
}

/**
 * Показать экран авторизации для Telegram WebApp
 */
function showTelegramAuthScreen() {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Авторизация...</title>
        <style>
            body {
                margin: 0;
                padding: 0;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: var(--tg-theme-bg-color, #ffffff);
                color: var(--tg-theme-text-color, #000000);
            }
            .auth-screen {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
            .auth-content {
                text-align: center;
            }
            .auth-text {
                margin-bottom: 20px;
                font-size: 16px;
                color: var(--tg-theme-hint-color, #999);
            }
            .spinner {
                border: 4px solid rgba(113, 113, 220, 0.1);
                border-top: 4px solid #7171dc;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                animation: spin 1s linear infinite;
                margin: 0 auto;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
    </head>
    <body>
        <div class="auth-screen">
            <div class="auth-content">
                <div class="auth-text">Авторизация...</div>
                <div class="spinner"></div>
            </div>
        </div>
        <?php include __DIR__ . '/../components/telegram_auth_check.php'; ?>
        <script>
            // Ждем авторизацию, затем перезагружаем
            setTimeout(function() {
                console.log('Reloading page after auth attempt...');
                window.location.reload();
            }, 2500);
        </script>
    </body>
    </html>
    <?php
}

// Check session timeout
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_LIFETIME)) {
    logout();
}

if (isset($_SESSION['user_id'])) {
    $_SESSION['last_activity'] = time();
}

// Helper functions
function redirect($url) {
    header("Location: $url");
    exit;
}

function jsonResponse($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function cleanPhoneNumber($phone) {
    // Remove all non-digits to store clean phone number in database
    return preg_replace('/\D/', '', $phone);
}

function formatPhoneNumber($phone) {
    // Remove all non-digits
    $cleaned = preg_replace('/\D/', '', $phone);
    
    // If phone starts with 7 (Russian country code), remove it since we'll add +7
    if (strlen($cleaned) >= 10 && substr($cleaned, 0, 1) === '7') {
        $cleaned = substr($cleaned, 1);
    }

    // Format the phone number
    if (strlen($cleaned) <= 3) {
        return "+7 ($cleaned";
    } elseif (strlen($cleaned) <= 6) {
        return "+7 (" . substr($cleaned, 0, 3) . ") " . substr($cleaned, 3);
    } elseif (strlen($cleaned) <= 8) {
        return "+7 (" . substr($cleaned, 0, 3) . ") " . substr($cleaned, 3, 3) . "-" . substr($cleaned, 6);
    } else {
        return "+7 (" . substr($cleaned, 0, 3) . ") " . substr($cleaned, 3, 3) . "-" . substr($cleaned, 6, 2) . "-" . substr($cleaned, 8, 2);
    }
}
?>
