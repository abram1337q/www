<?php
require_once 'config.php';

// Allow requests from any origin
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$filter = $_GET['category_id'] ?? 'all';
$page = $_GET['page'] ?? 1;
$count = $_GET['count'] ?? 100;

$shop_data = getShopItems($filter, $page, $count);
$special_offers = getSpecialOffers();

// Получаем полные данные товаров из YClients для проверки loyalty_abonement_type_id
global $yclients;
$fullProductsData = [];

try {
    $url = "https://api.yclients.com/api/v1/goods/" . YCLIENTS_COMPANY_ID . "/?page=1&count=100";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $yclients->getPublicHeaders());
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 200) {
        $data = json_decode($response, true);
        if (isset($data['success']) && $data['success'] && !empty($data['data'])) {
            foreach ($data['data'] as $item) {
                $fullProductsData[$item['good_id']] = $item;
            }
        }
    }
} catch (Exception $e) {
    error_log("Error fetching full products data: " . $e->getMessage());
}

// Обогащаем данные товаров информацией об абонементах
foreach ($shop_data['items'] as &$item) {
    $productId = $item['id'] ?? $item['good_id'] ?? null;
    if ($productId && isset($fullProductsData[$productId])) {
        $fullData = $fullProductsData[$productId];
        $item['is_abonement'] = !empty($fullData['loyalty_abonement_type_id']);
        $item['abonement_type_id'] = $fullData['loyalty_abonement_type_id'] ?? null;
        
        // Извлекаем количество из названия
        if ($item['is_abonement'] && preg_match('/(\d+)\s*(шт|штук)/ui', $item['title'], $matches)) {
            $item['quantity'] = (int)$matches[1];
        } else if ($item['is_abonement']) {
            $item['quantity'] = 1;
        }
    } else {
        $item['is_abonement'] = false;
    }
}

// Combine offers into the items list, marking them as special
foreach ($special_offers as &$offer) {
    $offer['is_special'] = true;
    $offer['category'] = 'Акции'; // Assign a category for special offers
    
    // Проверяем, является ли акция абонементом
    $productId = $offer['id'] ?? $offer['good_id'] ?? null;
    if ($productId && isset($fullProductsData[$productId])) {
        $fullData = $fullProductsData[$productId];
        $offer['is_abonement'] = !empty($fullData['loyalty_abonement_type_id']);
        $offer['abonement_type_id'] = $fullData['loyalty_abonement_type_id'] ?? null;
        
        if ($offer['is_abonement'] && preg_match('/(\d+)\s*(шт|штук)/ui', $offer['title'], $matches)) {
            $offer['quantity'] = (int)$matches[1];
        } else if ($offer['is_abonement']) {
            $offer['quantity'] = 1;
        }
    } else {
        $offer['is_abonement'] = false;
    }
}

// Prepend special offers to the list of items
$all_items = array_merge($special_offers, $shop_data['items']);

$categories = $shop_data['categories'];
if (!empty($special_offers)) {
    // Add "Акции" as a category if there are any special offers
    $categories = ['special' => 'Акции'] + $categories;
}


$response_data = [
    'items' => $all_items,
    'categories' => $categories
];

echo json_encode($response_data);
?>
