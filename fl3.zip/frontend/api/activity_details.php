<?php
header('Content-Type: application/json');
require_once 'config.php';

// Проверка авторизации
try {
    $user = requireAuth();
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

// Получаем ID активности
$activityId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$activityId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Activity ID is required']);
    exit;
}

global $yclients;

try {
    $details = $yclients->getActivityDetails($activityId);
    
    if ($details) {
        // Форматируем данные для фронтенда
        $dateTime = new DateTime($details['date']);
        $endTime = clone $dateTime;
        $endTime->modify('+' . $details['length'] . ' seconds');
        
        $response = [
            'success' => true,
            'data' => [
                'id' => $details['id'],
                'time' => $dateTime->format('H:i') . ' - ' . $endTime->format('H:i'),
                'duration' => ($details['length'] / 60) . ' мин',
                'trainer' => [
                    'name' => $details['staff']['name'] ?? 'Тренер',
                    'photo' => $details['staff']['avatar_big'] ?? 'Images/trainer.jpg'
                ],
                'capacity' => $details['capacity'] ?? 10,
                'records_count' => $details['records_count'] ?? 0
            ]
        ];
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Activity not found']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>

