<?php
require_once 'config.php';

class UserAPI {
    private $conn;
    private $database;

    public function __construct() {
        $this->conn = getDbConnection();
        // Database will be created lazily to avoid circular dependencies
    }

    /**
     * Get Database instance (lazy initialization)
     */
    private function getDatabase() {
        if (!$this->database) {
            require_once 'database.php';
            $this->database = new Database();
        }
        return $this->database;
    }

    /**
     * Убеждаемся, что необходимые таблицы существуют
     */
    private function ensureTablesExist() {
        $this->getDatabase()->createUsersTable();
    }

    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }

    /**
     * Получить пользователя по Telegram ID
     */
    public function getUserByTelegramId($telegramId) {
        // Ensure tables exist before querying
        $this->ensureTablesExist();
        
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE telegram_id = ?");
        $stmt->bind_param("i", $telegramId);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        return $user;
    }

    /**
     * Получить пользователя по телефону
     */
    public function getUserByPhone($phone) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE phone = ?");
        $stmt->bind_param("s", $phone);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        return $user;
    }

    /**
     * Получить баланс пользователя из карты лояльности YClients
     * 
     * @param int $userId ID пользователя в локальной БД
     * @return float|null Баланс или null если карта не найдена
     */
    public function getUserLoyaltyBalance($userId) {
        $user = $this->getUserById($userId);
        
        if (!$user || !$user['yclients_client_id']) {
            error_log("User {$userId} not found or has no YClients client ID");
            return null;
        }
        
        global $yclients;
        if (!$yclients) {
            error_log("YClients API not available");
            return null;
        }
        
        try {
            $balance = $yclients->getClientLoyaltyBalance($user['yclients_client_id']);
            return $balance;
        } catch (Exception $e) {
            error_log("Failed to get loyalty balance for user {$userId}: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Получить ID карты лояльности пользователя
     * 
     * @param int $userId ID пользователя в локальной БД
     * @return int|null ID карты или null если карта не найдена
     */
    public function getUserLoyaltyCardId($userId) {
        $user = $this->getUserById($userId);
        
        if (!$user || !$user['yclients_client_id']) {
            return null;
        }
        
        global $yclients;
        if (!$yclients) {
            return null;
        }
        
        try {
            $cardId = $yclients->getClientLoyaltyCardId($user['yclients_client_id']);
            return $cardId;
        } catch (Exception $e) {
            error_log("Failed to get loyalty card ID for user {$userId}: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Создать карту лояльности для пользователя
     * 
     * @param int $userId ID пользователя в локальной БД
     * @return array|null Данные созданной карты или null при ошибке
     */
    public function createLoyaltyCardForUser($userId) {
        $user = $this->getUserById($userId);
        
        if (!$user || !$user['yclients_client_id']) {
            error_log("Cannot create loyalty card: user {$userId} not found or has no YClients client ID");
            return null;
        }

        // Проверяем есть ли уже карта
        $existingCardId = $this->getUserLoyaltyCardId($userId);
        if ($existingCardId) {
            error_log("Loyalty card already exists for user {$userId}: card ID {$existingCardId}");
            return null;
        }

        // Проверяем наличие телефона
        if (empty($user['phone'])) {
            error_log("Cannot create loyalty card: user {$userId} has no phone number");
            return null;
        }

        // Проверяем наличие LOYALTY_CARD_TYPE_ID
        if (!defined('LOYALTY_CARD_TYPE_ID') || LOYALTY_CARD_TYPE_ID <= 0) {
            error_log("Cannot create loyalty card: LOYALTY_CARD_TYPE_ID not defined");
            return null;
        }

        // Форматируем телефон (нужен формат 70001234567)
        $phone = preg_replace('/\D/', '', $user['phone']);
        $phone = preg_replace('/^8/', '7', $phone);
        if (!preg_match('/^7/', $phone) && strlen($phone) == 10) {
            $phone = '7' . $phone;
        }

        // Генерируем номер карты
        $cardPrefix = defined('LOYALTY_CARD_PREFIX') ? LOYALTY_CARD_PREFIX : 'APP';
        $cardNumber = $cardPrefix . str_pad($userId, 8, '0', STR_PAD_LEFT);

        // Создаем карту
        global $yclients;
        try {
            $cardData = $yclients->createLoyaltyCard($phone, $cardNumber, LOYALTY_CARD_TYPE_ID);
            
            if ($cardData) {
                error_log("Created loyalty card for user {$userId}: card ID {$cardData['id']}, number {$cardNumber}");
                return $cardData;
            } else {
                error_log("Failed to create loyalty card for user {$userId}");
                return null;
            }
        } catch (Exception $e) {
            error_log("Error creating loyalty card for user {$userId}: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Получить пользователя по ID
     */
    public function getUserById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        return $user;
    }

    /**
     * Создать нового пользователя
     */
    public function createUser($userData) {
        // Ensure tables exist before creating user
        $this->ensureTablesExist();
        
        // First, try to create a YClients client
        global $yclients;
        $yclientsClient = $yclients ? $yclients->createClient($userData) : null;
        $yclientsClientId = $yclientsClient ? $yclientsClient['id'] : null;

        // Set default values if not provided
        $phone = isset($userData['phone']) ? $userData['phone'] : '';
        $username = isset($userData['username']) ? $userData['username'] : '';
        $photoUrl = isset($userData['photo_url']) ? $userData['photo_url'] : '';
        $balance = isset($userData['balance']) ? $userData['balance'] : 0;

        $stmt = $this->conn->prepare("INSERT INTO users (telegram_id, yclients_client_id, first_name, last_name, username, phone, photo_url, balance) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisssssi",
            $userData['telegram_id'],
            $yclientsClientId,
            $userData['first_name'],
            $userData['last_name'],
            $username,
            $phone,
            $photoUrl,
            $balance
        );
        
        if (!$stmt->execute()) {
            error_log('Failed to create user: ' . $stmt->error);
            $stmt->close();
            return null;
        }
        
        $userId = $stmt->insert_id;
        $stmt->close();

        $user = $this->getUserById($userId);

        // Автоматически создаем карту лояльности если настроено
        if ($user && $yclientsClientId) {
            $autoCreate = defined('AUTO_CREATE_LOYALTY_CARDS') ? AUTO_CREATE_LOYALTY_CARDS : false;
            
            if ($autoCreate) {
                $cardData = $this->createLoyaltyCardForUser($userId);
                if ($cardData) {
                    error_log("Auto-created loyalty card for new user {$userId}");
                }
            }
        }

        return $user;
    }

    /**
     * Обновить данные пользователя
     */
    public function updateUser($userId, $userData) {
        // First, get the current user to check if we need to create/update YClients client
        $currentUser = $this->getUserById($userId);

        // Если у пользователя нет yclients_client_id и передан телефон - создаем клиента в YClients
        if ($currentUser && !$currentUser['yclients_client_id'] && isset($userData['phone']) && !empty($userData['phone'])) {
            global $yclients;
            
            // Prepare data for YClients client creation
            $clientData = [
                'name' => ($userData['first_name'] ?? $currentUser['first_name']) . ' ' . ($userData['last_name'] ?? $currentUser['last_name']),
                'phone' => $userData['phone'],
                'email' => $userData['email'] ?? $currentUser['email'] ?? ''
            ];

            try {
                $yclientsClient = $yclients->createClient($clientData);
                
                if ($yclientsClient && isset($yclientsClient['id'])) {
                    // Сохраняем yclients_client_id
                    $userData['yclients_client_id'] = $yclientsClient['id'];
                    error_log("Created YClients client {$yclientsClient['id']} for user {$userId}");
                    
                    // Автоматически создаем карту лояльности если настроено
                    $autoCreate = defined('AUTO_CREATE_LOYALTY_CARDS') ? AUTO_CREATE_LOYALTY_CARDS : false;
                    if ($autoCreate) {
                        // Обновим пользователя сначала, чтобы у него был yclients_client_id
                        $tempUpdateFields = ["yclients_client_id = ?", "updated_at = NOW()"];
                        $tempStmt = $this->conn->prepare("UPDATE users SET " . implode(", ", $tempUpdateFields) . " WHERE id = ?");
                        $tempStmt->bind_param("ii", $yclientsClient['id'], $userId);
                        $tempStmt->execute();
                        $tempStmt->close();
                        
                        // Теперь создаем карту
                        $cardData = $this->createLoyaltyCardForUser($userId);
                        if ($cardData) {
                            error_log("Auto-created loyalty card for user {$userId} after phone update");
                        }
                    }
                }
            } catch (Exception $e) {
                error_log("Error creating YClients client for user {$userId}: " . $e->getMessage());
            }
        }

        $updateFields = [];
        $updateValues = [];
        $types = "";

        if (isset($userData['first_name'])) {
            $updateFields[] = "first_name = ?";
            $updateValues[] = $userData['first_name'];
            $types .= "s";
        }

        if (isset($userData['last_name'])) {
            $updateFields[] = "last_name = ?";
            $updateValues[] = $userData['last_name'];
            $types .= "s";
        }

        if (isset($userData['username'])) {
            $updateFields[] = "username = ?";
            $updateValues[] = $userData['username'];
            $types .= "s";
        }

        if (isset($userData['phone'])) {
            $updateFields[] = "phone = ?";
            $updateValues[] = $userData['phone'];
            $types .= "s";
        }

        if (isset($userData['email'])) {
            $updateFields[] = "email = ?";
            $updateValues[] = $userData['email'];
            $types .= "s";
        }

        if (isset($userData['photo_url'])) {
            $updateFields[] = "photo_url = ?";
            $updateValues[] = $userData['photo_url'];
            $types .= "s";
        }

        if (isset($userData['balance'])) {
            $updateFields[] = "balance = ?";
            $updateValues[] = $userData['balance'];
            $types .= "i";
        }

        if (isset($userData['yclients_client_id'])) {
            $updateFields[] = "yclients_client_id = ?";
            $updateValues[] = $userData['yclients_client_id'];
            $types .= "i";
        }

        if (empty($updateFields)) {
            return false;
        }

        $updateFields[] = "updated_at = NOW()";

        $sql = "UPDATE users SET " . implode(", ", $updateFields) . " WHERE id = ?";
        $stmt = $this->conn->prepare($sql);

        $updateValues[] = $userId;
        $types .= "i";

        $stmt->bind_param($types, ...$updateValues);
        $result = $stmt->execute();
        $stmt->close();

        return $result ? $this->getUserById($userId) : false;
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';

    $userAPI = new UserAPI();

    switch ($action) {
        case 'getByTelegramId':
            if (isset($_GET['telegram_id'])) {
                $user = $userAPI->getUserByTelegramId((int)$_GET['telegram_id']);
                jsonResponse($user);
            }
            break;

        case 'getByPhone':
            if (isset($_GET['phone'])) {
                $user = $userAPI->getUserByPhone($_GET['phone']);
                jsonResponse($user);
            }
            break;

        case 'getById':
            if (isset($_GET['id'])) {
                $user = $userAPI->getUserById((int)$_GET['id']);
                jsonResponse($user);
            }
            break;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    $userAPI = new UserAPI();

    switch ($action) {
        case 'create':
            if (isset($_POST['userData'])) {
                $userData = json_decode($_POST['userData'], true);
                $user = $userAPI->createUser($userData);
                jsonResponse($user);
            }
            break;

        case 'update':
            if (isset($_POST['userId']) && isset($_POST['userData'])) {
                $userId = (int)$_POST['userId'];
                $userData = json_decode($_POST['userData'], true);
                $user = $userAPI->updateUser($userId, $userData);
                jsonResponse($user);
            }
            break;
    }
}
?>
