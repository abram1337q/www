<?php
require_once 'config.php';
require_once 'user.php';
require_once 'notifications.php';

class DatabaseSeeder {
    private $conn;
    private $userAPI;
    private $notificationsAPI;

    public function __construct() {
        $this->conn = getDbConnection();
        $this->userAPI = new UserAPI();
        $this->notificationsAPI = new NotificationsAPI();
    }

    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }

    /**
     * Заполнение пользователей тестовыми данными
     */
    public function seedUsers() {
        $testUsers = [
            [
                'telegram_id' => 123456789,
                'first_name' => 'Тестовый',
                'last_name' => 'Пользователь',
                'phone' => '+7(999)999-99-99',
                'email' => 'test@example.com',
                'balance' => 5000
            ],
            [
                'telegram_id' => 987654321,
                'first_name' => 'Администратор',
                'last_name' => 'Системы',
                'phone' => '+7(999)999-99-98',
                'email' => 'admin@example.com',
                'balance' => 10000
            ]
        ];

        $createdUsers = [];
        foreach ($testUsers as $userData) {
            // Проверяем, существует ли пользователь
            $existingUser = $this->userAPI->getUserByTelegramId($userData['telegram_id']);
            if (!$existingUser) {
                $user = $this->userAPI->createUser($userData);
                if ($user) {
                    $createdUsers[] = $user;
                }
            }
        }

        return $createdUsers;
    }

    /**
     * Заполнение уведомлений тестовыми данными
     */
    public function seedNotifications() {
        // Получаем первого пользователя
        $testUser = $this->userAPI->getUserByTelegramId(123456789);
        if (!$testUser) {
            return false;
        }

        $testNotifications = [
            [
                'user_id' => $testUser['id'],
                'title' => 'Добро пожаловать!',
                'text' => 'Добро пожаловать в наш фитнес-клуб! Мы рады видеть вас среди наших клиентов.',
                'is_read' => false
            ],
            [
                'user_id' => $testUser['id'],
                'title' => 'Новая тренировка',
                'text' => 'Завтра в 10:00 у вас тренировка Yoga с тренером Петровой Марией',
                'is_read' => false
            ],
            [
                'user_id' => $testUser['id'],
                'title' => 'Специальное предложение',
                'text' => 'Скидка 20% на абонемент Full при покупке до конца недели',
                'is_read' => false
            ],
            [
                'user_id' => $testUser['id'],
                'title' => 'Изменение в расписании',
                'text' => 'Тренировка Cycle перенесена на 15:00',
                'is_read' => true
            ]
        ];

        $createdNotifications = [];
        foreach ($testNotifications as $notificationData) {
            $notificationId = $this->notificationsAPI->addNotification(
                $notificationData['user_id'],
                $notificationData['title'],
                $notificationData['text']
            );
            if ($notificationId) {
                $createdNotifications[] = $notificationId;
            }
        }

        return $createdNotifications;
    }

    /**
     * Создание дополнительных тестовых данных для разработки
     */
    public function seedDevelopmentData() {
        // Здесь можно добавить дополнительные тестовые данные
        // Например, больше пользователей, уведомлений и т.д.
        return true;
    }

    /**
     * Полная инициализация базы данных с тестовыми данными
     */
    public function seed() {
        $results = [];

        // Заполняем пользователей
        $users = $this->seedUsers();
        $results['users'] = count($users);

        // Заполняем уведомления
        $notifications = $this->seedNotifications();
        $results['notifications'] = count($notifications);

        // Заполняем дополнительные данные
        $devData = $this->seedDevelopmentData();
        $results['development_data'] = $devData;

        return $results;
    }

    /**
     * Очистка всех данных (для тестирования)
     */
    public function truncate() {
        $tables = ['notifications', 'balance_history', 'orders', 'users'];

        foreach ($tables as $table) {
            $this->conn->query("SET FOREIGN_KEY_CHECKS = 0");
            $this->conn->query("TRUNCATE TABLE $table");
            $this->conn->query("SET FOREIGN_KEY_CHECKS = 1");
        }

        return true;
    }

    /**
     * Перезагрузка данных (очистка + заполнение)
     */
    public function refresh() {
        $this->truncate();
        return $this->seed();
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    $seeder = new DatabaseSeeder();

    switch ($action) {
        case 'seed':
            $results = $seeder->seed();
            jsonResponse(['success' => true, 'results' => $results]);
            break;

        case 'seedUsers':
            $users = $seeder->seedUsers();
            jsonResponse(['success' => true, 'users_count' => count($users)]);
            break;

        case 'seedNotifications':
            $notifications = $seeder->seedNotifications();
            jsonResponse(['success' => true, 'notifications_count' => count($notifications)]);
            break;

        case 'truncate':
            $result = $seeder->truncate();
            jsonResponse(['success' => $result, 'message' => 'All data truncated']);
            break;

        case 'refresh':
            $results = $seeder->refresh();
            jsonResponse(['success' => true, 'results' => $results]);
            break;
    }
}

// CLI interface for seeding
if (php_sapi_name() === 'cli') {
    $action = $argv[1] ?? 'help';

    $seeder = new DatabaseSeeder();

    switch ($action) {
        case 'seed':
            echo "Seeding database...\n";
            $results = $seeder->seed();
            echo "Seeding completed:\n";
            echo "- Users: {$results['users']}\n";
            echo "- Notifications: {$results['notifications']}\n";
            break;

        case 'refresh':
            echo "Refreshing database...\n";
            $results = $seeder->refresh();
            echo "Refresh completed:\n";
            echo "- Users: {$results['users']}\n";
            echo "- Notifications: {$results['notifications']}\n";
            break;

        case 'truncate':
            echo "Truncating database...\n";
            $seeder->truncate();
            echo "Truncation completed.\n";
            break;

        default:
            echo "Usage: php seed.php [seed|refresh|truncate]\n";
            echo "  seed     - Add test data to existing database\n";
            echo "  refresh  - Truncate and reseed database\n";
            echo "  truncate - Remove all data from database\n";
            break;
    }
}
?>
