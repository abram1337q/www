<?php
/**
 * API endpoint для проверки статуса платежа
 * Используется для Ajax polling на фронтенде
 */

require_once '../config.php';
require_once 'orders.php';
require_once 'tkassa_api.php';
require_once 'balance.php';

header('Content-Type: application/json');

// Проверка авторизации
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$orderId = $_GET['order_id'] ?? '';

if (!$orderId) {
    http_response_code(400);
    echo json_encode(['error' => 'Order ID required']);
    exit;
}

$currentUser = getCurrentUser();
$ordersAPI = new OrdersAPI();
$order = $ordersAPI->getOrderByOrderId($orderId);

if (!$order) {
    http_response_code(404);
    echo json_encode(['error' => 'Order not found']);
    exit;
}

// Проверка что заказ принадлежит текущему пользователю
if ($order['user_id'] != $currentUser['id']) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied']);
    exit;
}

// Если статус уже completed/failed - возвращаем его
if ($order['status'] === 'completed') {
    echo json_encode([
        'status' => 'completed',
        'amount' => $order['amount'],
        'message' => 'Платеж успешно завершен'
    ]);
    exit;
}

if ($order['status'] === 'failed') {
    echo json_encode([
        'status' => 'failed',
        'message' => 'Платеж отклонен'
    ]);
    exit;
}

// Если pending - проверяем в T-Bank
$tkassaAPI = new TKassaAPI();
$paymentStatus = $tkassaAPI->getPaymentStatus($orderId);

if (!$paymentStatus) {
    echo json_encode([
        'status' => 'pending',
        'message' => 'Проверка статуса...'
    ]);
    exit;
}

$status = $paymentStatus['Status'] ?? null;

// Обрабатываем статус из T-Bank
if ($status === 'CONFIRMED' || $status === 'AUTHORIZED') {
    // Пополняем баланс
    $balanceAPI = new BalanceAPI();
    $updatedUser = $balanceAPI->rechargeBalance($order['user_id'], (int)$order['amount']);
    
    if ($updatedUser) {
        $ordersAPI->updateOrderStatus($orderId, 'completed');
        
        // Отправляем уведомление
        require_once 'notifications.php';
        $notificationsAPI = new NotificationsAPI();
        $notificationsAPI->addNotification(
            $order['user_id'],
            'Баланс пополнен',
            "Ваш баланс успешно пополнен на {$order['amount']} ₽"
        );
        
        echo json_encode([
            'status' => 'completed',
            'amount' => $order['amount'],
            'message' => 'Платеж успешно завершен!'
        ]);
        exit;
    }
}

if (in_array($status, ['CANCELED', 'REJECTED', 'REVERSED', 'DEADLINE_EXPIRED'])) {
    $ordersAPI->updateOrderStatus($orderId, 'failed');
    
    echo json_encode([
        'status' => 'failed',
        'message' => 'Платеж отклонен или отменен'
    ]);
    exit;
}

// Если статус NEW, FORM_SHOWED и т.д. - платеж еще в процессе
echo json_encode([
    'status' => 'pending',
    'message' => 'Платеж обрабатывается...',
    'tkassa_status' => $status
]);
?>

