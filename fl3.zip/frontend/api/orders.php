<?php
require_once 'config.php';

class OrdersAPI {
    private $conn;
    private $database;

    public function __construct() {
        $this->conn = getDbConnection();
        // Database will be created lazily to avoid circular dependencies
    }

    /**
     * Get Database instance (lazy initialization)
     */
    private function getDatabase() {
        if (!$this->database) {
            require_once 'database.php';
            $this->database = new Database();
        }
        return $this->database;
    }

    /**
     * Убеждаемся, что необходимые таблицы существуют
     */
    private function ensureTablesExist() {
        $this->getDatabase()->createUsersTable();
        $this->getDatabase()->createOrdersTable();
    }

    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }

    /**
     * Создать новый заказ
     */
    public function createOrder($orderData) {
        // Поддержка как нового формата (массив), так и старого (параметры)
        if (is_array($orderData)) {
            // Новый формат - массив данных
            $orderId = $orderData['order_id']; // Используем переданный order_id как первичный ключ
            $userId = $orderData['user_id'];
            $amount = $orderData['amount'];
            $status = $orderData['status'] ?? 'pending';
            $paymentMethod = $orderData['payment_method'] ?? 'tkassa';
            $description = $orderData['description'] ?? '';
            $paymentId = $orderData['payment_id'] ?? null;
        } else {
            // Старый формат для обратной совместимости
            $orderId = uniqid('order_');
            $userId = func_get_arg(0);
            $amount = func_get_arg(1);
            $status = func_get_arg(2) ?? 'pending';
            $paymentMethod = func_get_arg(3) ?? 'tkassa';
            $description = '';
            $paymentId = null;
        }

        // Сохраняем в таблицу orders (id = order_id, payment_id = T-Kassa PaymentId)
        $stmt = $this->conn->prepare("INSERT INTO orders (id, user_id, amount, status, payment_method, description, payment_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("siissss", $orderId, $userId, $amount, $status, $paymentMethod, $description, $paymentId);
        
        $result = $stmt->execute();
        
        if (!$result) {
            error_log("Failed to create order: " . $stmt->error);
        }
        
        $stmt->close();

        return $result ? $orderId : false;
    }

    /**
     * Получить заказ по ID
     */
    public function getOrderById($orderId) {
        $stmt = $this->conn->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->bind_param("s", $orderId);
        $stmt->execute();
        $result = $stmt->get_result();
        $order = $result->fetch_assoc();
        $stmt->close();

        return $order;
    }
    
    /**
     * Получить заказ по OrderId (для T-Kassa)
     */
    public function getOrderByOrderId($orderId) {
        // Для совместимости - orderId может быть в поле id или order_id
        $stmt = $this->conn->prepare("SELECT * FROM orders WHERE id = ? OR order_id = ? LIMIT 1");
        $stmt->bind_param("ss", $orderId, $orderId);
        $stmt->execute();
        $result = $stmt->get_result();
        $order = $result->fetch_assoc();
        $stmt->close();

        return $order;
    }
    
    /**
     * Получить pending заказы за последние N часов
     */
    public function getPendingOrders($hours = 24) {
        $stmt = $this->conn->prepare("
            SELECT * FROM orders 
            WHERE status = 'pending' 
            AND created_at > DATE_SUB(NOW(), INTERVAL ? HOUR)
            ORDER BY created_at DESC
        ");
        $stmt->bind_param("i", $hours);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $orders = [];
        while ($order = $result->fetch_assoc()) {
            $orders[] = $order;
        }
        
        $stmt->close();
        return $orders;
    }

    /**
     * Обновить статус заказа
     */
    public function updateOrderStatus($orderId, $status) {
        $stmt = $this->conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->bind_param("ss", $status, $orderId);
        $result = $stmt->execute();
        $stmt->close();

        return $result;
    }

    /**
     * Получить заказы пользователя
     */
    public function getUserOrders($userId, $status = null, $limit = 20) {
        $sql = "SELECT * FROM orders WHERE user_id = ?";
        $params = [$userId];
        $types = "i";

        if ($status) {
            $sql .= " AND status = ?";
            $params[] = $status;
            $types .= "s";
        }

        $sql .= " ORDER BY created_at DESC LIMIT ?";
        $params[] = $limit;
        $types .= "i";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $orders = [];
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
        $stmt->close();

        return $orders;
    }

    /**
     * Получить заказы по статусу
     */
    public function getOrdersByStatus($status, $limit = 50) {
        $stmt = $this->conn->prepare("SELECT * FROM orders WHERE status = ? ORDER BY created_at DESC LIMIT ?");
        $stmt->bind_param("si", $status, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        $orders = [];
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
        $stmt->close();

        return $orders;
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';

    $ordersAPI = new OrdersAPI();

    switch ($action) {
        case 'getById':
            if (isset($_GET['order_id'])) {
                $order = $ordersAPI->getOrderById($_GET['order_id']);
                jsonResponse($order);
            }
            break;

        case 'getUserOrders':
            if (isset($_GET['user_id'])) {
                $status = $_GET['status'] ?? null;
                $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
                $orders = $ordersAPI->getUserOrders((int)$_GET['user_id'], $status, $limit);
                jsonResponse($orders);
            }
            break;

        case 'getByStatus':
            if (isset($_GET['status'])) {
                $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
                $orders = $ordersAPI->getOrdersByStatus($_GET['status'], $limit);
                jsonResponse($orders);
            }
            break;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    $ordersAPI = new OrdersAPI();

    switch ($action) {
        case 'create':
            if (isset($_POST['user_id']) && isset($_POST['amount'])) {
                $status = $_POST['status'] ?? 'pending';
                $paymentMethod = $_POST['payment_method'] ?? 'tinkoff';
                $orderId = $ordersAPI->createOrder((int)$_POST['user_id'], (int)$_POST['amount'], $status, $paymentMethod);
                jsonResponse(['success' => $orderId !== false, 'order_id' => $orderId]);
            }
            break;

        case 'updateStatus':
            if (isset($_POST['order_id']) && isset($_POST['status'])) {
                $result = $ordersAPI->updateOrderStatus($_POST['order_id'], $_POST['status']);
                jsonResponse(['success' => $result]);
            }
            break;
    }
}
?>
