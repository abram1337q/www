<?php
require_once 'api/config.php';
require_once 'api/tkassa_api.php';

echo "Testing T-Kassa API...\n";

$tkassaAPI = new TKassaAPI();

// Тестовый платеж
$amount = 100; // 1 рубль в копейках
$orderId = 'TEST' . time();
$description = 'Тестовый платеж';
$successUrl = 'http://localhost:3000/balance.php?success=1&order=' . $orderId;
$failUrl = 'http://localhost:3000/balance.php?error=1&order=' . $orderId;

echo "Creating payment...\n";
echo "Amount: $amount копеек\n";
echo "Order ID: $orderId\n";
echo "Success URL: $successUrl\n";
echo "Fail URL: $failUrl\n";

$payment = $tkassaAPI->createPayment($amount, $orderId, $description, $successUrl, $failUrl);

echo "Payment result:\n";
print_r($payment);

if ($payment && $payment['success']) {
    echo "\nPayment URL: " . $payment['paymentUrl'] . "\n";
    if (!empty($payment['paymentUrl'])) {
        echo "Opening payment URL...\n";
        // В браузере это должно открыться автоматически
        header('Location: ' . $payment['paymentUrl']);
        exit;
    } else {
        echo "Payment URL is empty!\n";
        echo "Raw response:\n";
        print_r($payment['raw_response']);
    }
} else {
    echo "Payment creation failed!\n";
}
?>
