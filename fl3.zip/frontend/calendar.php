<?php
require_once 'api/config.php';
require_once 'api/abonements.php';

// Проверка авторизации с поддержкой Telegram
$user = requireAuth();

// Проверяем наличие активного абонемента
$abonementsAPI = new AbonementsAPI();
$canBook = $abonementsAPI->canBookTraining($user['id']);

$error = '';  // Initialize error variable

// Get selected date (default to today)
$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$selectedDateObj = new DateTime($selectedDate);

// Generate days for the next 14 days
$days = [];
$weekdays = [
    'Mon' => 'пн',
    'Tue' => 'вт',
    'Wed' => 'ср',
    'Thu' => 'чт',
    'Fri' => 'пт',
    'Sat' => 'сб',
    'Sun' => 'вс'
];
for ($i = 0; $i < 14; $i++) {
    $date = new DateTime();
    $date->modify("+$i days");
    $days[] = [
        'date' => $date->format('Y-m-d'),
        'day' => $date->format('j'),
        'weekday' => $weekdays[$date->format('D')]
    ];
}

// Получаем расписание из YClients
global $yclients;
$schedule_data = $yclients->getSchedule(0, $selectedDate, $selectedDate); // staff_id = 0 для всех сотрудников
error_log('Schedule data for date ' . $selectedDate . ': ' . print_r($schedule_data, true));

// Получаем записи пользователя для проверки статуса записи
$user_bookings = [];
if ($user['yclients_client_id']) {
    $user_bookings_data = $yclients->getClientBookings($user['yclients_client_id']);
    error_log('User bookings data: ' . print_r($user_bookings_data, true));
    // Создаем массив ID сеансов, на которые записан пользователь
    foreach ($user_bookings_data as $booking) {
        if (isset($booking['seance']['id'])) {
            $user_bookings[] = $booking['seance']['id'];
            error_log('User booked on seance ID: ' . $booking['seance']['id']);
        } else {
            error_log('Booking without seance ID: ' . print_r($booking, true));
        }
    }
}
error_log('User booked seance IDs: ' . print_r($user_bookings, true));

$schedule = [];
if (!empty($schedule_data)) {
    foreach($schedule_data as $item) {
        // Пропускаем записи без сеансов
        if (empty($item['seances'])) continue;

        foreach($item['seances'] as $seance) {
            $start_time = new DateTime($seance['date']);
            $end_time = new DateTime($seance['date']);
            $end_time->modify('+' . $seance['length'] . ' seconds');

            // Проверяем, записан ли пользователь на этот сеанс
            $is_booked = in_array($seance['id'], $user_bookings);
            $free_spots = $seance['capacity'] - count($seance['records']);

            error_log('Processing seance ID ' . $seance['id'] . ': is_booked=' . ($is_booked ? 'true' : 'false') . ', free_spots=' . $free_spots . ', records_count=' . count($seance['records']));

            $schedule[] = [
                'id' => $seance['id'],
                'title' => $seance['service']['title'],
                'time' => $start_time->format('H:i') . ' - ' . $end_time->format('H:i'),
                'start_time' => $start_time->format('H:i'),
                'end_time' => $end_time->format('H:i'),
                'duration' => ($seance['length'] / 60) . ' мин',
                'address' => APP_ADDRESS, // Assuming the address is constant for now
                'trainer' => [
                    'id' => $item['staff']['id'],
                    'name' => $item['staff']['name'],
                    'photo' => $item['staff']['avatar_big'] ?? 'Images/trainer.jpg'
                ],
                'freeSpots' => $free_spots,
                'totalSpots' => $seance['capacity'],
                'is_booked' => $is_booked,
                'price' => $seance['price'] ?? 0
            ];
        }
    }
}
error_log('Final schedule array count: ' . count($schedule));

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Расписание | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --secondary-color: #f4f4f4;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --danger-color: #ff4d4d;
            --success-color: #4CAF50;
            --border-radius: 16px;
            --button-radius: 13px;
            --shadow: 0px 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        html, body {
            margin: 0;
            padding: 0;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: #ffffff;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .wrap {
            width: 100%;
            max-width: 100%;
            overflow-x: hidden;
        }

        .app {
            max-width: 100%;
            padding: 0;
            margin: 0;
            width: 100%;
        }

        .page {
            width: 100%;
            max-width: 100%;
            padding: 0;
            margin: 0;
        }

        .page-bg {
            background: #E8E8E8;
            padding: 15px;
            border-radius: 25px 25px 0 0;
            min-height: calc(100vh - 200px);
            width: 100%;
            margin: 0;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .calendar-items {
            width: 100%;
            max-width: 470px;
            box-sizing: border-box;
        }

        /* Calendar Page */
        .calendar-page {
            padding-bottom: 80px;
        }

        .calendar-page-header {
            margin: 10px 0;
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        .calendar-month {
            position: absolute;
            top: 0;
            left: 0;
            font-size: 14px;
            color: var(--primary-color);
            font-weight: 700;
            margin-left: 15px;
        }

        .calendar-title {
            text-align: center;
            font-size: 14px;
            margin: 0;
            padding: 0;
            font-weight: bold;
            opacity: 0.8;
        }

        .calendar-address {
            text-align: center;
            font-size: 16px;
            margin: 5px 0 0;
            color: var(--light-text);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }

        .calendar-address svg {
            width: 16px;
            height: 16px;
            color: var(--primary-color);
        }

        .calendar-address strong {
            color: var(--primary-color);
            font-weight: 800;
        }

        .calendar-page-filter {
            position: absolute;
            top: 0;
            right: 0;
            cursor: pointer;
            color: var(--primary-color);
            margin-right: 15px;
        }

        .calendar-page-days {
            margin: 0 0 14px 0;
            display: flex;
            overflow-x: hidden;
            padding: 2px 10px;
            position: relative;
            justify-content: center;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: none;
            scroll-behavior: smooth;
            max-width: 100%;
        }

        .calendar-page-days::-webkit-scrollbar {
            display: none;
        }

        .calendar-nav-button {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 32px;
            height: 32px;
            border: none;
            background: none;
            cursor: pointer;
            z-index: 10;
            padding: 0;
        }

        .calendar-nav-button svg {
            width: 100%;
            height: 100%;
            color: #7171DC;
        }

        .calendar-nav-prev {
            left: 5px;
        }

        .calendar-nav-next {
            right: 5px;
        }

        .calendar-days-wrapper {
            display: flex;
            overflow-x: hidden;
            scroll-behavior: smooth;
            width: 80vw;
            margin: 0 auto;
            padding: 0 10px;
        }

        .calendar-day-button {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            width: 9vw;
            height: 5.3vh;
            border: 1px solid #7A7A7A;
            border-radius: 5vw;
            padding: 5px;
            margin-right: 10px;
            text-align: center;
            cursor: pointer;
            text-decoration: none;
            color: #7A7A7A;
            flex-shrink: 0;
        }

        .calendar-day-button:last-child {
            margin-right: 0;
        }

        .calendar-day-button.active {
            border-color: var(--primary-color);
            background: var(--primary-color);
            color: white;
            border: 1px solid #7A7A7A;
        }

        .calendar-day-button strong {
            display: block;
            font-size: 28px;
            line-height: 1.2;
            margin-bottom: -3px;
            color: #54575d;
        }

        .calendar-day-button span {
            display: block;
            font-size: 13px;
            line-height: 1;
            color: #7A7A7A;
        }

        .calendar-day-button.active strong,
        .calendar-day-button.active span {
            color: white;
        }

        .calendar-item {
            background: #FFFFFF;
            border-radius: 16px;
            padding: 12px 16px;
            margin-bottom: 20px;
            height: 210px;
            display: flex;
            flex-direction: column;
            width: 100%;
            max-width: 470px;
            box-sizing: border-box;
            border: 5px solid rgba(113, 113, 220, 0.12);
        }

        .calendar-item-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: -4px;
        }

        .calendar-item-content {
            display: flex;
            justify-content: space-between;
            margin-bottom: 7px;
        }

        .calendar-item-title-block {
            display: flex;
            flex-direction: column;
            gap: 0;
        }

        .calendar-item-title {
            color: #5334d9;
            font-size: 24px;
            font-weight: 900;
            font-style: italic;
            margin: 0;
            text-shadow: 0 0 1px #7171DC;
            -webkit-text-stroke: 0.3px #7171DC;
            line-height: 1;
        }

        .calendar-item-main {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 8px;
        }

        .calendar-item-time-row {
            display: flex;
            align-items: center;
            gap: 4px;
            color: #7171DC;
            font-size: 14px;
            margin-top: 2px;
            font-weight: 700;
        }

        .calendar-item-location {
            display: flex;
            align-items: center;
            gap: 4px;
            color: #7171DC;
            font-size: 15px;
            margin-top: 5px;
        }

        .calendar-item-location svg {
            color: #7171DC;
        }

        .calendar-item-time, .calendar-item-duration {
            font-size: 15px;
        }

        .calendar-item-duration{
            color: #7A7A7A;
        }

        .calendar-item-free {
            color: #7A7A7A;
            font-size: 13px;
            font-weight: 500;
        }

        .calendar-item-price {
            color: #7171dc;
            font-size: 14px;
            font-weight: 600;
        }

        .calendar-item-trainer {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 11px;
        }

        .calendar-item-trainer-photo {
            width: 62px;
            height: 62px;
            border-radius: 14px;
            object-fit: cover;
        }

        .calendar-item-trainer-name {
            display: flex;
            flex-direction: column;
            gap: 2px;
            color: #7171DC;
            font-size: 18px;
            margin-bottom: 10px;
            width: 95px;
        }

        .trainer-surname {
            font-weight: 700;
        }

        .trainer-firstname {
            font-weight: 700;
        }

        .calendar-item-button {
            width: 100%;
            background: #7171DC;
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px;
            font-size: 16px;
            font-weight: 550;
            cursor: pointer;
            height: 48px;
        }

        .calendar-item-button:disabled {
            background: #E5E5E5;
            cursor: not-allowed;
        }

        .calendar-item-button.booked {
            background: #4CAF50;
            color: white;
        }

        .calendar-item-button-link {
            text-decoration: none;
            color: inherit;
            display: block;
        }


        .loading {
            text-align: center;
            padding: 20px;
            color: var(--light-text);
        }

        .error {
            text-align: center;
            padding: 20px;
            color: var(--danger-color);
        }

        .no-data {
            text-align: center;
            padding: 20px;
            color: var(--light-text);
        }
        .success-message {
            background: #4CAF50;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .error-message {
            background: #f44336;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="calendar-page">
                <div class="calendar-page-header">
                    <div class="calendar-month">
                        <?php
                        $months = [
                            'январь', 'февраль', 'март', 'апрель', 'май', 'июнь',
                            'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'
                        ];
                        echo $months[$selectedDateObj->format('n') - 1];
                        ?>
                    </div>
                    <h2 class="calendar-title">Расписание тренировок</h2>
                    <p class="calendar-address">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 13C13.6569 13 15 11.6569 15 10C15 8.34315 13.6569 7 12 7C10.3431 7 9 8.34315 9 10C9 11.6569 10.3431 13 12 13Z" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12 22C16 18 20 14.4183 20 10C20 5.58172 16.4183 2 12 2C7.58172 2 4 5.58172 4 10C4 14.4183 8 18 12 22Z" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <strong><?php echo APP_NAME; ?></strong> <?php echo APP_ADDRESS; ?>
                    </p>
                    <a href="filters/filter.php" class="calendar-page-filter">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M22 3H2L10 12.46V19L14 21V12.46L22 3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </a>
                </div>

                <div class="calendar-page-days">
                    <button class="calendar-nav-button calendar-nav-prev">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                    <div class="calendar-days-wrapper">
                        <?php foreach ($days as $day): ?>
                            <a href="calendar.php?date=<?php echo $day['date']; ?>" class="calendar-day-button <?php echo $day['date'] === $selectedDate ? 'active' : ''; ?>">
                                <strong><?php echo $day['day']; ?></strong>
                                <span><?php echo $day['weekday']; ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    <button class="calendar-nav-button calendar-nav-next">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                </div>

                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const wrapper = document.querySelector('.calendar-days-wrapper');
                    const prevButton = document.querySelector('.calendar-nav-prev');
                    const nextButton = document.querySelector('.calendar-nav-next');

                    // Рассчитываем ширину одного дня в пикселях (9vw + 10px margin)
                    function getItemWidth() {
                        const vwValue = 9; // 9vw
                        const marginValue = 10; // 10px margin-right
                        const viewportWidth = window.innerWidth;
                        return (viewportWidth * vwValue / 100) + marginValue;
                    }

                    let itemWidth = getItemWidth();

                    // Восстанавливаем позицию скролла
                    const savedScrollPosition = localStorage.getItem('calendarScrollPosition');
                    if (savedScrollPosition) {
                        wrapper.scrollLeft = parseInt(savedScrollPosition);
                    }

                    // Находим и подсвечиваем активную дату
                    const activeButton = wrapper.querySelector('.calendar-day-button.active');
                    if (activeButton) {
                        // Вычисляем позицию активной даты
                        const activePosition = activeButton.offsetLeft - (wrapper.clientWidth - activeButton.offsetWidth) / 2;
                        // Если нет сохраненной позиции, скроллим к активной дате
                        if (!savedScrollPosition) {
                            wrapper.scrollLeft = activePosition;
                        }
                    }

                    function updateNavigation() {
                        const scrollLeft = wrapper.scrollLeft;
                        const maxScroll = wrapper.scrollWidth - wrapper.clientWidth;

                        prevButton.style.visibility = scrollLeft <= 0 ? 'hidden' : 'visible';
                        nextButton.style.visibility = scrollLeft >= maxScroll - 1 ? 'hidden' : 'visible';

                        // Сохраняем позицию скролла
                        localStorage.setItem('calendarScrollPosition', scrollLeft.toString());
                    }

                    function getVisibleItemsCount() {
                        const wrapperWidth = wrapper.clientWidth;
                        // Вычисляем сколько полных дней помещается в видимой области
                        return Math.floor(wrapperWidth / itemWidth);
                    }

                    function adjustWrapperWidth() {
                        itemWidth = getItemWidth(); // Пересчитываем при изменении размера
                        const containerWidth = document.querySelector('.calendar-page-days').clientWidth - 100; // Вычитаем отступы для стрелок
                        const possibleItems = Math.floor((containerWidth - 60) / itemWidth); // Учитываем отступы wrapper
                        const newWidth = (possibleItems * itemWidth) + 60; // Добавляем отступы обратно
                        wrapper.style.width = newWidth + 'px';
                        updateNavigation();
                    }

                    prevButton.addEventListener('click', function() {
                        const visibleCount = getVisibleItemsCount();
                        const scrollAmount = itemWidth * visibleCount;
                        wrapper.scrollBy({
                            left: -scrollAmount,
                            behavior: 'smooth'
                        });
                        setTimeout(updateNavigation, 300);
                    });

                    nextButton.addEventListener('click', function() {
                        const visibleCount = getVisibleItemsCount();
                        const scrollAmount = itemWidth * visibleCount;
                        wrapper.scrollBy({
                            left: scrollAmount,
                            behavior: 'smooth'
                        });
                        setTimeout(updateNavigation, 300);
                    });

                    // Добавляем обработчик для всех кнопок дат
                    wrapper.querySelectorAll('.calendar-day-button').forEach(button => {
                        button.addEventListener('click', function() {
                            // Сохраняем текущую позицию перед переходом
                            localStorage.setItem('calendarScrollPosition', wrapper.scrollLeft.toString());
                        });
                    });

                    // Вызываем функцию при загрузке и изменении размера окна
                    adjustWrapperWidth();
                    window.addEventListener('resize', function() {
                        adjustWrapperWidth();
                    });
                    wrapper.addEventListener('scroll', updateNavigation);
                    updateNavigation();
                });
                </script>

                <?php if (isset($success) && $success !== ''): ?>
                    <div class="success-message"><?php echo $success; ?></div>
                <?php endif; ?>

                <?php if (!empty($error)): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if (!$canBook['can_book']): ?>
                    <!-- Уведомление о необходимости абонемента -->
                    <div style="background: gray; color: white; padding: 15px; border-radius: 15px; margin-bottom: 15px; text-align: center;">
                        <div style="font-weight: 600; margin-bottom: 8px;">Нужен абонемент</div>
                        <div style="font-size: 14px; margin-bottom: 12px; opacity: 0.9;">
                            <?php echo $canBook['reason']; ?>
                        </div>
                        <a href="buy_abonement.php" style="display: inline-block; background: white; color: #667eea; padding: 10px 20px; border-radius: 10px; text-decoration: none; font-weight: 600;">
                            Купить абонемент
                        </a>
                    </div>
                <?php else: ?>
                    <!-- Показываем активный абонемент -->
                    <div style="background: #7ED9C8; color: white; padding: 15px; border-radius: 15px; margin-bottom: 15px; text-align: center;">
                        <div style="font-weight: 600; margin-bottom: 5px;">✓ Активный абонемент</div>
                        <div style="font-size: 14px; opacity: 0.9;">
                            <?php echo $canBook['type_name']; ?>
                            <?php if ($canBook['abonement_type'] === 'single'): ?>
                                (<?php echo $canBook['abonement']['balance']; ?> посещений)
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="page-bg">
                    <?php if (!empty($schedule)): ?>
                        <div class="calendar-items">
                            <?php foreach ($schedule as $item): ?>
                                <div class="calendar-item">
                                    <div class="calendar-item-top">
                                        <div class="calendar-item-title-block">
                                            <h3 class="calendar-item-title"><?php echo htmlspecialchars($item['title']); ?></h3>
                                            <div class="calendar-item-time-row">
                                                <span class="calendar-item-time"><?php echo $item['time']; ?></span>
                                                <span class="calendar-item-duration"><?php echo $item['duration']; ?></span>
                                            </div>
                                        </div>
                                        <div class="calendar-item-location">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M12 13C13.6569 13 15 11.6569 15 10C15 8.34315 13.6569 7 12 7C10.3431 7 9 8.34315 9 10C9 11.6569 10.3431 13 12 13Z" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M12 22C16 18 20 14.4183 20 10C20 5.58172 16.4183 2 12 2C7.58172 2 4 5.58172 4 10C4 14.4183 8 18 12 22Z" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            <?php echo htmlspecialchars($item['address']); ?>
                                        </div>
                                    </div>
                                    <div class="calendar-item-content">
                                        <div class="calendar-item-main">
                                            <div class="calendar-item-free">Свободно <?php echo $item['freeSpots']; ?> из <?php echo $item['totalSpots']; ?> мест</div>
                                            <?php if (isset($item['price']) && $item['price'] > 0): ?>
                                                <div class="calendar-item-price"><?php echo number_format($item['price'], 0, '.', ' '); ?> ₽</div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="calendar-item-trainer">
                                            <img src="<?php echo htmlspecialchars($item['trainer']['photo']); ?>" alt="" class="calendar-item-trainer-photo">
                                            <div class="calendar-item-trainer-name">
                                                <div class="trainer-surname"><?php echo explode(' ', $item['trainer']['name'])[0]; ?></div>
                                                <!-- <div class="trainer-firstname"><?php echo explode(' ', $item['trainer']['name'])[1]; ?></div> -->
                                            </div>
                                        </div>
                                    </div>
                                    <a href="session.php?id=<?php echo $item['id']; ?>&date=<?php echo urlencode($selectedDate); ?>" class="calendar-item-button-link">
                                        <button
                                            class="calendar-item-button <?php echo $item['is_booked'] ? 'booked' : ''; ?>"
                                            <?php echo (($item['freeSpots'] <= 0 && !$item['is_booked']) || $item['is_booked']) ? 'disabled' : ''; ?>>
                                            <?php
                                            if ($item['is_booked']) {
                                                echo 'Записан';
                                            } elseif ($item['freeSpots'] <= 0) {
                                                echo 'Нет мест';
                                            } else {
                                                echo 'Записаться';
                                            }
                                            ?>
                                        </button>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="no-data">
                            <p>На выбранную дату занятий не запланировано</p>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($error)): ?>
                        <div class="error"><?php echo $error; ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <?php $activePage = 'calendar'; include 'components/navigation.php'; ?>
    </div>
</body>
</html>
