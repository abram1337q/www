<?php
require_once 'api/config.php';

// Проверка авторизации с поддержкой Telegram
$user = requireAuth();

// Get special offers
$specialOffers = getSpecialOffers();

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Главная | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --secondary-color: #f4f4f4;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --danger-color: #ff4d4d;
            --success-color: #4CAF50;
            --border-radius: 16px;
            --button-radius: 13px;
            --shadow: 0px 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: #ffffff;
            overflow-y: auto;
            overflow-x: hidden;
        }
        
        @supports (-webkit-touch-callout: none) {
            html, body {
                height: -webkit-fill-available;
            }
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .wrap {
            width: 100%;
            max-width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .app {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 10px;
            margin-bottom: 10px;
        }

        .header-welcome {
            font-size: 24px;
            font-weight: 900;
            font-style: italic;
            color: #7171DC;
            line-height: 1.2;
        }

        .header-right {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
        }

        .header-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .header-balance-wrapper {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            padding: 4px 8px;
        }

        .header-balance {
            font-size: 11px;
            font-weight: 400;
            color: var(--light-text);
            text-align: center;
            line-height: 1;
        }

        .header-balance-amount {
            font-size: 14px;
            font-weight: 900;
            color: #7171DC;
            margin-top: 1px;
            line-height: 1;
            text-align: center;
        }

        .header-button {
            color: var(--primary-color);
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 4px;
            background: #fff;
            border: none;
            cursor: pointer;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            box-shadow: 0px 2px 8px rgba(0, 0, 0, 0.05);
        }

        .header-button svg {
            width: 16px;
            height: 16px;
        }

        /* Main content */
        .main-content {
            background: #E8E8E8;
            border-radius: 16px 16px 0 0;
            margin-top: -24px;
            position: relative;
            z-index: 2;
            width: 100%;
            box-shadow: none;
            display: flex;
            flex-direction: column;
            flex: 1;
            box-sizing: border-box;
            min-height: calc(100vh - 56px - 24px);
            overflow: hidden;
        }
        
        @media screen and (max-height: 700px) {
            .offer-card {
                height: 350px;
            }
            .gym-banner {
                height: 120px;
            }
        }
        
        @media screen and (max-height: 600px) {
            .offer-card {
                height: 300px;
            }
            .gym-banner {
                height: 100px;
            }
            .offer-title {
                margin: 40px 0 0 0;
            }
            .offer-price {
                margin: 30px 0 auto 0;
            }
        }

        .content-wrapper {
            padding: 20px 15px;
            position: relative;
            width: 100%;
            box-sizing: border-box;
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .gym-banner {
            width: 100%;
            height: 150px;
            object-fit: cover;
            position: relative;
            z-index: 1;
        }

        .offer-card-wrapper {
            display: flex;
            width: calc(100% + 30px);
            margin: 0 -15px 15px -15px;
            overflow-x: auto;
            overflow-y: hidden;
            box-sizing: border-box;
            scroll-snap-type: x mandatory;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: none;
            -ms-overflow-style: none;
            gap: 10px;
            padding: 0 15px;
        }
        
        .offer-card-wrapper::-webkit-scrollbar {
            display: none;
        }

        .offer-card {
            background: #7171dc;
            color: #fff;
            border-radius: 16px;
            padding: 20px;
            text-align: center;
            position: relative;
            border: 4px solid #fff;
            box-sizing: border-box;
            flex: 0 0 auto;
            min-width: 300px;
            max-width: 300px;
            height: 380px;
            display: flex;
            flex-direction: column;
            scroll-snap-align: start;
        }

        .offer-close {
            position: absolute;
            top: 6px;
            right: 10px;
            color: #fff;
            font-size: 22px;
            line-height: 1;
            cursor: pointer;
            font-weight: 600;
            z-index: 10;
            padding: 5px;
            user-select: none;
        }

        .offer-close:hover {
            opacity: 0.8;
        }

        .offer-special {
            font-size: 15px;
            font-weight: 500;
            position: absolute;
            top: 8px;
            left: 20px;
            text-align: left;
        }

        .offer-title {
            font-size: 28px;
            font-weight: 800;
            font-style: italic;
            margin: 60px 0 0 0;
            text-align: center;
        }

        .offer-subtitle {
            font-size: 14px;
            letter-spacing: 0.3px;
            font-weight: 500;
            margin: -4px 0 0 0;
            text-align: center;
        }

        .offer-price {
            margin: 50px 0 auto 0;
            text-align: center;
        }

        .price-amount {
            font-size: 28px;
            font-weight: 800;
            font-style: italic;
        }

        .price-period {
            font-size: 14px;
            font-weight: normal;
        }

        .offer-button {
            background: #fff;
            color: #7171dc;
            border: 5px solid #E8E8E8;
            border-radius: 12px;
            height: 85px;
            width: 100%;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 20px;
        }

        .club-info-button {
            background: #7171dc;
            color: #fff;
            border: 4px solid #fff;
            border-radius: 16px;
            height: 90px;
            width: 100%;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
            max-width: 350px;
        }

        .main-page {
            padding-bottom: 70px;
        }

        .main-page-bg {
            background: var(--secondary-color);
            border-radius: var(--border-radius);
            padding: 15px;
            margin-top: 15px;
        }

        .main-page-about-button {
            background: var(--primary-color);
            color: #fff;
            border: none;
            padding: 20px 0;
            text-align: center;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            margin: 20px 0;
            border-radius: var(--border-radius);
            width: 100%;
            box-sizing: border-box;
            display: block;
        }


        .main-page-special {
            background: var(--primary-color);
            color: #fff;
            text-align: center;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            margin: 0 0 20px 0;
            border-radius: var(--border-radius);
            padding: 20px 15px;
        }

        .special-button {
            color: var(--primary-color);
            background: #fff;
            border: none;
            text-align: center;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            margin: 15px 0 0 0;
            border-radius: var(--button-radius);
            padding: 15px 0;
            width: 100%;
        }

        .special-title {
            margin: 0 0 15px 0;
            font-size: 20px;
        }

        .special-text {
            margin: 0;
            font-size: 14px;
            font-weight: 400;
            line-height: 1.5;
        }

        .main-page-header {
            margin: 0 0 20px 0;
            padding: 15px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .main-page-welcome {
            font-size: 22px;
            font-weight: 700;
            color: var(--primary-color);
        }

        .main-page-balance {
            display: block;
            text-align: right;
        }

        .main-page-balance span {
            display: block;
            font-size: 12px;
            line-height: 1.2;
            color: var(--light-text);
            margin-bottom: 5px;
        }

        .main-page-balance strong {
            color: var(--primary-color);
            font-size: 22px;
            line-height: 1.2;
            display: block;
            font-weight: bold;
        }

        .main-page-buttons {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .button-notif,
        .button-profile {
            width: 24px;
            height: 24px;
            cursor: pointer;
            color: var(--primary-color);
        }

        .main-page-slider img {
            width: 100%;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            height: auto;
            object-fit: cover;
        }


        .offer-section {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .club-info-section {
            margin-top: auto;
            padding-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="main-page">
                <img src="Images/gym-banner.jpg" alt="Тренажерный зал" class="gym-banner">
                
                <div class="main-content">
                    <div class="content-wrapper">
                        <div class="header">
                            <div class="header-welcome">
                                Привет, <?php echo htmlspecialchars($user['first_name'] ?? 'Guest'); ?>!
                            </div>
                            <div class="header-right">
                                <div class="header-buttons">
                                    <a href="profile.php" class="header-button">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </a>
                                </div>
                                <div class="header-balance-wrapper">
                                    <div class="header-balance">
                                        Ваш баланс
                                    </div>
                                    <div class="header-balance-amount">
                                        <?php echo number_format($user['balance'] ?? 0, 0, '.', ' '); ?> ₽
                                    </div>
                        </div>
                    </div>
                </div>

                        <div class="offer-card-wrapper">
                            <?php if (!empty($specialOffers)): ?>
                                <?php foreach ($specialOffers as $offer): ?>
                                <div class="offer-card">
                                    <div class="offer-close">×</div>
                                    <div class="offer-special">Специальное предложение</div>
                                    <div class="offer-title"><?php echo htmlspecialchars($offer['title']); ?></div>
                                    <div class="offer-subtitle"><?php echo htmlspecialchars($offer['description']); ?></div>
                                    <div class="offer-price"><span class="price-amount"><?php echo number_format($offer['price'], 0, '.', ' '); ?></span><span class="price-period"> ₽</span></div>
                                    <button class="offer-button">Выбрать</button>
                                </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p>Актуальных акций пока нет.</p>
                            <?php endif; ?>
                        </div>

                        <a href="club.php" class="club-info-button">
                            Информация о клубе
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <?php $activePage = 'home'; include 'components/navigation.php'; ?>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Обработчик для закрытия карточек объявлений
        const closeButtons = document.querySelectorAll('.offer-close');
        closeButtons.forEach(function(button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const card = this.closest('.offer-card');
                if (card) {
                    card.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                    card.style.opacity = '0';
                    card.style.transform = 'scale(0.9)';
                    setTimeout(function() {
                        card.remove();
                    }, 300);
                }
            });
        });
    });
    </script>
</body>
</html>
