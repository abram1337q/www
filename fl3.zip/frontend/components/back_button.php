<?php
/**
 * Back button component
 *
 * @param string $href - URL to go back to
 * @param string $title - Title text to display next to the button (optional)
 * @param bool $useH1 - Whether to use h1 tag for title (default: false)
 * @param string $svgType - Type of SVG arrow ('filters' or 'default')
 */
function renderBackButton($href, $title = '', $useH1 = false, $svgType = 'default') {
    ?>
    <div class="header">
        <a href="<?php echo htmlspecialchars($href); ?>" class="back-button">
            <?php if ($svgType === 'filters'): ?>
                <svg class="back-arrow arrow-svg" viewBox="0 0 24 24">
                    <path d="M15 18L9 12L15 6"/>
                </svg>
            <?php else: ?>
                <svg viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            <?php endif; ?>
        </a>
        <?php if (!empty($title)): ?>
            <?php if ($useH1): ?>
                <h1 class="header-title"><?php echo htmlspecialchars($title); ?></h1>
            <?php else: ?>
                <div class="header-title"><?php echo htmlspecialchars($title); ?></div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php
}
?>

<style>
/* Back button styles - shared across all pages */
.back-button {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    cursor: pointer;
    color: var(--text-color);
}

.back-button svg {
    width: 20px;
    height: 20px;
}

.header {
    display: flex;
    align-items: center;
    padding: 24px 24px 0 24px;
    gap: 32px;
}

.header-title {
    font-size: 14px;
    font-weight: 500;
    color: var(--text-color);
    line-height: 20px;
}
</style>
