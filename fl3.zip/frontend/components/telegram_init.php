<!-- Telegram WebApp SDK -->
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<script src="js/telegram-webapp.js"></script>

<script>
// Глобальный обработчик для открытия внешних ссылок в браузере
document.addEventListener('DOMContentLoaded', function() {
    document.addEventListener('click', function(e) {
        const target = e.target.closest('a');
        if (target && target.href) {
            const url = target.href;
            // Проверяем, является ли ссылка внешней (начинается с http/https и не является внутренней навигацией)
            if ((url.startsWith('http://') || url.startsWith('https://')) && 
                !url.includes(window.location.hostname) && 
                !target.hasAttribute('data-internal')) {
                e.preventDefault();
                // Используем Telegram WebApp API для открытия в браузере
                if (window.Telegram && window.Telegram.WebApp) {
                    window.Telegram.WebApp.openLink(url);
                } else {
                    // Fallback для обычных браузеров
                    window.open(url, '_blank');
                }
            }
        }
    });
});
</script>

