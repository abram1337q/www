<?php
// Navigation component
// Usage: include 'components/navigation.php';
// Set $activePage variable before including, e.g. $activePage = 'home';
// Set $navType variable to 'main' or 'notifications', default is 'main'

$activePage = $activePage ?? 'home'; // Default to home if not set
$navType = $navType ?? 'main'; // Default to main navigation

// Function to load SVG by name
function getSvgIcon($name) {
    $svgPath = __DIR__ . '/../svg/' . $name . '.svg';
    if (file_exists($svgPath)) {
        $svgContent = file_get_contents($svgPath);
        // Add class to SVG for styling
        $svgContent = preg_replace('/<svg([^>]*)>/', '<svg$1 class="main-menu-icon">', $svgContent);
        return $svgContent;
    }
    // Fallback for missing icons
    return '<svg class="main-menu-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/></svg>';
}
?>
<style>
    .main-menu {
        background: #fff;
        width: 100%;
        padding: 10px 0 20px 0;
        text-align: center;
        position: fixed;
        bottom: 0;
        left: 0;
        box-shadow: 0px -2px 10px rgba(0, 0, 0, 0.05);
        z-index: 100;
    }

    .main-menu-button {
        display: inline-block;
        margin: 0 5px 0 10px;
        padding: 30px 0 0 0;
        font-size: 10px;
        text-align: center;
        line-height: 10px;
        color: #888888;
        cursor: pointer;
        text-decoration: none;
        position: relative;
    }

    .main-menu-icon {
        position: absolute;
        top: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 32px;
        height: 32px;
        color: currentColor;
    }

    .main-menu-button.active {
        color: #7171DC;
    }

    .active .main-menu-icon {
        color: #7171DC;
    }
</style>
<?php
?>
        <div class="main-menu">
            <a href="home.php" class="main-menu-button <?php echo $activePage === 'home' ? 'active' : ''; ?>">
                <?php echo getSvgIcon('home'); ?>
                Главная
            </a>
            <a href="calendar.php" class="main-menu-button <?php echo $activePage === 'calendar' ? 'active' : ''; ?>">
                <?php echo getSvgIcon('schedule'); ?>
                Расписание
            </a>
            <a href="my_products.php" class="main-menu-button <?php echo $activePage === 'products' ? 'active' : ''; ?>">
                <svg class="main-menu-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M21 16V8C20.9996 7.64927 20.9071 7.30481 20.7315 7.00116C20.556 6.69751 20.3037 6.44536 20 6.27L13 2.27C12.696 2.09446 12.3511 2.00205 12 2.00205C11.6489 2.00205 11.304 2.09446 11 2.27L4 6.27C3.69626 6.44536 3.44398 6.69751 3.26846 7.00116C3.09294 7.30481 3.00036 7.64927 3 8V16C3.00036 16.3507 3.09294 16.6952 3.26846 16.9988C3.44398 17.3025 3.69626 17.5546 4 17.73L11 21.73C11.304 21.9055 11.6489 21.9979 12 21.9979C12.3511 21.9979 12.696 21.9055 13 21.73L20 17.73C20.3037 17.5546 20.556 17.3025 20.7315 16.9988C20.9071 16.6952 20.9996 16.3507 21 16Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M3.27002 6.96L12 12.01L20.73 6.96" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M12 22.08V12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Товары
            </a>
            <a href="shop.php" class="main-menu-button <?php echo $activePage === 'shop' ? 'active' : ''; ?>">
                <?php echo getSvgIcon('shop'); ?>
                Магазин
            </a>
            <?php if ($navType === 'notifications'): ?>
            <a href="notifications.php" class="main-menu-button <?php echo $activePage === 'notifications' ? 'active' : ''; ?>">
                <svg class="main-menu-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 8C18 6.4087 17.3679 4.88258 16.2426 3.75736C15.1174 2.63214 13.5913 2 12 2C10.4087 2 8.88258 2.63214 7.75736 3.75736C6.63214 4.88258 6 6.4087 6 8C6 15 3 17 3 17H21C21 17 18 15 18 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M13.73 21C13.5542 21.3031 13.3019 21.5547 12.9982 21.7295C12.6946 21.9044 12.3504 21.9965 12 21.9965C11.6496 21.9965 11.3054 21.9044 11.0018 21.7295C10.6982 21.5547 10.4458 21.3031 10.27 21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Уведомления
            </a>
            <?php else: ?>
            <a href="assistant.php" class="main-menu-button <?php echo $activePage === 'assistant' ? 'active' : ''; ?>">
                <?php echo getSvgIcon('assistant'); ?>
                Ассистент
            </a>
            <?php endif; ?>
            <a href="profile.php" class="main-menu-button <?php echo $activePage === 'profile' ? 'active' : ''; ?>">
                <?php echo getSvgIcon('login'); ?>
                Профиль
            </a>
        </div>
