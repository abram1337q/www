<!-- Telegram WebApp Authentication Check -->
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<script>
(function() {
    'use strict';
    
    // Проверяем, есть ли Telegram WebApp
    if (!window.Telegram || !window.Telegram.WebApp) {
        console.log('Not a Telegram WebApp, continuing normally');
        return;
    }
    
    const tg = window.Telegram.WebApp;
    tg.ready();
    
    // Функция для извлечения параметров из хеша URL
    function getHashParams() {
        const hash = window.location.hash.substring(1);
        const params = {};
        if (hash) {
            hash.split('&').forEach(function(part) {
                const item = part.split('=');
                try {
                    const key = decodeURIComponent(item[0]);
                    const value = item[1] ? decodeURIComponent(item[1]) : '';
                    params[key] = value;
                } catch (e) {
                    console.warn('Failed to decode URL parameter:', part, e);
                }
            });
        }
        return params;
    }
    
    // Функция для проверки и авторизации через Telegram
    async function checkTelegramAuth() {
        console.log('Checking Telegram authentication...');
        
        // Пытаемся получить initData из разных источников
        let initData = tg.initData;
        
        // Если нет в tg.initData, пробуем из хеша URL (для прямых ссылок)
        if (!initData || initData.length === 0) {
            const hash = window.location.hash.substring(1);
            console.log('Hash string:', hash ? hash.substring(0, 50) + '...' : 'empty');
            
            // Извлекаем tgWebAppData напрямую без дополнительного декодирования
            const match = hash.match(/tgWebAppData=([^&]*)/);
            if (match && match[1]) {
                initData = match[1];
                console.log('InitData extracted from URL hash');
            }
        }
        
        // Если нет initData, пробуем из query параметров
        if (!initData || initData.length === 0) {
            const urlParams = new URLSearchParams(window.location.search);
            const tgData = urlParams.get('tgWebAppData');
            if (tgData) {
                initData = tgData;
                console.log('InitData extracted from query params');
            }
        }
        
        if (!initData || initData.length === 0) {
            console.log('No initData available');
            return false;
        }
        
        console.log('InitData found, length:', initData.length);
        console.log('InitData preview:', initData.substring(0, 50) + '...');
        
        // Проверяем, авторизованы ли мы уже
        try {
            const checkResponse = await fetch('api/config.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=check_session'
            });
            
            if (checkResponse.ok) {
                const sessionData = await checkResponse.json();
                if (sessionData.logged_in) {
                    console.log('Already logged in');
                    return true;
                }
            }
        } catch (e) {
            console.log('Session check failed, proceeding with auth');
        }
        
        // Пытаемся авторизоваться
        try {
            const formData = new FormData();
            formData.append('action', 'telegram_auth');
            formData.append('initData', initData);
            
            const response = await fetch('api/telegram_auth.php', {
                method: 'POST',
                body: formData
            });
            
            console.log('Server response status:', response.status);
            
            let data;
            try {
                const responseText = await response.text();
                console.log('Server response (first 200 chars):', responseText.substring(0, 200));
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('❌ Failed to parse server response:', parseError);
                return false;
            }
            
            if (data.success) {
                console.log(' Telegram authentication successful');
                console.log('User data:', data.user);
                
                // Очищаем URL от параметров Telegram
                const cleanUrl = window.location.pathname;
                if (window.location.hash || window.location.search.includes('tgWebAppData')) {
                    window.history.replaceState({}, document.title, cleanUrl);
                }
                
                return true;
            } else {
                console.error('❌ Telegram authentication failed:', data.error);
                return false;
            }
        } catch (error) {
            console.error('❌ Authentication error:', error);
            return false;
        }
    }
    
    // Запускаем проверку авторизации при загрузке страницы
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            checkTelegramAuth();
        });
    } else {
        checkTelegramAuth();
    }
})();
</script>

