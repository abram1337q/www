<?php
require_once 'api/config.php';

// Проверка авторизации с поддержкой Telegram
$user = requireAuth();

// Добавляем баланс, если его нет
if (!isset($user['balance'])) {
    $user['balance'] = 5000; // Устанавливаем тестовый баланс
}

// Handle logout
if (isset($_GET['logout'])) {
    logout();
    redirect('login.php');
}

// Get active tab
$activeTab = isset($_GET['tab']) ? $_GET['tab'] : 'profile';

// Создаем тестовые данные для тренировок и покупок
$trainings = [];
$purchases = [];

if ($user['yclients_client_id']) {
    global $yclients;
    $bookings = $yclients->getClientBookings($user['yclients_client_id']);
    
    // Быстрая загрузка: только базовая информация без деталей
    foreach ($bookings as $booking) {
        $dateTime = new DateTime($booking['date']);
        
        // Определяем статус тренировки (прошла или предстоит)
        $now = new DateTime();
        $status = $dateTime > $now ? 'Предстоит' : 'Завершена';
        
        $trainings[] = [
            'id' => $booking['id'],
            'title' => $booking['service']['title'],
            'date' => $booking['date'],
            'datetime' => $dateTime,
            'status' => $status,
            'address' => APP_ADDRESS
        ];
    }
    
    // Сортируем тренировки по дате (сначала предстоящие, потом прошедшие)
    usort($trainings, function($a, $b) {
        return $a['datetime'] <=> $b['datetime'];
    });

    $abonements = $yclients->getClientLoyaltyAbonements($user['yclients_client_id']);
    foreach ($abonements as $abonement) {
        $purchases[] = [
            'title' => $abonement['title'],
            'date' => $abonement['sale_date'],
            'price' => $abonement['cost'],
            'status' => $abonement['is_active'] ? 'Активен' : 'Истек'
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Профиль | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            /* background-color: #f9f9f9; */
        }

        body {
            font-family: "Inter", sans-serif;
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        a {
            text-decoration: none;
        }

        .clear {
            clear: both;
        }

        .wrap {
            width: 100%;
        }

        .app {
            padding: 0 15px;
            margin: 0 auto;
            max-width: 400px;
        }

        /* Profile Page */
        .profile-page {
            padding: 20px 0 90px;
        }

        .profile-header {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
        }

        .profile-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 20px;
            border: 2px solid #7171dc;
        }

        .profile-info {
            flex: 1;
        }

        .profile-name {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            margin: 0 0 5px 0;
        }

        .profile-phone {
            font-size: 14px;
            color: #666;
        }

        .profile-balance {
            font-size: 22px;
            font-weight: bold;
            color: #7171dc;
            margin-top: 10px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .balance-button {
            background: #7171dc;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.2s;
        }

        .balance-button:hover {
            background: #5a5abd;
        }

        .profile-tabs {
            display: flex;
            margin-bottom: 20px;
            border-bottom: 1px solid #f0f0f0;
        }

        .profile-tab {
            flex: 1;
            background: none;
            border: none;
            padding: 10px 0;
            font-size: 14px;
            color: #666;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
        }

        .profile-tab.active {
            color: #7171dc;
            font-weight: bold;
            border-bottom: 2px solid #7171dc;
        }

        .profile-section {
            margin-bottom: 30px;
        }

        .profile-section-title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin: 0 0 15px 0;
        }

        .profile-menu {
            list-style-type: none;
            padding: 0;
            margin: 0;
            background: #f5f5f5;
            border-radius: 12px;
            overflow: hidden;
        }

        .profile-menu-item {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            background: #f5f5f5;
            text-decoration: none;
            color: inherit;
            border-bottom: 1px solid #e0e0e0;
            transition: background-color 0.2s;
        }

        .profile-menu-item:last-child {
            border-bottom: none;
        }

        .profile-menu-item:active {
            background: #e8e8e8;
        }

        .profile-menu-icon {
            margin-right: 15px;
            color: #7171dc;
        }

        .profile-menu-text {
            flex: 1;
            font-size: 14px;
            color: #333;
        }

        .profile-menu-arrow {
            color: #bbbbbb;
        }

        .profile-logout {
            background: none;
            border: none;
            color: #ff4d4d;
            font-size: 14px;
            font-weight: 500;
            padding: 16px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            margin-top: 20px;
            text-decoration: none;
            background: #f5f5f5;
            border-radius: 12px;
            transition: background-color 0.2s;
        }

        .profile-logout:active {
            background: #e8e8e8;
        }

        .profile-logout-icon {
            margin-right: 10px;
            color: #ff4d4d;
        }

        .profile-trainings,
        .profile-purchases {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .profile-training-item,
        .profile-purchase-item {
            background: #fff;
            border: 1px solid #eeeeee;
            margin: 0 0 15px 0;
            border-radius: 16px;
            padding: 16px;
            position: relative;
            box-shadow: 0px 2px 8px rgba(0, 0, 0, 0.08);
            border: 3px solid rgba(113, 113, 220, 0.12);
        }

        .profile-training-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .profile-training-title,
        .profile-purchase-title {
            font-size: 18px;
            font-weight: 700;
            color: #333;
            margin-bottom: 0;
            flex: 1;
        }

        .profile-training-status,
        .profile-purchase-status {
            font-size: 12px;
            padding: 4px 12px;
            border-radius: 12px;
            font-weight: 600;
            white-space: nowrap;
            margin-left: 10px;
        }

        .profile-training-status.upcoming {
            background: #E8F5E9;
            color: #4CAF50;
        }

        .profile-training-status.completed {
            background: #F5F5F5;
            color: #9E9E9E;
        }

        .profile-training-info {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 12px;
        }

        .profile-training-info-row {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: #666;
        }

        .profile-training-info-row svg {
            width: 16px;
            height: 16px;
            color: #7171dc;
            flex-shrink: 0;
        }

        .profile-training-date,
        .profile-purchase-date {
            font-size: 14px;
            color: #666;
        }

        .profile-training-time {
            font-size: 14px;
            color: #666;
        }

        .profile-training-trainer {
            display: flex;
            align-items: center;
            gap: 12px;
            padding-top: 12px;
            border-top: 1px solid #f0f0f0;
        }

        .profile-training-trainer-photo {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            object-fit: cover;
        }

        .profile-training-trainer-info {
            display: flex;
            flex-direction: column;
        }

        .profile-training-trainer-label {
            font-size: 12px;
            color: #999;
        }

        .profile-training-trainer-name {
            font-size: 14px;
            font-weight: 600;
            color: #7171dc;
        }

        /* Skeleton loading styles */
        .skeleton {
            background: #E8E8E8;
            background-size: 200% 100%;
            animation: loading 1.5s ease-in-out infinite;
            border-radius: 4px;
        }

        @keyframes loading {
            0% {
                background-position: 200% 0;
            }
            100% {
                background-position: -200% 0;
            }
        }

        .skeleton-text {
            height: 14px;
            margin-bottom: 8px;
        }

        .skeleton-circle {
            width: 48px;
            height: 48px;
            border-radius: 12px;
        }

        .profile-training-item.loading .profile-training-info-row span,
        .profile-training-item.loading .profile-training-trainer-name {
            display: inline-block;
            width: 120px;
        }

        .profile-purchase-price {
            font-size: 16px;
            font-weight: bold;
            color: #ff4d4d;
            margin-bottom: 10px;
        }

            color: #7171dc;
        }

        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }

        .error {
            text-align: center;
            padding: 20px;
            color: #ff4d4d;
        }

        .no-data {
            text-align: center;
            padding: 20px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="profile-page">
                <div class="profile-header">
                    <img src="<?php echo !empty($user['photo_url']) ? htmlspecialchars($user['photo_url']) : '/images/avatar-placeholder.png'; ?>" alt="<?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>" class="profile-avatar">
                    <div class="profile-info">
                        <h1 class="profile-name"><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h1>
                        <p class="profile-phone"><?php echo htmlspecialchars($user['phone'] ? formatPhoneNumber($user['phone']) : 'Телефон не указан'); ?></p>
                        <div class="profile-balance">
                            <span><?php echo number_format($user['balance'], 0, '.', ' '); ?> ₽</span>
                            <a href="profile/balance.php" class="balance-button">Пополнить</a>
                        </div>
                    </div>
                </div>

                <div class="profile-tabs">
                    <a href="profile.php?tab=profile" class="profile-tab <?php echo $activeTab === 'profile' ? 'active' : ''; ?>">
                        Профиль
                    </a>
                    <a href="profile.php?tab=trainings" class="profile-tab <?php echo $activeTab === 'trainings' ? 'active' : ''; ?>">
                        Тренировки
                    </a>
                    <a href="profile.php?tab=purchases" class="profile-tab <?php echo $activeTab === 'purchases' ? 'active' : ''; ?>">
                        Покупки
                    </a>
                </div>

                <?php if ($activeTab === 'profile'): ?>
                    <div class="profile-section">
                        <!-- <h2 class="profile-section-title">Мой аккаунт</h2> -->
                        <ul class="profile-menu">
                            <a href="profile/personal.php" class="profile-menu-item">
                                <svg class="profile-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21M16 7C16 9.20914 14.2091 11 12 11C9.79086 11 8 9.20914 8 7C8 4.79086 9.79086 3 12 3C14.2091 3 16 4.79086 16 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="profile-menu-text">Личные данные</span>
                                <span class="profile-menu-arrow">›</span>
                            </a>
                            <a href="profile.php?tab=trainings" class="profile-menu-item">
                                <svg class="profile-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M16 4H8C5.79086 4 4 5.79086 4 8V16C4 18.2091 5.79086 20 8 20H16C18.2091 20 20 18.2091 20 16V8C20 5.79086 18.2091 4 16 4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M9 9L11 11L15 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="profile-menu-text">Мой зал</span>
                                <span class="profile-menu-arrow">›</span>
                            </a>
                            <a href="profile.php?tab=trainings" class="profile-menu-item">
                                <svg class="profile-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2V22M22 12H2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M6.34 6.34L17.66 17.66M17.66 6.34L6.34 17.66" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="profile-menu-text">История посещений</span>
                                <span class="profile-menu-arrow">›</span>
                            </a>
                            <a href="profile.php?tab=purchases" class="profile-menu-item">
                                <svg class="profile-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="profile-menu-text">История платежей</span>
                                <span class="profile-menu-arrow">›</span>
                            </a>
                            <div class="profile-menu-item" style="cursor: default;">
                                <svg class="profile-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M21 4H3C1.89543 4 1 4.89543 1 6V18C1 19.1046 1.89543 20 3 20H21C22.1046 20 23 19.1046 23 18V6C23 4.89543 22.1046 4 21 4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M1 10H23" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="profile-menu-text">Баланс</span>
                                <a href="profile/balance.php" class="balance-button" style="margin-left: auto;">Пополнить</a>
                            </div>
                            <a href="assistant.php" class="profile-menu-item">
                                <svg class="profile-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M9.09 9.00002C9.3251 8.33169 9.78915 7.76813 10.4 7.40915C11.0108 7.05018 11.7289 6.91896 12.4272 7.03873C13.1255 7.15851 13.7588 7.52154 14.2151 8.06354C14.6713 8.60553 14.9211 9.29152 14.92 10C14.92 12 11.92 13 11.92 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M12 17H12.01" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="profile-menu-text">Обратная связь</span>
                                <span class="profile-menu-arrow">›</span>
                            </a>
                            <a href="#" class="profile-menu-item">
                                <svg class="profile-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M14 2H6C4.89543 2 4 2.89543 4 4V20C4 21.1046 4.89543 22 6 22H18C19.1046 22 20 21.1046 20 20V8L14 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M14 2V8H20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M16 13H8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M16 17H8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M10 9H8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="profile-menu-text">Правовые документы</span>
                                <span class="profile-menu-arrow">›</span>
                            </a>
                            <!-- <a href="profile.php?logout=1" class="profile-logout">
                            <svg class="profile-logout-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            Выйти из аккаунта
                        </a> -->
                        </ul>

                   
                    </div>
                <?php elseif ($activeTab === 'trainings'): ?>
                    <div class="profile-section">
                        <h2 class="profile-section-title">Мои тренировки</h2>
                        
                        <?php if (empty($trainings)): ?>
                            <div class="no-data">
                                <p>У вас пока нет записей на тренировки</p>
                                <p style="margin-top: 10px;"><a href="calendar.php" style="color: #7171dc; text-decoration: underline;">Перейти к расписанию</a></p>
                            </div>
                        <?php else: ?>
                            <ul class="profile-trainings">
                                <?php foreach ($trainings as $training): ?>
                                    <li class="profile-training-item loading" data-activity-id="<?php echo $training['id']; ?>">
                                        <div class="profile-training-header">
                                            <div class="profile-training-title"><?php echo htmlspecialchars($training['title']); ?></div>
                                            <div class="profile-training-status <?php echo $training['status'] === 'Предстоит' ? 'upcoming' : 'completed'; ?>">
                                                <?php echo htmlspecialchars($training['status']); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="profile-training-info">
                                            <div class="profile-training-info-row">
                                                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8 2V5M16 2V5M3.5 9.09H20.5M21 8.5V17C21 20 19.5 22 16 22H8C4.5 22 3 20 3 17V8.5C3 5.5 4.5 3.5 8 3.5H16C19.5 3.5 21 5.5 21 8.5Z" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <span><?php echo $training['datetime']->format('d.m.Y'); ?></span>
                                            </div>
                                            
                                            <div class="profile-training-info-row">
                                                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M12 6V12L16 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <span class="skeleton skeleton-text" data-field="time">Загрузка...</span>
                                            </div>
                                            
                                            <div class="profile-training-info-row">
                                                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 13C13.6569 13 15 11.6569 15 10C15 8.34315 13.6569 7 12 7C10.3431 7 9 8.34315 9 10C9 11.6569 10.3431 13 12 13Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M12 22C16 18 20 14.4183 20 10C20 5.58172 16.4183 2 12 2C7.58172 2 4 5.58172 4 10C4 14.4183 8 18 12 22Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <span><?php echo htmlspecialchars($training['address']); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="profile-training-trainer">
                                            <div class="profile-training-trainer-photo skeleton skeleton-circle" data-field="trainer-photo"></div>
                                            <div class="profile-training-trainer-info">
                                                <div class="profile-training-trainer-label">Тренер</div>
                                                <div class="profile-training-trainer-name skeleton skeleton-text" data-field="trainer-name">Загрузка...</div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php elseif ($activeTab === 'purchases'): ?>
                    <div class="profile-section">
                        <h2 class="profile-section-title">Мои покупки</h2>
                        
                        <?php if (empty($purchases)): ?>
                            <div class="no-data">У вас пока нет покупок</div>
                        <?php else: ?>
                            <ul class="profile-purchases">
                                <?php foreach ($purchases as $purchase): ?>
                                    <li class="profile-purchase-item">
                                        <div class="profile-purchase-title"><?php echo htmlspecialchars($purchase['title']); ?></div>
                                        <div class="profile-purchase-date"><?php echo date('d.m.Y', strtotime($purchase['date'])); ?></div>
                                        <div class="profile-purchase-price"><?php echo number_format($purchase['price'], 0, '.', ' '); ?> ₽</div>
                                        <div class="profile-purchase-status"><?php echo htmlspecialchars($purchase['status']); ?></div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php $activePage = 'profile'; include 'components/navigation.php'; ?>
    </div>

    <script>
    // Асинхронная загрузка деталей тренировок
    document.addEventListener('DOMContentLoaded', function() {
        const trainingItems = document.querySelectorAll('.profile-training-item.loading');
        
        if (trainingItems.length === 0) return;
        
        // Загружаем детали для каждой тренировки
        trainingItems.forEach(async (item) => {
            const activityId = item.dataset.activityId;
            
            try {
                const response = await fetch(`api/activity_details.php?id=${activityId}`);
                const result = await response.json();
                
                if (result.success && result.data) {
                    const data = result.data;
                    
                    // Обновляем время и длительность
                    const timeField = item.querySelector('[data-field="time"]');
                    if (timeField) {
                        timeField.textContent = `${data.time} (${data.duration})`;
                        timeField.classList.remove('skeleton', 'skeleton-text');
                    }
                    
                    // Обновляем фото тренера
                    const trainerPhoto = item.querySelector('[data-field="trainer-photo"]');
                    if (trainerPhoto) {
                        const img = document.createElement('img');
                        img.src = data.trainer.photo;
                        img.alt = data.trainer.name;
                        img.className = 'profile-training-trainer-photo';
                        trainerPhoto.replaceWith(img);
                    }
                    
                    // Обновляем имя тренера
                    const trainerName = item.querySelector('[data-field="trainer-name"]');
                    if (trainerName) {
                        trainerName.textContent = data.trainer.name;
                        trainerName.classList.remove('skeleton', 'skeleton-text');
                    }
                    
                    // Убираем класс loading
                    item.classList.remove('loading');
                } else {
                    console.error('Failed to load activity details:', activityId);
                    // В случае ошибки показываем значения по умолчанию
                    item.classList.remove('loading');
                    const timeField = item.querySelector('[data-field="time"]');
                    if (timeField) {
                        timeField.textContent = 'Время уточняется';
                        timeField.classList.remove('skeleton', 'skeleton-text');
                    }
                    const trainerName = item.querySelector('[data-field="trainer-name"]');
                    if (trainerName) {
                        trainerName.textContent = 'Тренер';
                        trainerName.classList.remove('skeleton', 'skeleton-text');
                    }
                    const trainerPhoto = item.querySelector('[data-field="trainer-photo"]');
                    if (trainerPhoto) {
                        const img = document.createElement('img');
                        img.src = 'Images/trainer.jpg';
                        img.alt = 'Тренер';
                        img.className = 'profile-training-trainer-photo';
                        trainerPhoto.replaceWith(img);
                    }
                }
            } catch (error) {
                console.error('Error loading activity details:', error);
                item.classList.remove('loading');
            }
        });
    });
    </script>
</body>
</html>
