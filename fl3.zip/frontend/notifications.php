<?php
require_once 'api/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Get current user
$user = getCurrentUser();
if (!$user) {
    logout();
    redirect('login.php');
}

// Get notifications
$notifications = getUserNotifications($_SESSION['user_id']);

// Mark notification as read if requested
if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    $notificationId = (int)$_GET['mark_read'];
    markNotificationAsRead($notificationId);
    redirect('notifications.php');
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Уведомления | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        body {
            font-family: "Inter", sans-serif;
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        a {
            text-decoration: none;
        }

        .clear {
            clear: both;
        }

        .wrap {
            width: 100%;
        }

        .app {
            padding: 0 15px;
            margin: 0 auto;
            max-width: 400px;
        }

        /* Notifications Page */
        .notifications-page {
            padding: 20px 0 90px;
        }

        .notifications-header {
            margin-bottom: 20px;
        }

        .notifications-title {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin: 0;
        }

        .notifications-list {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .notification-item {
            background: #fff;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.05);
            position: relative;
        }

        .notification-item.unread {
            border-left: 3px solid #7171dc;
        }

        .notification-title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin: 0 0 10px 0;
        }

        .notification-text {
            font-size: 14px;
            color: #666;
            margin: 0 0 10px 0;
        }

        .notification-date {
            font-size: 12px;
            color: #999;
            margin: 0;
        }

        .notification-mark-read {
            position: absolute;
            top: 15px;
            right: 15px;
            background: none;
            border: none;
            color: #7171dc;
            font-size: 12px;
            cursor: pointer;
            padding: 0;
        }

        .no-notifications {
            text-align: center;
            padding: 30px 0;
            color: #666;
        }

            color: #7171dc;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="notifications-page">
                <div class="notifications-header">
                    <h1 class="notifications-title">Уведомления</h1>
                </div>

                <?php if (empty($notifications)): ?>
                    <div class="no-notifications">У вас пока нет уведомлений</div>
                <?php else: ?>
                    <ul class="notifications-list">
                        <?php foreach ($notifications as $notification): ?>
                            <li class="notification-item <?php echo $notification['is_read'] ? '' : 'unread'; ?>">
                                <h2 class="notification-title"><?php echo htmlspecialchars($notification['title']); ?></h2>
                                <p class="notification-text"><?php echo htmlspecialchars($notification['text']); ?></p>
                                <p class="notification-date"><?php echo date('d.m.Y H:i', strtotime($notification['created_at'])); ?></p>
                                <?php if (!$notification['is_read']): ?>
                                    <a href="notifications.php?mark_read=<?php echo $notification['id']; ?>" class="notification-mark-read"></a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
        
        <?php $activePage = 'notifications'; $navType = 'notifications'; include 'components/navigation.php'; ?>
    </div>
</body>
</html>
