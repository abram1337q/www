<?php
require_once 'api/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Get current user
$user = getCurrentUser();
if (!$user) {
    logout();
    redirect('login.php');
}

// Update the filter handling to use category IDs

// Get filter
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Map filter names to category IDs if needed
$categoryMap = [
    'trial' => 1,  // Assuming category ID 1 is for trial classes
    'morning' => 2, // Assuming category ID 2 is for morning classes
    'day' => 3,     // Assuming category ID 3 is for day classes
    'evening' => 4  // Assuming category ID 4 is for evening classes
];

// Convert filter name to category ID if applicable
$filterParam = isset($categoryMap[$filter]) ? $categoryMap[$filter] : $filter;

// Get shop items
$items = getShopItems($filterParam);


// Добавим отладочную информацию
error_log('Filter: ' . $filter);
error_log('Filter param: ' . $filterParam);

// Handle purchase
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'purchase') {
    $itemId = $_POST['item_id'] ?? 0;
    $price = $_POST['price'] ?? 0;
    
    // Find the item
    $selectedItem = null;
    foreach ($items as $item) {
        if ($item['id'] == $itemId) {
            $selectedItem = $item;
            break;
        }
    }
    
    if (!$selectedItem) {
        $error = 'Товар не найден';
    } elseif ($user['balance'] < $selectedItem['price']) {
        $error = 'Недостаточно средств на балансе';
    } else {
        // In a real application, this would update the user's balance and record the purchase
        // For now, we'll just show a success message
        $success = 'Покупка успешно совершена';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Магазин | Фитнес-клуб</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        html, body {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: "Inter", sans-serif;
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        a {
            text-decoration: none;
        }

        .clear {
            clear: both;
        }

        .wrap {
            width: 100%;
        }

        .app {
            padding: 0 40px;
            margin: 0 auto;
            max-width: 360px;
        }

        /* Shop Page */
        .shop-page {
            padding: 20px 0 70px;
        }

        .shop-header {
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .shop-title {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin: 0;
        }

        .shop-balance {
            font-size: 18px;
            font-weight: bold;
            color: #7171dc;
        }

        .shop-filters {
            display: flex;
            overflow-x: auto;
            margin-bottom: 20px;
            padding-bottom: 10px;
        }

        .shop-filter {
            padding: 8px 16px;
            background: #f0f0f0;
            border-radius: 20px;
            margin-right: 10px;
            font-size: 14px;
            color: #666;
            white-space: nowrap;
            cursor: pointer;
            text-decoration: none;
        }

        .shop-filter.active {
            background: #7171dc;
            color: #fff;
        }

        .shop-items {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }

        .shop-item {
            background: #fff;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.05);
        }

        .shop-item-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .shop-item-content {
            padding: 15px;
        }

        .shop-item-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin: 0 0 5px 0;
        }

        .shop-item-duration {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }

        .shop-item-description {
            font-size: 14px;
            color: #666;
            margin-bottom: 15px;
        }

        .shop-item-price {
            font-size: 18px;
            font-weight: bold;
            color: #7171dc;
            margin-bottom: 15px;
        }

        .shop-item-button {
            background: #7171dc;
            color: #fff;
            border: none;
            text-align: center;
            line-height: 14px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            margin: 0;
            border-radius: 30px;
            width: 100%;
            box-sizing: border-box;
            padding: 15px 0;
        }

        .shop-item-new {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #ff4d4d;
            color: #fff;
            padding: 5px 10px;
            border-radius: 10px;
            font-size: 12px;
            font-weight: bold;
        }

            color: #7171dc;
        }

        .success-message {
            background: #4CAF50;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .error-message {
            background: #f44336;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="shop-page">
                <div class="shop-header">
                    <h1 class="shop-title">Магазин</h1>
                    <div class="shop-balance"><?php echo number_format($user['balance'], 0, '.', ' '); ?> ₽</div>
                </div>

                <?php if (isset($success)): ?>
                    <div class="success-message"><?php echo $success; ?></div>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="shop-filters">
                    <a href="shop.php?filter=all" class="shop-filter <?php echo $filter === 'all' ? 'active' : ''; ?>">Все</a>
                    <a href="shop.php?filter=trial" class="shop-filter <?php echo $filter === 'trial' ? 'active' : ''; ?>">Пробные</a>
                    <a href="shop.php?filter=morning" class="shop-filter <?php echo $filter === 'morning' ? 'active' : ''; ?>">Утренние</a>
                    <a href="shop.php?filter=day" class="shop-filter <?php echo $filter === 'day' ? 'active' : ''; ?>">Дневные</a>
                    <a href="shop.php?filter=evening" class="shop-filter <?php echo $filter === 'evening' ? 'active' : ''; ?>">Вечерние</a>
                </div>
                <?php 
                error_log('Items count: ' . count($items)); 
                foreach ($items as $index => $item) {
                    error_log("Item $index: " . json_encode($item));
                }
                ?>
                <div class="shop-items">
                    <?php foreach ($items as $item): ?>
                        <div class="shop-item">
                            <?php if ($item['isNew']): ?>
                                <div class="shop-item-new">Новинка</div>
                            <?php endif; ?>
                            <img src="<?php echo !empty($item['image']) ? htmlspecialchars($item['image']) : '/images/photo-1.png'; ?>" alt="<?php echo htmlspecialchars($item['title']); ?>" class="shop-item-image">
                            <div class="shop-item-content">
                                <h2 class="shop-item-title"><?php echo htmlspecialchars($item['title']); ?></h2>
                                <p class="shop-item-duration"><?php echo htmlspecialchars($item['duration']); ?></p>
                                <p class="shop-item-description"><?php echo htmlspecialchars($item['description']); ?></p>
                                <p class="shop-item-price"><?php echo number_format($item['price'], 0, '.', ' '); ?> ₽</p>
                                <form method="post" action="shop.php?filter=<?php echo $filter; ?>">
                                    <input type="hidden" name="action" value="purchase">
                                    <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                                    <input type="hidden" name="price" value="<?php echo $item['price']; ?>">
                                    <button type="submit" class="shop-item-button">Купить</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <?php $activePage = 'tariffs'; include 'components/navigation.php'; ?>
    </div>
</body>
</html>
