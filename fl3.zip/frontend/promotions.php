
<?php
require_once 'api/config.php';
require_once 'components/back_button.php';

// Check if user is logged in
// if (!isLoggedIn()) {
//     redirect('login.php');
// }

// // Get current user
// $user = getCurrentUser();
// if (!$user) {
//     logout();
//     redirect('login.php');
// }

// Check if this is a Telegram WebApp
$isTelegramWebApp = isset($_GET['tgWebAppData']) || isset($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN']);

// Function to get promotions data from API
function getPromotions() {
    // TODO: Replace with actual API call
    // Example: return json_decode(file_get_contents(API_URL . '/promotions'), true);

    return [
        [
            'id' => 1,
            'title' => 'Скидка 20% на первое посещение',
            'description' => 'Специальное предложение для новых клиентов',
            'full_description' => 'Фи́тнес-клуб — место, сочетающее в себе спортивный зал для проведения групповых и танцевальных программ, спортивный зал для игровых видов спорта, тренажёрный зал, плавательный бассейн, кардио-зону, залы аэробики, студии сайкла, студии пилатеса на большом оборудовании, студии единоборств, студии йоги.',
            'image_url' => 'Images/promotion1.jpg',
            'link_url' => 'promotion_detail.php?id=1',
            'is_active' => true,
            'start_date' => '2024-01-01',
            'end_date' => '2024-12-31'
        ],
        [
            'id' => 2,
            'title' => 'Семейный абонемент',
            'description' => 'Скидка 15% при покупке абонемента на двоих',
            'full_description' => 'Фи́тнес-клуб — место, сочетающее в себе спортивный зал для проведения групповых и танцевальных программ, спортивный зал для игровых видов спорта, тренажёрный зал, плавательный бассейн, кардио-зону, залы аэробики, студии сайкла, студии пилатеса на большом оборудовании, студии единоборств, студии йоги.',
            'image_url' => 'Images/promotion2.jpg',
            'link_url' => 'promotion_detail.php?id=2',
            'is_active' => true,
            'start_date' => '2024-01-01',
            'end_date' => '2024-12-31'
        ],
        [
            'id' => 3,
            'title' => 'Раннее бронирование',
            'description' => 'Скидка 10% при бронировании за неделю',
            'full_description' => 'Фи́тнес-клуб — место, сочетающее в себе спортивный зал для проведения групповых и танцевальных программ, спортивный зал для игровых видов спорта, тренажёрный зал, плавательный бассейн, кардио-зону, залы аэробики, студии сайкла, студии пилатеса на большом оборудовании, студии единоборств, студии йоги.',
            'image_url' => 'Images/promotion3.jpg',
            'link_url' => 'promotion_detail.php?id=3',
            'is_active' => true,
            'start_date' => '2024-01-01',
            'end_date' => '2024-12-31'
        ],
        [
            'id' => 4,
            'title' => 'День рождения',
            'description' => 'Бесплатное посещение в день рождения',
            'full_description' => 'Фи́тнес-клуб — место, сочетающее в себе спортивный зал для проведения групповых и танцевальных программ, спортивный зал для игровых видов спорта, тренажёрный зал, плавательный бассейн, кардио-зону, залы аэробики, студии сайкла, студии пилатеса на большом оборудовании, студии единоборств, студии йоги.',
            'image_url' => 'Images/promotion4.jpg',
            'link_url' => 'promotion_detail.php?id=4',
            'is_active' => true,
            'start_date' => '2024-01-01',
            'end_date' => '2024-12-31'
        ]
    ];
}

// Get promotions data
$promotions = getPromotions();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Акции | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <?php if ($isTelegramWebApp): ?>
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <?php endif; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --secondary-color: #f4f4f4;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --danger-color: #ff4d4d;
            --success-color: #4CAF50;
            --border-radius: 16px;
            --button-radius: 13px;
            --shadow: 0px 2px 10px rgba(0, 0, 0, 0.05);
        }

        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: #ffffff;
            overflow-y: auto;
            overflow-x: hidden;
        }

        @supports (-webkit-touch-callout: none) {
            html, body {
                height: -webkit-fill-available;
            }
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .wrap {
            width: 100%;
            max-width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .app {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }


        /* Main content */
        .main-content {
            flex: 1;
            background: #ffffff;
            overflow-y: auto;
            margin-top: 24px;
        }

        .content-wrapper {
            padding: 0;
        }

        /* Promotions list */
        .promotions-list {
            display: flex;
            flex-direction: column;
            gap: 16px;
            padding: 0 24px 24px 24px;
        }

        .promotion-item {
            width: 100%;
            height: 136px;
            background: #E8E8E8;
            border-radius: 4px;
            overflow: hidden;
            position: relative;
        }

        .promotion-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 4px;
        }

        .promotion-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(0, 0, 0, 0.65);
            padding: 20px 16px 16px 16px;
            color: white;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
        }

        .promotion-title {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 6px;
            line-height: 1.2;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.5);
        }

        .promotion-description {
            font-size: 13px;
            font-weight: 400;
            opacity: 0.95;
            line-height: 1.4;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.5);
        }

        /* Navigation spacing */
        .main-page {
            padding-bottom: 70px;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="main-page">
                <!-- Header -->
                <?php renderBackButton('home.php', 'Акции', true); ?>

                <!-- Main content -->
                <div class="main-content">
                    <div class="content-wrapper">
                        <div class="promotions-list">
                            <?php foreach ($promotions as $promotion): ?>
                                <?php if ($promotion['is_active']): ?>
                                    <a href="<?php echo htmlspecialchars($promotion['link_url']); ?>" class="promotion-item">
                                        <img src="<?php echo htmlspecialchars($promotion['image_url']); ?>"
                                             alt="<?php echo htmlspecialchars($promotion['title']); ?>"
                                             class="promotion-image"
                                             onerror="this.src='Images/gym-banner.jpg'">
                                        <!-- <div class="promotion-overlay">
                                            <div class="promotion-title"><?php echo htmlspecialchars($promotion['title']); ?></div>
                                            <div class="promotion-description"><?php echo htmlspecialchars($promotion['description']); ?></div>
                                        </div> -->
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- <?php $activePage = 'promotions'; include 'components/navigation.php'; ?> -->
    </div>

    <?php if ($isTelegramWebApp): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Telegram WebApp
            const tg = window.Telegram.WebApp;
            tg.expand();
            tg.ready();
        });
    </script>
    <?php endif; ?>
</body>
</html>
