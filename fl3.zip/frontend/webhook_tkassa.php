<?php
require_once 'api/config.php';
require_once 'api/tkassa_api.php';
require_once 'api/balance.php';

// Логирование для отладки
function logWebhook($message, $data = null) {
    $logFile = 'webhook_tkassa.log';
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $message";

    if ($data !== null) {
        $logMessage .= " | Data: " . json_encode($data, JSON_UNESCAPED_UNICODE);
    }

    $logMessage .= PHP_EOL;
    file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
}

// Проверка аутентификации вебхука (если требуется T-Kassa)
function verifyWebhookAuth() {
    // T-Kassa может отправлять вебхуки без дополнительной аутентификации
    // или с использованием специальных заголовков
    // Здесь можно добавить проверку, если она требуется

    return true;
}

// Обработка вебхука от T-Kassa
function handleTKassaWebhook() {
    // Проверка метода запроса
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        logWebhook('Invalid request method: ' . $_SERVER['REQUEST_METHOD']);
        http_response_code(405);
        return;
    }

    // Получение данных вебхука
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        logWebhook('JSON decode error: ' . json_last_error_msg(), $input);
        http_response_code(400);
        return;
    }

    logWebhook('Webhook received', $data);

    // Проверка обязательных полей
    if (!isset($data['OrderId']) || !isset($data['Status'])) {
        logWebhook('Missing required fields: OrderId or Status');
        http_response_code(400);
        return;
    }

    $orderId = $data['OrderId'];
    $status = $data['Status'];

    logWebhook("Processing order $orderId with status $status");

    // Проверка статуса платежа
    // Согласно документации T-Bank API:
    // AUTHORIZED - платеж авторизован (для двухстадийной оплаты)
    // CONFIRMED - платеж подтвержден
    // CANCELED - платеж отменен
    // REFUNDED - платеж возвращен
    // REJECTED - платеж отклонен
    // DEADLINE_EXPIRED - истек срок оплаты
    // REVERSED - платеж отменен (реверс)

    if ($status === 'CONFIRMED') { // Платеж подтвержден
        processSuccessfulPayment($orderId, $data);
    } elseif ($status === 'AUTHORIZED') { // Для одностадийной оплаты тоже можно считать успехом
        processSuccessfulPayment($orderId, $data);
    } elseif (in_array($status, ['CANCELED', 'REFUNDED', 'REJECTED', 'REVERSED', 'DEADLINE_EXPIRED'])) {
        processFailedPayment($orderId, $data);
    } else {
        logWebhook("Payment status $status does not require processing");
    }

    // Возврат успешного ответа
    http_response_code(200);
    echo json_encode(['status' => 'ok']);
}

// Обработка успешного платежа
function processSuccessfulPayment($orderId, $webhookData) {
    // Ищем информацию о платеже в БД (таблица orders)
    require_once 'api/orders.php';
    require_once 'api/database.php';
    
    $ordersAPI = new OrdersAPI();
    $order = $ordersAPI->getOrderByOrderId($orderId);

    if (!$order) {
        logWebhook("Order not found in database: $orderId");
        return;
    }
    
    $userId = $order['user_id'];
    $amount = $order['amount'];
    
    // Проверяем, не был ли платеж уже обработан
    if ($order['status'] === 'completed') {
        logWebhook("Order $orderId already processed");
        return;
    }

    // Проверка суммы платежа (если доступна в вебхуке)
    if (isset($webhookData['Amount'])) {
        $webhookAmount = $webhookData['Amount'] / 100; // Конвертация из копеек
        if ($webhookAmount != $amount) {
            logWebhook("Amount mismatch: expected $amount, got $webhookAmount");
            return;
        }
    }

    // Пополнение баланса пользователя
    $balanceAPI = new BalanceAPI();
    $updatedUser = $balanceAPI->rechargeBalance($userId, (int)$amount);

    if ($updatedUser) {
        logWebhook("Balance successfully topped up for user $userId, amount: $amount");

        // Обновляем статус заказа в БД
        $ordersAPI->updateOrderStatus($order['id'], 'completed');

        // Добавление уведомления пользователю
        require_once 'api/notifications.php';
        $notificationsAPI = new NotificationsAPI();
        $notificationsAPI->createNotification(
            $userId,
            'Баланс пополнен',
            "Ваш баланс успешно пополнен на $amount ₽",
            'balance'
        );
        
        // Отправка уведомления в Telegram
        sendTelegramNotification($userId, $orderId, $amount, 'success');

        logWebhook("Payment $orderId processed successfully");
    } else {
        logWebhook("Failed to top up balance for user $userId");
    }
}

// Функция отправки уведомления в Telegram
function sendTelegramNotification($userId, $orderId, $amount, $status) {
    // Получаем telegram_id пользователя из БД
    $conn = getDbConnection();
    $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    
    if (!$user || !$user['telegram_id']) {
        logWebhook("No telegram_id found for user $userId");
        return false;
    }
    
    $telegramId = $user['telegram_id'];
    $botToken = TELEGRAM_BOT_TOKEN;
    
    if ($status === 'success') {
        $message = " <b>Платеж успешно завершен!</b>\n\n"
                 . "💰 Баланс пополнен на <b>{$amount} ₽</b>\n\n"
                 . "📝 Заказ: <code>{$orderId}</code>";
    } else {
        $message = "❌ <b>Платеж отклонен</b>\n\n"
                 . "📝 Заказ: <code>{$orderId}</code>\n\n"
                 . "Попробуйте еще раз или обратитесь в поддержку.";
    }
    
    // Отправка через Telegram Bot API
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    
    $data = [
        'chat_id' => $telegramId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200) {
        logWebhook("Telegram notification sent to user $userId (chat_id: $telegramId)");
        return true;
    } else {
        logWebhook("Failed to send Telegram notification to user $userId: HTTP $httpCode - $response");
        return false;
    }
}

// Обработка неудачного платежа
function processFailedPayment($orderId, $webhookData) {
    logWebhook("Payment $orderId failed or cancelled");

    // Поиск информации о платеже в БД
    require_once 'api/orders.php';
    require_once 'api/database.php';
    
    $ordersAPI = new OrdersAPI();
    $order = $ordersAPI->getOrderByOrderId($orderId);
    
    if (!$order) {
        logWebhook("Payment info not found for order $orderId");
        return;
    }
    
    $userId = $order['user_id'];
    $amount = $order['amount'];

    // Обновляем статус заказа
    $ordersAPI->updateOrderStatus($order['id'], 'failed');

    // Добавление уведомления пользователю об ошибке платежа
    require_once 'api/notifications.php';
    $notificationsAPI = new NotificationsAPI();
    $notificationsAPI->createNotification(
        $userId,
        'Ошибка платежа',
        'Платеж был отменен или отклонен. Попробуйте еще раз.',
        'payment'
    );
    
    // Отправка уведомления в Telegram
    sendTelegramNotification($userId, $orderId, $amount, 'failed');

    logWebhook("Failed payment $orderId processed for user $userId");
}

// Основная логика обработки вебхука
try {
    // Проверка аутентификации (если требуется)
    if (!verifyWebhookAuth()) {
        logWebhook('Webhook authentication failed');
        http_response_code(401);
        exit;
    }

    handleTKassaWebhook();

} catch (Exception $e) {
    logWebhook('Webhook processing error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}
?>
