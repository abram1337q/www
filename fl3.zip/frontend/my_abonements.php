<?php
require_once 'api/config.php';
require_once 'api/abonements.php';

// Проверка авторизации
$user = requireAuth();

// Получаем абонементы пользователя
$abonementsAPI = new AbonementsAPI();
$abonements = $abonementsAPI->getUserAbonements($user['id']);

// Разделяем на активные и истекшие
$activeAbonements = [];
$expiredAbonements = [];

foreach ($abonements as $abonement) {
    if ($abonement['is_active']) {
        $activeAbonements[] = $abonement;
    } else {
        $expiredAbonements[] = $abonement;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Мои абонементы | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: "Inter", sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .wrap {
            padding: 20px 15px 90px 15px;
            max-width: 600px;
            margin: 0 auto;
        }

        .page-header {
            margin-bottom: 20px;
        }

        .page-title {
            font-size: 24px;
            font-weight: 700;
            color: #333;
            margin: 0;
        }

        .section {
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 700;
            margin: 0 0 15px 0;
            color: #333;
        }

        .abonement-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .abonement-card.active {
            border: 2px solid #667eea;
        }

        .abonement-card.expired {
            opacity: 0.6;
        }

        .abonement-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .abonement-title {
            font-size: 18px;
            font-weight: 700;
            color: #333;
        }

        .abonement-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-active {
            background: #d4edda;
            color: #155724;
        }

        .status-expired {
            background: #f8d7da;
            color: #721c24;
        }

        .abonement-info {
            margin-bottom: 10px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-label {
            color: #666;
            font-size: 14px;
        }

        .info-value {
            font-weight: 600;
            color: #333;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #666;
        }

        .empty-state-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            text-decoration: none;
            background: #9B9FE8;
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .balance-badge {
            display: inline-block;
            background: #9B9FE8;
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <?php include 'components/back_button.php'; ?>
    
    <div class="wrap">
        <div class="page-header">
            <h1 class="page-title">Мои абонементы</h1>
        </div>

        <!-- Активные абонементы -->
        <div class="section">
            <h2 class="section-title">Активные</h2>
            
            <?php if (empty($activeAbonements)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">📋</div>
                    <div>У вас нет активных абонементов</div>
                </div>
                <a href="buy_abonement.php" class="btn">
                    Купить абонемент
                </a>
            <?php else: ?>
                <?php foreach ($activeAbonements as $abonement): ?>
                    <div class="abonement-card active">
                        <div class="abonement-header">
                            <div class="abonement-title"><?php echo $abonement['type_name']; ?></div>
                            <div class="abonement-status status-active">Активен</div>
                        </div>
                        <div class="abonement-info">
                            <?php if ($abonement['abonement_type'] === 'single'): ?>
                                <div class="info-row">
                                    <div class="info-label">Осталось посещений:</div>
                                    <div class="info-value">
                                        <span class="balance-badge"><?php echo $abonement['balance']; ?></span>
                                    </div>
                                </div>
                            <?php else: ?>
                                <?php if (isset($abonement['expires_at']) && $abonement['expires_at']): ?>
                                    <div class="info-row">
                                        <div class="info-label">Действует до:</div>
                                        <div class="info-value"><?php echo date('d.m.Y', strtotime($abonement['expires_at'])); ?></div>
                                    </div>
                                <?php endif; ?>
                                <div class="info-row">
                                    <div class="info-label">Посещений:</div>
                                    <div class="info-value">Безлимит</div>
                                </div>
                            <?php endif; ?>
                            <div class="info-row">
                                <div class="info-label">Куплен:</div>
                                <div class="info-value"><?php echo date('d.m.Y', strtotime($abonement['purchased_at'])); ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Истекшие абонементы -->
        <?php if (!empty($expiredAbonements)): ?>
            <div class="section">
                <h2 class="section-title">Истекшие</h2>
                <?php foreach ($expiredAbonements as $abonement): ?>
                    <div class="abonement-card expired">
                        <div class="abonement-header">
                            <div class="abonement-title"><?php echo $abonement['type_name']; ?></div>
                            <div class="abonement-status status-expired">Истек</div>
                        </div>
                        <div class="abonement-info">
                            <?php if (isset($abonement['expires_at']) && $abonement['expires_at']): ?>
                                <div class="info-row">
                                    <div class="info-label">Срок истек:</div>
                                    <div class="info-value"><?php echo date('d.m.Y', strtotime($abonement['expires_at'])); ?></div>
                                </div>
                            <?php endif; ?>
                            <div class="info-row">
                                <div class="info-label">Куплен:</div>
                                <div class="info-value"><?php echo date('d.m.Y', strtotime($abonement['purchased_at'])); ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php include 'components/navigation.php'; ?>
</body>
</html>

