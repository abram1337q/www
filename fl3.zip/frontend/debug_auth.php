<?php
require_once 'api/config.php';

// Проверка авторизации с поддержкой Telegram
$user = requireAuth();

// Если не авторизован, показываем диагностику
if (!$user) {
    echo "<h1>Не авторизован</h1>";
    echo "<p>Текущий пользователь: null</p>";
    echo "<p>Сессия: " . (isset($_SESSION['user_id']) ? 'Да' : 'Нет') . "</p>";
    exit;
}

echo "<h1>Диагностика авторизации</h1>";
echo "<h2>Текущий пользователь:</h2>";
echo "<ul>";
echo "<li>ID: " . ($user['id'] ?? 'null') . "</li>";
echo "<li>Telegram ID: " . ($user['telegram_id'] ?? 'null') . "</li>";
echo "<li>Имя: " . ($user['first_name'] ?? 'null') . " " . ($user['last_name'] ?? '') . "</li>";
echo "<li>Телефон: " . ($user['phone'] ?? 'null') . "</li>";
echo "<li>YClients Client ID: " . ($user['yclients_client_id'] ?? 'null') . "</li>";
echo "</ul>";

echo "<h2>Параметры запроса:</h2>";
echo "<ul>";
echo "<li>tgWebAppData: " . (isset($_GET['tgWebAppData']) ? 'Да (' . strlen($_GET['tgWebAppData']) . ' символов)' : 'Нет') . "</li>";
echo "<li>User Agent: " . ($_SERVER['HTTP_USER_AGENT'] ?? 'null') . "</li>";
echo "<li>Host: " . ($_SERVER['HTTP_HOST'] ?? 'null') . "</li>";
echo "</ul>";

if ($user['yclients_client_id']) {
    echo "<h2>Проверка записей в YClients:</h2>";

    global $yclients;
    try {
        $bookings = $yclients->getClientBookings($user['yclients_client_id']);
        echo "<p>Найдено записей: " . count($bookings) . "</p>";

        if (!empty($bookings)) {
            echo "<ul>";
            foreach ($bookings as $booking) {
                echo "<li>Activity ID: " . $booking['id'] . ", Дата: " . $booking['date'] . "</li>";
            }
            echo "</ul>";
        } else {
            echo "<p><strong>Записей не найдено!</strong></p>";
        }
    } catch (Exception $e) {
        echo "<p><strong>Ошибка при получении записей: " . $e->getMessage() . "</strong></p>";
    }
} else {
    echo "<h2>Предупреждение:</h2>";
    echo "<p>У пользователя нет связи с YClients клиентом. Записи не могут быть загружены.</p>";
    echo "<p>Возможные причины:</p>";
    echo "<ul>";
    echo "<li>Пользователь не указал телефон при регистрации</li>";
    echo "<li>Телефон не найден в базе YClients</li>";
    echo "<li>Связь была удалена или не создана</li>";
    echo "</ul>";
}

echo "<h2>Связывание с YClients (если нужно):</h2>";
if (!empty($user['phone'])) {
    echo "<p>У пользователя есть телефон: " . $user['phone'] . "</p>";
    echo "<p>Пытаемся найти клиента в YClients...</p>";

    global $yclients;
    try {
        $yclientsClient = $yclients->findClientByPhone($user['phone']);
        if ($yclientsClient) {
            echo "<p><strong>Найден клиент YClients: ID " . $yclientsClient['id'] . ", Имя: " . $yclientsClient['name'] . "</strong></p>";
            echo "<p>Обновляем связь...</p>";

            $updatedUser = updateUser($user['id'], ['yclients_client_id' => $yclientsClient['id']]);
            if ($updatedUser) {
                echo "<p><strong> Связь обновлена! Перезагрузите страницу.</strong></p>";
            } else {
                echo "<p><strong>❌ Ошибка при обновлении связи</strong></p>";
            }
        } else {
            echo "<p><strong>❌ Клиент с таким телефоном не найден в YClients</strong></p>";
        }
    } catch (Exception $e) {
        echo "<p><strong>❌ Ошибка при поиске: " . $e->getMessage() . "</strong></p>";
    }
} else {
    echo "<p>У пользователя нет телефона. Необходимо указать телефон для связи с YClients.</p>";
}
?>







