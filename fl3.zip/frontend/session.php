<?php
require_once 'api/config.php';
require_once 'api/abonements.php';

// Проверка авторизации с поддержкой Telegram
$user = requireAuth();

// Проверяем наличие активного абонемента
$abonementsAPI = new AbonementsAPI();
$canBook = $abonementsAPI->canBookTraining($user['id']);

// Get session data from URL parameters
$sessionId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Get real session data from YClients API
$session = null;
global $yclients;

// Get activities for the selected date to find the specific session
$schedule_data = $yclients->getSchedule(0, $selectedDate, $selectedDate);
error_log("Session lookup for ID {$sessionId} on date {$selectedDate}: " . print_r($schedule_data, true));

// Find the specific seance by ID
if (!empty($schedule_data)) {
    foreach($schedule_data as $item) {
        if (empty($item['seances'])) continue;

        foreach($item['seances'] as $seance) {
            if ($seance['id'] == $sessionId) {
                $start_time = new DateTime($seance['date']);
                $end_time = new DateTime($seance['date']);
                $end_time->modify('+' . $seance['length'] . ' seconds');

                $session = [
                    'id' => $seance['id'],
                    'title' => $seance['service']['title'],
                    'date' => $selectedDate,
                    'time' => $start_time->format('H:i') . ' - ' . $end_time->format('H:i'),
                    'start_time' => $start_time->format('H:i'),
                    'end_time' => $end_time->format('H:i'),
                    'duration' => ($seance['length'] / 60) . ' мин',
                    'address' => APP_ADDRESS,
                    'trainer' => [
                        'id' => $item['staff']['id'],
                        'name' => $item['staff']['name'],
                        'photo' => $item['staff']['avatar_big'] ?? 'Images/trainer.jpg'
                    ],
                    'freeSpots' => $seance['capacity'] - count($seance['records']),
                    'totalSpots' => $seance['capacity'],
                    'description' => 'Описание тренировки будет получено из системы управления.',
                    'price' => $seance['price'] ?? 0
                ];
                break 2;
            }
        }
    }
}

if (!$session) {
    // Redirect back to calendar if session not found
    error_log("Session {$sessionId} not found in API data");
    redirect('calendar.php');
}

// Handle booking
$bookingMessage = '';
$bookingError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'book_session') {
    try {
        // Подготавливаем данные клиента
        $clientData = [
            'name' => $user['first_name'] . ' ' . ($user['last_name'] ?? ''),
            'phone' => $user['phone'] ?? '',
            'email' => $user['email'] ?? ''
        ];
        
        // Записываем на активность
        $bookingResult = $yclients->bookActivity($sessionId, $clientData);
        
        if ($bookingResult === true || (is_array($bookingResult) && !isset($bookingResult['http_code']))) {
            $bookingMessage = 'Вы успешно записались на занятие: ' . $session['title'];
            error_log("User {$user['id']} successfully booked activity {$sessionId}");
            
            // Сохраняем бронирование в локальную БД
            require_once 'api/bookings.php';
            $bookingsAPI = new BookingsAPI();
            
            // Получаем record_id из ответа API
            $recordId = null;
            if (is_array($bookingResult) && isset($bookingResult['id'])) {
                $recordId = $bookingResult['id'];
            }
            
            // Получаем цену услуги
            $servicePrice = $session['price'] ?? 0;
            
            // Создаем запись о бронировании
            $bookingId = $bookingsAPI->createBooking(
                $user['id'],
                $sessionId,
                $recordId,
                $session['title'],
                $servicePrice,
                $session['date'] . ' ' . $session['start_time'] . ':00'
            );
            
            if ($bookingId) {
                error_log("Booking saved to DB with ID {$bookingId}");
                
                // Списываем визит с абонемента (если есть активный)
                if ($canBook['can_book']) {
                    $deductResult = $abonementsAPI->deductVisit($user['id'], $recordId);
                    if ($deductResult['success']) {
                        error_log("Visit deducted from abonement for user {$user['id']}, booking {$bookingId}");
                    } else {
                        error_log("Failed to deduct visit from abonement: {$deductResult['message']}");
                    }
                }
            } else {
                error_log("Failed to save booking to DB");
            }
            
            // Обновляем данные сессии после записи
            $schedule_data = $yclients->getSchedule(0, $selectedDate, $selectedDate);
            foreach($schedule_data as $item) {
                if (empty($item['seances'])) continue;
                foreach($item['seances'] as $seance) {
                    if ($seance['id'] == $sessionId) {
                        $session['freeSpots'] = $seance['capacity'] - count($seance['records']);
                        break 2;
                    }
                }
            }
        } else {
            $bookingError = 'Не удалось записаться на занятие. ';
            
            // Добавляем детали ошибки для отладки
            if (is_array($bookingResult) && isset($bookingResult['http_code'])) {
                $bookingError .= "HTTP {$bookingResult['http_code']}. ";
                
                if (isset($bookingResult['response']['meta']['message'])) {
                    $bookingError .= "Сообщение: {$bookingResult['response']['meta']['message']}. ";
                }
                
                if (isset($bookingResult['response']['data'])) {
                    $bookingError .= "Данные: " . json_encode($bookingResult['response']['data'], JSON_UNESCAPED_UNICODE) . ". ";
                }
                
                $bookingError .= "URL: {$bookingResult['url']}. ";
                $bookingError .= "Отправленные данные: " . json_encode($bookingResult['request_data'], JSON_UNESCAPED_UNICODE);
            } else {
                $bookingError .= "Неизвестная ошибка.";
            }
            
            error_log("Booking failed for user {$user['id']}: " . json_encode($bookingResult));
        }
    } catch (Exception $e) {
        $bookingError = 'Ошибка сервера. Попробуйте позже.';
        error_log("Booking error for user {$user['id']}: " . $e->getMessage());
    }
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title><?php echo htmlspecialchars($session['title']); ?> | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --secondary-color: #f4f4f4;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --danger-color: #ff4d4d;
            --success-color: #4CAF50;
            --border-radius: 16px;
            --button-radius: 13px;
            --shadow: 0px 2px 10px rgba(0, 0, 0, 0.05);
        }

        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: #ffffff;
            overflow-y: auto;
            overflow-x: hidden;
        }

        @supports (-webkit-touch-callout: none) {
            html, body {
                height: -webkit-fill-available;
            }
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .wrap {
            width: 100%;
            max-width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .app {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
        }


        /* Main content */
        .main-content {
            padding: 20px 24px 90px 24px;
            flex: 1;
        }

        .session-title {
            font-size: 24px;
            font-weight: 900;
            font-style: italic;
            color: #5334d9;
            text-shadow: 0 0 1px #7171DC;
            -webkit-text-stroke: 0.3px #7171DC;
            margin: 0;
            line-height: 1;
            margin-bottom: 24px;
        }

        .session-info {
            margin-bottom: 24px;
        }

        .session-info-item {
            font-size: 14px;
            font-weight: 400;
            line-height: 20px;
            color: var(--text-color);
            margin-bottom: 16px;
        }

        .session-info-item:last-child {
            margin-bottom: 0;
        }

        .separator {
            height: 1px;
            background-color: #f0f0f0;
            margin: 24px 0;
        }

        .trainer-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 24px;
        }

        .trainer-photo {
            width: 20px;
            height: 20px;
            border-radius: 16px;
            object-fit: cover;
            background-color: #e8e8e8;
        }

        .trainer-name {
            font-size: 14px;
            font-weight: 400;
            line-height: 20px;
            color: var(--text-color);
        }

        .trainer-arrow {
            margin-left: auto;
            width: 20px;
            height: 20px;
            color: var(--text-color);
        }

        .session-description {
            font-size: 14px;
            font-weight: 400;
            line-height: 20px;
            color: var(--text-color);
            margin-bottom: 32px;
        }

        .book-button {
            position: absolute;
            bottom: 24px;
            left: 50%;
            transform: translateX(-50%);
            width: 90vw;
            height: 13vw;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 13px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            display: block;
            margin: 0 auto;
        }

        .book-button:disabled {
            background-color: #e5e5e5;
            cursor: not-allowed;
        }

        .success-message {
            background: #4CAF50;
            color: white;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
        }

        .error-message {
            background: #f44336;
            color: white;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: left;
            font-size: 12px;
            word-break: break-word;
            white-space: pre-wrap;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <!-- Header -->
            <?php
            require_once 'components/back_button.php';
            renderBackButton("calendar.php?date=" . urlencode($selectedDate), htmlspecialchars($session['title']), false, 'default');
            ?>

            <!-- Main content -->
            <div class="main-content">
                <!-- <h1 class="session-title"><?php echo htmlspecialchars($session['title']); ?></h1> -->
                <div class="separator"></div>

                <?php if (!empty($bookingMessage)): ?>
                    <div class="success-message">
                        <?php echo htmlspecialchars($bookingMessage); ?>
                        
                        <?php 
                        // Проверяем был ли использован абонемент
                        $usedAbonement = isset($deductResult) && $deductResult['success'];
                        ?>
                        
                        <?php if ($usedAbonement): ?>
                            <!-- Использован абонемент - показываем информацию -->
                            <div style="margin-top: 16px; padding: 16px; background: #f8f9fa; border-radius: 12px; border: 1px solid #e9ecef;">
                                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                                    <div style="width: 24px; height: 24px; background: #4CAF50; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                                        <svg width="14" height="11" viewBox="0 0 14 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 5.5L5 9.5L13 1.5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                    </div>
                                    <div style="font-size: 16px; font-weight: 600; color: #333;">
                                        Оплачено абонементом
                                    </div>
                                </div>
                                <div style="font-size: 14px; color: #666; margin-bottom: 16px; padding-left: 32px;">
                                    <?php 
                                    $activeAbonement = $abonementsAPI->getActiveAbonement($user['id']);
                                    if ($activeAbonement) {
                                        if ($activeAbonement['balance'] > 0) {
                                            echo "Осталось визитов: <strong>" . $activeAbonement['balance'] . "</strong>";
                                        } else {
                                            echo "Последний визит использован";
                                        }
                                    }
                                    ?>
                                </div>
                                <a href="my_abonements.php" style="display: inline-block; background: #7171dc; color: white; padding: 12px 20px; border-radius: var(--button-radius); text-decoration: none; font-weight: 600; font-size: 14px; transition: all 0.2s ease;">
                                    Мои абонементы
                                </a>
                            </div>
                        <?php elseif (isset($session['price']) && $session['price'] > 0): ?>
                            <!-- Нет абонемента - показываем оплату -->
                            <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid rgba(255,255,255,0.3);">
                                <div style="font-size: 18px; font-weight: 700; margin-bottom: 12px;">
                                    Стоимость: <?php echo number_format($session['price'], 0, '.', ' '); ?> ₽
                                </div>
                                <div style="font-size: 14px; margin-bottom: 12px;">
                                    Ваш баланс: <?php echo number_format($user['balance'], 0, '.', ' '); ?> ₽
                                </div>
                                <?php if ($user['balance'] >= $session['price']): ?>
                                    <a href="my_bookings.php" style="display: inline-block; background: white; color: #4CAF50; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600; margin-top: 8px;">
                                        Оплатить сейчас
                                    </a>
                                <?php else: ?>
                                    <div style="font-size: 13px; opacity: 0.9; margin-top: 8px;">
                                        Недостаточно средств. Пополните баланс или оплатите позже в разделе "Профиль → Тренировки"
                                    </div>
                                    <a href="balance.php" style="display: inline-block; background: white; color: #4CAF50; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600; margin-top: 12px;">
                                        Пополнить баланс
                                    </a>
                                <?php endif; ?>
                                <div style="margin-top: 12px; font-size: 12px; opacity: 0.8;">
                                    Вы можете оплатить позже в разделе<br>"Профиль → Мои тренировки"
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($bookingError)): ?>
                    <div class="error-message"><?php echo htmlspecialchars($bookingError); ?></div>
                <?php endif; ?>

                <div class="session-info">
                    <div class="session-info-item">
                        <?php
                        $dateObj = new DateTime($session['date']);
                        $weekdays = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
                        $months = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
                        echo $weekdays[$dateObj->format('w')] . ', ' . $dateObj->format('j') . ' ' . $months[$dateObj->format('n') - 1];
                        ?>
                    </div>
                    <div class="session-info-item"><?php echo htmlspecialchars($session['time']); ?></div>
                    <div class="session-info-item">Места <?php echo $session['freeSpots']; ?> / <?php echo $session['totalSpots']; ?></div>
                </div>

                <div class="separator"></div>

                <div class="trainer-info">
                    <img src="<?php echo htmlspecialchars($session['trainer']['photo']); ?>" alt="Тренер" class="trainer-photo">
                    <div class="trainer-name"><?php echo htmlspecialchars($session['trainer']['name']); ?></div>
                    <svg class="trainer-arrow" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>

                <div class="separator"></div>

                <div class="session-description">
                    <?php echo htmlspecialchars($session['description']); ?>
                </div>

                <?php if (!$canBook['can_book']): ?>
                    <!-- Нет абонемента - показываем кнопку покупки -->
                    <div style="text-align: center; margin-bottom: 100px;">
                        <p style="color: #666; margin-bottom: 15px;">
                            <?php echo $canBook['reason']; ?>
                        </p>
                        <a href="buy_abonement.php" class="book-button" style="display: inline-block; text-decoration: none; position: static; transform: none;">
                            Купить абонемент
                        </a>
                    </div>
                <?php else: ?>
                    <!-- Есть абонемент - показываем кнопку записи -->
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="book_session">
                        <button type="submit" class="book-button" <?php echo ($session['freeSpots'] <= 0) ? 'disabled' : ''; ?>>
                            <?php echo ($session['freeSpots'] <= 0) ? 'Нет мест' : 'Записаться'; ?>
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
