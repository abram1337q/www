<?php
/**
 * Скрипт для ручной проверки статуса платежа
 * Использование: https://fitness.dev.relight.com.ru/frontend/check_payment_manual.php?order_id=YOUR_ORDER_ID
 */

require_once 'api/config.php';
require_once 'api/database.php';
require_once 'api/tkassa_api.php';
require_once 'api/orders.php';
require_once 'api/balance.php';
require_once 'api/notifications.php';

// Логирование
error_log("=== Manual Payment Check Script Started ===");

// Получаем OrderId из параметра
$orderId = $_GET['order_id'] ?? null;

if (!$orderId) {
    die("ERROR: Укажите order_id в параметрах URL (например: ?order_id=17612415663282)");
}

echo "<h2>Проверка платежа: $orderId</h2>\n";
error_log("Checking payment for OrderId: $orderId");

// Получаем информацию о заказе из БД
$ordersAPI = new OrdersAPI();
$order = $ordersAPI->getOrderByOrderId($orderId);

if (!$order) {
    echo "<p style='color: red;'>❌ Заказ $orderId не найден в базе данных</p>\n";
    error_log("Order $orderId not found in database");
    die();
}

echo "<h3>Информация о заказе из БД:</h3>\n";
echo "<pre>" . print_r($order, true) . "</pre>\n";
error_log("Order data: " . json_encode($order));

// Проверяем наличие payment_id
$paymentId = $order['payment_id'] ?? null;
if (empty($paymentId)) {
    echo "<p style='color: red;'>❌ У этого заказа нет PaymentId (возможно, старый заказ). Невозможно проверить статус.</p>\n";
    error_log("Order $orderId has no payment_id");
    die();
}

// Проверяем статус в T-Kassa
$tkassaAPI = new TKassaAPI();
echo "<h3>Запрашиваем статус из T-Kassa...</h3>\n";
echo "<p>PaymentId: <strong>$paymentId</strong></p>\n";
error_log("Requesting payment status from T-Kassa for PaymentId: $paymentId");

$paymentStatus = $tkassaAPI->getPaymentStatus($paymentId);

if (!$paymentStatus) {
    echo "<p style='color: red;'>❌ Не удалось получить статус платежа из T-Kassa</p>\n";
    error_log("Failed to get payment status from T-Kassa");
    die();
}

echo "<h3>Ответ от T-Kassa:</h3>\n";
echo "<pre>" . print_r($paymentStatus, true) . "</pre>\n";
error_log("T-Kassa response: " . json_encode($paymentStatus));

// Проверяем статус платежа
$status = $paymentStatus['Status'] ?? 'UNKNOWN';
echo "<h3>Статус платежа: <strong>$status</strong></h3>\n";

// Обрабатываем успешный платеж
if ($status === 'CONFIRMED' || $status === 'AUTHORIZED') {
    echo "<p style='color: green;'> Платеж подтвержден! Обрабатываем...</p>\n";
    
    // Проверяем, не обработан ли уже заказ
    if ($order['status'] === 'completed') {
        echo "<p style='color: orange;'>⚠️ Заказ уже обработан ранее</p>\n";
        error_log("Order $orderId already processed");
    } else {
        // Обрабатываем платеж
        try {
            $amount = $order['amount'];
            $userId = $order['user_id'];
            
            echo "<p>💰 Пополняем баланс пользователя $userId на сумму $amount ₽</p>\n";
            error_log("Processing payment: userId=$userId, amount=$amount");
            
            // Пополняем баланс
            $balanceAPI = new BalanceAPI();
            $balanceAPI->rechargeBalance($userId, $amount);
            echo "<p style='color: green;'> Баланс пополнен</p>\n";
            
            // Обновляем статус заказа
            $ordersAPI->updateOrderStatus($order['id'], 'completed');
            echo "<p style='color: green;'> Статус заказа обновлен на 'completed'</p>\n";
            
            // Отправляем уведомление
            $notificationsAPI = new NotificationsAPI();
            $notificationsAPI->createNotification(
                $userId,
                'Баланс пополнен',
                "Ваш баланс пополнен на {$amount} ₽",
                'balance'
            );
            echo "<p style='color: green;'> Уведомление создано</p>\n";
            
            // Отправляем Telegram уведомление
            sendTelegramNotification($userId, $orderId, $amount, 'success');
            echo "<p style='color: green;'> Telegram уведомление отправлено</p>\n";
            
            echo "<h3 style='color: green;'>🎉 ПЛАТЕЖ УСПЕШНО ОБРАБОТАН!</h3>\n";
            error_log("Payment processed successfully for OrderId: $orderId");
            
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Ошибка при обработке платежа: " . $e->getMessage() . "</p>\n";
            error_log("Error processing payment: " . $e->getMessage());
        }
    }
} elseif (in_array($status, ['CANCELED', 'REJECTED', 'REFUNDED', 'REVERSED', 'DEADLINE_EXPIRED'])) {
    echo "<p style='color: red;'>❌ Платеж отклонен/отменен</p>\n";
    
    // Обновляем статус заказа
    if ($order['status'] !== 'failed') {
        $ordersAPI->updateOrderStatus($order['id'], 'failed');
        echo "<p>Статус заказа обновлен на 'failed'</p>\n";
        
        // Отправляем уведомление
        sendTelegramNotification($userId, $orderId, $order['amount'], 'failed');
        echo "<p>Telegram уведомление отправлено</p>\n";
    }
} else {
    echo "<p style='color: orange;'>⏳ Платеж в статусе: $status (ожидание)</p>\n";
}

echo "<hr><p><a href='?order_id=$orderId'>Обновить статус</a></p>\n";

// Функция отправки Telegram уведомления
function sendTelegramNotification($userId, $orderId, $amount, $status) {
    error_log("Sending Telegram notification: userId=$userId, orderId=$orderId, status=$status");
    
    try {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT telegram_id FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if (!$user || !$user['telegram_id']) {
            error_log("User $userId not found or has no telegram_id");
            return false;
        }
        
        $telegramId = $user['telegram_id'];
        $botToken = TELEGRAM_BOT_TOKEN;
        
        if ($status === 'success') {
            $message = " <b>Платеж успешно завершен!</b>\n\n"
                     . "💰 Баланс пополнен на <b>{$amount} ₽</b>\n\n"
                     . "📝 Заказ: <code>{$orderId}</code>";
        } else {
            $message = "❌ <b>Платеж отклонен</b>\n\n"
                     . "📝 Заказ: <code>{$orderId}</code>\n\n"
                     . "Попробуйте еще раз или обратитесь в поддержку.";
        }
        
        $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
        $data = [
            'chat_id' => $telegramId,
            'text' => $message,
            'parse_mode' => 'HTML'
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        
        error_log("Telegram API response: $response");
        return true;
        
    } catch (Exception $e) {
        error_log("Failed to send Telegram notification: " . $e->getMessage());
        return false;
    }
}
?>

