/**
 * Telegram WebApp инициализация и утилиты
 */

// Инициализация Telegram WebApp
function initTelegramWebApp() {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        
        // Инициализируем приложение
        tg.ready();
        
        // Разворачиваем на весь экран
        tg.expand();
        
        // Устанавливаем цвета темы
        tg.setHeaderColor('bg_color');
        tg.setBackgroundColor('#ffffff');
        
        // Включаем подтверждение при закрытии для определенных страниц
        const confirmPages = ['payment.php', 'shop.php'];
        const currentPage = window.location.pathname.split('/').pop();
        if (confirmPages.includes(currentPage)) {
            tg.enableClosingConfirmation();
        }
        
        return tg;
    }
    return null;
}

// Показать кнопку "Назад" в Telegram
function showTelegramBackButton(callback) {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        tg.BackButton.show();
        tg.BackButton.onClick(callback);
    }
}

// Скрыть кнопку "Назад" в Telegram
function hideTelegramBackButton() {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        tg.BackButton.hide();
    }
}

// Показать главную кнопку Telegram
function showTelegramMainButton(text, callback) {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        tg.MainButton.setText(text);
        tg.MainButton.show();
        tg.MainButton.onClick(callback);
    }
}

// Скрыть главную кнопку Telegram
function hideTelegramMainButton() {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        tg.MainButton.hide();
    }
}

// Показать уведомление через Telegram
function showTelegramAlert(message) {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        tg.showAlert(message);
    } else {
        alert(message);
    }
}

// Показать подтверждение через Telegram
function showTelegramConfirm(message, callback) {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        tg.showConfirm(message, callback);
    } else {
        const result = confirm(message);
        callback(result);
    }
}

// Получить данные пользователя из Telegram
function getTelegramUser() {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        return tg.initDataUnsafe?.user || null;
    }
    return null;
}

// Проверка, запущено ли приложение в Telegram
function isTelegramWebApp() {
    return !!(window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.initData);
}

// Открыть ссылку в Telegram
function openTelegramLink(url) {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        tg.openLink(url);
    } else {
        window.open(url, '_blank');
    }
}

// Закрыть Mini App
function closeTelegramWebApp() {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        tg.close();
    }
}

// Вибрация через Telegram
function triggerHapticFeedback(style = 'medium') {
    if (window.Telegram && window.Telegram.WebApp) {
        const tg = window.Telegram.WebApp;
        if (tg.HapticFeedback) {
            tg.HapticFeedback.impactOccurred(style);
        }
    }
}

// Экспорт для глобального использования
window.TelegramWebApp = {
    init: initTelegramWebApp,
    showBackButton: showTelegramBackButton,
    hideBackButton: hideTelegramBackButton,
    showMainButton: showTelegramMainButton,
    hideMainButton: hideTelegramMainButton,
    showAlert: showTelegramAlert,
    showConfirm: showTelegramConfirm,
    getUser: getTelegramUser,
    isWebApp: isTelegramWebApp,
    openLink: openTelegramLink,
    close: closeTelegramWebApp,
    haptic: triggerHapticFeedback
};

// Автоматическая инициализация при загрузке DOM
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTelegramWebApp);
} else {
    initTelegramWebApp();
}

