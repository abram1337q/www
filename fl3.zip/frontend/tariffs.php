<?php
require_once 'api/config.php';

// Проверка авторизации с поддержкой Telegram
$user = requireAuth();

// Добавляем баланс, если его нет
if (!isset($user['balance'])) {
    $user['balance'] = 5000; // Устанавливаем тестовый баланс
}

// Создаем тестовые специальные предложения
$specialOffers = [
    [
        'id' => 1,
        'title' => 'Месячный абонемент',
        'description' => "✓ Безлимитное посещение\n✓ Персональная программа\n✓ Консультация диетолога",
        'price' => 3000,
        'period' => '1 месяц'
    ],
    [
        'id' => 2,
        'title' => 'Квартальный абонемент',
        'description' => "✓ Безлимитное посещение\n✓ Персональная программа\n✓ Консультация диетолога\n✓ 2 персональные тренировки",
        'price' => 8000,
        'period' => '3 месяца'
    ]
];

// Handle purchase
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'purchase') {
    $offerId = $_POST['offer_id'] ?? 0;
    $price = $_POST['price'] ?? 0;
    
    // Find the offer
    $selectedOffer = null;
    foreach ($specialOffers as $offer) {
        if ($offer['id'] == $offerId) {
            $selectedOffer = $offer;
            break;
        }
    }

    if (!$selectedOffer) {
        $error = 'Тариф не найден';
    } elseif ($user['balance'] < $selectedOffer['price']) {
        $error = 'Недостаточно средств на балансе';
    } else {
        // Уменьшаем баланс пользователя
        $user['balance'] -= $selectedOffer['price'];
        $_SESSION['user'] = $user; // Сохраняем обновленный баланс в сессии
        $success = 'Тариф успешно приобретен';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Тарифы | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --secondary-color: #f4f4f4;
            --text-color: #333333;
            --light-text: #888888;
            --border-color: #f0f0f0;
            --danger-color: #ff4d4d;
            --success-color: #4CAF50;
            --border-radius: 16px;
            --button-radius: 13px;
            --shadow: 0px 2px 10px rgba(0, 0, 0, 0.05);
        }

        html, body {
            margin: 0;
            padding: 0;
            font-family: "Inter", sans-serif;
            color: var(--text-color);
            background-color: #ffffff;
            min-height: 100vh;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .wrap {
            width: 100%;
            max-width: 100%;
            overflow-x: hidden;
            min-height: 100vh;
            padding-bottom: 90px;
            box-sizing: border-box;
        }

        .app {
            max-width: 100%;
            padding: 0;
            margin: 0;
            width: 100%;
            min-height: 100vh;
        }

        .page {
            width: 100%;
            max-width: 100%;
            padding: 0;
            margin: 0;
            min-height: 100vh;
        }

        .page-bg {
            background: #ffffff;
            padding: 15px;
            width: 100%;
            margin: 0;
            box-sizing: border-box;
            min-height: calc(100vh - 170px);
        }

        /* Header */
        .tariffs-header {
            display: flex;
            align-items: center;
            padding: 24px 0;
            margin-bottom: 20px;
        }

        .back-button {
            width: 20px;
            height: 20px;
            background: none;
            border: none;
            cursor: pointer;
            padding: 0;
            margin-right: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .back-arrow {
            width: 20px;
            height: 20px;
            transform: rotate(180deg);
        }

        .tariffs-title {
            font-size: 14px;
            font-weight: 500;
            margin: 0;
            flex-grow: 1;
            text-align: center;
            margin-right: 32px;
        }

        /* Time filters */
        .time-filters {
            display: flex;
            gap: 0;
            margin-bottom: 20px;
        }

        .time-filter {
            font-family: "Inter", sans-serif;
            font-size: 14px;
            font-weight: 500;
            color: #7a7a7a;
            background: none;
            border: none;
            cursor: pointer;
            padding: 0;
            flex: 1;
            text-align: center;
        }

        .time-filter.active {
            color: #7171dc;
        }

        /* Tariff items */
        .tariff-items {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .tariff-item {
            border: 1px solid #7171dc;
            border-radius: 4px;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .tariff-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .tariff-badge {
            width: 76px;
            height: 20px;
            background: #7171dc;
            border-radius: 2px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .tariff-name {
            font-family: "Inter", sans-serif;
            font-size: 14px;
            font-weight: 500;
            color: white;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .tariff-right {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 4px;
        }

        .tariff-price {
            font-family: "Inter", sans-serif;
            font-size: 14px;
            font-weight: 400;
            color: black;
            text-align: right;
        }

        .tariff-time {
            font-family: "Inter", sans-serif;
            font-size: 14px;
            font-weight: 400;
            color: black;
            text-align: right;
        }

        .balance-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 15px;
        }

        .balance-info {
            display: flex;
            flex-direction: column;
        }

        .balance-label {
            font-size: 14px;
            color: #7A7A7A;
            margin-bottom: 4px;
        }

        .balance-amount {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-color);
        }

        .balance-button {
            background: var(--primary-color);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 12px 24px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            height: 25px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .success-message {
            background: #4CAF50;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .error-message {
            background: #f44336;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const timeFilters = document.querySelectorAll('.time-filter');

            timeFilters.forEach(filter => {
                filter.addEventListener('click', function() {
                    // Убираем класс active у всех кнопок
                    timeFilters.forEach(btn => btn.classList.remove('active'));
                    // Добавляем класс active нажатой кнопке
                    this.classList.add('active');
                });
            });
        });

        function goBack() {
            window.history.back();
        }
    </script>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="page">
                <div class="page-bg">
                    <!-- Header -->
                    <div class="tariffs-header">
                        <button class="back-button" onclick="goBack()">
                            <svg class="back-arrow" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 6V12L16 14" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <h1 class="tariffs-title">Тарифы</h1>
                    </div>

                    <!-- Time filters -->
                    <div class="time-filters">
                        <button class="time-filter active">Пробные</button>
                        <button class="time-filter">Утро</button>
                        <button class="time-filter">Вечер</button>
                        <button class="time-filter">Все время</button>
                    </div>

                    <!-- Tariff items -->
                    <div class="tariff-items">
                        <div class="tariff-item">
                            <div class="tariff-left">
                                <div class="tariff-badge">
                                    <div class="tariff-name">Бодрость</div>
                                </div>
                            </div>
                            <div class="tariff-right">
                                <div class="tariff-price">100 ₽ / 100 занятий</div>
                                <div class="tariff-time">Утро</div>
                            </div>
                        </div>

                        <div class="tariff-item">
                            <div class="tariff-left">
                                <div class="tariff-badge">
                                    <div class="tariff-name">Лайт</div>
                                </div>
                            </div>
                            <div class="tariff-right">
                                <div class="tariff-price">100 ₽ / мес</div>
                                <div class="tariff-time">Ежедневно</div>
                            </div>
                        </div>

                        <div class="tariff-item">
                            <div class="tariff-left">
                                <div class="tariff-badge">
                                    <div class="tariff-name">Бодрость</div>
                                </div>
                            </div>
                            <div class="tariff-right">
                                <div class="tariff-price">100 ₽ / 100 занятий</div>
                                <div class="tariff-time">Утро</div>
                            </div>
                        </div>

                        <div class="tariff-item">
                            <div class="tariff-left">
                                <div class="tariff-badge">
                                    <div class="tariff-name">Лайт</div>
                                </div>
                            </div>
                            <div class="tariff-right">
                                <div class="tariff-price">100 ₽ / мес</div>
                                <div class="tariff-time">Ежедневно</div>
                            </div>
                        </div>

                        <div class="tariff-item">
                            <div class="tariff-left">
                                <div class="tariff-badge">
                                    <div class="tariff-name">Бодрость</div>
                                </div>
                            </div>
                            <div class="tariff-right">
                                <div class="tariff-price">100 ₽ / 100 занятий</div>
                                <div class="tariff-time">Утро</div>
                            </div>
                        </div>

                        <div class="tariff-item">
                            <div class="tariff-left">
                                <div class="tariff-badge">
                                    <div class="tariff-name">Лайт</div>
                                </div>
                            </div>
                            <div class="tariff-right">
                                <div class="tariff-price">100 ₽ / мес</div>
                                <div class="tariff-time">Ежедневно</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php $activePage = 'tariffs'; include 'components/navigation.php'; ?>
    </div>
</body>
</html>
