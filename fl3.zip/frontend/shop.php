<?php
require_once 'api/config.php';
$user = requireAuth();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Магазин | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        :root {
            --primary-color: #7171dc;
            --bg-color: #f4f4f4;
            --text-color: #333;
            --light-text-color: #888;
        }
        body {
            background-color: #fff;
        }
        .wrap {
            padding-bottom: 90px;
        }
        .page-header {
            padding: 20px 15px;
            text-align: center;
        }
        .page-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-color);
        }
        .filters-container {
            padding: 0 15px 15px;
            overflow-x: auto;
            white-space: nowrap;
            -webkit-overflow-scrolling: touch;
        }
        .filters-container::-webkit-scrollbar {
            display: none;
        }
        .filter-btn {
            display: inline-block;
            padding: 10px 20px;
            margin-right: 10px;
            background-color: var(--bg-color);
            color: var(--text-color);
            border: none;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease-in-out;
        }
        .filter-btn.active {
            background-color: var(--primary-color);
            color: #fff;
            font-weight: 600;
        }
        .products-grid {
            padding: 0 15px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
        }
        .product-card {
            background: #fff;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            display: flex;
            flex-direction: column;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            text-decoration: none;
            color: inherit;
            position: relative;
        }
        .product-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.1);
        }
        .product-card:active {
            transform: translateY(0);
        }
        .abonement-badge {
            position: absolute;
            top: 8px;
            left: 8px;
            background: rgba(103, 126, 234, 0.95);
            color: white;
            padding: 4px 10px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 600;
            z-index: 10;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }
        .product-image {
            width: 100%;
            height: 120px;
            object-fit: cover;
        }
        .product-info {
            padding: 12px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }
        .product-title {
            font-size: 15px;
            font-weight: 600;
            margin: 0 0 5px;
            flex-grow: 1;
        }
        .product-price {
            font-size: 16px;
            font-weight: 700;
            color: var(--primary-color);
            margin-top: 10px;
        }
        .loader {
            text-align: center;
            padding: 50px;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="app">
            <div class="page-header">
                <h1 class="page-title">Магазин</h1>
            </div>

            <div class="filters-container" id="filters-container">
                <!-- Категории будут загружены сюда -->
            </div>

            <div class="products-grid" id="products-grid">
                <!-- Товары будут загружены сюда -->
            </div>
            
            <div class="loader" id="loader">
                <p>Загрузка товаров...</p>
            </div>
        </div>
        <?php $activePage = 'shop'; include 'components/navigation.php'; ?>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const productsGrid = document.getElementById('products-grid');
        const filtersContainer = document.getElementById('filters-container');
        const loader = document.getElementById('loader');
        let allItems = [];
        let allCategories = {};

        function renderProducts(items) {
            productsGrid.innerHTML = '';
            if (items.length === 0) {
                productsGrid.innerHTML = '<p>Товары в этой категории не найдены.</p>';
                return;
            }
            items.forEach(item => {
                const productId = item.id || item.good_id || '';
                const isAbonement = item.is_abonement || false;
                const quantity = item.quantity || 1;
                
                // Формируем бейдж для абонемента
                let abonementBadge = '';
                if (isAbonement) {
                    abonementBadge = `<div class="abonement-badge">📦 Пополняемый${quantity > 1 ? ' (+' + quantity + ' шт)' : ''}</div>`;
                }
                
                const card = `
                    <a href="product_detail.php?id=${productId}" class="product-card">
                        ${abonementBadge}
                        <img src="${item.image}" alt="${item.title}" class="product-image">
                        <div class="product-info">
                            <h3 class="product-title">${item.title}</h3>
                            <p class="product-price">${item.price} ₽</p>
                        </div>
                    </a>
                `;
                productsGrid.insertAdjacentHTML('beforeend', card);
            });
        }

        function renderFilters(categories) {
            filtersContainer.innerHTML = '<button class="filter-btn active" data-category-id="all">Все</button>';
            for (const [id, name] of Object.entries(categories)) {
                filtersContainer.insertAdjacentHTML('beforeend', `<button class="filter-btn" data-category-id="${id}">${name}</button>`);
            }

            filtersContainer.querySelectorAll('.filter-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    filtersContainer.querySelector('.filter-btn.active').classList.remove('active');
                    this.classList.add('active');
                    const categoryId = this.dataset.categoryId;
                    filterProducts(categoryId);
                });
            });
        }

        function filterProducts(categoryId) {
            if (categoryId === 'all') {
                renderProducts(allItems);
            } else if (categoryId === 'special') {
                const filteredItems = allItems.filter(item => item.is_special);
                renderProducts(filteredItems);
            } else {
                const filteredItems = allItems.filter(item => item.category_id == categoryId);
                renderProducts(filteredItems);
            }
        }

        async function fetchProducts() {
            try {
                const response = await fetch('api/products.php');
                const data = await response.json();
                allItems = data.items;
                allCategories = data.categories;

                renderFilters(allCategories);
                renderProducts(allItems);

            } catch (error) {
                console.error('Ошибка при загрузке товаров:', error);
                productsGrid.innerHTML = '<p>Не удалось загрузить товары. Попробуйте позже.</p>';
            } finally {
                loader.style.display = 'none';
            }
        }

        fetchProducts();
    });
    </script>
</body>
</html>
