<?php
require_once 'api/config.php';
require_once 'api/bookings.php';

// Проверка авторизации
$user = requireAuth();

// Синхронизируем visit_id для всех бронирований пользователя
$bookingsAPI = new BookingsAPI();
$syncedCount = $bookingsAPI->syncVisitIds($user['id']);
if ($syncedCount > 0) {
    error_log("Synced {$syncedCount} visit IDs for user {$user['id']}");
}

// Обработка оплаты
$paymentMessage = '';
$paymentError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'pay_booking') {
    $bookingId = isset($_POST['booking_id']) ? (int)$_POST['booking_id'] : 0;
    
    if ($bookingId) {
        $result = $bookingsAPI->payBooking($bookingId, $user['id']);
        
        if ($result['success']) {
            $paymentMessage = $result['message'];
            // Обновляем пользователя чтобы получить новый баланс
            $user = getCurrentUser();
        } else {
            $paymentError = $result['message'];
            if (isset($result['required']) && isset($result['current'])) {
                $paymentError .= " (Требуется: {$result['required']}₽, Доступно: {$result['current']}₽)";
            }
        }
    }
}

// Получаем бронирования пользователя
$bookings = $bookingsAPI->getUserBookings($user['id']);

// Разделяем на оплаченные и неоплаченные
$unpaidBookings = [];
$paidBookings = [];

foreach ($bookings as $booking) {
    if ($booking['paid'] == 1) {
        $paidBookings[] = $booking;
    } else {
        $unpaidBookings[] = $booking;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Мои записи | <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <?php include 'components/telegram_init.php'; ?>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: "Inter", sans-serif;
            background-color: #ffffff;
            color: #333;
        }

        .wrap {
            padding: 20px 15px 90px 15px;
        }

        .page-header {
            margin-bottom: 20px;
        }

        .page-title {
            font-size: 24px;
            font-weight: 700;
            color: #333;
            margin: 0 0 10px 0;
        }

        .balance-info {
            font-size: 14px;
            color: #888;
        }

        .balance-amount {
            font-weight: 600;
            color: #7171dc;
            font-size: 16px;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .section {
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin: 0 0 15px 0;
        }

        .booking-card {
            background: #f8f8f8;
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 12px;
        }

        .booking-title {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin: 0 0 8px 0;
        }

        .booking-info {
            font-size: 14px;
            color: #666;
            margin-bottom: 4px;
        }

        .booking-price {
            font-size: 18px;
            font-weight: 700;
            color: #7171dc;
            margin: 12px 0;
        }

        .booking-status {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
            margin-top: 8px;
        }

        .status-paid {
            background-color: #d4edda;
            color: #155724;
        }

        .status-unpaid {
            background-color: #fff3cd;
            color: #856404;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            text-align: center;
            cursor: pointer;
            border: none;
            width: 100%;
            margin-top: 12px;
            transition: opacity 0.2s;
        }

        .btn:active {
            opacity: 0.7;
        }

        .btn-primary {
            background-color: #7171dc;
            color: #ffffff;
        }

        .btn-disabled {
            background-color: #ddd;
            color: #999;
            cursor: not-allowed;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #888;
        }

        .empty-state-icon {
            font-size: 48px;
            margin-bottom: 16px;
        }

        form {
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="page-header">
            <h1 class="page-title">Мои записи</h1>
            <div class="balance-info">
                Баланс: <span class="balance-amount"><?php echo number_format($user['balance'], 0, '.', ' '); ?> ₽</span>
            </div>
        </div>

        <?php if ($paymentMessage): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($paymentMessage); ?>
            </div>
        <?php endif; ?>

        <?php if ($paymentError): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($paymentError); ?>
            </div>
        <?php endif; ?>

        <!-- Неоплаченные записи -->
        <div class="section">
            <h2 class="section-title">Ожидают оплаты</h2>
            
            <?php if (empty($unpaidBookings)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">✓</div>
                    <div>Нет неоплаченных записей</div>
                </div>
            <?php else: ?>
                <?php foreach ($unpaidBookings as $booking): ?>
                    <div class="booking-card">
                        <div class="booking-title"><?php echo htmlspecialchars($booking['service_title']); ?></div>
                        <div class="booking-info">
                            📅 <?php echo date('d.m.Y в H:i', strtotime($booking['datetime'])); ?>
                        </div>
                        <div class="booking-price"><?php echo number_format($booking['service_price'], 0, '.', ' '); ?> ₽</div>
                        <span class="booking-status status-unpaid">Не оплачено</span>
                        
                        <?php if (empty($booking['visit_id'])): ?>
                            <!-- Визит еще не состоялся - оплата недоступна -->
                            <div class="btn btn-secondary" style="cursor: not-allowed; opacity: 0.6;">
                                Оплата после посещения
                            </div>
                        <?php else: ?>
                            <!-- Визит состоялся - можно оплатить -->
                            <form method="POST" action="">
                                <input type="hidden" name="action" value="pay_booking">
                                <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                <button type="submit" class="btn btn-primary" 
                                        <?php echo ($user['balance'] < $booking['service_price']) ? 'disabled' : ''; ?>>
                                    <?php if ($user['balance'] >= $booking['service_price']): ?>
                                        Оплатить
                                    <?php else: ?>
                                        Недостаточно средств
                                    <?php endif; ?>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Оплаченные записи -->
        <div class="section">
            <h2 class="section-title">Оплаченные</h2>
            
            <?php if (empty($paidBookings)): ?>
                <div class="empty-state">
                    <div>Нет оплаченных записей</div>
                </div>
            <?php else: ?>
                <?php foreach ($paidBookings as $booking): ?>
                    <div class="booking-card">
                        <div class="booking-title"><?php echo htmlspecialchars($booking['service_title']); ?></div>
                        <div class="booking-info">
                            📅 <?php echo date('d.m.Y в H:i', strtotime($booking['datetime'])); ?>
                        </div>
                        <div class="booking-price"><?php echo number_format($booking['service_price'], 0, '.', ' '); ?> ₽</div>
                        <span class="booking-status status-paid">✓ Оплачено</span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php $activePage = 'bookings'; include 'components/navigation.php'; ?>
</body>
</html>

