<?php
/**
 * Скрипт для получения информации о типах карт лояльности (включая абонементы)
 * из YClients API
 */

require_once 'frontend/api/config.php';

echo "=== Получение типов карт лояльности из YClients ===\n\n";

// Нужно использовать метод GET /api/v1/loyalty/card_types/{company_id}
$url = "https://api.yclients.com/api/v1/loyalty/card_types/" . YCLIENTS_COMPANY_ID;

$headers = [
    'Accept: application/vnd.yclients.v2+json',
    'Content-Type: application/json',
    'Authorization: Bearer ' . YCLIENTS_PARTNER_TOKEN . ', User ' . YCLIENTS_USER_TOKEN
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: {$httpCode}\n";
echo "URL: {$url}\n\n";

if ($httpCode !== 200) {
    echo "❌ Ошибка запроса!\n";
    echo "Response: {$response}\n";
    exit(1);
}

$data = json_decode($response, true);

if (!isset($data['success']) || !$data['success']) {
    echo "❌ API вернул ошибку!\n";
    echo "Response: {$response}\n";
    exit(1);
}

$cardTypes = $data['data'] ?? [];

echo " Найдено типов карт: " . count($cardTypes) . "\n\n";
echo "=== СПИСОК ТИПОВ КАРТ ===\n\n";

foreach ($cardTypes as $type) {
    echo "ID: {$type['id']}\n";
    echo "Название: {$type['title']}\n";
    echo "Тип: ";
    
    if (isset($type['service_item_type'])) {
        echo "Абонемент (количество услуг)\n";
    } elseif (isset($type['is_time_based']) && $type['is_time_based']) {
        echo "Абонемент (срок действия)\n";
    } else {
        echo "Карта лояльности\n";
    }
    
    if (isset($type['balance'])) {
        echo "Баланс: {$type['balance']}\n";
    }
    
    if (isset($type['max_discount_percent'])) {
        echo "Макс. скидка: {$type['max_discount_percent']}%\n";
    }
    
    echo "\n" . str_repeat("-", 50) . "\n\n";
}

echo "\n=== РЕКОМЕНДАЦИИ ===\n\n";
echo "Для реализации системы абонементов создайте в админке YClients:\n\n";
echo "1. Тип карты 'Разовое посещение':\n";
echo "   - Тип: Абонемент (количество услуг)\n";
echo "   - Количество услуг: 1\n";
echo "   - Срок действия: 30 дней\n";
echo "   - Скопируйте его ID в config.php как ABONEMENT_SINGLE_TYPE_ID\n\n";

echo "2. Тип карты 'Месячный безлимит':\n";
echo "   - Тип: Абонемент (срок действия)\n";
echo "   - Срок действия: 30 дней\n";
echo "   - Количество услуг: безлимит\n";
echo "   - Скопируйте его ID в config.php как ABONEMENT_MONTHLY_TYPE_ID\n\n";

echo "После создания запустите этот скрипт снова чтобы увидеть ID\n";

?>

