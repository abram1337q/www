<?php
/**
 * Скрипт для получения информации о типах карт лояльности из YClients
 * Используйте этот скрипт для заполнения loyalty_cards_config.php
 * 
 * Использование: php get_loyalty_card_info.php
 */

require_once 'frontend/api/config.php';
require_once 'frontend/api/yclients_api.php';

echo "=== Получение информации о картах лояльности ===\n\n";

global $yclients;

if (!$yclients) {
    die("ОШИБКА: YClients API не инициализирован\n");
}

// Получаем типы карт лояльности
echo "Получение типов карт лояльности:\n";
echo "-----------------------------------\n";

try {
    $url = "https://api.yclients.com/api/v1/loyalty/types/" . YCLIENTS_COMPANY_ID;
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . YCLIENTS_PARTNER_TOKEN . ', User ' . YCLIENTS_USER_TOKEN,
        'Accept: application/vnd.yclients.v2+json',
        'Content-Type: application/json'
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "HTTP Code: {$httpCode}\n";
    echo "Response: {$response}\n\n";
    
    $data = json_decode($response, true);
    
    if ($httpCode == 200 && isset($data['success']) && $data['success']) {
        $types = $data['data'] ?? [];
        
        if (!empty($types)) {
            echo "Найдено типов карт: " . count($types) . "\n\n";
            
            foreach ($types as $type) {
                echo "ID типа: " . ($type['id'] ?? 'N/A') . "\n";
                echo "Название: " . ($type['title'] ?? 'N/A') . "\n";
                echo "Тип начисления: " . ($type['accrual_type'] ?? 'N/A') . "\n";
                echo "Валюта: " . ($type['currency'] ?? 'N/A') . "\n";
                echo "\n";
            }
            
            // Рекомендуем первый тип
            if (!empty($types)) {
                $firstType = $types[0];
                echo "РЕКОМЕНДАЦИЯ:\n";
                echo "Используйте ID типа карты: " . $firstType['id'] . "\n";
                echo "Название: " . ($firstType['title'] ?? 'N/A') . "\n\n";
            }
        } else {
            echo "⚠️  Типы карт не найдены.\n";
            echo "Создайте тип карты лояльности в панели YClients:\n";
            echo "1. Зайдите в YClients → Настройки → Лояльность\n";
            echo "2. Создайте новый тип карты с валютой (рубли)\n";
            echo "3. Запустите этот скрипт повторно\n\n";
        }
    } else {
        echo "⚠️  Ошибка получения типов карт: " . ($data['meta']['message'] ?? 'Unknown error') . "\n\n";
    }
    
} catch (Exception $e) {
    echo "ОШИБКА: " . $e->getMessage() . "\n\n";
}

// Проверяем существующие карты клиентов
echo "Проверка существующих карт лояльности:\n";
echo "-----------------------------------\n";

$conn = getDbConnection();
$result = $conn->query("SELECT id, yclients_client_id, first_name, last_name FROM users WHERE yclients_client_id IS NOT NULL LIMIT 1");

if ($result && $row = $result->fetch_assoc()) {
    echo "Проверяем карты для клиента:\n";
    echo "User ID: {$row['id']}\n";
    echo "YClients ID: {$row['yclients_client_id']}\n";
    echo "Имя: {$row['first_name']} {$row['last_name']}\n\n";
    
    try {
        $cards = $yclients->getClientLoyaltyCards($row['yclients_client_id']);
        
        if ($cards && !empty($cards)) {
            echo "✓ Найдено карт: " . count($cards) . "\n\n";
            
            foreach ($cards as $card) {
                echo "ID карты: " . ($card['id'] ?? 'N/A') . "\n";
                echo "Номер: " . ($card['number'] ?? 'N/A') . "\n";
                echo "Баланс: " . ($card['balance'] ?? 0) . " ₽\n";
                echo "ID типа: " . ($card['type_id'] ?? 'N/A') . "\n";
                echo "\n";
            }
        } else {
            echo "ℹ️  У клиента нет карт лояльности.\n";
            echo "Карты будут созданы автоматически при миграции.\n\n";
        }
    } catch (Exception $e) {
        echo "ОШИБКА при получении карт: " . $e->getMessage() . "\n\n";
    }
} else {
    echo "Не найдено пользователей с YClients ID в БД\n\n";
}

$conn->close();

echo "===================================\n";
echo "СЛЕДУЮЩИЕ ШАГИ:\n";
echo "===================================\n";
echo "1. Если типы карт не найдены - создайте их в панели YClients\n";
echo "2. Скопируйте loyalty_cards_config.example.php в loyalty_cards_config.php\n";
echo "3. Укажите LOYALTY_CARD_TYPE_ID из списка выше\n";
echo "4. Запустите миграцию: php migrate_to_loyalty_cards.php\n\n";

?>

