<?php
/**
 * Скрипт для генерации токена Tinkoff Payment API
 * Следует инструкциям: https://www.tinkoff.ru/kassa/develop/api/payments/init-request/
 */

function generateToken($params, $password) {
    // Добавляем пароль в массив параметров
    $params['Password'] = $password;

    // Сортируем массив по ключам в алфавитном порядке
    ksort($params);

    // Конкатенируем только значения в одну строку
    $tokenString = '';
    foreach ($params as $value) {
        $tokenString .= $value;
    }

    // Вычисляем SHA-256 хэш
    return hash('sha256', $tokenString);
}

// Обработка формы
$terminalKey = '';
$amount = '';
$orderId = '';
$description = '';
$password = '5ZG0aA#rYT5U$ZwG'; // Пароль по умолчанию
$customFields = [];
$token = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $terminalKey = $_POST['terminal_key'] ?? '';
    $amount = $_POST['amount'] ?? '';
    $orderId = $_POST['order_id'] ?? '';
    $description = $_POST['description'] ?? '';
    $password = $_POST['password'] ?? '';

    // Собираем пользовательские поля
    if (isset($_POST['custom_fields'])) {
        foreach ($_POST['custom_fields'] as $field) {
            if (!empty($field['key']) && !empty($field['value'])) {
                $customFields[] = $field;
            }
        }
    }

    // Создаем массив параметров
    $params = [];
    if (!empty($terminalKey)) $params['TerminalKey'] = $terminalKey;
    if (!empty($amount)) $params['Amount'] = (string)$amount;
    if (!empty($orderId)) $params['OrderId'] = $orderId;
    if (!empty($description)) $params['Description'] = $description;

    // Добавляем пользовательские поля
    foreach ($customFields as $field) {
        $params[$field['key']] = $field['value'];
    }

    if (!empty($params)) {
        $token = generateToken($params, $password);
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Генератор токена Tinkoff Payment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="password"], input[type="number"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .custom-field {
            display: flex;
            gap: 10px;
            align-items: center;
            margin-bottom: 10px;
        }
        .custom-field input {
            flex: 1;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 10px;
        }
        button:hover {
            background-color: #0056b3;
        }
        .add-field-btn {
            background-color: #28a745;
        }
        .add-field-btn:hover {
            background-color: #218838;
        }
        .result {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 15px;
            margin-top: 20px;
        }
        .token-display {
            font-family: monospace;
            background-color: #e9ecef;
            padding: 10px;
            border-radius: 4px;
            word-break: break-all;
        }
        .copy-btn {
            margin-top: 10px;
            background-color: #6c757d;
        }
        .copy-btn:hover {
            background-color: #545b62;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Генератор токена Tinkoff Payment API</h1>

        <form method="post">
            <div class="form-group">
                <label for="terminal_key">Terminal Key:</label>
                <input type="text" id="terminal_key" name="terminal_key" value="<?php echo htmlspecialchars($terminalKey); ?>" required>
            </div>

            <div class="form-group">
                <label for="amount">Amount:</label>
                <input type="number" id="amount" name="amount" value="<?php echo htmlspecialchars($amount); ?>" required>
            </div>

            <div class="form-group">
                <label for="order_id">Order ID:</label>
                <input type="text" id="order_id" name="order_id" value="<?php echo htmlspecialchars($orderId); ?>" required>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <input type="text" id="description" name="description" value="<?php echo htmlspecialchars($description); ?>">
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" value="<?php echo htmlspecialchars($password); ?>" required>
            </div>

            <div class="form-group">
                <label>Дополнительные поля:</label>
                <div id="custom-fields">
                    <?php foreach ($customFields as $index => $field): ?>
                        <div class="custom-field">
                            <input type="text" name="custom_fields[<?php echo $index; ?>][key]" placeholder="Ключ" value="<?php echo htmlspecialchars($field['key']); ?>">
                            <input type="text" name="custom_fields[<?php echo $index; ?>][value]" placeholder="Значение" value="<?php echo htmlspecialchars($field['value']); ?>">
                            <button type="button" onclick="removeField(this)">Удалить</button>
                        </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="add-field-btn" onclick="addField()">Добавить поле</button>
            </div>

            <button type="submit">Сгенерировать токен</button>
        </form>

        <?php if (!empty($token)): ?>
            <div class="result">
                <h3>Результат:</h3>
                <div class="token-display"><?php echo htmlspecialchars($token); ?></div>
                <button class="copy-btn" onclick="copyToClipboard('<?php echo htmlspecialchars($token); ?>')">Копировать токен</button>
            </div>
        <?php endif; ?>
    </div>

    <script>
        let fieldIndex = <?php echo count($customFields); ?>;

        function addField() {
            const container = document.getElementById('custom-fields');
            const fieldDiv = document.createElement('div');
            fieldDiv.className = 'custom-field';
            fieldDiv.innerHTML = `
                <input type="text" name="custom_fields[${fieldIndex}][key]" placeholder="Ключ">
                <input type="text" name="custom_fields[${fieldIndex}][value]" placeholder="Значение">
                <button type="button" onclick="removeField(this)">Удалить</button>
            `;
            container.appendChild(fieldDiv);
            fieldIndex++;
        }

        function removeField(button) {
            button.parentElement.remove();
        }

        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('Токен скопирован в буфер обмена!');
            }, function(err) {
                console.error('Ошибка копирования: ', err);
            });
        }
    </script>
</body>
</html>
