<?php
// Прямое подключение к БД без config_.php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'fitnes_miniapp');

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");
    echo " Подключение к базе данных успешно!\n";

    // Проверим таблицы
    $result = $conn->query("SHOW TABLES");
    echo "📋 Найденные таблицы:\n";
    while ($row = $result->fetch_array()) {
        echo "- " . $row[0] . "\n";
    }

    // Проверим пользователей
    $result = $conn->query("SELECT COUNT(*) as count FROM users");
    $row = $result->fetch_assoc();
    echo "👥 Пользователей в базе: " . $row['count'] . "\n";

    $conn->close();
} catch (Exception $e) {
    echo "❌ Ошибка: " . $e->getMessage() . "\n";
}
?>
