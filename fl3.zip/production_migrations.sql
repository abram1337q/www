-- SQL миграции для продакшен сервера

-- 1. Добавить колонку visit_id в таблицу bookings (если еще не добавлена)
ALTER TABLE bookings
ADD COLUMN visit_id INT NULL AFTER record_id;

-- 2. Создать таблицу user_abonements для системы абонементов
CREATE TABLE IF NOT EXISTS user_abonements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    abonement_type ENUM('single', 'monthly') NOT NULL,
    balance INT NOT NULL DEFAULT 0,
    purchased_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_active (user_id, is_active),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



