<?php
/**
 * Тестовый файл для диагностики проблем с T-Kassa API
 */

require_once 'frontend/api/config.php';
require_once 'frontend/api/tkassa_api.php';

// Создаем экземпляр API
$tkassaAPI = new TKassaAPI();

// Тестовые данные
$amount = 100.00; // Сумма в рублях
$userId = 1;
$orderId = $tkassaAPI->generateOrderId($userId);
$description = 'Пополнение баланса фитнес-клуба';
$successUrl = 'http://localhost:3000/balance.php?success=1&order=';
$failUrl = 'http://localhost:3000/balance.php?error=1&order=';

// Добавляем orderId к URL'ам
$successUrl .= $orderId;
$failUrl .= $orderId;

echo "=== Тестирование T-Kassa API ===\n";
echo "Параметры запроса:\n";
echo "Amount: $amount\n";
echo "Order ID: $orderId\n";
echo "Description: $description\n";
echo "Success URL: $successUrl\n";
echo "Fail URL: $failUrl\n\n";

// Тестируем создание платежа
echo "Создание платежа...\n";
$payment = $tkassaAPI->createPayment($amount, $orderId, $description, $successUrl, $failUrl);

if ($payment && $payment['success']) {
    echo " Платеж успешно создан!\n";
    echo "Payment ID: " . ($payment['paymentId'] ?? 'неизвестен') . "\n";
    echo "Payment URL: " . ($payment['paymentUrl'] ?? 'не указан') . "\n";

    if ($payment['raw_response']) {
        echo "\nОтвет API T-Kassa:\n";
        echo json_encode($payment['raw_response'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    }
} else {
    echo "❌ Ошибка создания платежа!\n";

    if ($payment && isset($payment['raw_response'])) {
        echo "Ответ API T-Kassa:\n";
        echo json_encode($payment['raw_response'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    } else {
        echo "Нет ответа от API или ошибка в коде\n";
    }
}

// Тестируем получение статуса платежа
if (isset($payment['paymentId']) && !empty($payment['paymentId'])) {
    echo "\n=== Проверка статуса платежа ===\n";
    $status = $tkassaAPI->getPaymentStatus($payment['paymentId']);

    if ($status) {
        echo " Статус платежа получен:\n";
        echo json_encode($status, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    } else {
        echo "❌ Ошибка получения статуса платежа\n";
    }
}

echo "\n=== Конфигурация T-Kassa ===\n";
echo "Terminal ID: " . TKASSA_TERMINAL . "\n";
echo "Password: " . TKASSA_PASSWORD . "\n";
echo "Merchant Name: " . TKASSA_MERCHANT_NAME . "\n";
echo "Merchant ID: " . TKASSA_MERCHANT_ID . "\n";
echo "Terminal ID Numeric: " . TKASSA_TERMINAL_ID . "\n";
echo "SBP Merchant ID: " . TKASSA_SBP_MERCHANT_ID . "\n";
echo "Token: " . (TKASSA_TOKEN ?: 'не указан') . "\n";
?>
