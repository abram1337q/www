from .user import User
from .product import Product
from .favorite import UserFavoriteProduct

__all__ = ["User", "Product", "UserFavoriteProduct"] 