from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database.connection import Base
import hashlib
import secrets
from app.utils.encryption import encrypt_password, decrypt_password, verify_password

class User(Base):
    """Модель пользователя Telegram"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    telegram_id = Column(Integer, unique=True, nullable=False, index=True, comment='ID пользователя в Telegram')
    username = Column(String(255), nullable=True, comment='Username пользователя в Telegram')
    first_name = Column(String(255), nullable=True, comment='Имя пользователя')
    last_name = Column(String(255), nullable=True, comment='Фамилия пользователя')
    preferred_region = Column(String(10), default='en-ua', comment='Предпочитаемый регион (en-ua, en-tr, en-in)')
    
    # Настройки отображения регионов (по умолчанию все включены)
    show_ukraine_prices = Column(Boolean, default=True, comment='Показывать цены Украины')
    show_turkey_prices = Column(Boolean, default=True, comment='Показывать цены Турции')
    show_india_prices = Column(Boolean, default=True, comment='Показывать цены Индии')
    
    # PSN данные пользователя
    platform = Column(String(50), nullable=True, comment='PlayStation платформа (PS4, PS5)')
    psn_email = Column(String(255), nullable=True, comment='Email для PSN аккаунта')
    psn_password_hash = Column(Text, nullable=True, comment='Зашифрованный пароль PSN аккаунта')
    psn_password_salt = Column(String(32), nullable=True, comment='Соль для шифрования пароля')
    
    is_active = Column(Boolean, default=True, comment='Активен ли пользователь')
    created_at = Column(DateTime, default=datetime.utcnow, comment='Дата регистрации')
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment='Дата последнего обновления')
    
    # Связь с избранными товарами
    favorite_products = relationship("UserFavoriteProduct", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User(telegram_id={self.telegram_id}, username='{self.username}')>"
    
    @property
    def full_name(self):
        """Полное имя пользователя"""
        parts = [self.first_name, self.last_name]
        return " ".join(filter(None, parts)) or self.username or f"User {self.telegram_id}"
    
    def get_enabled_regions(self):
        """Получить список включенных регионов"""
        regions = []
        if self.show_ukraine_prices:
            regions.append('en-ua')
        if self.show_turkey_prices:
            regions.append('en-tr')
        if self.show_india_prices:
            regions.append('en-in')
        return regions
    
    def get_preferred_region_info(self):
        """Получить информацию о предпочитаемом регионе"""
        region_map = {
            'en-tr': {'code': 'TRL', 'symbol': '₺', 'flag': '🇹🇷', 'name': 'Турция'},
            'en-ua': {'code': 'UAH', 'symbol': '₴', 'flag': '🇺🇦', 'name': 'Украина'},
            'en-in': {'code': 'INR', 'symbol': '₹', 'flag': '🇮🇳', 'name': 'Индия'}
        }
        return region_map.get(self.preferred_region, region_map['en-ua'])
    
    def set_psn_password(self, password: str):
        """Установить PSN пароль с шифрованием"""
        if not password:
            self.psn_password_hash = None
            self.psn_password_salt = None
            return
        
        # Шифруем пароль
        encrypted_password, salt = encrypt_password(password)
        
        self.psn_password_hash = encrypted_password
        self.psn_password_salt = salt
    
    def verify_psn_password(self, password: str) -> bool:
        """Проверить PSN пароль"""
        if not self.psn_password_hash or not self.psn_password_salt:
            return False
        
        return verify_password(password, self.psn_password_hash, self.psn_password_salt)
    
    def get_psn_password(self) -> str:
        """
        Получить расшифрованный PSN пароль
        
        Returns:
            str: Расшифрованный PSN пароль или пустая строка если пароль не задан
        """
        if not self.psn_password_hash or not self.psn_password_salt:
            return ""
        
        return decrypt_password(self.psn_password_hash, self.psn_password_salt)
    
    @property
    def has_psn_credentials(self) -> bool:
        """Проверить, есть ли PSN данные у пользователя"""
        return bool(self.psn_email and self.psn_password_hash) 