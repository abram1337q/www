"""
API для оплаты через карты пополнения PlayStation Store India
Использует oplata.info для покупки карт нужного номинала
"""

import aiohttp
from typing import Dict, List, Optional, Tuple
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# Константы для API
OPLATA_URL = "https://www.oplata.info/asp2/pay.asp"
OPLATA_PAY_WM_URL = "https://www.oplata.info/asp2/pay_wm.asp"
BASE_URL = "https://www.oplata.info"

# ID товара на oplata.info для карт пополнения Индии
INDIA_CARD_PRODUCT_ID = "4457989"
AGENT_ID = "605064"

# Карты пополнения и их option values
# Структура: номинал -> (option_value, is_available)
@dataclass
class CardDenomination:
    value: int  # Номинал в INR
    option_id: str  # ID опции в форме
    available: bool = True  # Доступна ли карта

# Номиналы карт пополнения для Индии
INDIA_CARD_DENOMINATIONS = [
    CardDenomination(1000, "4243895", True),
    CardDenomination(2000, "4284863", True),
    CardDenomination(3000, "4284949", True),
    CardDenomination(4000, "4243901", True),
    CardDenomination(5000, "4243903", False),  # Часто out of stock
]

# Заголовки для имитации браузера
BROWSER_HEADERS = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "accept-language": "ru,en;q=0.9",
    "cache-control": "no-cache",
    "content-type": "application/x-www-form-urlencoded",
    "origin": "https://www.oplata.info",
    "referer": "https://www.oplata.info/",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
}


class IndiaPaymentAPIError(Exception):
    """Исключение для ошибок API оплаты Индии"""
    pass


@dataclass
class CardPurchaseInfo:
    """Информация о покупке карт пополнения"""
    cards: List[CardDenomination]  # Список карт для покупки
    total_value: int  # Общая сумма карт в INR
    game_price: int  # Цена игры в INR
    remaining_balance: int  # Остаток на кошельке после покупки игры
    quantity_map: Dict[int, int]  # Количество карт каждого номинала {номинал: количество}

    @property
    def total_cards(self) -> int:
        """Общее количество карт"""
        return sum(self.quantity_map.values())

    def get_description_ru(self) -> str:
        """Получить описание покупки на русском"""
        card_descriptions = []
        for denomination, quantity in sorted(self.quantity_map.items(), reverse=True):
            if quantity == 1:
                card_descriptions.append(f"карту на {denomination} Rs")
            else:
                card_descriptions.append(f"{quantity} карты по {denomination} Rs")

        cards_text = " и ".join(card_descriptions) if len(card_descriptions) <= 2 else ", ".join(card_descriptions[:-1]) + f" и {card_descriptions[-1]}"

        message = f"Вы покупаете {cards_text}. "
        message += f"Этого хватит для оплаты выбранного товара в PS Store "

        if self.remaining_balance > 0:
            message += f"и {self.remaining_balance} Rs останутся в Вашем кошельке на аккаунте PSN."
        else:
            message += "без остатка на кошельке."

        return message

    def get_description_en(self) -> str:
        """Получить описание покупки на английском"""
        card_descriptions = []
        for denomination, quantity in sorted(self.quantity_map.items(), reverse=True):
            if quantity == 1:
                card_descriptions.append(f"a {denomination} Rs card")
            else:
                card_descriptions.append(f"{quantity} cards of {denomination} Rs each")

        cards_text = " and ".join(card_descriptions) if len(card_descriptions) <= 2 else ", ".join(card_descriptions[:-1]) + f", and {card_descriptions[-1]}"

        message = f"You are purchasing {cards_text}. "
        message += f"This will cover the cost of the selected item in PS Store "

        if self.remaining_balance > 0:
            message += f"and {self.remaining_balance} Rs will remain in your PSN wallet."
        else:
            message += "with no remaining balance."

        return message


class IndiaPaymentAPI:
    """API для покупки карт пополнения PlayStation Store India через oplata.info"""

    def __init__(self):
        """Инициализация API клиента"""
        self.available_cards = self._get_available_cards()

    def _get_available_cards(self) -> List[CardDenomination]:
        """Получить список доступных карт (можно обновлять динамически)"""
        return [card for card in INDIA_CARD_DENOMINATIONS if card.available]

    async def check_card_availability(self) -> Dict[int, bool]:
        """
        Проверить доступность карт на сайте
        TODO: Реализовать парсинг страницы для проверки статуса "out of stock"
        """
        try:
            async with aiohttp.ClientSession() as session:
                url = f"{OPLATA_PAY_WM_URL}?id_d={INDIA_CARD_PRODUCT_ID}&ai={AGENT_ID}&_ow=0"
                async with session.get(url, headers=BROWSER_HEADERS) as response:
                    if response.status == 200:
                        html = await response.text()
                        availability = {}
                        for card in INDIA_CARD_DENOMINATIONS:
                            # Проверяем, есть ли "out of stock" рядом с этой опцией
                            is_disabled = f'value="{card.option_id}"' in html and 'disabled' in html.split(f'value="{card.option_id}"')[0].split('input')[-1]
                            availability[card.value] = not is_disabled
                        return availability
        except Exception as e:
            logger.error(f"Error checking card availability: {e}")

        # Возвращаем текущий статус по умолчанию
        return {card.value: card.available for card in INDIA_CARD_DENOMINATIONS}

    def calculate_cards_needed(self, game_price_inr: float) -> CardPurchaseInfo:
        """
        Рассчитать, какие карты нужно купить для данной цены игры

        Логика:
        1. Выбираем минимальную комбинацию карт, покрывающую цену игры
        2. Если большой номинал недоступен, используем несколько меньших

        Args:
            game_price_inr: Цена игры в индийских рупиях

        Returns:
            CardPurchaseInfo с информацией о необходимых картах
        """
        price = int(game_price_inr)
        available = sorted(self.available_cards, key=lambda c: c.value, reverse=True)

        # Если цена <= 0, ошибка
        if price <= 0:
            raise IndiaPaymentAPIError("Цена игры должна быть больше 0")

        # Ищем оптимальную комбинацию карт
        result_cards = []
        quantity_map = {}
        remaining_price = price

        # Алгоритм: жадный подход с резервированием
        # 1. Пробуем найти одну карту, которая покрывает цену
        for card in available:
            if card.value >= price:
                # Нашли карту, которая покрывает всю цену
                best_single = card
                break
        else:
            best_single = None

        # 2. Также пробуем комбинации
        best_combo = self._find_best_combination(price, available)

        # 3. Выбираем лучший вариант (меньше остаток или меньше карт)
        if best_single:
            single_remainder = best_single.value - price
            combo_remainder = best_combo['total'] - price if best_combo else float('inf')

            if single_remainder <= combo_remainder or (single_remainder == combo_remainder and 1 <= len(best_combo.get('cards', []))):
                # Используем одну карту
                result_cards = [best_single]
                quantity_map = {best_single.value: 1}
                total_value = best_single.value
            else:
                # Используем комбинацию
                result_cards = best_combo['cards']
                quantity_map = best_combo['quantity_map']
                total_value = best_combo['total']
        elif best_combo:
            result_cards = best_combo['cards']
            quantity_map = best_combo['quantity_map']
            total_value = best_combo['total']
        else:
            # Не нашли подходящих карт
            raise IndiaPaymentAPIError(f"Невозможно подобрать карты для суммы {price} INR")

        remaining_balance = total_value - price

        return CardPurchaseInfo(
            cards=result_cards,
            total_value=total_value,
            game_price=price,
            remaining_balance=remaining_balance,
            quantity_map=quantity_map
        )

    def _find_best_combination(self, price: int, available_cards: List[CardDenomination]) -> Optional[Dict]:
        """
        Найти лучшую комбинацию карт для покрытия цены
        Использует динамическое программирование для оптимизации
        """
        if not available_cards:
            return None

        # Максимальная сумма, которую рассматриваем
        max_sum = price + max(card.value for card in available_cards)

        # dp[i] = (минимальное количество карт для суммы i, комбинация карт)
        INF = float('inf')
        dp = [(INF, [])] * (max_sum + 1)
        dp[0] = (0, [])

        for i in range(1, max_sum + 1):
            for card in available_cards:
                if card.value <= i:
                    prev_count, prev_cards = dp[i - card.value]
                    if prev_count + 1 < dp[i][0]:
                        new_cards = prev_cards + [card]
                        dp[i] = (prev_count + 1, new_cards)

        # Ищем минимальную сумму >= price с минимальным количеством карт
        best = None
        for total in range(price, max_sum + 1):
            count, cards = dp[total]
            if count < INF:
                # Подсчитываем количество карт каждого номинала
                quantity_map = {}
                for card in cards:
                    quantity_map[card.value] = quantity_map.get(card.value, 0) + 1

                candidate = {
                    'total': total,
                    'cards': cards,
                    'quantity_map': quantity_map,
                    'count': count
                }

                if best is None:
                    best = candidate
                elif total - price < best['total'] - price:
                    # Меньше остаток
                    best = candidate
                elif total - price == best['total'] - price and count < best['count']:
                    # Такой же остаток, но меньше карт
                    best = candidate

                # Оптимизация: если нашли точное совпадение или минимальный остаток
                if total == price:
                    break

        return best

    def _create_payment_data(
        self,
        card: CardDenomination,
        quantity: int = 1,
        need_registration: bool = False
    ) -> Dict[str, str]:
        """Создает данные для POST запроса к API оплаты"""

        data = {
            "Lang": "ru-RU",
            "ID_D": INDIA_CARD_PRODUCT_ID,
            "product_id": INDIA_CARD_PRODUCT_ID,
            "Agent": AGENT_ID,
            "AgentN": "",
            "FailPage": f"https://x-box-store.ru/detail/{INDIA_CARD_PRODUCT_ID}",
            "NoClearBuyerQueryString": "NoClear",
            "TypeCurr": "API_5020_RUB",
            "firstrun": "0",
            "product_cnt": str(quantity),
            f"Option_radio_1449937": card.option_id,
        }

        # Добавляем опцию регистрации аккаунта если нужно
        if need_registration:
            data["Option_checkbox_1518483"] = "4592011"

        return data

    def _build_full_url(self, redirect_url: str) -> str:
        """Преобразует относительный URL в абсолютный"""
        if redirect_url.startswith("/"):
            return f"{BASE_URL}{redirect_url}"
        elif redirect_url.startswith("http"):
            return redirect_url
        else:
            return f"{BASE_URL}/asp2/{redirect_url}"

    async def _send_payment_request(self, payment_data: Dict[str, str]) -> str:
        """Отправляет POST запрос и возвращает URL для оплаты"""
        try:
            logger.info(f"💳 India card payment request: data={payment_data}")

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url=OPLATA_URL,
                    headers=BROWSER_HEADERS,
                    data=payment_data,
                    allow_redirects=False,
                ) as response:
                    if response.status in [301, 302, 303, 307, 308]:
                        redirect_url = response.headers.get("Location")
                        if redirect_url:
                            full_url = self._build_full_url(redirect_url)
                            logger.info(f"Payment redirect received: {redirect_url}")
                            return full_url
                        else:
                            raise IndiaPaymentAPIError("Редирект не найден в ответе сервера")
                    else:
                        response_text = await response.text()
                        logger.error(f"Unexpected API response status: {response.status}, body: {response_text[:500]}")
                        raise IndiaPaymentAPIError(f"Неожиданный статус ответа: {response.status}")
        except aiohttp.ClientError as e:
            logger.error(f"Payment API request failed: {str(e)}")
            raise IndiaPaymentAPIError(f"Ошибка соединения с API оплаты: {str(e)}")

    async def get_payment_url(
        self,
        game_price_inr: float,
        need_registration: bool = False
    ) -> Tuple[str, CardPurchaseInfo]:
        """
        Получает ссылку для оплаты карты пополнения

        Args:
            game_price_inr: Цена игры в индийских рупиях
            need_registration: Нужна ли регистрация аккаунта (+200 RUB)

        Returns:
            Tuple: (URL для оплаты, информация о покупке карт)

        Raises:
            IndiaPaymentAPIError: При ошибке генерации ссылки
        """
        # Рассчитываем нужные карты
        purchase_info = self.calculate_cards_needed(game_price_inr)

        logger.info(f"🇮🇳 India payment: game_price={game_price_inr} INR, "
                    f"cards={purchase_info.quantity_map}, "
                    f"total={purchase_info.total_value} INR, "
                    f"remaining={purchase_info.remaining_balance} INR")

        # Для простоты берем первую (самую большую) карту
        # TODO: Если нужно несколько карт разных номиналов, генерируем несколько ссылок
        if len(purchase_info.quantity_map) == 1:
            denomination = list(purchase_info.quantity_map.keys())[0]
            quantity = purchase_info.quantity_map[denomination]
            card = next(c for c in self.available_cards if c.value == denomination)

            # Создаем данные для запроса
            payment_data = self._create_payment_data(
                card=card,
                quantity=quantity,
                need_registration=need_registration
            )

            # Отправляем запрос и получаем ссылку
            payment_url = await self._send_payment_request(payment_data)

            return payment_url, purchase_info
        else:
            # Если нужно несколько разных номиналов - пока используем самый большой
            # В будущем можно добавить генерацию нескольких ссылок
            denomination = max(purchase_info.quantity_map.keys())
            card = next(c for c in self.available_cards if c.value == denomination)

            payment_data = self._create_payment_data(
                card=card,
                quantity=purchase_info.quantity_map[denomination],
                need_registration=need_registration
            )

            payment_url = await self._send_payment_request(payment_data)

            # Добавляем предупреждение о необходимости дополнительных карт
            logger.warning(f"⚠️ Multiple card denominations needed but only one link generated")

            return payment_url, purchase_info

    def get_direct_payment_url(self, denomination: int = 1000) -> str:
        """
        Получить прямую ссылку на страницу оплаты карты определенного номинала
        (без POST-запроса, просто URL)
        """
        return f"{OPLATA_PAY_WM_URL}?id_d={INDIA_CARD_PRODUCT_ID}&ai={AGENT_ID}&_ow=0"


# Глобальный экземпляр API
india_payment_api = IndiaPaymentAPI()
