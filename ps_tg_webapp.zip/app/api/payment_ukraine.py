"""
API для оплаты через покупку игр на PlayStation UA Украина
Использует oplata.info для обработки платежей в UAH
"""

import aiohttp
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)

# Константы для API
OPLATA_URL = "https://www.oplata.info/asp2/pay.asp"
BASE_URL = "https://www.oplata.info"

# ID товара на oplata.info для покупки игр в Украине
UKRAINE_PRODUCT_ID = "3593163"
AGENT_ID = "605064"

# Заголовки для имитации браузера
BROWSER_HEADERS = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "accept-language": "ru,en;q=0.9",
    "cache-control": "no-cache",
    "content-type": "application/x-www-form-urlencoded",
    "origin": "https://www.oplata.info",
    "pragma": "no-cache",
    "referer": "https://www.oplata.info/asp2/pay_wm.asp?id_d=3593163&ai=605064&_ow=0",
    "sec-ch-ua": '"Chromium";v="136", "YaBrowser";v="25.6", "Not.A/Brand";v="99"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
}


class UkrainePaymentAPIError(Exception):
    """Исключение для ошибок API оплаты Украины"""
    pass


class UkrainePaymentAPI:
    """API для покупки игр на PlayStation Store Ukraine через oplata.info"""

    def __init__(self):
        """Инициализация API клиента"""
        pass

    def _create_payment_data(
        self,
        game: str,
        email: str,
        password: str,
        uah_amount: float,
        twofa_code: str = "",
    ) -> Dict[str, str]:
        """
        Создает данные для POST запроса к API оплаты Украины

        Поля формы (ID получены с https://www.oplata.info/asp2/pay_wm.asp?id_d=3593163):
        - Option_text_277928: название игры
        - Option_text_277929: PSN Email (required)
        - Option_text_277932: PSN Password (required)
        - Option_text_2254506: 2FA backup code
        - Option_checkbox_3344172: согласие с риском блокировки (value=13242692)
        """

        data = {
            # Фиксированные поля для товара
            "ID_D": UKRAINE_PRODUCT_ID,
            "Agent": AGENT_ID,
            "FailPage": f"https://plati.market/itm/?idd={UKRAINE_PRODUCT_ID}",
            "Lang": "ru-RU",
            "TypeCurr": "RUR",  # Валюта оплаты - рубли
            "_ow": "0",
            "product_cnt": "1",
            "unit_cnt": str(int(uah_amount)),  # Количество UAH

            # Пользовательские данные
            "Option_text_277928": game,  # Название игры
            "Option_text_277929": email,  # PSN Email
            "Option_text_277932": password,  # PSN Password
            "Option_text_2254506": twofa_code,  # 2FA backup code
            "Option_checkbox_3344172": "13242692",  # Согласие с риском блокировки
        }

        return data

    def _build_full_url(self, redirect_url: str) -> str:
        """Преобразует относительный URL в абсолютный"""
        if redirect_url.startswith("/"):
            return f"{BASE_URL}{redirect_url}"
        elif redirect_url.startswith("http"):
            return redirect_url
        else:
            return f"{BASE_URL}/asp2/{redirect_url}"

    async def _send_payment_request(self, payment_data: Dict[str, str]) -> str:
        """Отправляет POST запрос и возвращает URL для оплаты"""
        try:
            game_name = payment_data.get("Option_text_277928", "Unknown")
            uah_amount = payment_data.get("unit_cnt", "Unknown")

            logger.info(f"💰 Ukraine payment request: game='{game_name}', amount={uah_amount} UAH")
            logger.debug(f"Full payment data: {payment_data}")

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url=OPLATA_URL,
                    headers=BROWSER_HEADERS,
                    data=payment_data,
                    allow_redirects=False,
                ) as response:
                    if response.status in [301, 302, 303, 307, 308]:
                        redirect_url = response.headers.get("Location")
                        if redirect_url:
                            full_url = self._build_full_url(redirect_url)
                            logger.info(f"Payment redirect received: {redirect_url}")
                            return full_url
                        else:
                            raise UkrainePaymentAPIError("Редирект не найден в ответе сервера")
                    else:
                        response_text = await response.text()
                        logger.error(f"Unexpected API response status: {response.status}, body: {response_text[:500]}")
                        raise UkrainePaymentAPIError(f"Неожиданный статус ответа: {response.status}")
        except aiohttp.ClientError as e:
            logger.error(f"Payment API request failed: {str(e)}")
            raise UkrainePaymentAPIError(f"Ошибка соединения с API оплаты: {str(e)}")

    def get_direct_payment_url(self) -> str:
        """
        Получить прямую ссылку на страницу оплаты
        Используется для редиректа пользователя на страницу оплаты без POST-запроса
        """
        return f"https://www.oplata.info/asp2/pay_wm.asp?id_d={UKRAINE_PRODUCT_ID}&ai={AGENT_ID}&_ow=0"

    async def get_payment_url(
        self,
        game: str,
        email: str,
        password: str,
        uah_price: float,
        twofa_code: str = ""
    ) -> str:
        """
        Получает ссылку для оплаты игры в Украине

        Args:
            game: Название игры для покупки
            email: PSN почта
            password: PSN пароль
            uah_price: Цена товара в гривнах (UAH)
            twofa_code: Код двухфакторной аутентификации (если есть)

        Returns:
            Полная ссылка для перехода к оплате

        Raises:
            UkrainePaymentAPIError: При ошибке генерации ссылки
        """
        # Проверяем лимиты
        if uah_price < 250:
            raise UkrainePaymentAPIError(f"Минимальная сумма покупки: 250 UAH (указано: {uah_price} UAH)")
        if uah_price > 7000:
            raise UkrainePaymentAPIError(f"Максимальная сумма покупки: 7000 UAH (указано: {uah_price} UAH)")

        # Логируем параметры запроса
        logger.info(f"🇺🇦 Generating Ukraine payment URL: game='{game}', price={uah_price} UAH")

        # Создаем данные для запроса
        payment_data = self._create_payment_data(
            game=game,
            email=email,
            password=password,
            uah_amount=uah_price,
            twofa_code=twofa_code
        )

        # Отправляем запрос и получаем ссылку
        payment_url = await self._send_payment_request(payment_data)

        # Проверяем, что получили правильную ссылку
        if "pay_api.asp" in payment_url or "oplata.info" in payment_url:
            logger.info(f"✅ Ukraine payment URL generated: {payment_url}")
            return payment_url
        else:
            logger.error(f"Invalid payment URL received: {payment_url}")
            raise UkrainePaymentAPIError(f"Получена неверная ссылка оплаты")


# Глобальный экземпляр API
ukraine_payment_api = UkrainePaymentAPI()
