from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, func
from typing import Optional, List, Dict
from app.models import User, Product, UserFavoriteProduct
from app.models.currency_rate import CurrencyRate
from app.api.schemas import UserCreate, UserUpdate, ProductFilter, PaginationParams, CurrencyRateCreate, CurrencyRateUpdate

class UserCRUD:
    @staticmethod
    def get_by_telegram_id(db: Session, telegram_id: int) -> Optional[User]:
        """Получить пользователя по Telegram ID"""
        return db.query(User).filter(User.telegram_id == telegram_id).first()

    @staticmethod
    def create(db: Session, user_data: UserCreate) -> User:
        """Создать нового пользователя"""
        user = User(**user_data.model_dump())
        db.add(user)
        db.commit()
        db.refresh(user)
        return user

    @staticmethod
    def update(db: Session, user: User, update_data: UserUpdate) -> User:
        """Обновить данные пользователя"""
        update_fields = update_data.model_dump(exclude_unset=True)

        # Обрабатываем специальные поля
        psn_password = update_fields.pop('psn_password', None)

        # Обычные поля
        for field, value in update_fields.items():
            setattr(user, field, value)

        # Специальная обработка PSN пароля
        if psn_password is not None:
            user.set_psn_password(psn_password)

        db.commit()
        db.refresh(user)
        return user

    @staticmethod
    def get_or_create(db: Session, user_data: UserCreate) -> tuple[User, bool]:
        """Получить пользователя или создать, если не существует"""
        user = UserCRUD.get_by_telegram_id(db, user_data.telegram_id)
        if user:
            return user, False
        return UserCRUD.create(db, user_data), True

class ProductCRUD:
    @staticmethod
    def get_by_id(db: Session, product_id: str, region: Optional[str] = None) -> Optional[Product]:
        """Получить товар по ID и опционально региону"""
        query = db.query(Product).filter(Product.id == product_id)

        if region:
            query = query.filter(Product.region == region)

        return query.first()

    @staticmethod
    def get_by_id_all_regions(db: Session, product_id: str) -> List[Product]:
        """Получить товар во всех регионах"""
        return db.query(Product).filter(Product.id == product_id).all()

    @staticmethod
    def get_list(
        db: Session,
        filters: ProductFilter,
        pagination: PaginationParams,
        user: Optional[User] = None
    ) -> tuple[List[Product], int]:
        """Получить список товаров с фильтрацией и пагинацией"""
        query = db.query(Product)

        # Фильтр по регионам пользователя
        if user:
            enabled_regions = user.get_enabled_regions()
            if enabled_regions:
                query = query.filter(Product.region.in_(enabled_regions))

        # Применяем фильтры
        if filters.category:
            query = query.filter(Product.category.ilike(f"%{filters.category}%"))

        if filters.region:
            query = query.filter(Product.region == filters.region)

        if filters.search:
            search_term = f"%{filters.search}%"
            query = query.filter(
                or_(
                    Product.name.ilike(search_term),
                    Product.main_name.ilike(search_term),
                    Product.description.ilike(search_term),
                    Product.publisher.ilike(search_term),
                    Product.tags.ilike(search_term)
                )
            )

        if filters.has_discount is not None:
            if filters.has_discount:
                query = query.filter(
                    and_(
                        Product.discount.isnot(None),
                        Product.discount > 0
                    )
                )
            else:
                query = query.filter(
                    or_(
                        Product.discount.is_(None),
                        Product.discount <= 0
                    )
                )

        if filters.has_ps_plus is not None:
            if filters.has_ps_plus:
                query = query.filter(
                    or_(
                        Product.ps_plus == 1,
                        and_(Product.ps_price.isnot(None), Product.ps_price > 0)
                    )
                )

        if filters.has_ea_access is not None:
            if filters.has_ea_access:
                query = query.filter(
                    and_(
                        Product.ea_access.isnot(None),
                        Product.ea_access != '0'
                    )
                )

        # Фильтр по цене
        if filters.min_price is not None:
            query = query.filter(Product.price >= filters.min_price)

        if filters.max_price is not None:
            query = query.filter(Product.price <= filters.max_price)

        # Подсчет общего количества
        total = query.count()

        # Применяем пагинацию
        offset = (pagination.page - 1) * pagination.limit
        products = query.offset(offset).limit(pagination.limit).all()

        return products, total

    @staticmethod
    def get_categories(db: Session) -> List[str]:
        """Получить список всех категорий товаров"""
        categories = db.query(Product.category).filter(
            Product.category.isnot(None)
        ).distinct().all()
        return sorted([cat[0] for cat in categories if cat[0]])

    @staticmethod
    def get_regions(db: Session) -> List[str]:
        """Получить список всех доступных регионов"""
        regions = db.query(Product.region).filter(
            Product.region.isnot(None)
        ).distinct().all()
        return sorted([reg[0] for reg in regions if reg[0]])

    @staticmethod
    def prepare_product_with_prices(product: Product, db: Session = None) -> dict:
        """Подготовить товар с информацией о ценах"""
        region_info = product.get_region_info()

        product_dict = {
            'id': product.id,
            'name': product.name,
            'main_name': product.get_display_name(),
            'category': product.category,
            'region': product.region,
            'type': product.type,
            'image': product.image,
            'publisher': product.publisher,
            'description': product.description,
            'discount': product.discount,
            'discount_end': product.discount_end,
            'has_discount': product.has_discount,
            'has_ps_plus': product.has_ps_plus,
            'has_ea_access': product.has_ea_access,
            'rating': product.rating,
            'edition': product.edition,
            'platforms': product.platforms,
            'localization': product.localization,
            'region_info': region_info,
            # Оригинальные цены в валюте региона
            'price': product.price,
            'old_price': product.old_price,
            'ps_price': product.ps_price,
            'ea_price': product.ea_price,
            'current_price': product.get_current_price(),
            'price_with_currency': product.get_price_with_currency(),
            'all_prices': product.get_all_prices(),
            # Цены в рублях (если есть доступ к БД)
            'rub_price': product.get_rub_price(db) if db else None,
            'rub_price_old': product.get_rub_old_price(db) if db else None,
            'rub_ps_price': product.get_rub_ps_price(db) if db else None,
            'rub_ea_price': product.get_rub_ea_price(db) if db else None,
            # Прочее
            'compound': product.get_compound_list(),
            'info': product.get_info_list(),
            'tags': product.get_tags_list()
        }

        return product_dict

    @staticmethod
    def prepare_product_with_multi_region_prices(product: Product, db: Session, user: Optional[User] = None) -> dict:
        """
        Подготовить товар с ценами из всех регионов в рублях

        В новой структуре БД все региональные цены хранятся в одной записи:
        price_uah, price_try, price_inr

        Args:
            product: Product объект с региональными ценами
            db: сессия БД
            user: пользователь для фильтрации регионов

        Returns:
            dict с данными товара и ценами из всех регионов в рублях
        """
        # Маппинг регионов
        region_mapping = {
            'uah': {'flag': '🇺🇦', 'name': 'Украина', 'code': 'UAH', 'price_field': 'price_uah', 'old_price_field': 'old_price_uah'},
            'try': {'flag': '🇹🇷', 'name': 'Турция', 'code': 'TRY', 'price_field': 'price_try', 'old_price_field': 'old_price_try'},
            'inr': {'flag': '🇮🇳', 'name': 'Индия', 'code': 'INR', 'price_field': 'price_inr', 'old_price_field': 'old_price_inr'}
        }

        # Определяем какие регионы показывать
        enabled_regions = ['en-ua', 'en-tr', 'en-in']
        if user:
            enabled_regions = user.get_enabled_regions()

        # Маппинг enabled_regions к коротким кодам
        region_enable_map = {
            'en-ua': 'uah',
            'en-tr': 'try',
            'en-in': 'inr'
        }

        # Собираем цены из всех регионов
        regional_prices = []
        min_price = None

        for enabled_region in enabled_regions:
            region_key = region_enable_map.get(enabled_region)
            if not region_key or region_key not in region_mapping:
                continue

            region_info = region_mapping[region_key]

            # Получаем цену из соответствующего поля
            price = getattr(product, region_info['price_field'], None)
            old_price = getattr(product, region_info['old_price_field'], None)

            if price and price > 0:
                # Конвертируем в рубли
                from app.models.currency_rate import CurrencyRate
                rate = CurrencyRate.get_rate_for_price(db, region_info['code'], price)
                price_rub = round(price * rate, 2)
                old_price_rub = round(old_price * rate, 2) if old_price and old_price > 0 else None

                # Вычисляем скидку
                has_discount = False
                discount_percent = None
                if old_price and old_price > price:
                    has_discount = True
                    discount_percent = int(((old_price - price) / old_price) * 100)

                regional_prices.append({
                    'region': enabled_region,
                    'flag': region_info['flag'],
                    'name': region_info['name'],
                    'currency_code': region_info['code'],
                    'price_rub': price_rub,
                    'old_price_rub': old_price_rub,
                    'has_discount': has_discount,
                    'discount_percent': discount_percent
                })

                # Обновляем минимальную цену
                if min_price is None or price_rub < min_price:
                    min_price = price_rub

        product_dict = {
            'id': product.id,
            'name': product.name,
            'main_name': product.get_display_name(),
            'category': product.category,
            'type': product.type,
            'image': product.image,
            'publisher': product.publisher,
            'description': product.description,
            'rating': product.rating,
            'edition': product.edition,
            'platforms': product.platforms,
            'localization': product.localization,
            'has_discount': any(p['has_discount'] for p in regional_prices),
            'has_ps_plus': product.has_ps_plus,
            'has_ea_access': product.has_ea_access,
            # Прочее
            'compound': product.get_compound_list(),
            'info': product.get_info_list(),
            'tags': product.get_tags_list(),
            # Цены из всех регионов
            'regional_prices': regional_prices,
            'min_price_rub': min_price
        }

        return product_dict

    @staticmethod
    def get_unique_products_by_main_name(
        db: Session,
        filters: ProductFilter,
        pagination: PaginationParams,
        user: Optional[User] = None
    ) -> tuple[List[Dict], int]:
        """
        Получить уникальные товары (без дубликатов по main_name),
        выбирая лучшую цену из всех регионов
        """
        query = db.query(Product)

        # Фильтр по регионам пользователя
        enabled_regions = ['en-ua', 'en-tr', 'en-in']
        if user:
            enabled_regions = user.get_enabled_regions()

        if enabled_regions:
            query = query.filter(Product.region.in_(enabled_regions))

        # Применяем остальные фильтры
        if filters.category:
            query = query.filter(Product.category.ilike(f"%{filters.category}%"))

        if filters.search:
            search_term = f"%{filters.search}%"
            query = query.filter(
                or_(
                    Product.name.ilike(search_term),
                    Product.main_name.ilike(search_term),
                    Product.description.ilike(search_term),
                    Product.publisher.ilike(search_term)
                )
            )

        # Получаем все товары
        all_products = query.all()

        # Группируем по main_name и выбираем лучшую цену
        unique_products = {}
        for product in all_products:
            main_name = product.get_display_name()

            if main_name not in unique_products:
                unique_products[main_name] = product
            else:
                # Сравниваем цены и оставляем дешевле
                existing = unique_products[main_name]
                existing_price = existing.get_current_price() or float('inf')
                current_price = product.get_current_price() or float('inf')

                if current_price < existing_price:
                    unique_products[main_name] = product

        # Применяем фильтры скидок после группировки
        filtered_products = []
        for product in unique_products.values():
            if filters.has_discount is not None:
                if filters.has_discount and not product.has_discount:
                    continue
                if not filters.has_discount and product.has_discount:
                    continue

            if filters.min_price is not None:
                if not product.price or product.price < filters.min_price:
                    continue

            if filters.max_price is not None:
                if not product.price or product.price > filters.max_price:
                    continue

            filtered_products.append(product)

        total = len(filtered_products)

        # Применяем пагинацию
        offset = (pagination.page - 1) * pagination.limit
        paginated_products = filtered_products[offset:offset + pagination.limit]

        # Подготавливаем продукты с ценами
        result = [ProductCRUD.prepare_product_with_prices(p) for p in paginated_products]

        return result, total

    @staticmethod
    def get_products_grouped_by_name(
        db: Session,
        filters: ProductFilter,
        pagination: PaginationParams,
        user: Optional[User] = None
    ) -> tuple[List[Dict], int]:
        """
        Получить список товаров с ценами из всех доступных регионов в рублях

        В новой структуре БД каждый товар имеет цены для всех регионов в одной записи
        """
        query = db.query(Product)

        # Применяем фильтры
        if filters.category:
            query = query.filter(Product.category.ilike(f"%{filters.category}%"))

        if filters.search:
            search_term = f"%{filters.search}%"
            query = query.filter(
                or_(
                    Product.name.ilike(search_term),
                    Product.main_name.ilike(search_term),
                    Product.description.ilike(search_term),
                    Product.publisher.ilike(search_term)
                )
            )

        if filters.has_discount is not None and filters.has_discount:
            query = query.filter(
                or_(
                    and_(Product.old_price_uah.isnot(None), Product.old_price_uah > Product.price_uah),
                    and_(Product.old_price_try.isnot(None), Product.old_price_try > Product.price_try),
                    and_(Product.old_price_inr.isnot(None), Product.old_price_inr > Product.price_inr)
                )
            )

        if filters.has_ps_plus is not None and filters.has_ps_plus:
            query = query.filter(
                or_(
                    Product.ps_plus == 1,
                    and_(Product.ps_price.isnot(None), Product.ps_price > 0)
                )
            )

        # Получаем все товары
        all_products = query.all()

        # Применяем фильтр по цене (проверяем минимальную цену в рублях среди всех регионов)
        filtered_products = []
        for product in all_products:
            # Вычисляем минимальную цену в рублях из всех регионов
            min_price_rub = None

            from app.models.currency_rate import CurrencyRate

            # Проверяем Украину
            if product.price_uah and product.price_uah > 0:
                rate = CurrencyRate.get_rate_for_price(db, 'UAH', product.price_uah)
                price_rub = product.price_uah * rate
                if min_price_rub is None or price_rub < min_price_rub:
                    min_price_rub = price_rub

            # Проверяем Турцию
            if product.price_try and product.price_try > 0:
                rate = CurrencyRate.get_rate_for_price(db, 'TRY', product.price_try)
                price_rub = product.price_try * rate
                if min_price_rub is None or price_rub < min_price_rub:
                    min_price_rub = price_rub

            # Проверяем Индию
            if product.price_inr and product.price_inr > 0:
                rate = CurrencyRate.get_rate_for_price(db, 'INR', product.price_inr)
                price_rub = product.price_inr * rate
                if min_price_rub is None or price_rub < min_price_rub:
                    min_price_rub = price_rub

            # Применяем фильтры по цене
            if filters.min_price is not None:
                if min_price_rub is None or min_price_rub < filters.min_price:
                    continue

            if filters.max_price is not None:
                if min_price_rub is None or min_price_rub > filters.max_price:
                    continue

            filtered_products.append((product, min_price_rub))

        # Сортируем по минимальной цене или алфавиту
        filtered_products.sort(key=lambda x: (x[1] if x[1] else float('inf'), x[0].get_display_name()))

        total = len(filtered_products)

        # Применяем пагинацию
        offset = (pagination.page - 1) * pagination.limit
        paginated_products = filtered_products[offset:offset + pagination.limit]

        # Подготавливаем продукты с мультирегиональными ценами
        result = []
        for product, min_price in paginated_products:
            product_dict = ProductCRUD.prepare_product_with_multi_region_prices(
                product, db, user
            )
            result.append(product_dict)

        return result, total

class FavoriteCRUD:
    @staticmethod
    def add_to_favorites(db: Session, user_id: int, product_id: str) -> Optional[UserFavoriteProduct]:
        """Добавить товар в избранное"""
        # Проверяем, что товар не уже в избранном
        existing = db.query(UserFavoriteProduct).filter(
            and_(
                UserFavoriteProduct.user_id == user_id,
                UserFavoriteProduct.product_id == product_id
            )
        ).first()

        if existing:
            return existing

        favorite = UserFavoriteProduct(user_id=user_id, product_id=product_id)
        db.add(favorite)
        db.commit()
        db.refresh(favorite)
        return favorite

    @staticmethod
    def remove_from_favorites(db: Session, user_id: int, product_id: str) -> bool:
        """Удалить товар из избранного"""
        favorite = db.query(UserFavoriteProduct).filter(
            and_(
                UserFavoriteProduct.user_id == user_id,
                UserFavoriteProduct.product_id == product_id
            )
        ).first()

        if favorite:
            db.delete(favorite)
            db.commit()
            return True
        return False

    @staticmethod
    def get_user_favorites(db: Session, user_id: int) -> List[UserFavoriteProduct]:
        """Получить все избранные товары пользователя"""
        return db.query(UserFavoriteProduct).options(
            joinedload(UserFavoriteProduct.product)
        ).filter(UserFavoriteProduct.user_id == user_id).all()

    @staticmethod
    def is_favorite(db: Session, user_id: int, product_id: str) -> bool:
        """Проверить, находится ли товар в избранном у пользователя"""
        return db.query(UserFavoriteProduct).filter(
            and_(
                UserFavoriteProduct.user_id == user_id,
                UserFavoriteProduct.product_id == product_id
            )
        ).first() is not None

class CurrencyRateCRUD:
    """CRUD для курсов валют - оставлен для обратной совместимости"""
    @staticmethod
    def get_all(db: Session) -> List[CurrencyRate]:
        """Получить все курсы валют"""
        return db.query(CurrencyRate).order_by(
            CurrencyRate.currency_from,
            CurrencyRate.price_min
        ).all()

    @staticmethod
    def get_active(db: Session) -> List[CurrencyRate]:
        """Получить активные курсы валют"""
        return db.query(CurrencyRate).filter(
            CurrencyRate.is_active == True
        ).order_by(
            CurrencyRate.currency_from,
            CurrencyRate.price_min
        ).all()

    @staticmethod
    def get_by_id(db: Session, rate_id: int) -> Optional[CurrencyRate]:
        """Получить курс по ID"""
        return db.query(CurrencyRate).filter(CurrencyRate.id == rate_id).first()

    @staticmethod
    def create(db: Session, rate_data: CurrencyRateCreate, created_by: int = None) -> CurrencyRate:
        """Создать новый курс валют"""
        rate = CurrencyRate(**rate_data.model_dump(), created_by=created_by)
        db.add(rate)
        db.commit()
        db.refresh(rate)
        return rate

    @staticmethod
    def update(db: Session, rate: CurrencyRate, update_data: CurrencyRateUpdate) -> CurrencyRate:
        """Обновить курс валют"""
        update_fields = update_data.model_dump(exclude_unset=True)
        for field, value in update_fields.items():
            setattr(rate, field, value)
        db.commit()
        db.refresh(rate)
        return rate

    @staticmethod
    def delete(db: Session, rate: CurrencyRate) -> bool:
        """Удалить курс валют"""
        db.delete(rate)
        db.commit()
        return True

    @staticmethod
    def get_by_currency(db: Session, currency_from: str) -> List[CurrencyRate]:
        """Получить курсы для конкретной валюты"""
        return db.query(CurrencyRate).filter(
            and_(
                CurrencyRate.currency_from == currency_from,
                CurrencyRate.is_active == True
            )
        ).order_by(CurrencyRate.price_min).all()

class AdminCRUD:
    @staticmethod
    def get_stats(db: Session) -> dict:
        """Получить статистику для админки"""
        from datetime import datetime

        # Статистика товаров
        total_products = db.query(Product).count()

        # Уникальные товары (по названию)
        unique_products = db.query(Product.main_name).distinct().count()

        # Товары по регионам
        products_by_region = {}
        regions = db.query(Product.region, func.count(Product.id)).group_by(Product.region).all()
        for region, count in regions:
            products_by_region[region or 'unknown'] = count

        # Статистика пользователей
        total_users = db.query(User).count()
        active_users = db.query(User).filter(User.is_active == True).count()

        # Статистика избранного
        total_favorites = db.query(UserFavoriteProduct).count()

        # Статистика курсов валют
        currency_rates_count = db.query(CurrencyRate).filter(CurrencyRate.is_active == True).count()
        products_with_rub_prices = 0  # Заглушка, так как цены конвертируются динамически

        return {
            'total_products': total_products,
            'active_products': unique_products,
            'total_users': total_users,
            'active_users': active_users,
            'total_favorites': total_favorites,
            'products_by_region': products_by_region,
            'currency_rates_count': currency_rates_count,
            'products_with_rub_prices': total_products,
            'last_db_check': datetime.now()
        }

    @staticmethod
    def get_users_with_stats(db: Session, limit: int = 50) -> List[dict]:
        """Получить пользователей со статистикой"""
        users_query = db.query(User).order_by(User.created_at.desc()).limit(limit)
        users = []

        for user in users_query:
            favorites_count = db.query(UserFavoriteProduct).filter(
                UserFavoriteProduct.user_id == user.id
            ).count()

            user_data = {
                'id': user.id,
                'telegram_id': user.telegram_id,
                'username': user.username,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'full_name': user.full_name,
                'is_active': user.is_active,
                'created_at': user.created_at,
                'favorites_count': favorites_count,
                'has_psn_credentials': user.has_psn_credentials
            }
            users.append(user_data)

        return users

# Создаем экземпляры для использования
user_crud = UserCRUD()
product_crud = ProductCRUD()
favorite_crud = FavoriteCRUD()
currency_rate_crud = CurrencyRateCRUD()
admin_crud = AdminCRUD()
