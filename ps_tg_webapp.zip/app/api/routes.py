from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session
from typing import List, Optional
import logging
from datetime import datetime
from app.database.connection import get_db
from app.api.schemas import (
    User, UserCreate, UserUpdate, UserWithFavorites,
    Product, ProductListResponse, ProductFilter, PaginationParams,
    Favorite, FavoriteCreate, RegionEnum, RegionSettings,
    PSNCredentials, PSNCredentialsResponse
)
from app.api.crud import user_crud, product_crud, favorite_crud
from app.api.payment import payment_api, PaymentAPIError
from app.utils.network_check import diagnose_payment_site_issues

logger = logging.getLogger(__name__)

router = APIRouter()

# Роуты для пользователей
@router.post("/users/", response_model=User, tags=["Users"], summary="Создать пользователя")
async def create_user(request: Request, user_data: UserCreate, db: Session = Depends(get_db)):
    """Создать нового пользователя или получить существующего"""
    user, created = user_crud.get_or_create(db, user_data)
    return user

@router.get("/users/{telegram_id}", response_model=UserWithFavorites, tags=["Users"], summary="Получить пользователя")
async def get_user(request: Request, telegram_id: int, db: Session = Depends(get_db)):
    """Получить пользователя по Telegram ID"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    return user

@router.put("/users/{telegram_id}", response_model=User, tags=["Users"], summary="Обновить пользователя")
async def update_user(
    telegram_id: int,
    update_data: UserUpdate,
    db: Session = Depends(get_db)
):
    """Обновить данные пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    return user_crud.update(db, user, update_data)

@router.put("/users/{telegram_id}/region-settings", response_model=User, tags=["Users"], summary="Обновить настройки регионов")
async def update_region_settings(
    telegram_id: int,
    region_settings: RegionSettings,
    db: Session = Depends(get_db)
):
    """Обновить настройки отображения региональных цен"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    update_data = UserUpdate(
        show_ukraine_prices=region_settings.show_ukraine_prices,
        show_turkey_prices=region_settings.show_turkey_prices,
        show_india_prices=region_settings.show_india_prices
    )

    return user_crud.update(db, user, update_data)

@router.get("/users/{telegram_id}/region-settings", response_model=RegionSettings, tags=["Users"], summary="Получить настройки регионов")
async def get_region_settings(telegram_id: int, db: Session = Depends(get_db)):
    """Получить настройки региональных цен пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    return RegionSettings(
        show_ukraine_prices=user.show_ukraine_prices,
        show_turkey_prices=user.show_turkey_prices,
        show_india_prices=user.show_india_prices
    )

@router.put("/users/{telegram_id}/psn-credentials", response_model=dict, tags=["Users"], summary="Обновить PSN данные")
async def update_psn_credentials(
    telegram_id: int,
    psn_data: PSNCredentials,
    db: Session = Depends(get_db)
):
    """Обновить PSN данные пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    # Обновляем данные
    if psn_data.platform is not None:
        user.platform = psn_data.platform.value
    if psn_data.psn_email is not None:
        user.psn_email = psn_data.psn_email
    if psn_data.psn_password is not None:
        user.set_psn_password(psn_data.psn_password)

    db.commit()
    db.refresh(user)

    return {"message": "PSN данные обновлены успешно"}

@router.get("/users/{telegram_id}/psn-credentials", response_model=PSNCredentialsResponse, tags=["Users"], summary="Получить PSN данные")
async def get_psn_credentials(telegram_id: int, db: Session = Depends(get_db)):
    """Получить PSN данные пользователя (без пароля)"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    return PSNCredentialsResponse(
        platform=user.platform,
        psn_email=user.psn_email,
        has_password=bool(user.psn_password_hash)
    )

# Роуты для товаров
@router.get("/products/", tags=["Products"], summary="Список товаров")
async def get_products(
    page: int = Query(1, ge=1, description="Номер страницы"),
    limit: int = Query(20, ge=1, le=100, description="Количество элементов на странице"),
    category: Optional[str] = Query(None, description="Фильтр по категории"),
    region: Optional[str] = Query(None, description="Фильтр по региону (UA, TR, IN)"),
    search: Optional[str] = Query(None, description="Поиск по названию, описанию, издателю"),
    min_price: Optional[float] = Query(None, ge=0, description="Минимальная цена в рублях"),
    max_price: Optional[float] = Query(None, ge=0, description="Максимальная цена в рублях"),
    has_discount: Optional[bool] = Query(None, description="Только товары со скидкой"),
    has_ps_plus: Optional[bool] = Query(None, description="Доступно в PS Plus"),
    has_ea_access: Optional[bool] = Query(None, description="Доступно в EA Access"),
    platform: Optional[str] = Query(None, description="Фильтр по платформе (PS4, PS5, BOTH)"),
    players: Optional[str] = Query(None, description="Фильтр по количеству игроков"),
    telegram_id: Optional[int] = Query(None, description="ID пользователя для настроек отображения"),
    grouped: bool = Query(True, description="Группировать товары с ценами из всех регионов"),
    db: Session = Depends(get_db)
):
    """Получить список товаров с фильтрацией и пагинацией"""
    # Нормализуем регион: en-tr -> TR, en-in -> IN, en-ua -> UA
    region_normalize_map = {
        'en-ua': 'UA',
        'en-tr': 'TR',
        'en-in': 'IN',
        'ua': 'UA',
        'tr': 'TR',
        'in': 'IN',
        'uah': 'UA',
        'try': 'TR',
        'inr': 'IN'
    }
    normalized_region = region_normalize_map.get(region.lower(), region.upper()) if region else None

    filters = ProductFilter(
        category=category,
        region=normalized_region,
        search=search,
        min_price=min_price,
        max_price=max_price,
        has_discount=has_discount,
        has_ps_plus=has_ps_plus,
        has_ea_access=has_ea_access,
        platform=platform,
        players=players
    )
    pagination = PaginationParams(page=page, limit=limit)

    # Получаем пользователя если указан telegram_id
    user = None
    if telegram_id:
        user = user_crud.get_by_telegram_id(db, telegram_id)

    # Используем новый метод группировки с мультирегиональными ценами
    if grouped:
        products_with_prices, total = product_crud.get_products_grouped_by_name(
            db, filters, pagination, user
        )
    else:
        # Старый метод для совместимости
        products, total = product_crud.get_list(db, filters, pagination, user)
        products_with_prices = []
        for product in products:
            product_dict = product_crud.prepare_product_with_prices(product, db)
            products_with_prices.append(product_dict)

    return {
        "products": products_with_prices,
        "total": total,
        "page": page,
        "limit": limit,
        "has_next": (page * limit) < total
    }

@router.get("/products/{product_id}", response_model=dict, tags=["Products"], summary="Получить товар")
async def get_product(
    product_id: str,
    region: Optional[str] = Query(None, description="Регион товара"),
    telegram_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """Получить товар по ID"""
    # Нормализуем регион
    region_normalize_map = {
        'en-ua': 'UA',
        'en-tr': 'TR',
        'en-in': 'IN',
        'ua': 'UA',
        'tr': 'TR',
        'in': 'IN',
        'uah': 'UA',
        'try': 'TR',
        'inr': 'IN'
    }
    normalized_region = region_normalize_map.get(region.lower(), region.upper()) if region else None

    # ЛОГИРОВАНИЕ
    logger.info(f"🔍 get_product called:")
    logger.info(f"   product_id: {product_id}")
    logger.info(f"   region (original): {region}")
    logger.info(f"   normalized_region: {normalized_region}")

    product_orm = product_crud.get_by_id(db, product_id, normalized_region)
    if not product_orm:
        raise HTTPException(status_code=404, detail="Товар не найден")

    logger.info(f"✅ Found product: region={product_orm.region}, localization={product_orm.localization}")

    # Получаем пользователя если указан telegram_id
    user = None
    if telegram_id:
        user = user_crud.get_by_telegram_id(db, telegram_id)

    # На детальной странице показываем цены из всех регионов для сравнения
    return product_crud.prepare_product_with_all_regions(product_orm, db, user)

@router.get("/products/categories/list", response_model=List[str], tags=["Products"], summary="Список категорий")
async def get_categories(db: Session = Depends(get_db)):
    """Получить список всех категорий товаров"""
    return product_crud.get_categories(db)

@router.get("/products/regions/list", response_model=List[str], tags=["Products"], summary="Список регионов")
async def get_regions(db: Session = Depends(get_db)):
    """Получить список всех доступных регионов"""
    return product_crud.get_regions(db)

# Роуты для избранного
@router.post("/users/{telegram_id}/favorites/", response_model=dict, tags=["Favorites"], summary="Добавить в избранное")
async def add_to_favorites(
    telegram_id: int,
    favorite_data: FavoriteCreate,
    db: Session = Depends(get_db)
):
    """Добавить товар в избранное пользователя"""
    logger.info(f"⭐ Adding to favorites - telegram_id: {telegram_id}, product_id: {favorite_data.product_id}")
    logger.info(f"⭐ favorite_data type: {type(favorite_data)}, product_id type: {type(favorite_data.product_id)}")

    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        logger.error(f"❌ User not found: {telegram_id}")
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    logger.info(f"✅ User found: {user.id}, preferred_region: {user.preferred_region}")

    # Сначала пробуем найти товар без региона (любой регион)
    products = product_crud.get_by_id_all_regions(db, favorite_data.product_id)
    logger.info(f"🔍 Found {len(products)} products with id {favorite_data.product_id} across all regions")

    if not products:
        logger.error(f"❌ Product not found in any region: {favorite_data.product_id}")
        raise HTTPException(status_code=404, detail="Товар не найден")

    # Используем регион из запроса или первый найденный товар
    region = favorite_data.region
    product = None

    if region:
        # Ищем товар в указанном регионе
        product = next((p for p in products if p.region == region), None)
        if product:
            logger.info(f"✅ Using product from specified region: {product.region}, name: {product.name}")

    if not product:
        # Если регион не указан или не найден, используем первый
        product = products[0]
        region = product.region
        logger.info(f"✅ Using product from fallback region: {product.region}, name: {product.name}")

    favorite = favorite_crud.add_to_favorites(db, user.id, favorite_data.product_id, region)
    logger.info(f"✅ Favorite added successfully: {favorite.id}, region: {favorite.region}")
    return {"message": "Товар добавлен в избранное", "favorite_id": favorite.id}

@router.delete("/users/{telegram_id}/favorites/{product_id}", response_model=dict, tags=["Favorites"], summary="Удалить из избранного")
async def remove_from_favorites(
    telegram_id: int,
    product_id: str,
    db: Session = Depends(get_db)
):
    """Удалить товар из избранного пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    success = favorite_crud.remove_from_favorites(db, user.id, product_id)
    if not success:
        raise HTTPException(status_code=404, detail="Товар не найден в избранном")

    return {"message": "Товар удален из избранного"}

@router.get("/users/{telegram_id}/favorites/", response_model=List[dict], tags=["Favorites"], summary="Список избранного")
async def get_user_favorites(telegram_id: int, db: Session = Depends(get_db)):
    """Получить все избранные товары пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    favorites = favorite_crud.get_user_favorites(db, user.id)

    # Обрабатываем каждый избранный товар
    processed_favorites = []
    for favorite in favorites:
        # Получаем товар в том регионе, в котором он был добавлен в избранное
        product_to_show = favorite.product

        # Если сохранен регион, попробуем найти товар именно в этом регионе
        if favorite.region:
            regional_product = product_crud.get_by_id(db, favorite.product_id, favorite.region)
            if regional_product:
                product_to_show = regional_product
                logger.info(f"✅ Showing favorite in saved region: {favorite.region}")
            else:
                logger.warning(f"⚠️ Saved region {favorite.region} not found for product {favorite.product_id}, using default")

        # В избранном показываем цены из всех регионов для сравнения
        product_dict = product_crud.prepare_product_with_all_regions(product_to_show, db, user)

        favorite_dict = {
            'id': favorite.id,
            'user_id': favorite.user_id,
            'product_id': favorite.product_id,
            'region': favorite.region,  # Добавляем сохраненный регион
            'created_at': favorite.created_at,
            'product': product_dict
        }
        processed_favorites.append(favorite_dict)

    return processed_favorites

@router.get("/users/{telegram_id}/favorites/{product_id}/check", response_model=dict, tags=["Favorites"], summary="Проверить избранное")
async def check_favorite(
    telegram_id: int,
    product_id: str,
    db: Session = Depends(get_db)
):
    """Проверить, находится ли товар в избранном у пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    is_favorite = favorite_crud.is_favorite(db, user.id, product_id)
    return {"is_favorite": is_favorite}

# Роуты для оплаты
@router.post("/users/{telegram_id}/products/{product_id}/payment-url", response_model=dict, tags=["Payment"], summary="Генерация ссылки оплаты")
async def generate_payment_url(
    telegram_id: int,
    product_id: str,
    region: Optional[str] = Query(None, description="Регион товара"),
    use_ps_plus: bool = Query(False, description="Использовать цену PS Plus"),
    db: Session = Depends(get_db)
):
    """
    Генерировать ссылку для оплаты товара через plati.market

    Требует настроенные PSN данные пользователя (платформа, email, пароль)

    NOTE: Функционал временно работает на основе цен из выбранного региона
    """
    # Получаем пользователя
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    # Проверяем наличие PSN данных
    if not user.has_psn_credentials:
        raise HTTPException(
            status_code=400,
            detail="PSN данные не настроены. Необходимо указать платформу, email и пароль в профиле"
        )

    # Нормализуем регион
    region_normalize_map = {
        'en-ua': 'UA',
        'en-tr': 'TR',
        'en-in': 'IN',
        'ua': 'UA',
        'tr': 'TR',
        'in': 'IN',
        'uah': 'UA',
        'try': 'TR',
        'inr': 'IN'
    }
    normalized_region = region_normalize_map.get(region.lower(), region.upper()) if region else None

    # Проверяем что регион указан
    if not normalized_region:
        raise HTTPException(status_code=400, detail="Необходимо указать регион")

    # Получаем товар С ФИЛЬТРАЦИЕЙ ПО РЕГИОНУ (теперь каждый регион - отдельная строка)
    product = product_crud.get_by_id(db, product_id, region=normalized_region)
    if not product:
        raise HTTPException(status_code=404, detail=f"Товар не найден в регионе {normalized_region}")

    # Получаем цену с учетом PS Plus
    region_price_map = {
        'TR': ('price_try', 'ps_plus_price_try'),
        'UA': ('price_uah', 'ps_plus_price_uah'),
        'IN': ('price_inr', 'ps_plus_price_inr')
    }

    price_field, ps_plus_field = region_price_map.get(normalized_region, (None, None))

    current_price = None
    if price_field:
        # Если включен PS Plus и есть PS Plus цена - используем её
        if use_ps_plus and ps_plus_field:
            ps_plus_price = getattr(product, ps_plus_field, None)
            if ps_plus_price and ps_plus_price > 0:
                current_price = ps_plus_price

        # Если PS Plus цена не найдена или не включена - используем обычную
        if not current_price:
            current_price = getattr(product, price_field, None)

    # Проверяем наличие цены
    if not current_price or current_price <= 0:
        raise HTTPException(
            status_code=400,
            detail=f"Для данного товара не установлена цена в регионе {region}"
        )

    # Получаем данные для API
    game_name = product.get_display_name()
    platform = user.platform
    psn_email = user.psn_email
    psn_password = user.get_psn_password()
    region_info = product.get_region_info()

    if not platform or not psn_email:
        raise HTTPException(
            status_code=400,
            detail="Неполные PSN данные. Проверьте настройки профиля"
        )

    # Конвертируем цену в рубли для payment API
    from app.models.currency_rate import CurrencyRate
    currency_code = region_info['code']
    rate = CurrencyRate.get_rate_for_price(db, currency_code, current_price)
    price_rub = round(current_price * rate, 2)

    try:
        # Логируем запрос на генерацию ссылки
        price_type = "PS Plus" if use_ps_plus else "Regular"
        logger.info(f"🛒 Payment request: user={telegram_id}, product='{game_name}' ({product_id}), price={current_price} {currency_code} ({price_type}) = {price_rub} RUB, region={product.region}, platform={platform}")

        # Генерируем ссылку оплаты
        # Для турецкого региона передаем цену в лирах для правильного курса
        is_turkey = product.region == 'TR'
        payment_url = await payment_api.get_payment_url(
            platform=platform,
            game=game_name,
            email=psn_email,
            password=psn_password,
            price=price_rub,
            trl_price=current_price if is_turkey else None,
            twofa_code=""
        )

        logger.info(f"✅ Payment URL generated for user {telegram_id}, product {product_id}")

        return {
            "payment_url": payment_url,
            "product_name": game_name,
            "platform": platform,
            "psn_email": psn_email,
            "price": current_price,
            "price_rub": price_rub,
            "currency": region_info['code'],
            "region": product.region
        }

    except PaymentAPIError as e:
        logger.error(f"Payment API error for user {telegram_id}, product {product_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Ошибка генерации ссылки оплаты: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error generating payment URL: {str(e)}")
        raise HTTPException(status_code=500, detail="Произошла неожиданная ошибка")

@router.get("/payment/diagnose", response_model=dict, tags=["Payment"], summary="Диагностика проблем с оплатой")
async def diagnose_payment_issues():
    """
    Проводит диагностику доступности сайта оплаты и возвращает рекомендации
    по решению возможных проблем
    """
    try:
        diagnosis = await diagnose_payment_site_issues()
        return {
            "status": "success",
            "diagnosis": diagnosis,
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Error during payment site diagnosis: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "diagnosis": {
                "issues_found": ["Ошибка проведения диагностики"],
                "recommendations": ["Обратитесь к администратору"]
            },
            "timestamp": datetime.utcnow().isoformat()
        }
