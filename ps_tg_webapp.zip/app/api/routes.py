from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session
from typing import List, Optional
import logging
from datetime import datetime
from app.database.connection import get_db
from app.api.schemas import (
    User, UserCreate, UserUpdate, UserWithFavorites,
    Product, ProductListResponse, ProductFilter, PaginationParams,
    Favorite, FavoriteCreate, RegionEnum, RegionSettings,
    PSNCredentials, PSNCredentialsResponse
)
from app.api.crud import user_crud, product_crud, favorite_crud
from app.api.payment import payment_api, PaymentAPIError
from app.utils.network_check import diagnose_payment_site_issues

logger = logging.getLogger(__name__)

router = APIRouter()

# Роуты для пользователей
@router.post("/users/", response_model=User, tags=["Users"], summary="Создать пользователя")
async def create_user(request: Request, user_data: UserCreate, db: Session = Depends(get_db)):
    """Создать нового пользователя или получить существующего"""
    user, created = user_crud.get_or_create(db, user_data)
    return user

@router.get("/users/{telegram_id}", response_model=UserWithFavorites, tags=["Users"], summary="Получить пользователя")
async def get_user(request: Request, telegram_id: int, db: Session = Depends(get_db)):
    """Получить пользователя по Telegram ID"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    return user

@router.put("/users/{telegram_id}", response_model=User, tags=["Users"], summary="Обновить пользователя")
async def update_user(
    telegram_id: int,
    update_data: UserUpdate,
    db: Session = Depends(get_db)
):
    """Обновить данные пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    return user_crud.update(db, user, update_data)

@router.put("/users/{telegram_id}/region-settings", response_model=User, tags=["Users"], summary="Обновить настройки регионов")
async def update_region_settings(
    telegram_id: int,
    region_settings: RegionSettings,
    db: Session = Depends(get_db)
):
    """Обновить настройки отображения региональных цен"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    update_data = UserUpdate(
        show_ukraine_prices=region_settings.show_ukraine_prices,
        show_turkey_prices=region_settings.show_turkey_prices,
        show_india_prices=region_settings.show_india_prices
    )

    return user_crud.update(db, user, update_data)

@router.get("/users/{telegram_id}/region-settings", response_model=RegionSettings, tags=["Users"], summary="Получить настройки регионов")
async def get_region_settings(telegram_id: int, db: Session = Depends(get_db)):
    """Получить настройки региональных цен пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    return RegionSettings(
        show_ukraine_prices=user.show_ukraine_prices,
        show_turkey_prices=user.show_turkey_prices,
        show_india_prices=user.show_india_prices
    )

@router.put("/users/{telegram_id}/psn-credentials", response_model=dict, tags=["Users"], summary="Обновить PSN данные")
async def update_psn_credentials(
    telegram_id: int,
    psn_data: PSNCredentials,
    db: Session = Depends(get_db)
):
    """Обновить PSN данные пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    # Обновляем данные
    if psn_data.platform is not None:
        user.platform = psn_data.platform.value
    if psn_data.psn_email is not None:
        user.psn_email = psn_data.psn_email
    if psn_data.psn_password is not None:
        user.set_psn_password(psn_data.psn_password)

    db.commit()
    db.refresh(user)

    return {"message": "PSN данные обновлены успешно"}

@router.get("/users/{telegram_id}/psn-credentials", response_model=PSNCredentialsResponse, tags=["Users"], summary="Получить PSN данные")
async def get_psn_credentials(telegram_id: int, db: Session = Depends(get_db)):
    """Получить PSN данные пользователя (без пароля)"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    return PSNCredentialsResponse(
        platform=user.platform,
        psn_email=user.psn_email,
        has_password=bool(user.psn_password_hash)
    )

# Роуты для товаров
@router.get("/products/", tags=["Products"], summary="Список товаров")
async def get_products(
    page: int = Query(1, ge=1, description="Номер страницы"),
    limit: int = Query(20, ge=1, le=100, description="Количество элементов на странице"),
    category: Optional[str] = Query(None, description="Фильтр по категории"),
    region: Optional[str] = Query(None, description="Фильтр по региону (en-ua, en-tr, en-in)"),
    search: Optional[str] = Query(None, description="Поиск по названию, описанию, издателю"),
    min_price: Optional[float] = Query(None, ge=0, description="Минимальная цена в рублях"),
    max_price: Optional[float] = Query(None, ge=0, description="Максимальная цена в рублях"),
    has_discount: Optional[bool] = Query(None, description="Только товары со скидкой"),
    has_ps_plus: Optional[bool] = Query(None, description="Доступно в PS Plus"),
    has_ea_access: Optional[bool] = Query(None, description="Доступно в EA Access"),
    telegram_id: Optional[int] = Query(None, description="ID пользователя для настроек отображения"),
    grouped: bool = Query(True, description="Группировать товары с ценами из всех регионов"),
    db: Session = Depends(get_db)
):
    """Получить список товаров с фильтрацией и пагинацией"""
    filters = ProductFilter(
        category=category,
        region=region,
        search=search,
        min_price=min_price,
        max_price=max_price,
        has_discount=has_discount,
        has_ps_plus=has_ps_plus,
        has_ea_access=has_ea_access
    )
    pagination = PaginationParams(page=page, limit=limit)

    # Получаем пользователя если указан telegram_id
    user = None
    if telegram_id:
        user = user_crud.get_by_telegram_id(db, telegram_id)

    # Используем новый метод группировки с мультирегиональными ценами
    if grouped:
        products_with_prices, total = product_crud.get_products_grouped_by_name(
            db, filters, pagination, user
        )
    else:
        # Старый метод для совместимости
        products, total = product_crud.get_list(db, filters, pagination, user)
        products_with_prices = []
        for product in products:
            product_dict = product_crud.prepare_product_with_prices(product, db)
            products_with_prices.append(product_dict)

    return {
        "products": products_with_prices,
        "total": total,
        "page": page,
        "limit": limit,
        "has_next": (page * limit) < total
    }

@router.get("/products/{product_id}", response_model=dict, tags=["Products"], summary="Получить товар")
async def get_product(
    product_id: str,
    region: Optional[str] = Query(None, description="Регион товара"),
    telegram_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """Получить товар по ID и региону"""
    product_orm = product_crud.get_by_id(db, product_id, region)
    if not product_orm:
        raise HTTPException(status_code=404, detail="Товар не найден")

    return product_crud.prepare_product_with_prices(product_orm, db)

@router.get("/products/categories/list", response_model=List[str], tags=["Products"], summary="Список категорий")
async def get_categories(db: Session = Depends(get_db)):
    """Получить список всех категорий товаров"""
    return product_crud.get_categories(db)

@router.get("/products/regions/list", response_model=List[str], tags=["Products"], summary="Список регионов")
async def get_regions(db: Session = Depends(get_db)):
    """Получить список всех доступных регионов"""
    return product_crud.get_regions(db)

# Роуты для избранного
@router.post("/users/{telegram_id}/favorites/", response_model=dict, tags=["Favorites"], summary="Добавить в избранное")
async def add_to_favorites(
    telegram_id: int,
    favorite_data: FavoriteCreate,
    db: Session = Depends(get_db)
):
    """Добавить товар в избранное пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    product = product_crud.get_by_id(db, favorite_data.product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Товар не найден")

    favorite = favorite_crud.add_to_favorites(db, user.id, favorite_data.product_id)
    return {"message": "Товар добавлен в избранное", "favorite_id": favorite.id}

@router.delete("/users/{telegram_id}/favorites/{product_id}", response_model=dict, tags=["Favorites"], summary="Удалить из избранного")
async def remove_from_favorites(
    telegram_id: int,
    product_id: str,
    db: Session = Depends(get_db)
):
    """Удалить товар из избранного пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    success = favorite_crud.remove_from_favorites(db, user.id, product_id)
    if not success:
        raise HTTPException(status_code=404, detail="Товар не найден в избранном")

    return {"message": "Товар удален из избранного"}

@router.get("/users/{telegram_id}/favorites/", response_model=List[dict], tags=["Favorites"], summary="Список избранного")
async def get_user_favorites(telegram_id: int, db: Session = Depends(get_db)):
    """Получить все избранные товары пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    favorites = favorite_crud.get_user_favorites(db, user.id)

    # Обрабатываем каждый избранный товар
    processed_favorites = []
    for favorite in favorites:
        product_dict = product_crud.prepare_product_with_prices(favorite.product)

        favorite_dict = {
            'id': favorite.id,
            'user_id': favorite.user_id,
            'product_id': favorite.product_id,
            'created_at': favorite.created_at,
            'product': product_dict
        }
        processed_favorites.append(favorite_dict)

    return processed_favorites

@router.get("/users/{telegram_id}/favorites/{product_id}/check", response_model=dict, tags=["Favorites"], summary="Проверить избранное")
async def check_favorite(
    telegram_id: int,
    product_id: str,
    db: Session = Depends(get_db)
):
    """Проверить, находится ли товар в избранном у пользователя"""
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    is_favorite = favorite_crud.is_favorite(db, user.id, product_id)
    return {"is_favorite": is_favorite}

# Роуты для оплаты
@router.post("/users/{telegram_id}/products/{product_id}/payment-url", response_model=dict, tags=["Payment"], summary="Генерация ссылки оплаты")
async def generate_payment_url(
    telegram_id: int,
    product_id: str,
    region: Optional[str] = Query(None, description="Регион товара"),
    db: Session = Depends(get_db)
):
    """
    Генерировать ссылку для оплаты товара через plati.market

    Требует настроенные PSN данные пользователя (платформа, email, пароль)

    NOTE: Функционал временно работает на основе цен из выбранного региона
    """
    # Получаем пользователя
    user = user_crud.get_by_telegram_id(db, telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    # Проверяем наличие PSN данных
    if not user.has_psn_credentials:
        raise HTTPException(
            status_code=400,
            detail="PSN данные не настроены. Необходимо указать платформу, email и пароль в профиле"
        )

    # Получаем товар
    product = product_crud.get_by_id(db, product_id, region)
    if not product:
        raise HTTPException(status_code=404, detail="Товар не найден")

    # Проверяем наличие цены
    current_price = product.get_current_price()
    if not current_price or current_price <= 0:
        raise HTTPException(
            status_code=400,
            detail="Для данного товара не установлена цена"
        )

    # Получаем данные для API
    game_name = product.get_display_name()
    platform = user.platform
    psn_email = user.psn_email
    psn_password = user.get_psn_password()
    region_info = product.get_region_info()

    if not platform or not psn_email:
        raise HTTPException(
            status_code=400,
            detail="Неполные PSN данные. Проверьте настройки профиля"
        )

    try:
        # Логируем запрос на генерацию ссылки
        logger.info(f"🛒 Payment request: user={telegram_id}, product='{game_name}' ({product_id}), price={current_price} {region_info['code']}, region={product.region}, platform={platform}")

        # Генерируем ссылку оплаты
        payment_url = await payment_api.get_payment_url(
            platform=platform,
            game=game_name,
            email=psn_email,
            password=psn_password,
            price=current_price,
            trl_price=current_price if product.region == 'en-tr' else None,
            twofa_code=""
        )

        logger.info(f"✅ Payment URL generated for user {telegram_id}, product {product_id}")

        return {
            "payment_url": payment_url,
            "product_name": game_name,
            "platform": platform,
            "psn_email": psn_email,
            "price": current_price,
            "currency": region_info['code'],
            "region": product.region
        }

    except PaymentAPIError as e:
        logger.error(f"Payment API error for user {telegram_id}, product {product_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Ошибка генерации ссылки оплаты: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error generating payment URL: {str(e)}")
        raise HTTPException(status_code=500, detail="Произошла неожиданная ошибка")

@router.get("/payment/diagnose", response_model=dict, tags=["Payment"], summary="Диагностика проблем с оплатой")
async def diagnose_payment_issues():
    """
    Проводит диагностику доступности сайта оплаты и возвращает рекомендации
    по решению возможных проблем
    """
    try:
        diagnosis = await diagnose_payment_site_issues()
        return {
            "status": "success",
            "diagnosis": diagnosis,
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Error during payment site diagnosis: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "diagnosis": {
                "issues_found": ["Ошибка проведения диагностики"],
                "recommendations": ["Обратитесь к администратору"]
            },
            "timestamp": datetime.utcnow().isoformat()
        }
