#!/usr/bin/env python3
"""
Скрипт миграции для добавления поля payment_email в таблицу users.

Это поле используется для автозаполнения email на странице оплаты oplata.info
для всех регионов (Турция, Индия, Украина).

Запуск:
    python scripts/migrate_payment_email.py
"""

import sqlite3
import os
import sys

# Добавляем корневую директорию проекта в путь
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Путь к базе данных
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'scripts', 'products.db')

def check_column_exists(cursor, table_name, column_name):
    """Проверяет, существует ли колонка в таблице"""
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = cursor.fetchall()
    column_names = [col[1] for col in columns]
    return column_name in column_names

def migrate():
    """Выполняет миграцию базы данных"""
    print(f"📦 Миграция базы данных: {DB_PATH}")

    if not os.path.exists(DB_PATH):
        print(f"❌ База данных не найдена: {DB_PATH}")
        # Попробуем найти в другом месте
        alt_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'products.db')
        if os.path.exists(alt_path):
            print(f"✅ Найдена альтернативная база: {alt_path}")
            global DB_PATH
            DB_PATH = alt_path
        else:
            print("❌ База данных не найдена ни в одном из путей")
            return False

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    try:
        # Проверяем существование таблицы users
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        if not cursor.fetchone():
            print("❌ Таблица 'users' не найдена в базе данных")
            return False

        # Проверяем, существует ли уже колонка payment_email
        if check_column_exists(cursor, 'users', 'payment_email'):
            print("✅ Колонка 'payment_email' уже существует в таблице 'users'")
            return True

        # Добавляем колонку payment_email
        print("🔧 Добавляем колонку 'payment_email' в таблицу 'users'...")
        cursor.execute("""
            ALTER TABLE users
            ADD COLUMN payment_email VARCHAR(255) DEFAULT NULL
        """)

        conn.commit()
        print("✅ Колонка 'payment_email' успешно добавлена!")

        # Проверяем результат
        cursor.execute("PRAGMA table_info(users)")
        columns = cursor.fetchall()
        print("\n📋 Текущая структура таблицы 'users':")
        for col in columns:
            print(f"   - {col[1]} ({col[2]})")

        return True

    except sqlite3.Error as e:
        print(f"❌ Ошибка SQLite: {e}")
        conn.rollback()
        return False

    finally:
        conn.close()

def show_stats():
    """Показывает статистику по пользователям"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM users WHERE payment_email IS NOT NULL AND payment_email != ''")
        users_with_email = cursor.fetchone()[0]

        print(f"\n📊 Статистика:")
        print(f"   - Всего пользователей: {total_users}")
        print(f"   - С payment_email: {users_with_email}")

    except sqlite3.Error as e:
        print(f"⚠️ Не удалось получить статистику: {e}")

    finally:
        conn.close()

if __name__ == "__main__":
    print("=" * 50)
    print("🚀 Миграция: добавление payment_email")
    print("=" * 50)

    success = migrate()

    if success:
        show_stats()
        print("\n✅ Миграция завершена успешно!")
    else:
        print("\n❌ Миграция не выполнена")
        sys.exit(1)
