#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Добавление полей PS Plus цен в базу данных"""

import sys
import os
import io

# Настраиваем кодировку для Windows
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import create_engine, text
from config.settings import settings

def main():
    print("=" * 60)
    print("Migration: Adding PS Plus price fields")
    print("=" * 60)
    
    engine = create_engine(
        settings.DATABASE_URL,
        connect_args={"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {}
    )
    
    with engine.connect() as conn:
        # Проверяем текущие колонки
        result = conn.execute(text("PRAGMA table_info(products)"))
        columns = [row[1] for row in result.fetchall()]
        print(f"\nCurrent columns count: {len(columns)}")
        
        # Поля для добавления
        fields_to_add = [
            ('ps_plus_price_uah', 'REAL'),
            ('ps_plus_price_try', 'REAL'),
            ('ps_plus_price_inr', 'REAL')
        ]
        
        added_count = 0
        skipped_count = 0
        
        for field_name, field_type in fields_to_add:
            if field_name in columns:
                print(f"[SKIP] Field {field_name} already exists")
                skipped_count += 1
                continue
            
            try:
                sql = f"ALTER TABLE products ADD COLUMN {field_name} {field_type} DEFAULT NULL"
                conn.execute(text(sql))
                conn.commit()
                print(f"[OK] Added field: {field_name}")
                added_count += 1
            except Exception as e:
                error_msg = str(e).lower()
                if "duplicate" in error_msg or "already exists" in error_msg:
                    print(f"[SKIP] Field {field_name} already exists")
                    skipped_count += 1
                else:
                    print(f"[ERROR] Error adding {field_name}: {e}")
                    raise
        
        print(f"\n{'=' * 60}")
        print(f"Result: added {added_count}, skipped {skipped_count}")
        print(f"{'=' * 60}")
        
        # Финальная проверка
        result = conn.execute(text("PRAGMA table_info(products)"))
        columns = [row[1] for row in result.fetchall()]
        print(f"\nFinal columns count: {len(columns)}")
        
        all_present = all(field[0] in columns for field in fields_to_add)
        if all_present:
            print("[SUCCESS] All PS Plus price fields added successfully!")
        else:
            missing = [f[0] for f in fields_to_add if f[0] not in columns]
            print(f"[ERROR] Missing fields: {missing}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n[CRITICAL ERROR]: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

