#!/usr/bin/env python3
"""
Миграция базы данных для добавления полей PS Plus цен в таблицу products
"""

import sys
import os
from pathlib import Path

# Добавляем корневую директорию в путь
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from sqlalchemy import create_engine, text
from config.settings import settings
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def check_migration_needed():
    """Проверить, нужна ли миграция"""
    engine = create_engine(
        settings.DATABASE_URL,
        connect_args={"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {}
    )
    
    with engine.connect() as conn:
        try:
            # Проверяем наличие новых полей
            result = conn.execute(text("PRAGMA table_info(products)"))
            columns = [row[1] for row in result.fetchall()]
            
            needed_fields = ['ps_plus_price_uah', 'ps_plus_price_try', 'ps_plus_price_inr']
            missing_fields = [field for field in needed_fields if field not in columns]
            
            if missing_fields:
                logger.info(f"Необходимо добавить поля: {missing_fields}")
                return True
            else:
                logger.info("Все поля уже существуют в базе данных")
                return False
                
        except Exception as e:
            logger.error(f"Ошибка при проверке миграции: {e}")
            return True

def run_migration():
    """Выполнить миграцию базы данных"""
    engine = create_engine(
        settings.DATABASE_URL,
        connect_args={"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {}
    )
    
    with engine.connect() as conn:
        # Начинаем транзакцию
        trans = conn.begin()
        
        try:
            logger.info("🔄 Начинаем миграцию базы данных для добавления PS Plus цен...")
            
            # Проверяем текущие колонки
            result = conn.execute(text("PRAGMA table_info(products)"))
            columns = [row[1] for row in result.fetchall()]
            logger.info(f"📋 Текущие колонки в таблице products: {len(columns)}")
            
            # Добавляем поля для PS Plus цен
            migrations = [
                {
                    'name': 'ps_plus_price_uah',
                    'sql': 'ALTER TABLE products ADD COLUMN ps_plus_price_uah REAL DEFAULT NULL'
                },
                {
                    'name': 'ps_plus_price_try',
                    'sql': 'ALTER TABLE products ADD COLUMN ps_plus_price_try REAL DEFAULT NULL'
                },
                {
                    'name': 'ps_plus_price_inr',
                    'sql': 'ALTER TABLE products ADD COLUMN ps_plus_price_inr REAL DEFAULT NULL'
                }
            ]
            
            for migration in migrations:
                field_name = migration['name']
                migration_sql = migration['sql']
                
                # Проверяем, существует ли уже поле
                if field_name in columns:
                    logger.info(f"⚠️  Поле {field_name} уже существует, пропускаем")
                    continue
                
                try:
                    logger.info(f"📝 Добавляем поле: {field_name}")
                    conn.execute(text(migration_sql))
                    logger.info(f"✅ Поле {field_name} успешно добавлено")
                except Exception as e:
                    error_msg = str(e).lower()
                    if "duplicate column" in error_msg or "already exists" in error_msg:
                        logger.warning(f"⚠️  Поле {field_name} уже существует (пропускаем)")
                    else:
                        logger.error(f"❌ Ошибка при добавлении поля {field_name}: {e}")
                        raise
            
            # Коммитим транзакцию
            trans.commit()
            logger.info("✅ Миграция выполнена успешно!")
            
            # Проверяем результат
            result = conn.execute(text("PRAGMA table_info(products)"))
            columns = [row[1] for row in result.fetchall()]
            logger.info(f"📋 Всего колонок в таблице products: {len(columns)}")
            
            # Проверяем наличие новых полей
            new_fields = ['ps_plus_price_uah', 'ps_plus_price_try', 'ps_plus_price_inr']
            for field in new_fields:
                if field in columns:
                    logger.info(f"✅ Поле {field} присутствует в базе данных")
                else:
                    logger.warning(f"⚠️  Поле {field} отсутствует в базе данных")
            
        except Exception as e:
            # Откатываем транзакцию в случае ошибки
            trans.rollback()
            logger.error(f"❌ Ошибка при выполнении миграции: {e}")
            raise

def verify_migration():
    """Проверить успешность миграции"""
    logger.info("\n🔍 Проверяем миграцию...")
    
    try:
        engine = create_engine(
            settings.DATABASE_URL,
            connect_args={"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {}
        )
        
        with engine.connect() as conn:
            result = conn.execute(text("PRAGMA table_info(products)"))
            columns = [row[1] for row in result.fetchall()]
            
            required_fields = ['ps_plus_price_uah', 'ps_plus_price_try', 'ps_plus_price_inr']
            missing_fields = [field for field in required_fields if field not in columns]
            
            if missing_fields:
                logger.error(f"❌ Не все поля добавлены: {missing_fields}")
                return False
            else:
                logger.info("✅ Все поля успешно добавлены в базу данных")
                return True
                
    except Exception as e:
        logger.error(f"❌ Ошибка при проверке миграции: {e}")
        return False

if __name__ == "__main__":
    if check_migration_needed():
        logger.info("Миграция необходима, запускаем...")
        run_migration()
        verify_migration()
        logger.info("\n🎉 Миграция PS Plus цен завершена успешно!")
    else:
        logger.info("✅ Миграция не требуется, база данных уже обновлена.")



