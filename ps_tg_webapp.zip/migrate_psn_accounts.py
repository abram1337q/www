#!/usr/bin/env python3
"""
Скрипт миграции базы данных для добавления таблицы psn_accounts.
Позволяет хранить разные PSN данные для разных регионов (Турция, Украина).
Индию не трогаем - там используются карты пополнения.

Использование:
    python scripts/migrate_psn_accounts.py

Опции:
    --dry-run    Только показать SQL запросы, не выполнять
    --migrate-existing    Мигрировать существующие PSN данные из таблицы users
"""

import sys
import os
import argparse
import sqlite3
from pathlib import Path

# Добавляем путь к корню проекта
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))


def get_db_path():
    """Получить путь к базе данных"""
    # Пробуем найти products.db
    possible_paths = [
        project_root / "products.db",
        project_root / "product.db",
        Path("./products.db"),
        Path("./product.db"),
    ]

    for path in possible_paths:
        if path.exists():
            return str(path)

    # Если не нашли, возвращаем дефолтный путь
    return str(project_root / "products.db")


def table_exists(cursor, table_name: str) -> bool:
    """Проверить существует ли таблица"""
    cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table_name,)
    )
    return cursor.fetchone() is not None


def column_exists(cursor, table_name: str, column_name: str) -> bool:
    """Проверить существует ли колонка в таблице"""
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [row[1] for row in cursor.fetchall()]
    return column_name in columns


def create_psn_accounts_table(cursor, dry_run: bool = False):
    """Создать таблицу psn_accounts"""

    sql = """
    CREATE TABLE IF NOT EXISTS psn_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        region VARCHAR(10) NOT NULL,
        psn_email VARCHAR(255),
        psn_password_hash TEXT,
        psn_password_salt VARCHAR(32),
        platform VARCHAR(50),
        twofa_backup_code TEXT,
        twofa_backup_salt VARCHAR(32),
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE (user_id, region)
    );
    """

    print("=" * 60)
    print("СОЗДАНИЕ ТАБЛИЦЫ psn_accounts")
    print("=" * 60)
    print()
    print("SQL запрос:")
    print(sql)
    print()

    if dry_run:
        print("[DRY RUN] Таблица НЕ создана")
    else:
        cursor.execute(sql)
        print("[OK] Таблица psn_accounts создана успешно!")

    # Создаем индексы
    indexes = [
        "CREATE INDEX IF NOT EXISTS idx_psn_accounts_user_id ON psn_accounts(user_id);",
        "CREATE INDEX IF NOT EXISTS idx_psn_accounts_region ON psn_accounts(region);",
        "CREATE INDEX IF NOT EXISTS idx_psn_accounts_user_region ON psn_accounts(user_id, region);",
    ]

    print()
    print("Создание индексов:")
    for idx_sql in indexes:
        print(f"  {idx_sql}")
        if not dry_run:
            cursor.execute(idx_sql)

    if not dry_run:
        print("[OK] Индексы созданы успешно!")
    print()


def migrate_existing_psn_data(cursor, dry_run: bool = False):
    """
    Мигрировать существующие PSN данные из таблицы users в psn_accounts.
    Создает записи для всех регионов (UA, TR) с одинаковыми данными.
    """

    print("=" * 60)
    print("МИГРАЦИЯ СУЩЕСТВУЮЩИХ PSN ДАННЫХ")
    print("=" * 60)
    print()

    # Проверяем есть ли пользователи с PSN данными
    cursor.execute("""
        SELECT id, telegram_id, psn_email, psn_password_hash, psn_password_salt, platform
        FROM users
        WHERE psn_email IS NOT NULL AND psn_password_hash IS NOT NULL
    """)

    users_with_psn = cursor.fetchall()

    if not users_with_psn:
        print("Нет пользователей с существующими PSN данными для миграции.")
        print()
        return

    print(f"Найдено {len(users_with_psn)} пользователей с PSN данными")
    print()

    # Регионы для миграции (Индию не трогаем!)
    regions = ['UA', 'TR']

    migrated_count = 0
    skipped_count = 0

    for user in users_with_psn:
        user_id, telegram_id, psn_email, psn_password_hash, psn_password_salt, platform = user

        print(f"Пользователь ID={user_id} (Telegram: {telegram_id})")
        print(f"  Email: {psn_email}")
        print(f"  Platform: {platform}")

        for region in regions:
            # Проверяем нет ли уже записи для этого региона
            cursor.execute(
                "SELECT id FROM psn_accounts WHERE user_id = ? AND region = ?",
                (user_id, region)
            )
            existing = cursor.fetchone()

            if existing:
                print(f"  [{region}] Уже существует, пропускаем")
                skipped_count += 1
                continue

            insert_sql = """
                INSERT INTO psn_accounts
                (user_id, region, psn_email, psn_password_hash, psn_password_salt, platform, is_active)
                VALUES (?, ?, ?, ?, ?, ?, 1)
            """

            if dry_run:
                print(f"  [{region}] [DRY RUN] Будет создана запись")
            else:
                cursor.execute(insert_sql, (
                    user_id, region, psn_email, psn_password_hash, psn_password_salt, platform
                ))
                print(f"  [{region}] Создана запись")
                migrated_count += 1

        print()

    print(f"Итого: создано {migrated_count} записей, пропущено {skipped_count}")
    print()


def show_current_state(cursor):
    """Показать текущее состояние таблицы psn_accounts"""

    print("=" * 60)
    print("ТЕКУЩЕЕ СОСТОЯНИЕ ТАБЛИЦЫ psn_accounts")
    print("=" * 60)
    print()

    if not table_exists(cursor, 'psn_accounts'):
        print("Таблица psn_accounts НЕ существует!")
        print()
        return

    cursor.execute("SELECT COUNT(*) FROM psn_accounts")
    total = cursor.fetchone()[0]

    print(f"Всего записей: {total}")
    print()

    if total > 0:
        cursor.execute("""
            SELECT pa.id, pa.user_id, u.telegram_id, pa.region, pa.psn_email, pa.platform, pa.is_active
            FROM psn_accounts pa
            LEFT JOIN users u ON pa.user_id = u.id
            ORDER BY pa.user_id, pa.region
        """)

        rows = cursor.fetchall()

        print(f"{'ID':<5} {'User ID':<8} {'Telegram':<12} {'Region':<8} {'Email':<30} {'Platform':<10} {'Active':<6}")
        print("-" * 85)

        for row in rows:
            id_, user_id, telegram_id, region, email, platform, is_active = row
            email_short = email[:27] + "..." if email and len(email) > 30 else (email or "")
            print(f"{id_:<5} {user_id:<8} {telegram_id or '':<12} {region:<8} {email_short:<30} {platform or '':<10} {is_active:<6}")

    print()

    # Статистика по регионам
    cursor.execute("""
        SELECT region, COUNT(*) as cnt
        FROM psn_accounts
        WHERE is_active = 1
        GROUP BY region
    """)

    region_stats = cursor.fetchall()

    if region_stats:
        print("Статистика по регионам (активные):")
        for region, cnt in region_stats:
            print(f"  {region}: {cnt} аккаунтов")

    print()


def main():
    parser = argparse.ArgumentParser(
        description="Миграция БД: добавление таблицы psn_accounts для региональных PSN данных"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Только показать SQL запросы, не выполнять"
    )
    parser.add_argument(
        "--migrate-existing",
        action="store_true",
        help="Мигрировать существующие PSN данные из таблицы users"
    )
    parser.add_argument(
        "--show-state",
        action="store_true",
        help="Показать текущее состояние таблицы psn_accounts"
    )
    parser.add_argument(
        "--db-path",
        type=str,
        default=None,
        help="Путь к файлу базы данных SQLite"
    )

    args = parser.parse_args()

    # Определяем путь к БД
    db_path = args.db_path or get_db_path()

    print()
    print("=" * 60)
    print("МИГРАЦИЯ БАЗЫ ДАННЫХ: PSN ACCOUNTS")
    print("=" * 60)
    print()
    print(f"База данных: {db_path}")
    print(f"Dry run: {'Да' if args.dry_run else 'Нет'}")
    print()

    if not os.path.exists(db_path):
        print(f"ОШИБКА: Файл базы данных не найден: {db_path}")
        print("Укажите путь через --db-path")
        sys.exit(1)

    # Подключаемся к БД
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        # Проверяем существует ли таблица users
        if not table_exists(cursor, 'users'):
            print("ОШИБКА: Таблица 'users' не найдена в базе данных!")
            sys.exit(1)

        # Показываем текущее состояние если запрошено
        if args.show_state:
            show_current_state(cursor)
            return

        # Создаем таблицу psn_accounts если не существует
        if not table_exists(cursor, 'psn_accounts'):
            create_psn_accounts_table(cursor, args.dry_run)
        else:
            print("Таблица psn_accounts уже существует.")
            print()

        # Мигрируем существующие данные если запрошено
        if args.migrate_existing:
            migrate_existing_psn_data(cursor, args.dry_run)

        # Показываем итоговое состояние
        if not args.dry_run:
            show_current_state(cursor)

        # Коммитим изменения
        if not args.dry_run:
            conn.commit()
            print("[OK] Все изменения сохранены в базу данных")
        else:
            print("[DRY RUN] Изменения НЕ сохранены")

    except Exception as e:
        print(f"ОШИБКА: {e}")
        conn.rollback()
        sys.exit(1)
    finally:
        conn.close()

    print()
    print("=" * 60)
    print("МИГРАЦИЯ ЗАВЕРШЕНА")
    print("=" * 60)
    print()


if __name__ == "__main__":
    main()
