// Hero секция с анимированным водным фоном и таймером
"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import type { SiteData } from "@/lib/data"

interface HeroProps {
  data: SiteData
}

// Компонент таймера обратного отсчёта
function CountdownTimer({ targetDate }: { targetDate: string }) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  })

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = new Date(targetDate).getTime() - new Date().getTime()

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60)
        })
      }
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)
    return () => clearInterval(timer)
  }, [targetDate])

  const timeBlocks = [
    { value: timeLeft.days, label: "дней" },
    { value: timeLeft.hours, label: "часов" },
    { value: timeLeft.minutes, label: "минут" },
    { value: timeLeft.seconds, label: "секунд" }
  ]

  return (
    <div className="flex flex-wrap justify-center gap-2 sm:gap-3 md:gap-4">
      {timeBlocks.map((block, index) => (
        <div
          key={block.label}
          className="flex flex-col items-center"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <div className="relative group">
            {/* Свечение за блоком */}
            <div className="absolute inset-0 bg-gradient-to-b from-cyan-400/30 to-teal-400/30 rounded-xl sm:rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-500" />

            {/* Блок с числом */}
            <div className="relative w-14 h-14 sm:w-18 sm:h-18 md:w-20 md:h-20 lg:w-24 lg:h-24 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl sm:rounded-2xl flex items-center justify-center overflow-hidden">
              {/* Анимированные волны внутри */}
              <div className="absolute inset-0 opacity-30">
                <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-cyan-500/50 to-transparent animate-pulse" />
              </div>

              <span className="relative text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white tabular-nums">
                {String(block.value).padStart(2, "0")}
              </span>
            </div>
          </div>
          <span className="mt-1.5 sm:mt-2 text-[10px] sm:text-xs text-cyan-100/80 uppercase tracking-wider">
            {block.label}
          </span>
        </div>
      ))}
    </div>
  )
}

export function Hero({ data }: HeroProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Анимированный градиентный фон */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-cyan-900 to-teal-900">
        {/* Волновые слои */}
        <div className="absolute inset-0">
          {/* Первый слой волн */}
          <svg
            className="absolute bottom-0 left-0 right-0 w-full h-48 sm:h-64 opacity-20"
            viewBox="0 0 1440 320"
            preserveAspectRatio="none"
          >
            <path
              fill="currentColor"
              className="text-cyan-400 animate-wave"
              d="M0,160L48,176C96,192,192,224,288,213.3C384,203,480,149,576,138.7C672,128,768,160,864,181.3C960,203,1056,213,1152,197.3C1248,181,1344,139,1392,117.3L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
            />
          </svg>

          {/* Второй слой волн */}
          <svg
            className="absolute bottom-0 left-0 right-0 w-full h-36 sm:h-48 opacity-30"
            viewBox="0 0 1440 320"
            preserveAspectRatio="none"
          >
            <path
              fill="currentColor"
              className="text-teal-400 animate-wave-slow"
              d="M0,224L48,213.3C96,203,192,181,288,181.3C384,181,480,203,576,218.7C672,235,768,245,864,234.7C960,224,1056,192,1152,181.3C1248,171,1344,181,1392,186.7L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
            />
          </svg>
        </div>

        {/* Плавающие пузырьки */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(15)].map((_, i) => (
            <div
              key={`bubble-${i}`}
              className="absolute rounded-full bg-white/10 animate-float"
              style={{
                width: `${Math.floor(Math.random() * 20 + 10)}px`,
                height: `${Math.floor(Math.random() * 20 + 10)}px`,
                left: `${Math.floor(Math.random() * 100)}%`,
                bottom: `-50px`,
                animationDuration: `${Math.floor(Math.random() * 10 + 8)}s`,
                animationDelay: `${Math.floor(Math.random() * 5)}s`
              }}
            />
          ))}
        </div>

        {/* Световые блики */}
        <div className="absolute top-1/4 left-1/4 w-64 sm:w-96 h-64 sm:h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-64 sm:w-96 h-64 sm:h-96 bg-teal-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
      </div>

      {/* Контент */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 pt-20 sm:pt-24 pb-16 text-center">
        {/* Бейдж */}
        <div className="inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 mb-4 sm:mb-6 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-xs sm:text-sm text-cyan-100">
          <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-cyan-400 animate-pulse" />
          {data.eventDate} • {data.eventLocation}
        </div>

        {/* Заголовок */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-bold text-white mb-2 sm:mb-4">
          <span className="block">{data.forumTitle}</span>
          <span className="block mt-1 sm:mt-2 bg-gradient-to-r from-cyan-300 via-teal-300 to-cyan-300 bg-clip-text text-transparent">
            «{data.forumSubtitle}»
          </span>
        </h1>

        {/* Подзаголовок */}
        <p className="max-w-xl sm:max-w-2xl mx-auto text-base sm:text-lg md:text-xl text-cyan-100/80 mb-6 sm:mb-10 px-4">
          Главное событие для специалистов по детскому плаванию и развитию
        </p>

        {/* Таймер */}
        <div className="mb-6 sm:mb-10">
          <p className="text-xs sm:text-sm text-cyan-200/60 uppercase tracking-widest mb-3 sm:mb-4">
            До начала форума осталось
          </p>
          <CountdownTimer targetDate={data.eventStartDate} />
        </div>

        {/* Кнопки */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 px-4">
          <Button
            size="lg"
            className="w-full sm:w-auto text-base sm:text-lg px-6 sm:px-10"
            onClick={() => window.open(data.ticketLink, "_blank")}
          >
            Купить билет
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="w-full sm:w-auto border-white/30 text-white hover:bg-white hover:text-slate-900 text-base sm:text-lg px-6 sm:px-10"
            onClick={() => {
              document.querySelector("#program")?.scrollIntoView({ behavior: "smooth" })
            }}
          >
            Программа
          </Button>
        </div>

        {/* Стрелка вниз */}
        <div className="absolute bottom-6 sm:bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
          <button
            onClick={() => {
              document.querySelector("#about")?.scrollIntoView({ behavior: "smooth" })
            }}
            className="p-2 rounded-full text-white/50 hover:text-white transition-colors"
          >
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
              <path d="M6 9L12 15L18 9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>
      </div>
    </section>
  )
}
