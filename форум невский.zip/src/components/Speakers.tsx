// Секция "Спикеры" с карточками экспертов
"use client"

import { Card, CardContent } from "@/components/ui/card"
import type { SiteData } from "@/lib/data"

interface SpeakersProps {
  data: SiteData
}

export function Speakers({ data }: SpeakersProps) {
  return (
    <section id="speakers" className="relative py-16 sm:py-20 lg:py-24 bg-white overflow-hidden">
      {/* Декоративные элементы */}
      <div className="absolute top-20 right-0 w-48 sm:w-64 h-48 sm:h-64 bg-gradient-to-br from-cyan-100 to-teal-100 rounded-full blur-3xl opacity-60" />
      <div className="absolute bottom-20 left-0 w-48 sm:w-64 h-48 sm:h-64 bg-gradient-to-br from-teal-100 to-cyan-100 rounded-full blur-3xl opacity-60" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Заголовок */}
        <div className="text-center mb-10 sm:mb-16">
          <span className="inline-block px-3 sm:px-4 py-1 mb-3 sm:mb-4 text-xs sm:text-sm font-medium text-cyan-600 bg-cyan-50 rounded-full">
            Эксперты
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-3 sm:mb-4">
            Спикеры форума
          </h2>
          <div className="w-16 sm:w-24 h-1 bg-gradient-to-r from-cyan-500 to-teal-500 mx-auto rounded-full mb-4 sm:mb-6" />
          <p className="max-w-2xl mx-auto text-sm sm:text-base md:text-lg text-slate-600 px-4">
            Ведущие специалисты в области детского плавания и развития поделятся своим опытом
          </p>
        </div>

        {/* Сетка спикеров */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4 md:gap-6">
          {data.speakers.map((speaker, index) => (
            <Card
              key={speaker.id}
              className="group overflow-hidden hover:shadow-xl transition-all duration-500"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <CardContent className="p-0">
                {/* Фото спикера */}
                <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-slate-100 to-slate-200">
                  {speaker.photo ? (
                    <img
                      src={speaker.photo}
                      alt={speaker.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  ) : (
                    // Плейсхолдер с инициалами
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-cyan-500 to-teal-500">
                      <span className="text-2xl sm:text-3xl md:text-4xl font-bold text-white">
                        {speaker.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                      </span>
                    </div>
                  )}

                  {/* Оверлей при наведении */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>

                {/* Информация о спикере */}
                <div className="p-3 sm:p-4">
                  <h3 className="font-bold text-sm sm:text-base text-slate-900 mb-0.5 sm:mb-1 truncate">
                    {speaker.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 line-clamp-2">
                    {speaker.role}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Приглашение стать спикером */}
        <div className="mt-10 sm:mt-16 text-center">
          <p className="text-sm sm:text-base text-slate-500">
            Хотите выступить на форуме?{" "}
            <a
              href="#contacts"
              className="text-cyan-600 hover:text-cyan-700 font-medium underline underline-offset-4"
              onClick={(e) => {
                e.preventDefault()
                document.querySelector("#contacts")?.scrollIntoView({ behavior: "smooth" })
              }}
            >
              Свяжитесь с нами
            </a>
          </p>
        </div>
      </div>
    </section>
  )
}
