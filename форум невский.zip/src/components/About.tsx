// Секция "О форуме" с преимуществами и форматом проведения
"use client"

import { Card, CardContent } from "@/components/ui/card"
import type { SiteData } from "@/lib/data"

interface AboutProps {
  data: SiteData
}

export function About({ data }: AboutProps) {
  // Иконки для преимуществ
  const advantageIcons = [
    // Качество
    <svg key="quality" viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>,
    // Развитие
    <svg key="growth" viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M13 7L18 12M18 12L13 17M18 12H6M3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>,
    // Спорт
    <svg key="sport" viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M12 8V16M8 12H16M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ]

  return (
    <section id="about" className="relative py-16 sm:py-20 lg:py-24 bg-gradient-to-b from-white to-slate-50 overflow-hidden">
      {/* Декоративные элементы */}
      <div className="absolute top-0 left-0 w-48 sm:w-72 h-48 sm:h-72 bg-cyan-100 rounded-full blur-3xl opacity-50 -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-48 sm:w-72 h-48 sm:h-72 bg-teal-100 rounded-full blur-3xl opacity-50 translate-x-1/2 translate-y-1/2" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Заголовок секции */}
        <div className="text-center mb-10 sm:mb-16">
          <span className="inline-block px-3 sm:px-4 py-1 mb-3 sm:mb-4 text-xs sm:text-sm font-medium text-cyan-600 bg-cyan-50 rounded-full">
            Знакомство
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-3 sm:mb-4">
            {data.aboutTitle}
          </h2>
          <div className="w-16 sm:w-24 h-1 bg-gradient-to-r from-cyan-500 to-teal-500 mx-auto rounded-full" />
        </div>

        {/* Описание */}
        <div className="max-w-3xl mx-auto text-center mb-10 sm:mb-16">
          <p className="text-base sm:text-lg md:text-xl text-slate-600 leading-relaxed px-4">
            {data.aboutDescription}
          </p>
        </div>

        {/* Блок "Мы стремимся" */}
        <div className="mb-10 sm:mb-16">
          <h3 className="text-xl sm:text-2xl font-bold text-center text-slate-900 mb-6 sm:mb-8">
            Мы стремимся
          </h3>

          <div className="grid gap-4 sm:gap-6 md:grid-cols-3">
            {data.advantages.map((advantage, index) => (
              <Card
                key={`advantage-${index}`}
                className="group hover:scale-[1.02] transition-all duration-300"
              >
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-start gap-3 sm:gap-4">
                    <div className="flex-shrink-0 w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-teal-500 flex items-center justify-center text-white shadow-lg shadow-cyan-500/25 group-hover:shadow-cyan-500/40 transition-shadow">
                      {advantageIcons[index]}
                    </div>
                    <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
                      {advantage}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Формат проведения */}
        <Card className="bg-gradient-to-br from-cyan-500 to-teal-500 border-0 text-white overflow-hidden">
          <CardContent className="p-6 sm:p-8 md:p-10 relative">
            {/* Декоративные волны */}
            <div className="absolute inset-0 opacity-10">
              <svg className="absolute bottom-0 left-0 right-0 w-full h-32" viewBox="0 0 1440 120" preserveAspectRatio="none">
                <path fill="white" d="M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z"/>
              </svg>
            </div>

            <div className="relative text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 mb-4 sm:mb-6 rounded-2xl bg-white/20 backdrop-blur-sm">
                <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6 sm:w-8 sm:h-8">
                  <path d="M8 7V3M16 7V3M7 11H17M5 21H19C20.1046 21 21 20.1046 21 19V7C21 5.89543 20.1046 5 19 5H5C3.89543 5 3 5.89543 3 7V19C3 20.1046 3.89543 21 5 21Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="text-lg sm:text-xl md:text-2xl font-bold mb-2 sm:mb-3">Формат проведения</h3>
              <p className="text-base sm:text-lg text-white/90 max-w-2xl mx-auto px-4">
                {data.format}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Секции форума */}
        <div className="mt-10 sm:mt-16">
          <h3 className="text-xl sm:text-2xl font-bold text-center text-slate-900 mb-6 sm:mb-8">
            Ключевые направления
          </h3>

          <div className="flex flex-wrap justify-center gap-2 sm:gap-3">
            {data.sections.map((section, index) => (
              <span
                key={`section-${index}`}
                className="px-4 sm:px-6 py-2 sm:py-3 rounded-full bg-white border border-slate-200 text-sm sm:text-base text-slate-700 shadow-sm hover:shadow-md hover:border-cyan-300 hover:text-cyan-700 transition-all duration-300 cursor-default"
              >
                {section}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
