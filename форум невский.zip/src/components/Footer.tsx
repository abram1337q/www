// Футер сайта с навигацией и ссылками
"use client"

import type { SiteData } from "@/lib/data"

interface FooterProps {
  data: SiteData
}

export function Footer({ data }: FooterProps) {
  const currentYear = new Date().getFullYear()

  const navLinks = [
    { href: "#about", label: "О форуме" },
    { href: "#program", label: "Программа" },
    { href: "#speakers", label: "Спикеры" },
    { href: "#pricing", label: "Стоимость" },
    { href: "#contacts", label: "Контакты" },
  ]

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <footer className="bg-slate-900 text-white">
      {/* Основной контент футера */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        <div className="grid gap-6 sm:gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Логотип и описание */}
          <div className="lg:col-span-2">
            <a
              href="#"
              className="inline-flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4"
              onClick={(e) => {
                e.preventDefault()
                window.scrollTo({ top: 0, behavior: "smooth" })
              }}
            >
              {/* Иконка */}
              <div className="w-8 h-8 sm:w-10 sm:h-10">
                <svg viewBox="0 0 40 40" className="w-full h-full">
                  <defs>
                    <linearGradient id="footerWaveGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#06b6d4" />
                      <stop offset="100%" stopColor="#14b8a6" />
                    </linearGradient>
                  </defs>
                  <circle cx="20" cy="20" r="18" fill="url(#footerWaveGradient)" />
                  <path d="M10 22 Q15 18 20 22 Q25 26 30 22" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round" />
                  <path d="M10 18 Q15 14 20 18 Q25 22 30 18" stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" opacity="0.7" />
                </svg>
              </div>
              <div>
                <span className="block text-lg sm:text-xl font-bold">{data.forumTitle}</span>
                <span className="block text-xs sm:text-sm text-cyan-400">«{data.forumSubtitle}»</span>
              </div>
            </a>
            <p className="text-sm sm:text-base text-slate-400 max-w-md mb-4 sm:mb-6">
              Главное событие для специалистов по детскому плаванию и развитию.
              {data.eventDate}, {data.eventLocation}.
            </p>

            {/* Соцсети */}
            <div className="flex gap-3 sm:gap-4">
              <a
                href={data.telegramLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-slate-800 hover:bg-[#229ED9] flex items-center justify-center transition-colors"
              >
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 sm:w-5 sm:h-5">
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                </svg>
              </a>
              <a
                href={data.vkLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-slate-800 hover:bg-[#0077FF] flex items-center justify-center transition-colors"
              >
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 sm:w-5 sm:h-5">
                  <path d="M15.684 0H8.316C1.592 0 0 1.592 0 8.316v7.368C0 22.408 1.592 24 8.316 24h7.368C22.408 24 24 22.408 24 15.684V8.316C24 1.592 22.408 0 15.684 0zm3.692 17.123h-1.744c-.66 0-.862-.523-2.049-1.712-1.033-1.003-1.49-1.135-1.744-1.135-.357 0-.458.102-.458.593v1.561c0 .424-.135.678-1.253.678-1.846 0-3.896-1.118-5.335-3.202C4.624 10.857 4 8.634 4 8.179c0-.254.102-.491.593-.491h1.744c.44 0 .61.203.78.677.863 2.49 2.303 4.675 2.896 4.675.22 0 .322-.102.322-.66V9.721c-.068-1.186-.695-1.287-.695-1.71 0-.203.17-.407.44-.407h2.744c.373 0 .508.203.508.643v3.473c0 .372.17.508.271.508.22 0 .407-.136.814-.542 1.27-1.422 2.184-3.61 2.184-3.61.119-.254.322-.491.763-.491h1.744c.525 0 .644.27.525.643-.22 1.017-2.354 4.031-2.354 4.031-.186.305-.254.44 0 .78.186.254.796.779 1.203 1.253.745.847 1.32 1.558 1.473 2.049.17.49-.085.744-.576.744z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Навигация */}
          <div>
            <h4 className="font-bold text-base sm:text-lg mb-3 sm:mb-4">Навигация</h4>
            <nav className="space-y-2 sm:space-y-3">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => scrollToSection(link.href)}
                  className="block text-sm sm:text-base text-slate-400 hover:text-white transition-colors"
                >
                  {link.label}
                </button>
              ))}
            </nav>
          </div>

          {/* Контакты */}
          <div>
            <h4 className="font-bold text-base sm:text-lg mb-3 sm:mb-4">Контакты</h4>
            <div className="space-y-2 sm:space-y-3">
              <a
                href={`tel:${data.phone.replace(/\s/g, "")}`}
                className="block text-sm sm:text-base text-slate-400 hover:text-white transition-colors"
              >
                {data.phone}
              </a>
              <p className="text-sm sm:text-base text-slate-400">
                {data.eventLocation}
              </p>
              <p className="text-sm sm:text-base text-slate-400">
                {data.eventDate}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Нижняя часть футера */}
      <div className="border-t border-slate-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4 text-center sm:text-left">
            <p className="text-xs sm:text-sm text-slate-500">
              {currentYear} {data.forumTitle} «{data.forumSubtitle}». Все права защищены.
            </p>
            <a
              href="/admin"
              className="text-xs sm:text-sm text-slate-600 hover:text-slate-400 transition-colors"
            >
              Панель управления
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
