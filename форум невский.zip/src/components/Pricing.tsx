// Секция "Стоимость" с тарифами и условиями
"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { SiteData } from "@/lib/data"

interface PricingProps {
  data: SiteData
}

export function Pricing({ data }: PricingProps) {
  return (
    <section id="pricing" className="relative py-16 sm:py-20 lg:py-24 bg-gradient-to-b from-slate-50 to-white overflow-hidden">
      {/* Декоративный фон */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-48 sm:w-96 h-48 sm:h-96 bg-cyan-100 rounded-full blur-3xl opacity-40" />
        <div className="absolute bottom-1/4 right-1/4 w-48 sm:w-96 h-48 sm:h-96 bg-teal-100 rounded-full blur-3xl opacity-40" />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Заголовок */}
        <div className="text-center mb-10 sm:mb-16">
          <span className="inline-block px-3 sm:px-4 py-1 mb-3 sm:mb-4 text-xs sm:text-sm font-medium text-cyan-600 bg-cyan-50 rounded-full">
            Билеты
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-3 sm:mb-4">
            Стоимость участия
          </h2>
          <div className="w-16 sm:w-24 h-1 bg-gradient-to-r from-cyan-500 to-teal-500 mx-auto rounded-full mb-4 sm:mb-6" />
          <p className="max-w-2xl mx-auto text-sm sm:text-base md:text-lg text-slate-600 px-4">
            Выберите удобный тариф. Чем раньше покупаете — тем выгоднее!
          </p>
        </div>

        {/* Тарифы */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6 mb-8 sm:mb-12">
          {data.tariffs.map((tariff, index) => (
            <Card
              key={tariff.id}
              className={`relative overflow-hidden transition-all duration-300 ${
                tariff.isActive
                  ? "ring-2 ring-cyan-500 shadow-xl shadow-cyan-500/20 scale-[1.02]"
                  : "opacity-75 hover:opacity-100"
              }`}
            >
              {/* Бейдж для активного тарифа */}
              {tariff.isActive && (
                <div className="absolute top-0 right-0">
                  <Badge className="rounded-none rounded-bl-xl text-[10px] sm:text-xs">
                    Актуально
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center pb-2 sm:pb-4">
                <p className="text-xs sm:text-sm text-slate-500 mb-1 sm:mb-2">{tariff.deadline}</p>
                <CardTitle className="text-2xl sm:text-3xl md:text-4xl font-bold">
                  <span className="bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent">
                    {tariff.price.toLocaleString("ru-RU")}
                  </span>
                  <span className="text-base sm:text-lg text-slate-400 ml-1">р</span>
                </CardTitle>
              </CardHeader>

              <CardContent className="text-center pt-0">
                <Button
                  variant={tariff.isActive ? "default" : "outline"}
                  size="sm"
                  className="w-full text-xs sm:text-sm"
                  onClick={() => window.open(data.ticketLink, "_blank")}
                  disabled={!tariff.isActive}
                >
                  {tariff.isActive ? "Купить" : "Скоро"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Дополнительные условия */}
        <div className="grid gap-3 sm:gap-4 md:grid-cols-3 max-w-4xl mx-auto">
          {/* Групповая скидка */}
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-4 sm:p-6">
              <div className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4 rounded-xl bg-emerald-100 flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 sm:w-6 sm:h-6 text-emerald-600">
                  <path d="M17 21V19C17 17.9391 16.5786 16.9217 15.8284 16.1716C15.0783 15.4214 14.0609 15 13 15H5C3.93913 15 2.92172 15.4214 2.17157 16.1716C1.42143 16.9217 1 17.9391 1 19V21M23 21V19C22.9993 18.1137 22.7044 17.2528 22.1614 16.5523C21.6184 15.8519 20.8581 15.3516 20 15.13M16 3.13C16.8604 3.35031 17.623 3.85071 18.1676 4.55232C18.7122 5.25392 19.0078 6.11683 19.0078 7.005C19.0078 7.89318 18.7122 8.75608 18.1676 9.45769C17.623 10.1593 16.8604 10.6597 16 10.88M13 7C13 9.20914 11.2091 11 9 11C6.79086 11 5 9.20914 5 7C5 4.79086 6.79086 3 9 3C11.2091 3 13 4.79086 13 7Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="text-xs sm:text-sm text-slate-700 font-medium">{data.groupDiscount}</p>
            </CardContent>
          </Card>

          {/* Рассрочка */}
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-4 sm:p-6">
              <div className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4 rounded-xl bg-amber-100 flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 sm:w-6 sm:h-6 text-amber-600">
                  <path d="M12 1V23M17 5H9.5C8.57174 5 7.6815 5.36875 7.02513 6.02513C6.36875 6.6815 6 7.57174 6 8.5C6 9.42826 6.36875 10.3185 7.02513 10.9749C7.6815 11.6313 8.57174 12 9.5 12H14.5C15.4283 12 16.3185 12.3687 16.9749 13.0251C17.6313 13.6815 18 14.5717 18 15.5C18 16.4283 17.6313 17.3185 16.9749 17.9749C16.3185 18.6313 15.4283 19 14.5 19H6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="text-xs sm:text-sm text-slate-700 font-medium">{data.installment}</p>
            </CardContent>
          </Card>

          {/* Для юрлиц */}
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-4 sm:p-6">
              <div className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4 rounded-xl bg-blue-100 flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600">
                  <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M12 12H15M12 16H15M9 12H9.01M9 16H9.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="text-xs sm:text-sm text-slate-700 font-medium">{data.legalEntity}</p>
            </CardContent>
          </Card>
        </div>

        {/* CTA */}
        <div className="mt-10 sm:mt-12 text-center">
          <Button
            size="lg"
            className="text-base sm:text-lg px-8 sm:px-12"
            onClick={() => window.open(data.ticketLink, "_blank")}
          >
            Купить билет сейчас
          </Button>
        </div>
      </div>
    </section>
  )
}
