// Хук для работы с данными сайта
"use client"

import { useState, useEffect, useCallback } from "react"
import { type SiteData, getSiteData, saveSiteData, defaultSiteData } from "@/lib/data"

export function useSiteData() {
  const [data, setData] = useState<SiteData>(defaultSiteData)
  const [isLoaded, setIsLoaded] = useState(false)

  // Загрузка данных при монтировании
  useEffect(() => {
    setData(getSiteData())
    setIsLoaded(true)
  }, [])

  // Обновление данных
  const updateData = useCallback((newData: Partial<SiteData>) => {
    setData((prev) => {
      const updated = { ...prev, ...newData }
      saveSiteData(updated)
      return updated
    })
  }, [])

  // Полная замена данных
  const replaceData = useCallback((newData: SiteData) => {
    setData(newData)
    saveSiteData(newData)
  }, [])

  return { data, updateData, replaceData, isLoaded }
}
