// Хедер сайта с навигацией и кнопкой регистрации
"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import type { SiteData } from "@/lib/data"

interface HeaderProps {
  data: SiteData
}

export function Header({ data }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  // Отслеживание скролла для изменения стиля хедера
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Навигационные ссылки
  const navLinks = [
    { href: "#about", label: "О форуме" },
    { href: "#program", label: "Программа" },
    { href: "#speakers", label: "Спикеры" },
    { href: "#pricing", label: "Стоимость" },
    { href: "#contacts", label: "Контакты" },
  ]

  // Плавная прокрутка
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setIsMobileMenuOpen(false)
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? "bg-white/90 backdrop-blur-xl shadow-lg shadow-cyan-500/5"
          : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Логотип */}
          <a
            href="#"
            className="flex items-center gap-2 sm:gap-3 group"
            onClick={(e) => {
              e.preventDefault()
              window.scrollTo({ top: 0, behavior: "smooth" })
            }}
          >
            {/* Иконка волны */}
            <div className="relative w-8 h-8 sm:w-10 sm:h-10">
              <svg viewBox="0 0 40 40" className="w-full h-full">
                <defs>
                  <linearGradient id="waveGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#06b6d4" />
                    <stop offset="100%" stopColor="#14b8a6" />
                  </linearGradient>
                </defs>
                <circle cx="20" cy="20" r="18" fill="url(#waveGradient)" className="group-hover:scale-110 transition-transform duration-300 origin-center" />
                <path
                  d="M10 22 Q15 18 20 22 Q25 26 30 22"
                  stroke="white"
                  strokeWidth="2.5"
                  fill="none"
                  strokeLinecap="round"
                  className="animate-pulse"
                />
                <path
                  d="M10 18 Q15 14 20 18 Q25 22 30 18"
                  stroke="white"
                  strokeWidth="2"
                  fill="none"
                  strokeLinecap="round"
                  opacity="0.7"
                />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className={`text-base sm:text-lg font-bold transition-colors duration-300 ${
                isScrolled ? "text-slate-900" : "text-white"
              }`}>
                {data.forumTitle}
              </span>
              <span className={`text-xs sm:text-sm transition-colors duration-300 ${
                isScrolled ? "text-cyan-600" : "text-cyan-200"
              }`}>
                {data.forumSubtitle}
              </span>
            </div>
          </a>

          {/* Навигация для десктопа */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => scrollToSection(link.href)}
                className={`px-3 xl:px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 hover:bg-white/10 ${
                  isScrolled
                    ? "text-slate-700 hover:text-cyan-600 hover:bg-cyan-50"
                    : "text-white/90 hover:text-white"
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Кнопка регистрации */}
          <div className="flex items-center gap-2 sm:gap-4">
            <Button
              size="sm"
              className="hidden sm:inline-flex"
              onClick={() => window.open(data.ticketLink, "_blank")}
            >
              Регистрация
            </Button>

            {/* Мобильное меню */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`lg:hidden p-2 rounded-lg transition-colors ${
                isScrolled ? "text-slate-900" : "text-white"
              }`}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                {isMobileMenuOpen ? (
                  <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                ) : (
                  <>
                    <path d="M4 6H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M4 12H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M4 18H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  </>
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Мобильное меню */}
        <div
          className={`lg:hidden overflow-hidden transition-all duration-300 ${
            isMobileMenuOpen ? "max-h-80 pb-4" : "max-h-0"
          }`}
        >
          <nav className="flex flex-col gap-1 pt-2">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => scrollToSection(link.href)}
                className={`px-4 py-3 rounded-lg text-sm font-medium text-left transition-all duration-300 ${
                  isScrolled
                    ? "text-slate-700 hover:text-cyan-600 hover:bg-cyan-50"
                    : "text-white/90 hover:text-white hover:bg-white/10"
                }`}
              >
                {link.label}
              </button>
            ))}
            <Button
              size="sm"
              className="mt-2 sm:hidden"
              onClick={() => window.open(data.ticketLink, "_blank")}
            >
              Регистрация
            </Button>
          </nav>
        </div>
      </div>
    </header>
  )
}
