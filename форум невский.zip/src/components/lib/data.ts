// Данные сайта - редактируются через админ-панель
// Все тексты, спикеры, тарифы хранятся здесь

export interface Speaker {
  id: string
  name: string
  photo: string
  role: string
}

export interface Tariff {
  id: string
  deadline: string
  price: number
  isActive: boolean
}

export interface SiteData {
  // Основная информация
  forumTitle: string
  forumSubtitle: string
  eventDate: string
  eventLocation: string

  // О форуме
  aboutTitle: string
  aboutDescription: string
  advantages: string[]
  format: string

  // Программа
  programDay1Title: string
  programDay1Time: string
  programDay1Description: string
  programDay2Title: string
  programDay2Time: string
  programDay2Description: string

  // Секции
  sections: string[]

  // Спикеры
  speakers: Speaker[]

  // Тарифы
  tariffs: Tariff[]
  groupDiscount: string
  installment: string
  legalEntity: string

  // Контакты
  phone: string
  telegramLink: string
  vkLink: string
  ticketLink: string

  // Таймер - дата начала форума
  eventStartDate: string
}

// Начальные данные
export const defaultSiteData: SiteData = {
  forumTitle: "Невский форум",
  forumSubtitle: "Дети и вода",
  eventDate: "25-26 апреля 2026",
  eventLocation: "Санкт-Петербург",

  aboutTitle: "О форуме",
  aboutDescription: "Невский форум «Дети и вода» собирает вместе уникальных экспертов в сфере плавания и детского развития, которые поделятся своими знаниями, наработками и кейсами в работе с детьми.",
  advantages: [
    "Улучшить качество услуг в детских бассейнах России и стран СНГ",
    "Мотивировать специалистов развиваться, обучаться и повышать свой профессиональный статус",
    "Поддерживать детский оздоровительный спорт, ведь «Спорт — это норма жизни!»"
  ],
  format: "Доклады и мастер-классы в воде с перерывами на нетворкинг и кофе-брейки",

  programDay1Title: "День 1 — Доклады",
  programDay1Time: "10:00 — 19:00",
  programDay1Description: "Теоретическая часть: доклады от ведущих экспертов отрасли",
  programDay2Title: "День 2 — Практика",
  programDay2Time: "10:00 — 19:00",
  programDay2Description: "Мастер-классы в бассейне и доклады в зале",

  sections: [
    "Грудничковое плавание",
    "Обучение плаванию в раннем возрасте",
    "Психология в разных возрастных группах",
    "Двигательное развитие детей",
    "Коррекционное плавание",
    "Смежные дисциплины (неврология, педагогика, психиатрия)"
  ],

  speakers: [
    { id: "1", name: "Спикер 1", photo: "", role: "Эксперт по грудничковому плаванию" },
    { id: "2", name: "Спикер 2", photo: "", role: "Детский психолог" },
    { id: "3", name: "Спикер 3", photo: "", role: "Тренер по плаванию" },
    { id: "4", name: "Спикер 4", photo: "", role: "Невролог" },
    { id: "5", name: "Спикер 5", photo: "", role: "Педагог" },
    { id: "6", name: "Спикер 6", photo: "", role: "Специалист по раннему развитию" },
    { id: "7", name: "Спикер 7", photo: "", role: "Инструктор по плаванию" },
    { id: "8", name: "Спикер 8", photo: "", role: "Реабилитолог" },
    { id: "9", name: "Спикер 9", photo: "", role: "Детский тренер" },
    { id: "10", name: "Спикер 10", photo: "", role: "Эксперт по коррекционному плаванию" },
  ],

  tariffs: [
    { id: "1", deadline: "до 15 января", price: 6500, isActive: true },
    { id: "2", deadline: "до 1 марта", price: 8000, isActive: false },
    { id: "3", deadline: "до 1 апреля", price: 9500, isActive: false },
    { id: "4", deadline: "до 24 апреля", price: 11000, isActive: false },
  ],
  groupDiscount: "Групповая скидка от 3 билетов — 10%",
  installment: "Возможна рассрочка от Т-Банк",
  legalEntity: "Возможна оплата для юридических лиц по счету",

  phone: "+7 980 742-17-70",
  telegramLink: "https://t.me/forumdetyivodaspb",
  vkLink: "https://vk.com/forumdetyivodaspb",
  ticketLink: "https://cbiletom.ru/event.php?event=11669",

  eventStartDate: "2026-04-25T10:00:00"
}

// Ключ для localStorage
const STORAGE_KEY = "nevsky_forum_data"

// Получить данные
export function getSiteData(): SiteData {
  if (typeof window === "undefined") return defaultSiteData

  const stored = localStorage.getItem(STORAGE_KEY)
  if (stored) {
    try {
      return { ...defaultSiteData, ...JSON.parse(stored) }
    } catch {
      return defaultSiteData
    }
  }
  return defaultSiteData
}

// Сохранить данные
export function saveSiteData(data: SiteData): void {
  if (typeof window === "undefined") return
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
}

// Сбросить к дефолтным
export function resetSiteData(): void {
  if (typeof window === "undefined") return
  localStorage.removeItem(STORAGE_KEY)
}

// Пароль админа (можно изменить)
export const ADMIN_PASSWORD = "forum2026"
