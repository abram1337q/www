// Секция "Программа" с расписанием по дням
"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { SiteData } from "@/lib/data"

interface ProgramProps {
  data: SiteData
}

export function Program({ data }: ProgramProps) {
  return (
    <section id="program" className="relative py-16 sm:py-20 lg:py-24 bg-slate-50 overflow-hidden">
      {/* Фоновый паттерн */}
      <div className="absolute inset-0 opacity-30">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="waves-pattern" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <path d="M0 50 Q25 40 50 50 Q75 60 100 50" stroke="#06b6d4" strokeWidth="0.5" fill="none" opacity="0.3"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#waves-pattern)"/>
        </svg>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Заголовок */}
        <div className="text-center mb-10 sm:mb-16">
          <span className="inline-block px-3 sm:px-4 py-1 mb-3 sm:mb-4 text-xs sm:text-sm font-medium text-cyan-600 bg-cyan-50 rounded-full">
            Расписание
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-3 sm:mb-4">
            Программа форума
          </h2>
          <div className="w-16 sm:w-24 h-1 bg-gradient-to-r from-cyan-500 to-teal-500 mx-auto rounded-full" />
        </div>

        {/* Табы с днями */}
        <Tabs defaultValue="day1" className="max-w-4xl mx-auto">
          <TabsList className="w-full grid grid-cols-2 h-12 sm:h-14 mb-6 sm:mb-8">
            <TabsTrigger value="day1" className="text-sm sm:text-base">
              25 апреля
            </TabsTrigger>
            <TabsTrigger value="day2" className="text-sm sm:text-base">
              26 апреля
            </TabsTrigger>
          </TabsList>

          {/* День 1 */}
          <TabsContent value="day1">
            <Card className="overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <CardTitle className="text-lg sm:text-xl md:text-2xl">{data.programDay1Title}</CardTitle>
                  <span className="text-cyan-100 text-sm sm:text-base">{data.programDay1Time}</span>
                </div>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 md:p-8">
                <p className="text-slate-600 text-sm sm:text-base mb-4 sm:mb-6">{data.programDay1Description}</p>

                {/* Примерное расписание */}
                <div className="space-y-3 sm:space-y-4">
                  {[
                    { time: "10:00 - 10:30", title: "Регистрация участников и приветственный кофе" },
                    { time: "10:30 - 11:30", title: "Открытие форума. Вступительное слово организаторов" },
                    { time: "11:30 - 12:30", title: "Доклад: Современные методики грудничкового плавания" },
                    { time: "12:30 - 13:00", title: "Кофе-брейк и нетворкинг" },
                    { time: "13:00 - 14:00", title: "Доклад: Психология работы с детьми в воде" },
                    { time: "14:00 - 15:00", title: "Обеденный перерыв" },
                    { time: "15:00 - 16:00", title: "Доклад: Двигательное развитие через плавание" },
                    { time: "16:00 - 17:00", title: "Панельная дискуссия: Смежные дисциплины" },
                    { time: "17:00 - 17:30", title: "Кофе-брейк" },
                    { time: "17:30 - 19:00", title: "Доклады: Коррекционное плавание" },
                  ].map((item, index) => (
                    <div
                      key={`day1-${index}`}
                      className="flex gap-3 sm:gap-4 items-start p-3 sm:p-4 rounded-xl bg-slate-50 hover:bg-cyan-50 transition-colors group"
                    >
                      <div className="flex-shrink-0 w-20 sm:w-28 text-xs sm:text-sm font-medium text-cyan-600">
                        {item.time}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm sm:text-base text-slate-700 group-hover:text-slate-900 transition-colors">
                          {item.title}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* День 2 */}
          <TabsContent value="day2">
            <Card className="overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-teal-500 to-teal-600 text-white">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <CardTitle className="text-lg sm:text-xl md:text-2xl">{data.programDay2Title}</CardTitle>
                  <span className="text-teal-100 text-sm sm:text-base">{data.programDay2Time}</span>
                </div>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 md:p-8">
                <p className="text-slate-600 text-sm sm:text-base mb-4 sm:mb-6">{data.programDay2Description}</p>

                {/* Примерное расписание */}
                <div className="space-y-3 sm:space-y-4">
                  {[
                    { time: "10:00 - 10:30", title: "Сбор участников. Подготовка к практике" },
                    { time: "10:30 - 12:00", title: "Мастер-класс в бассейне: Грудничковое плавание" },
                    { time: "12:00 - 12:30", title: "Перерыв" },
                    { time: "12:30 - 14:00", title: "Мастер-класс в бассейне: Обучение детей раннего возраста" },
                    { time: "14:00 - 15:00", title: "Обеденный перерыв" },
                    { time: "15:00 - 16:30", title: "Параллельная секция: Доклады в зале" },
                    { time: "15:00 - 16:30", title: "Мастер-класс: Коррекционное плавание" },
                    { time: "16:30 - 17:00", title: "Кофе-брейк" },
                    { time: "17:00 - 18:30", title: "Финальный мастер-класс и практика" },
                    { time: "18:30 - 19:00", title: "Закрытие форума. Вручение сертификатов" },
                  ].map((item, index) => (
                    <div
                      key={`day2-${index}`}
                      className="flex gap-3 sm:gap-4 items-start p-3 sm:p-4 rounded-xl bg-slate-50 hover:bg-teal-50 transition-colors group"
                    >
                      <div className="flex-shrink-0 w-20 sm:w-28 text-xs sm:text-sm font-medium text-teal-600">
                        {item.time}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm sm:text-base text-slate-700 group-hover:text-slate-900 transition-colors">
                          {item.title}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  )
}
