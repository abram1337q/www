#!/bin/bash

# Остановить все контейнеры и удалить их
docker-compose -f docker-compose.dev.yml down

# Загрузить переменные окружения из .env.development
export $(cat .env.development | grep -v '^#' | xargs)

# Запустить бэкенд и базу данных
docker-compose -f docker-compose.dev.yml up -d postgres backend bot

# Перейти в директорию фронтенда и установить зависимости
cd frontend && npm install

# Запустить фронтенд локально
npm run dev -- --host --port 5312
