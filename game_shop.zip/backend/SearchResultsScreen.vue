<template>
    <div class="search-results-screen" v-close-keyboard ref="searchScreenRef">
        <div class="search-header">
            <div class="search-container">
                <input
                    type="text"
                    v-model="searchQuery"
                    placeholder="Поиск"
                    @input="handleInput"
                    @compositionstart="handleCompositionStart"
                    @compositionend="handleCompositionEnd"
                    @keyup="handleKeyup"
                    @keyup.enter="searchAndHideKeyboard"
                    @focus="handleFocus"
                    @blur="handleBlur"
                    enterkeyhint="search"
                    class="search-input"
                    ref="searchInputRef"
                    autocomplete="off"
                    autocorrect="off"
                    autocapitalize="off"
                    spellcheck="false"
                    inputmode="search"
                />
                <button class="filter-button" @click="toggleFilters">
                    <img src="/assets/img/filters.svg" alt="Фильтры" />
                    <span class="filter-count" v-if="activeFiltersCount">{{
                        activeFiltersCount
                    }}</span>
                </button>
            </div>
            <Transition name="slide">
                <div class="filters-panel" v-if="isFiltersOpen">
                    <div class="filter-section">
                        <div class="filter-header">
                            <h3>Фильтры</h3>
                            <button class="reset-button" @click="resetFilters">
                                Сбросить все
                            </button>
                        </div>
                    </div>

                    <div class="filter-section price-section">
                        <div class="price-filter">
                            <div class="price-label">Стоимость</div>
                            <div class="price-inputs">
                                <div class="price-range">
                                    <span class="price-prefix">от</span>
                                    <input
                                        type="number"
                                        v-model="priceFrom"
                                        placeholder="0"
                                        enterkeyhint="done"
                                        @keyup.enter="hideKeyboard"
                                    />
                                    <span class="price-prefix">до</span>
                                    <input
                                        type="number"
                                        v-model="priceTo"
                                        placeholder="999999"
                                        enterkeyhint="done"
                                        @keyup.enter="hideKeyboard"
                                    />
                                    <span class="price-currency"> руб.</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="filter-section">
                        <div class="filter-chips">
                            <button
                                v-for="genre in availableGenres"
                                :key="genre.id"
                                :class="{
                                    active: isGenreSelected(genre.id),
                                }"
                                @click="toggleGenre(genre)"
                                class="filter-chip"
                            >
                                {{ genre.name }}
                            </button>
                        </div>
                    </div>
                </div>
            </Transition>
        </div>
        <div class="search-results" v-if="searchQuery || activeFiltersCount">
            <div v-if="isLoading" class="loading-state">
                <div class="loading-spinner"></div>
                <p>Поиск игр...</p>
            </div>

            <div v-else-if="error" class="error-state">
                <p>{{ error }}</p>
            </div>

            <div v-else-if="searchResults.length === 0" class="empty-state">
                <p>По вашему запросу ничего не найдено</p>
            </div>

            <div v-else class="results-list">
                <template
                    v-for="product in paginatedSearchResults"
                    :key="`${product.id}-${product.edition?.id || 'base'}`"
                >
                    <ProductCard :product="product" />
                </template>
            </div>

            <!-- Кнопка обращения в поддержку -->
            <SupportButton v-if="searchResults.length > 0 && !isLoading && !error" />

            <!-- Пагинация -->
            <div v-if="totalPages > 1 && !isLoading && !error && searchResults.length > 0" class="pagination-container">
                <button
                    class="pagination-btn"
                    @click="goToFirstPage"
                    :disabled="currentPage === 1"
                >
                    «
                </button>
                <button
                    class="pagination-btn"
                    @click="goToPrevPage"
                    :disabled="currentPage === 1"
                >
                    ‹
                </button>

                <div class="page-numbers">
                    <button
                        v-for="page in displayedPages"
                        :key="page"
                        class="page-number"
                        :class="{ active: currentPage === page }"
                        @click="goToPage(page)"
                    >
                        {{ page }}
                    </button>
                </div>

                <button
                    class="pagination-btn"
                    @click="goToNextPage"
                    :disabled="currentPage === totalPages"
                >
                    ›
                </button>
                <button
                    class="pagination-btn"
                    @click="goToLastPage"
                    :disabled="currentPage === totalPages"
                >
                    »
                </button>
            </div>
        </div>
        <div class="empty-state" v-else>
            <p>Введите запрос для поиска</p>
        </div>
    </div>
</template>

<script setup>
import ProductCard from '@/components/common/ProductCard.vue';
import SupportButton from '@/components/common/SupportButton.vue';
import { getGenres, searchGames } from '@/services/apiService';
import { computed, onMounted, onBeforeUnmount, onUnmounted, ref, watch, nextTick } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

const router = useRouter();
const store = useStore();
const currentCurrency = computed(() => store.state.user.currentCurrency);

// Используем Vuex вместо локальных переменных
const searchQuery = computed({
    get: () => store.getters['search/getSearchQuery'],
    set: value => store.dispatch('search/setSearchQuery', value),
});

const searchResults = computed(() => store.getters['search/getSearchResults']);
const isLoading = computed(() => store.getters['search/isLoading']);
const error = computed(() => store.getters['search/getError']);
const isFiltersOpen = computed(() => store.getters['search/isFiltersOpen']);
const selectedGenres = computed(
    () => store.getters['search/getSelectedGenres']
);
const priceFrom = computed({
    get: () => store.getters['search/getPriceFrom'],
    set: value => store.dispatch('search/setPriceFrom', value),
});
const priceTo = computed({
    get: () => store.getters['search/getPriceTo'],
    set: value => store.dispatch('search/setPriceTo', value),
});
const activeFiltersCount = computed(
    () => store.getters['search/activeFiltersCount']
);
const expandedSearchResults = computed(
    () => store.getters['search/expandedSearchResults']
);

// Кеширование результатов поиска
const searchCache = new Map();
const getCacheKey = params => JSON.stringify(params);

// Санитизация поискового запроса
const sanitizeSearchQuery = query => {
    return query.replace(/[<>]/g, '').trim();
};

// Функция для нормализации строки - удаляет специальные символы для лучшего поиска
const normalizeString = str => {
    return str
        .toLowerCase()
        .replace(/[^\w\sа-яё]/gi, '') // Удаляем все специальные символы, оставляя только буквы, цифры и пробелы
        .replace(/\s+/g, ' ') // Заменяем множественные пробелы на одиночные
        .trim();
};

// Состояния для жанров
const availableGenres = ref([]);

// Флаг для отслеживания композиционного ввода (для Android клавиатур)
const isComposing = ref(false);
const searchInputRef = ref(null);

// Переменные для polling механизма
let pollingInterval = null;
let lastPolledValue = '';

// Функция polling - проверяет значение поля ввода каждые 150ms
const startPolling = () => {
    // Останавливаем предыдущий polling, если есть
    stopPolling();

    lastPolledValue = searchInputRef.value?.value || '';

    pollingInterval = setInterval(() => {
        if (!searchInputRef.value) return;

        const currentValue = searchInputRef.value.value;

        // Если значение изменилось
        if (currentValue !== lastPolledValue) {
            lastPolledValue = currentValue;

            // Обновляем searchQuery и запускаем поиск
            searchQuery.value = currentValue;
            triggerSearch();
        }
    }, 150); // Проверяем каждые 150ms
};

const stopPolling = () => {
    if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
    }
    lastPolledValue = '';
};

// Обработчики фокуса для управления polling
const handleFocus = () => {
    startPolling();
};

const handleBlur = () => {
    stopPolling();
    // Финальная проверка при потере фокуса
    if (searchInputRef.value) {
        const finalValue = searchInputRef.value.value;
        if (finalValue !== searchQuery.value) {
            searchQuery.value = finalValue;
            triggerSearch();
        }
    }
};

// Обработчики композиционного ввода (оставляем как дополнительный механизм)
const handleCompositionStart = () => {
    isComposing.value = true;
};

const handleCompositionEnd = (e) => {
    isComposing.value = false;
    // Принудительно обновляем значение и запускаем поиск
    if (e.target.value) {
        searchQuery.value = e.target.value;
        lastPolledValue = e.target.value;
        triggerSearch();
    }
};

const handleInput = (e) => {
    // Обновляем значение (polling подхватит изменение)
    const newValue = e.target.value;
    if (newValue !== searchQuery.value) {
        searchQuery.value = newValue;
        lastPolledValue = newValue;
        triggerSearch();
    }
};

// Дополнительный обработчик для keyup - обходит проблемы с автокоррекцией Android
const handleKeyup = (e) => {
    // Игнорируем специальные клавиши
    if (e.key === 'Enter' || e.key === 'Escape' || e.key === 'Tab') {
        return;
    }

    // Принудительно читаем значение из поля ввода
    const currentValue = e.target.value;

    // Если значение изменилось, обновляем и запускаем поиск
    if (currentValue !== searchQuery.value) {
        searchQuery.value = currentValue;
        lastPolledValue = currentValue;
        triggerSearch();
    }
};

// Функция для запуска поиска с debounce
let searchTimeout;
let priceFilterTimeout;

const triggerSearch = (isPriceFilter = false) => {
    // Для фильтра цен используем отдельный таймер с большей задержкой
    if (isPriceFilter) {
        clearTimeout(priceFilterTimeout);
        priceFilterTimeout = setTimeout(() => {
            if (
                (searchQuery.value && searchQuery.value.trim().length >= 3) ||
                selectedGenres.value.length > 0 ||
                priceFrom.value ||
                priceTo.value
            ) {
                store.dispatch('search/setCurrentPage', 1);
                performSearch();
            } else {
                store.dispatch('search/setSearchResults', []);
                store.dispatch('search/setCurrentPage', 1);
            }
        }, 2000); // 2 секунды для фильтра цен
    } else {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            if (
                (searchQuery.value && searchQuery.value.trim().length >= 3) ||
                selectedGenres.value.length > 0 ||
                priceFrom.value ||
                priceTo.value
            ) {
                store.dispatch('search/setCurrentPage', 1);
                performSearch();
            } else {
                store.dispatch('search/setSearchResults', []);
                store.dispatch('search/setCurrentPage', 1);
            }
        }, 2000); // Увеличено до 2 секунд для поиска - уменьшает нагрузку
    }
};

// Загрузка жанров
const loadGenres = async () => {
    try {
        const genres = await getGenres();
        // Исключаем типы продуктов из списка жанров
        const excludedTypes = ['Виртуальные деньги', 'Дополнение', 'Игра', 'Подписка'];
        availableGenres.value = genres.filter(genre => !excludedTypes.includes(genre.name));
    } catch (error) {
        console.error('Error loading genres:', error);
    }
};

// Функции для работы с жанрами
const isGenreSelected = genreId => {
    return selectedGenres.value.some(genre => genre.id === genreId);
};

const toggleGenre = genre => {
    const newSelectedGenres = [...selectedGenres.value];
    const index = newSelectedGenres.findIndex(g => g.id === genre.id);

    if (index === -1) {
        newSelectedGenres.push(genre);
    } else {
        newSelectedGenres.splice(index, 1);
    }

    store.dispatch('search/setSelectedGenres', newSelectedGenres);
};

const toggleFilters = () => {
    store.dispatch('search/toggleFilters');
};

const resetFilters = () => {
    store.dispatch('search/resetFilters');
    performSearch();
};

// Блокируем скролл фона, когда открыты фильтры
watch(isFiltersOpen, (newValue) => {
    if (newValue) {
        // Блокируем прокрутку body
        document.body.style.overflow = 'hidden';
    } else {
        // Разблокируем прокрутку body
        document.body.style.overflow = '';
    }
});

// Разблокируем скролл при размонтировании компонента
onUnmounted(() => {
    document.body.style.overflow = '';
});

watch([priceFrom, priceTo], ([newFrom, newTo]) => {
    if (newFrom && newTo && Number(newFrom) > Number(newTo)) {
        store.dispatch(
            'search/setError',
            'Минимальная цена не может быть больше максимальной'
        );
        store.dispatch('search/setSearchResults', []);
    } else if (error.value) {
        store.dispatch('search/setError', null);
    }
});

const performSearch = async () => {
    try {
        if (error.value) return;

        store.dispatch('search/setLoading', true);
        store.dispatch('search/setError', null);

        const searchParams = {
            query: sanitizeSearchQuery(searchQuery.value),
            genres: selectedGenres.value.length
                ? selectedGenres.value.map(g => g.id).join(',')
                : undefined,
            priceFrom: Number(priceFrom.value) || undefined,
            priceTo: Number(priceTo.value) || undefined,
            currency_id: currentCurrency.value?.id,
        };

        // Удаляем undefined параметры
        Object.keys(searchParams).forEach(
            key => searchParams[key] === undefined && delete searchParams[key]
        );

        // Проверяем кеш
        const cacheKey = getCacheKey(searchParams);
        if (store.getters['search/hasCache'](cacheKey)) {
            const cachedResults =
                store.getters['search/getFromCache'](cacheKey);
            store.dispatch('search/setSearchResults', cachedResults);
            store.dispatch('search/setLoading', false);
            return;
        }

        console.log('Sending search request with params:', searchParams);
        const results = await searchGames(searchParams);
        store.dispatch('search/setSearchResults', results || []);

        // Сохраняем в кеш
        store.dispatch('search/addToCache', {
            key: cacheKey,
            results: results || [],
        });
    } catch (err) {
        console.error('Search error:', err);
        store.dispatch(
            'search/setError',
            'Произошла ошибка при поиске игр. Пожалуйста, попробуйте позже.'
        );
        store.dispatch('search/setSearchResults', []);
    } finally {
        store.dispatch('search/setLoading', false);
    }
};

// Отдельные watchers для разных фильтров
watch(
    [priceFrom, priceTo],
    () => {
        triggerSearch(true); // Используем задержку 2 секунды для цен
    }
);

watch(
    [selectedGenres, currentCurrency],
    () => {
        triggerSearch(false); // Обычная задержка для жанров и валюты
    },
    { deep: true }
);

// Функция для скрытия клавиатуры
const hideKeyboard = () => {
    if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
    }
};

// Функция для поиска и скрытия клавиатуры
const searchAndHideKeyboard = () => {
    performSearch();
    hideKeyboard();
};

// Пагинация - используем Vuex store
const currentPage = computed({
    get: () => store.getters['search/getCurrentPage'],
    set: value => store.dispatch('search/setCurrentPage', value),
});

const paginatedSearchResults = computed(() => store.getters['search/paginatedSearchResults']);
const totalPages = computed(() => store.getters['search/getTotalPages']);
const searchScreenRef = ref(null);

const displayedPages = computed(() => {
    const maxVisiblePages = 5;
    const halfVisible = Math.floor(maxVisiblePages / 2);

    let startPage = Math.max(currentPage.value - halfVisible, 1);
    let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages.value);

    if (endPage - startPage + 1 < maxVisiblePages) {
        startPage = Math.max(endPage - maxVisiblePages + 1, 1);
    }

    const pages = [];
    for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
    }

    return pages;
});

// Сохранение позиции скролла
let scrollTimeout = null;
const handleScroll = () => {
    if (scrollTimeout) {
        clearTimeout(scrollTimeout);
    }

    scrollTimeout = setTimeout(() => {
        if (searchScreenRef.value) {
            store.dispatch('search/setScrollPosition', searchScreenRef.value.scrollTop);
        }
    }, 200);
};

const savePageState = () => {
    const scrollPosition = searchScreenRef.value ? searchScreenRef.value.scrollTop : 0;
    store.dispatch('search/setScrollPosition', scrollPosition);
};

const goToPage = (page) => {
    if (page >= 1 && page <= totalPages.value) {
        currentPage.value = page;
        savePageState();
        // Прокручиваем страницу вверх при смене страницы
        if (searchScreenRef.value) {
            searchScreenRef.value.scrollTop = 0;
        }
    }
};

const goToFirstPage = () => {
    if (currentPage.value > 1) {
        goToPage(1);
    }
};

const goToPrevPage = () => {
    if (currentPage.value > 1) {
        goToPage(currentPage.value - 1);
    }
};

const goToNextPage = () => {
    if (currentPage.value < totalPages.value) {
        goToPage(currentPage.value + 1);
    }
};

const goToLastPage = () => {
    if (currentPage.value < totalPages.value) {
        goToPage(totalPages.value);
    }
};

// Восстановление позиции скролла при монтировании
onMounted(() => {
    loadGenres();

    // Если у нас уже есть результаты поиска в хранилище, не нужно делать новый запрос
    if (searchResults.value.length === 0 && searchQuery.value) {
        performSearch();
    }

    // Запускаем таймер автоматической очистки кеша
    scheduleCacheCleanup();

    // Добавляем обработчик скролла после монтирования DOM
    nextTick(() => {
        if (searchScreenRef.value) {
            searchScreenRef.value.addEventListener('scroll', handleScroll);

            // Восстанавливаем позицию скролла
            const savedScrollPosition = store.getters['search/getScrollPosition'];
            if (savedScrollPosition) {
                setTimeout(() => {
                    if (searchScreenRef.value) {
                        searchScreenRef.value.scrollTop = savedScrollPosition;
                    }
                }, 100);
            }
        }
    });
});

// Таймер для автоматической очистки кеша при простое
let cacheCleanupTimeout = null;

// Функция для планирования очистки кеша через 5 минут простоя
const scheduleCacheCleanup = () => {
    if (cacheCleanupTimeout) {
        clearTimeout(cacheCleanupTimeout);
    }

    // Очищаем кеш через 5 минут простоя для экономии памяти
    cacheCleanupTimeout = setTimeout(() => {
        console.log('Clearing search cache due to inactivity');
        store.dispatch('search/clearCache');
    }, 5 * 60 * 1000); // 5 минут
};

// Сбрасываем таймер очистки при каждом поиске
watch(searchResults, () => {
    scheduleCacheCleanup();
});

// Очищаем обработчики при размонтировании
onBeforeUnmount(() => {
    stopPolling();
    if (searchTimeout) {
        clearTimeout(searchTimeout);
        searchTimeout = null;
    }
    if (priceFilterTimeout) {
        clearTimeout(priceFilterTimeout);
        priceFilterTimeout = null;
    }
    if (scrollTimeout) {
        clearTimeout(scrollTimeout);
        scrollTimeout = null;
    }
    if (cacheCleanupTimeout) {
        clearTimeout(cacheCleanupTimeout);
        cacheCleanupTimeout = null;
    }
    if (searchScreenRef.value) {
        searchScreenRef.value.removeEventListener('scroll', handleScroll);
    }
    savePageState();

    // Очищаем кеш при выходе со страницы поиска для экономии памяти
    const cacheSize = store.getters['search/getCacheSize'];
    if (cacheSize > 20) {
        console.log(`Clearing large cache (${cacheSize} entries) on unmount`);
        store.dispatch('search/clearCache');
    }
});
</script>

<style scoped>
.search-results-screen {
    height: 100vh;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
    position: relative;
    padding: 16px;
    padding-bottom: 140px;
}

.search-header {
    position: sticky;
    top: 0;
    background: white;
    padding: 8px 0;
    margin: -16px -16px 16px -16px;
    border-bottom: 1px solid #eee;
    z-index: 1000;
}

.search-container {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 0 16px;
    animation: moveFromMenu 0.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
    transform-origin: center bottom;
    position: relative;
    width: 100%;
}

@keyframes moveFromMenu {
    0% {
        transform: translate3d(calc(-50% + 46.5px), calc(100vh + 20px), 0)
            scale(0.4);
        opacity: 0;
        width: 93px;
    }
    100% {
        transform: translate3d(0, 0, 0) scale(1);
        opacity: 1;
        width: 100%;
    }
}

.search-input {
    flex: 1;
    height: 36px;
    padding: 0 12px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 16px;
    background-color: #f5f5f5;
}

.search-input:focus {
    outline: none;
    border-color: #0066cc;
    background-color: white;
}

.filter-button {
    position: relative;
    width: 36px;
    height: 36px;
    padding: 6px;
    border: none;
    border-radius: 8px;
    background: none;
    cursor: pointer;
}

.filter-button:hover {
    background-color: #f5f5f5;
}

.filter-button img {
    width: 100%;
    height: 100%;
}

.filter-count {
    position: absolute;
    top: 0;
    right: 0;
    background: #007aff;
    color: white;
    border-radius: 50%;
    width: 18px;
    height: 18px;
    font-size: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.filters-panel {
    background: white;
    padding: 16px;
    border-bottom: 1px solid #eee;
    transform-origin: top;
    max-height: calc(100vh - 200px);
    overflow-y: auto;
}

.filter-section {
    margin-bottom: 24px;
}

.filter-section:last-child {
    margin-bottom: 0;
}

.filter-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
}

.filter-chip {
    padding: 8px 16px;
    border-radius: 100px;
    border: 1px solid #e7e7e7;
    background: white;
    font-size: 15px;
    color: #333;
    cursor: pointer;
    transition: all 0.2s;
    font-weight: 400;
}

.filter-chip:hover {
    background: #f5f5f5;
}

.filter-chip.active {
    background: #007aff;
    color: white;
    border-color: #007aff;
}

.price-section {
    padding: 0 4px;
}

.price-filter {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.price-label {
    font-size: 15px;
    color: #333;
    font-weight: 400;
}

.price-inputs {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.price-range {
    display: flex;
    align-items: center;
    gap: 8px;
}

.price-prefix {
    color: #333;
    font-size: 15px;
}

.price-currency {
    color: #333;
    font-size: 15px;
    margin-left: 4px;
}

.price-range input {
    width: 70px;
    height: 32px;
    padding: 0 8px;
    border: 1px solid #e7e7e7;
    border-radius: 8px;
    font-size: 15px;
    color: #333;
}

.price-range input:focus {
    outline: none;
    border-color: #007aff;
}

.empty-state {
    text-align: center;
    color: #666;
    margin-top: 32px;
}

.slide-enter-active,
.slide-leave-active {
    transition: all 0.3s ease-out;
}

.slide-enter-from {
    opacity: 0;
    transform: translateY(-20px);
}

.slide-leave-to {
    opacity: 0;
    transform: translateY(-20px);
}

.results-list {
    display: flex;
    flex-direction: column;
    gap: 16px;
    padding: 16px 0;
}

.loading-state {
    text-align: center;
    padding: 2rem;
}

.loading-spinner {
    width: 40px;
    height: 40px;
    border: 3px solid #f3f3f3;
    border-top: 3px solid #007aff;
    border-radius: 50%;
    margin: 0 auto 1rem;
    animation: spin 1s linear infinite;
}

.error-state {
    text-align: center;
    color: #ff3b30;
    padding: 2rem;
}

.empty-state {
    text-align: center;
    color: #666;
    padding: 2rem;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}

.filter-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
}

.filter-header h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    color: #333;
}

.reset-button {
    padding: 6px 12px;
    border: none;
    border-radius: 6px;
    background-color: #f5f5f5;
    color: #666;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.reset-button:hover {
    background-color: #e5e5e5;
    color: #333;
}

.reset-button:active {
    transform: scale(0.98);
}

.pagination-container {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
    position: fixed;
    bottom: 90px;
    left: 0;
    right: 0;
    padding: 16px;
    z-index: 10;
}

.pagination-btn,
.page-number {
    min-width: 32px;
    height: 32px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #ffffff;
    color: #000000;
    font-size: 14px;
    cursor: pointer;
    border-radius: 8px;
    transition: background-color 0.2s;
}

.pagination-btn {
    border: 1px solid #000000;
    padding-bottom: 2px;
}

.page-number {
    border: 1px solid #000000;
}

.pagination-btn:disabled {
    opacity: 0.3;
    cursor: not-allowed;
}

.pagination-btn:not(:disabled):hover,
.page-number:not(.active):hover {
    background: #f1f1f1;
}

.page-numbers {
    display: flex;
    gap: 8px;
}

.page-number.active {
    background: #007aff;
    color: #ffffff;
}
</style>
