import dotenv from 'dotenv';
import fs from 'fs';
import http from 'http';
import https from 'https';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import app from './src/app.js';
import sequelize from './src/config/database.js';

// Настройка путей для загрузки .env из корневой директории
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '../');

// Загрузка переменных окружения
const NODE_ENV = process.env.NODE_ENV || 'development';
const envFile = NODE_ENV === 'production' ? '.env.prod' : '.env.development';
dotenv.config({ path: path.join(rootDir, envFile) });

const PORT = process.env.PORT || 3000;
const HTTPS_PORT = 3443;
const USE_HTTPS =
	(process.env.USE_HTTPS === 'true' || process.env.USE_SSL === 'true') &&
	NODE_ENV === 'production';

let server;

if (USE_HTTPS) {
	// Режим HTTPS для продакшена
	try {
		const certPath = '/etc/letsencrypt/live/pwstore.ru';
		const keyPath = path.join(certPath, 'privkey.pem');
		const certFilePath = path.join(certPath, 'fullchain.pem');

		// Проверяем наличие и доступность файлов сертификатов
		if (fs.existsSync(keyPath) && fs.existsSync(certFilePath)) {
			try {
				const sslOptions = {
					key: fs.readFileSync(keyPath),
					cert: fs.readFileSync(certFilePath),
				};
				const httpsServer = https.createServer(sslOptions, app);
				const httpServer = http.createServer((req, res) => {
					const httpsUrl = `https://${req.headers.host}${req.url}`;
					res.writeHead(301, { Location: httpsUrl });
					res.end();
				});

				server = httpsServer;
				server.listen(HTTPS_PORT, '0.0.0.0', () => {
					console.log(`HTTPS Server running on port ${HTTPS_PORT}`);
				});
				httpServer.listen(PORT, '0.0.0.0', () => {
					console.log(
						`HTTP Server redirecting to HTTPS on port ${PORT}`
					);
				});
			} catch (err) {
				console.error('Error reading SSL certificates:', err);
				console.log('Falling back to HTTP...');
				server = http.createServer(app);
			}
		} else {
			console.log('SSL certificates not found, falling back to HTTP...');
			server = http.createServer(app);
		}
	} catch (err) {
		console.error('Error loading SSL certificates:', err);
		console.log('Falling back to HTTP...');
		server = http.createServer(app);
	}
} else {
	// Режим HTTP для разработки
	server = http.createServer(app);
}

if (!server.listening) {
	server.listen(PORT, '0.0.0.0', () => {
		console.log(`HTTP Server running on port ${PORT}`);
	});
}

// Функция для получения локального IP-адреса
function getLocalIpAddress() {
	const interfaces = os.networkInterfaces();
	for (const interfaceName of Object.keys(interfaces)) {
		for (const iface of interfaces[interfaceName]) {
			if (iface.family === 'IPv4' && !iface.internal) {
				return iface.address;
			}
		}
	}
	return 'localhost';
}

const LOCAL_IP = getLocalIpAddress();

async function startServer() {
	try {
		console.log('Testing database connection...');
		await sequelize.authenticate();
		console.log('Database connection has been established successfully.');

		console.log('Syncing database models...');
		const db = (await import('./src/models/index.js')).default;
		await db.syncModels();
		console.log('Database models synchronized successfully.');

		// Обработка сигналов завершения
		process.on('SIGINT', () => gracefulShutdown('SIGINT'));
		process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
	} catch (error) {
		console.error('Unable to start server:', error);
		process.exit(1);
	}
}

function gracefulShutdown(signal) {
	console.log(`Received ${signal}. Shutting down gracefully.`);
	server.close(() => {
		console.log('Server closed.');
		sequelize
			.close()
			.then(() => {
				console.log('Database connection closed.');
				process.exit(0);
			})
			.catch(err => {
				console.error('Error closing database connection:', err);
				process.exit(1);
			});
	});
}

startServer();
