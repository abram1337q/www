import cron from 'node-cron';
import mailingService from '../services/mailingService.js';
import logger from '../utils/logger.js';

// Флаг для предотвращения параллельного запуска задачи
let isProcessing = false;

// Запускаем проверку каждую минуту
cron.schedule('* * * * *', async () => {
	// Если задача уже выполняется, пропускаем текущий запуск
	if (isProcessing) {
		logger.info('Mailing task is already running, skipping this run');
		return;
	}

	try {
		isProcessing = true;
		logger.info('Starting scheduled mailing check');
		await mailingService.processScheduledMailings();
	} catch (error) {
		logger.error('Error in mailing task:', error);
	} finally {
		isProcessing = false;
		logger.info('Finished scheduled mailing check');
	}
});
