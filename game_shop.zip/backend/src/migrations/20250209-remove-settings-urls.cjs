'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.removeColumn('Settings', 'shop_button_url');
    await queryInterface.removeColumn('Settings', 'help_button_url');
    await queryInterface.removeColumn('Settings', 'reviews_button_url');
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.addColumn('Settings', 'shop_button_url', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'https://default-shop-url.com'
    });
    await queryInterface.addColumn('Settings', 'help_button_url', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'https://default-help-url.com'
    });
    await queryInterface.addColumn('Settings', 'reviews_button_url', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'https://t.me/+e04JICrd2KQ4Nzdi'
    });
  }
};
