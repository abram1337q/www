'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    // Удаляем старые колонки timestamps если они существуют
    try {
      await queryInterface.removeColumn('FeedItemCollections', 'created_at');
      await queryInterface.removeColumn('FeedItemCollections', 'updated_at');
    } catch (error) {
      console.log('Timestamps columns do not exist, skipping removal');
    }

    // Проверяем существование primary key
    try {
      await queryInterface.addConstraint('FeedItemCollections', {
        fields: ['feed_item_id', 'collection_id'],
        type: 'primary key',
        name: 'feed_item_collections_pkey'
      });
    } catch (error) {
      console.log('Primary key already exists, skipping');
    }
  },

  async down(queryInterface, Sequelize) {
    // В случае отката добавляем колонки timestamps обратно
    await queryInterface.addColumn('FeedItemCollections', 'created_at', {
      type: Sequelize.DATE,
      allowNull: false,
      defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
    });

    await queryInterface.addColumn('FeedItemCollections', 'updated_at', {
      type: Sequelize.DATE,
      allowNull: false,
      defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
    });
  }
};
