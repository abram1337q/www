import Edition from '../models/edition.js';
import EditionName from '../models/editionName.js';
import Mailing from '../models/mailing.js';
import ProductCard from '../models/productCard.js';
import ProductCollection from '../models/productCollection.js';
import User from '../models/user.js';
import { branding } from './branding.js';
import { componentLoader, Components } from './componentLoader.js';

import ruLocale from './locales/ruLocale.js';
import { currencyRangeResource } from './resources/currencyRangeResource.js';
import { currencyResource } from './resources/currencyResource.js';
import { editionNameResource } from './resources/editionNameResource.js';
import { editionResource } from './resources/editionResource.js';
import { feedItemResource } from './resources/feedItemResource.js';
import { genreResource } from './resources/genreResource.js';
import { localizationResource } from './resources/localizationResource.js';
import { mailingResource } from './resources/mailingResource.js';
import { paymentResource } from './resources/paymentResource.js';
import { platformResource } from './resources/platformResource.js';
import { productCardResource } from './resources/productCardResource.js';
import { productCollectionResource } from './resources/productCollectionResource.js';
import { promoResource } from './resources/promoResource.js';
import { settingsResource } from './resources/settingsResource.js';
import { userResource } from './resources/userResource.js';

const adminJsOptions = {
	rootPath: '/admin',
	resources: [
		settingsResource,
		platformResource,
		genreResource,
		editionResource,
		productCardResource,
		productCollectionResource,
		editionNameResource,
		localizationResource,
		currencyResource,
		currencyRangeResource,
		mailingResource,
		userResource,
		feedItemResource,
		promoResource,
		paymentResource,
	],
	dashboard: {
		component: Components.Dashboard,
		handler: async () => {
			console.log('Dashboard handler started');
			try {
				const totalProducts = await ProductCard.count();
				console.log('Total products:', totalProducts);
				const totalCollections = await ProductCollection.count();
				console.log('Total collections:', totalCollections);
				const totalMailings = await Mailing.count();
				console.log('Total mailings:', totalMailings);
				const totalUsers = await User.count();
				console.log('Total users:', totalUsers);
				const totalEditions = await Edition.count();
				console.log('Total editions:', totalEditions);
				const totalEditionNames = await EditionName.count();
				console.log('Total edition names:', totalEditionNames);

				console.log('Dashboard data:', {
					totalProducts,
					totalCollections,
					totalMailings,
					totalUsers,
					totalEditions,
					totalEditionNames,
				});

				return {
					totalProducts,
					totalCollections,
					totalMailings,
					totalUsers,
					totalEditions,
					totalEditionNames,
				};
			} catch (error) {
				console.error('Error in dashboard handler:', error);
				return {
					totalProducts: 0,
					totalCollections: 0,
					totalMailings: 0,
					totalUsers: 0,
					totalEditions: 0,
					totalEditionNames: 0,
				};
			}
		},
	},
	branding,
	locale: {
		language: 'en',
		translations: {
			en: ruLocale,
		},
	},
	componentLoader,
	loginComponent: Components.Login,
};

const authOptions = {
	authenticate: async (email, password) => {
		const adminEmail = process.env.ADMIN_EMAIL || 'example@admin.com';
		const adminPassword = process.env.ADMIN_PASSWORD || 'password';
		console.log('Login attempt:', { email, adminEmail });
		if (email === adminEmail && password === adminPassword) {
			console.log('Login successful');
			return Promise.resolve({ email: adminEmail, role: 'admin' });
		}
		console.log('Login failed');
		return null;
	},
	cookieName: 'gameshop_adminjs',
	cookiePassword:
		process.env.ADMIN_COOKIE_SECRET || 'some-long-secure-password',
};

export { adminJsOptions, authOptions, Components };
