import Platform from '../../models/platform.js';
import { uploadFile } from '../../utils/uploadFile.js';
import { createBaseResource } from './baseResource.js';
const baseResource = createBaseResource(Platform);

export const platformResource = {
	...baseResource,
	options: {
		...baseResource.options,
		navigation: {
			name: 'Платформы',
			icon: 'Game',
		},
		properties: {
			id: {
				position: 1,
			},
			name: {
				position: 2,
				isTitle: true,
				isRequired: true,
			},
			icon_url: {
				position: 3,
				isRequired: false,
				components: {
					edit: 'ImageUpload',
					show: 'ImagePreview',
					list: 'ImagePreview',
				},
				isVisible: {
					list: true,
					filter: false,
					show: true,
					edit: true,
				},
			},
			created_at: {
				position: 4,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
			updated_at: {
				position: 5,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
		},
		actions: {
			new: {
				before: async request => {
					const { payload } = request;

					console.log('New platform payload:', payload);

					// Validate required fields
					if (!payload.name) {
						throw new Error('Название платформы обязательно');
					}

					// Handle file upload
					if (payload['icon_url.file']) {
						try {
							const fileData = {
								name: payload['icon_url.name'],
								size: payload['icon_url.size'],
								type: payload['icon_url.mime'],
								file: payload['icon_url.file'],
							};
							console.log('Trying to upload file:', fileData);
							const uploadPath = await uploadFile(
								fileData,
								'platforms'
							);

							delete payload['icon_url.name'];
							delete payload['icon_url.size'];
							delete payload['icon_url.mime'];
							delete payload['icon_url.file'];
							payload.icon_url = uploadPath;
						} catch (error) {
							console.error('Error uploading file:', error);
							throw new Error('Ошибка при загрузке файла');
						}
					}

					return request;
				},
			},
			edit: {
				before: async request => {
					const { payload } = request;

					if (!payload.name) {
						throw new Error('Название платформы обязательно');
					}

					// Handle file upload
					if (payload['icon_url.file']) {
						// Если это новый файл
						if (payload['icon_url.path']) {
							try {
								const fileData = {
									name: payload['icon_url.name'],
									size: payload['icon_url.size'],
									type: payload['icon_url.mime'],
									file: payload['icon_url.file'],
								};
								console.log('Trying to upload file:', fileData);
								const uploadPath = await uploadFile(
									fileData,
									'platforms'
								);

								delete payload['icon_url.name'];
								delete payload['icon_url.size'];
								delete payload['icon_url.mime'];
								delete payload['icon_url.file'];
								payload.icon_url = uploadPath;
							} catch (error) {
								console.error('Error uploading file:', error);
								throw new Error('Ошибка при загрузке файла');
							}
						}
						// Если это строка с URL, оставляем как есть
						else if (typeof payload['icon_url'] === 'string') {
							payload.icon_url = payload['icon_url'];
						}
						// Если что-то другое, очищаем
						else {
							payload.icon_url = null;
						}
					}

					return request;
				},
			},
		},
	},
};
