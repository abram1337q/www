import EditionName from '../../models/editionName.js';

export const editionNameResource = {
	resource: EditionName,
	options: {
		navigation: {
			name: 'Названия изданий',
			icon: 'Tag',
		},
		properties: {
			id: {
				position: 1,
			},
			name: {
				position: 2,
				isTitle: true,
				isRequired: true,
			},
			created_at: {
				position: 3,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
			updated_at: {
				position: 4,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
		},
		actions: {
			new: {
				isAccessible: true,
			},
			edit: {
				isAccessible: true,
			},
			delete: {
				isAccessible: true,
			},
		},
	},
};
