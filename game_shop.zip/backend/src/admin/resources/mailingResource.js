import Mailing from '../../models/mailing.js';
import mailingService from '../../services/mailingService.js';
import ImageShow from '../components/ImageShow.jsx';
import { beforeUpdateHook } from '../hooks.js';

const handleValidationError = record => {
  if (!record) return;

  console.log('Validation check for record:', record);
  console.log('Current time:', new Date());
  if (record.params.scheduledAt) {
    console.log('Scheduled time:', new Date(record.params.scheduledAt));
  }

  const errors = [];

  // Проверяем обязательные поля
  if (!record.params.content) {
    errors.push('Содержание рассылки обязательно');
  }

  // Проверяем статус и дату для scheduled
  if (record.params.status === 'scheduled') {
    if (!record.params.scheduledAt) {
      errors.push('Для запланированной рассылки необходимо указать дату');
    } else {
      const scheduledDate = new Date(record.params.scheduledAt);
      const now = new Date();

      // Преобразуем обе даты в UTC для корректного сравнения
      const scheduledUTC = Date.UTC(
        scheduledDate.getUTCFullYear(),
        scheduledDate.getUTCMonth(),
        scheduledDate.getUTCDate(),
        scheduledDate.getUTCHours(),
        scheduledDate.getUTCMinutes(),
        scheduledDate.getUTCSeconds()
      );

      const nowUTC = Date.UTC(
        now.getUTCFullYear(),
        now.getUTCMonth(),
        now.getUTCDate(),
        now.getUTCHours(),
        now.getUTCMinutes(),
        now.getUTCSeconds()
      );

      if (scheduledUTC <= nowUTC) {
        errors.push('Дата отправки должна быть в будущем');
      }
    }
  }

  // Проверяем URL изображения, если оно есть
  if (record.params.imageUrl) {
    try {
      new URL(record.params.imageUrl);
    } catch (e) {
      errors.push('Некорректный URL изображения');
    }
  }

  if (errors.length > 0) {
    throw new Error(errors.join(', '));
  }
};

export const mailingResource = {
  resource: Mailing,
  options: {
    id: 'Mailings',
    navigation: {
      name: 'Рассылки',
      icon: 'Email',
    },
    properties: {
      content: {
        type: 'richtext',
        label: 'Содержание',
        isVisible: {
          list: false,
          filter: false,
          show: true,
          edit: true,
        },
        custom: {
          maxLength: 4096,
        },
      },
      imageUrl: {
        isVisible: { list: true, filter: true, show: true, edit: true },
        components: { show: ImageShow },
        label: 'URL изображения',
      },
      buttonEnabled: {
        type: 'boolean',
        label: 'Добавить кнопку',
        isVisible: {
          list: false,
          filter: false,
          show: true,
          edit: true,
        },
      },
      buttonText: {
        type: 'string',
        label: 'Текст кнопки',
        isVisible: {
          list: false,
          filter: false,
          show: true,
          edit: true,
        },
        custom: {
          maxLength: 64,
        },
      },
      buttonUrl: {
        type: 'string',
        label: 'Ссылка кнопки',
        isVisible: {
          list: false,
          filter: false,
          show: true,
          edit: true,
        },
        custom: {
          maxLength: 512,
        },
      },
      testTelegramId: {
        type: 'string',
        label: 'Тестовая отправка (Telegram ID)',
        isVisible: {
          list: false,
          filter: false,
          show: true,
          edit: true,
        },
        custom: {
          maxLength: 64,
        },
      },
      status: {
        type: 'select',
        label: 'Статус',
        availableValues: [
          { value: 'draft', label: 'Черновик' },
          { value: 'scheduled', label: 'Запланирована' },
          { value: 'processing', label: 'Отправляется' },
          { value: 'sent', label: 'Отправлена' },
          { value: 'cancelled', label: 'Отменена' },
          { value: 'error', label: 'Ошибка' },
        ],
      },
      scheduledAt: {
        type: 'datetime',
        label: 'Запланировано на',
        isVisible: {
          list: true,
          filter: true,
          show: true,
          edit: true,
        },
      },
      sentAt: {
        type: 'datetime',
        label: 'Отправлено',
        isVisible: {
          edit: false,
          list: true,
          show: true,
          filter: true,
        },
      },
      createdBy: {
        isVisible: false,
      },
    },
    actions: {
      new: {
        before: async request => {
          console.log('Before creating mailing:', request.payload);
          return request;
        },
        after: async (response, request) => {
          console.log('After creating mailing. Response:', response);
          if (response.record && response.record.errors) {
            console.error(
              'Validation errors:',
              response.record.errors
            );
          }
          return response;
        },
        handler: async (request, response, context) => {
          try {
            const result = await context.resource.create(
              request.payload
            );
            console.log('Create result:', result);

            return {
              record: result.params || result,
              redirectUrl: context.h.resourceActionUrl({
                resourceId: context.resource.id(),
                actionName: 'list',
              }),
            };
          } catch (error) {
            console.error('Error creating mailing:', error);
            throw error;
          }
        },
      },
      edit: {
        before: async (request, context) => {
          console.log('Edit request:', request);
          return beforeUpdateHook(request, context);
        },
        after: async (response, request, context) => {
          console.log('Edit response:', response);
          try {
            handleValidationError(response.record);
            return response;
          } catch (error) {
            console.error('Error in edit:', error);
            throw error;
          }
        },
      },
      sendNow: {
        actionType: 'record',
        icon: 'Send',
        label: 'Отправить сейчас',
        component: false,
        handler: async (request, response, context) => {
          const { record, currentAdmin } = context;
          try {
            if (!record.params.content) {
              throw new Error(
                'Содержание рассылки не может быть пустым'
              );
            }

            await mailingService.sendMailingNow(record.params.id);
            return {
              record: record.toJSON(currentAdmin),
              notice: {
                message: 'Рассылка успешно отправлена',
                type: 'success',
              },
            };
          } catch (error) {
            console.error('Error in sendNow:', error);
            return {
              record: record.toJSON(currentAdmin),
              notice: {
                message:
                  error.message ||
                  'Ошибка при отправке рассылки',
                type: 'error',
              },
            };
          }
        },
        isVisible: context => {
          return (
            ['draft', 'scheduled', 'error'].includes(
              context.record?.params?.status
            ) && context.record?.params?.status !== 'processing'
          );
        },
      },
    },
    listProperties: [
      'content',
      'imageUrl',
      'status',
      'scheduledAt',
      'sentAt',
    ],
    filterProperties: ['status', 'scheduledAt', 'sentAt'],
    editProperties: [
      'content',
      'imageUrl',
      'buttonEnabled',
      'buttonText',
      'buttonUrl',
      'testTelegramId',
      'status',
      'scheduledAt',
    ],
    showProperties: [
      'content',
      'imageUrl',
      'buttonEnabled',
      'buttonText',
      'buttonUrl',
      'testTelegramId',
      'status',
      'scheduledAt',
      'sentAt',
    ],
  },
};
