import { uploadFile } from '../../utils/uploadFile.js';

export const createBaseResource = (resource) => {
  return {
    resource,
    options: {
      properties: {},
      actions: {
        new: {
          before: async (request) => {
            const { payload } = request;
            const modifiedPayload = { ...payload };

            // Handle file uploads for all image fields
            for (const [key, value] of Object.entries(payload)) {
              if (value instanceof Object && value.type === 'file') {
                const uploadPath = await uploadFile(value, resource.name.toLowerCase());
                modifiedPayload[key] = uploadPath;
              }
            }

            request.payload = modifiedPayload;
            return request;
          }
        },
        edit: {
          before: async (request) => {
            const { payload } = request;
            const modifiedPayload = { ...payload };

            // Handle file uploads for all image fields
            for (const [key, value] of Object.entries(payload)) {
              if (value instanceof Object && value.type === 'file') {
                const uploadPath = await uploadFile(value, resource.name.toLowerCase());
                modifiedPayload[key] = uploadPath;
              }
            }

            request.payload = modifiedPayload;
            return request;
          }
        }
      }
    }
  };
};
