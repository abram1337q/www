import { Op, Sequelize } from 'sequelize';
import Edition from '../../models/edition.js';

// Функция для расчета процента скидки
const calculateDiscountPercentage = (price, discountAmount) => {
    if (!price || !discountAmount) return 0;
    // Если discount_amount - это цена со скидкой, то процент скидки рассчитывается иначе
    return Math.round(((price - discountAmount) / price) * 100);
};

const handleLocalizations = async (response, request, context) => {
    try {
        const { record } = context;

        const localizationIds = Object.entries(record.params)
            .filter(([key]) => key.startsWith('localizations.'))
            .map(([_, value]) => value)
            .filter(Boolean);

        console.log('handleLocalizations called with:', {
            recordId: record.params.id,
            recordParams: record.params,
            localizationIds,
        });

        if (localizationIds.length > 0) {
            const edition = await Edition.findByPk(record.params.id, {
                include: [
                    {
                        association: 'localizations',
                        through: { attributes: [] },
                    },
                ],
            });

            if (edition) {
                console.log('Setting localizations:', {
                    editionId: edition.id,
                    localizationIds,
                });

                // Используем raw query для отладки
                const sequelize = Edition.sequelize;
                const [results] = await sequelize.query(
                    `SELECT * FROM edition_localizations WHERE edition_id = ${edition.id}`
                );
                console.log('Current edition_localizations:', results);

                // Сначала удаляем все существующие связи
                await sequelize.query(
                    `DELETE FROM edition_localizations WHERE edition_id = ${edition.id}`
                );

                // Добавляем новые связи с правильными полями
                for (const localizationId of localizationIds) {
                    await sequelize.query(
                        `INSERT INTO edition_localizations
                        (edition_id, localization_id, "createdAt", "updatedAt")
                        VALUES (${edition.id}, ${localizationId}, NOW(), NOW())`
                    );
                }

                const updatedEdition = await Edition.findByPk(
                    record.params.id,
                    {
                        include: [
                            {
                                association: 'localizations',
                                through: { attributes: [] },
                            },
                        ],
                    }
                );

                console.log('Updated edition localizations:', {
                    editionId: updatedEdition.id,
                    localizations: updatedEdition.localizations,
                });
            } else {
                console.error('Edition not found:', record.params.id);
            }
        } else {
            console.log('No localizations provided in params:', record.params);
        }
        return response;
    } catch (error) {
        console.error('Error in handleLocalizations:', error);
        // Не пробрасываем ошибку дальше, а возвращаем оригинальный ответ
        // Это предотвратит отображение ошибки в AdminJS, но запись все равно будет создана
        return response;
    }
};

const handleCollections = async (response, request, context) => {
    try {
        const { record } = context;

        // Собираем все коллекции из параметров
        // ВАЖНО: Исключаем showcase_collection_id - это НЕ основная коллекция!
        const collectionIds = Object.entries(record.params)
            .filter(([key]) => key.startsWith('collections.') && key !== 'showcase_collection_id')
            .map(([_, value]) => value)
            .filter(Boolean);

        console.log('handleCollections called with:', {
            recordId: record.params.id,
            recordParams: record.params,
            collectionIds,
            showcase_collection_id: record.params.showcase_collection_id, // для дебага
        });

        if (collectionIds.length > 0) {
            const edition = await Edition.findByPk(record.params.id, {
                include: ['collections'],
            });

            if (edition) {
                console.log('Setting collections:', {
                    editionId: edition.id,
                    collectionIds,
                });

                await edition.setCollections(collectionIds);

                // Проверяем, что коллекции были установлены
                const updatedEdition = await Edition.findByPk(
                    record.params.id,
                    {
                        include: ['collections'],
                    }
                );

                console.log('Updated edition collections:', {
                    editionId: updatedEdition.id,
                    collections: updatedEdition.collections,
                });
            } else {
                console.error('Edition not found:', record.params.id);
            }
        } else {
            console.log('No collections provided in params:', record.params);
        }
        return response;
    } catch (error) {
        console.error('Error in handleCollections:', error);
        // Не пробрасываем ошибку дальше, а возвращаем оригинальный ответ
        // Это предотвратит отображение ошибки в AdminJS, но запись все равно будет создана
        return response;
    }
};

const handlePlatforms = async (response, request, context) => {
    try {
        const { record } = context;

        // Собираем все платформы из параметров
        const platformIds = Object.entries(record.params)
            .filter(([key]) => key.startsWith('platforms.'))
            .map(([_, value]) => value)
            .filter(Boolean);

        console.log('handlePlatforms called with:', {
            recordId: record.params.id,
            recordParams: record.params,
            platformIds,
        });

        if (platformIds.length > 0) {
            const edition = await Edition.findByPk(record.params.id, {
                include: ['platforms'],
            });

            if (edition) {
                console.log('Setting platforms:', {
                    editionId: edition.id,
                    platformIds,
                });

                await edition.setPlatforms(platformIds, {
                    ignoreDuplicates: true,
                });

                // Проверяем, что платформы были установлены
                const updatedEdition = await Edition.findByPk(
                    record.params.id,
                    {
                        include: ['platforms'],
                    }
                );

                console.log('Updated edition platforms:', {
                    editionId: updatedEdition.id,
                    platforms: updatedEdition.platforms,
                });
            } else {
                console.error('Edition not found:', record.params.id);
            }
        } else {
            console.log('No platforms provided in params:', record.params);
        }
        return response;
    } catch (error) {
        console.error('Error in handlePlatforms:', error);
        // Не пробрасываем ошибку дальше, а возвращаем оригинальный ответ
        // Это предотвратит отображение ошибки в AdminJS, но запись все равно будет создана
        return response;
    }
};

const handleUpdateInfo = async (response, request, context) => {
    try {
        const { record } = context;
        const editionId = record.params.id;
        const source = record.params.source;
        const productStoreUrl = record.params.product_store_url;
        const displayCurrencyId = record.params.display_currency_id;

        console.log('handleUpdateInfo called with:', {
            editionId,
            source,
            productStoreUrl,
            displayCurrencyId,
        });

        // Проверяем, что есть ID записи
        if (!editionId) {
            console.log('No edition ID available yet, skipping update_info handling');
            return response;
        }

        // Работаем только с manual записями
        if (source !== 'manual') {
            console.log('Not a manual record, skipping update_info handling');
            return response;
        }

        const sequelize = Edition.sequelize;

        if (productStoreUrl && productStoreUrl.trim() !== '') {
            // === ЕСТЬ ССЫЛКА - ДОБАВЛЯЕМ В update_info ===
            // Галочка allow_auto_update контролирует обновление отдельно (в триггере/update.py)

            if (!displayCurrencyId) {
                throw new Error('❌ Укажите валюту отображения (display_currency_id) для добавления в update_info!');
            }

            // Извлекаем SKU из ссылки (последняя часть URL после последнего /)
            // Пример: https://store.playstation.com/ru-ua/product/EP9000-CUSA00123_00-GAMENAME0000000
            const urlParts = productStoreUrl.trim().split('/').filter(part => part.length > 0);
            const productId = urlParts[urlParts.length - 1];

            if (!productId || productId.length === 0) {
                throw new Error('❌ Не удалось извлечь ID товара из ссылки. Проверьте формат ссылки!');
            }

            console.log('Extracted product ID:', productId);

            // Используем параметризованные запросы для безопасности
            // QueryTypes.SELECT возвращает массив строк напрямую
            const existing = await sequelize.query(
                'SELECT * FROM update_info WHERE edition_id = $1 AND currency = $2',
                {
                    bind: [editionId, displayCurrencyId],
                    type: sequelize.QueryTypes.SELECT
                }
            );

            if (existing && existing.length > 0) {
                // Обновляем существующую запись
                await sequelize.query(
                    'UPDATE update_info SET id = $1 WHERE edition_id = $2 AND currency = $3',
                    {
                        bind: [productId, editionId, displayCurrencyId]
                    }
                );
                console.log('✅ Updated update_info record:', {
                    productId,
                    editionId,
                    currencyId: displayCurrencyId,
                });
            } else {
                // Создаем новую запись
                await sequelize.query(
                    'INSERT INTO update_info (id, edition_id, currency) VALUES ($1, $2, $3)',
                    {
                        bind: [productId, editionId, displayCurrencyId]
                    }
                );
                console.log('✅ Created update_info record:', {
                    productId,
                    editionId,
                    currencyId: displayCurrencyId,
                });
            }

            console.log('💡 Галочка allow_auto_update контролирует, будет ли update.py обновлять этот товар');
        } else {
            // === НЕТ ССЫЛКИ - УДАЛЯЕМ ИЗ update_info ===

            await sequelize.query(
                'DELETE FROM update_info WHERE edition_id = $1',
                {
                    bind: [editionId]
                }
            );

            console.log('🗑️ Removed from update_info (no product_store_url):', {
                editionId
            });
        }

        return response;
    } catch (error) {
        console.error('Error in handleUpdateInfo:', error);
        // Пробрасываем ошибку, чтобы пользователь увидел сообщение
        throw error;
    }
};

const handleShowcase = async (response, request, context) => {
    try {
        const { record } = context;
        const editionId = record.params.id;
        const showInShowcase = record.params.show_in_showcase === 'true' || record.params.show_in_showcase === true;
        const showcaseCollectionId = record.params.showcase_collection_id;

        console.log('handleShowcase called with:', {
            editionId,
            showInShowcase,
            showcaseCollectionId,
            type: typeof record.params.show_in_showcase,
            value: record.params.show_in_showcase,
        });

        if (!editionId) {
            console.log('No edition ID, skipping showcase handling');
            return response;
        }

        const sequelize = Edition.sequelize;
        const { CollectionShowcaseEdition } = sequelize.models;

        // Получаем информацию об издании (нужен display_currency_id)
        const edition = await Edition.findByPk(editionId);
        if (!edition) {
            console.error('Edition not found:', editionId);
            return response;
        }

        const currencyId = edition.display_currency_id;
        if (!currencyId) {
            console.log('Edition has no display_currency_id, skipping showcase');
            return response;
        }

        if (showInShowcase) {
            // === ВКЛЮЧЕНА ГАЛОЧКА - ДОБАВЛЯЕМ В ВИТРИНУ ===

            // Проверяем, выбрана ли коллекция
            if (!showcaseCollectionId) {
                throw new Error('Выберите коллекцию для витрины!');
            }

            const collectionId = showcaseCollectionId;

            // Проверяем, есть ли уже этот товар в витрине ЭТОЙ коллекции (на любой позиции)
            const existingInThisCollection = await CollectionShowcaseEdition.findOne({
                where: {
                    edition_id: editionId,
                    collection_id: collectionId,
                    currency_id: currencyId,
                },
            });

            if (existingInThisCollection) {
                console.log('Edition already in this collection showcase, updating fields');
                // Товар уже в витрине этой коллекции - просто обновляем поля
                await edition.update({
                    show_in_showcase: true,
                    showcase_collection_id: collectionId,
                });
                return response;
            }

            // Проверяем, сколько уже товаров в витрине для этой коллекции и региона
            const showcaseCount = await CollectionShowcaseEdition.count({
                where: {
                    collection_id: collectionId,
                    currency_id: currencyId,
                },
            });

            if (showcaseCount >= 3) {
                throw new Error(`В витрине этой коллекции для этого региона уже 3 товара. Сначала удалите один из существующих.`);
            }

            // Проверяем, есть ли товар в основной коллекции
            const editionWithCollections = await Edition.findByPk(editionId, {
                include: ['collections'],
            });

            const isInMainCollection = editionWithCollections.collections.some(c => c.id === collectionId);
            console.log('Edition in main collection?', isInMainCollection);

            // Если товара НЕТ в основной коллекции - добавляем его туда
            if (!isInMainCollection) {
                await editionWithCollections.addCollection(collectionId);
                console.log('Added edition to main collection (it was not there before)');
            }

            // Удаляем этот товар из витрины других коллекций для ЭТОГО региона (если был добавлен)
            await CollectionShowcaseEdition.destroy({
                where: {
                    edition_id: editionId,
                    currency_id: currencyId,
                    // Не удаляем из текущей коллекции, только из других
                },
            });
            console.log('Removed edition from other collection showcases for this region (if any)');

            // Находим следующую свободную позицию
            const usedPositions = await CollectionShowcaseEdition.findAll({
                where: {
                    collection_id: collectionId,
                    currency_id: currencyId,
                },
                attributes: ['position'],
            });

            const usedPositionNumbers = usedPositions.map(p => p.position);
            let position = 1;
            while (usedPositionNumbers.includes(position) && position <= 3) {
                position++;
            }

            // Создаем запись в таблице витрины
            await CollectionShowcaseEdition.create({
                collection_id: collectionId,
                edition_id: editionId,
                currency_id: currencyId,
                position: position,
                was_in_collection_before: isInMainCollection,  // Запоминаем, был ли товар в коллекции
            });

            // Обновляем поля в модели Edition
            await edition.update({
                show_in_showcase: true,
                showcase_collection_id: collectionId,
            });

            console.log('Added to showcase:', {
                collectionId,
                editionId,
                currencyId,
                position,
                was_in_collection_before: isInMainCollection,
            });
        } else {
            // === ГАЛОЧКА СНЯТА - УДАЛЯЕМ ИЗ ВИТРИНЫ ===

            // Сначала получаем записи витрины для проверки флага was_in_collection_before
            const showcaseEntries = await CollectionShowcaseEdition.findAll({
                where: {
                    edition_id: editionId,
                    currency_id: currencyId,
                },
            });

            console.log(`Found ${showcaseEntries.length} showcase entries to remove`);

            // Удаляем из основной коллекции, если товар НЕ был там изначально
            for (const entry of showcaseEntries) {
                if (!entry.was_in_collection_before) {
                    const editionWithCollections = await Edition.findByPk(editionId, {
                        include: ['collections'],
                    });

                    // Удаляем из основной коллекции
                    await editionWithCollections.removeCollection(entry.collection_id);
                    console.log(`Removed edition from main collection ${entry.collection_id} (was not there before)`);
                } else {
                    console.log(`Keeping edition in main collection ${entry.collection_id} (was there before)`);
                }
            }

            // Удаляем ВСЕ записи этого издания из витрины для ЭТОГО региона
            const deletedCount = await CollectionShowcaseEdition.destroy({
                where: {
                    edition_id: editionId,
                    currency_id: currencyId,
                },
            });

            console.log(`Removed edition from showcase for this region (deleted ${deletedCount} entries)`);

            // Обновляем поля в модели Edition
            await edition.update({
                show_in_showcase: false,
                showcase_collection_id: null,
            });
        }

        return response;
    } catch (error) {
        console.error('Error in handleShowcase:', error);
        // Пробрасываем ошибку, чтобы пользователь увидел сообщение
        throw error;
    }
};

export const editionResource = {
    resource: Edition,
    options: {
        navigation: {
            name: 'Издания',
            icon: 'Box',
        },
        properties: {
            id: {
                position: 1,
            },
            is_hidden: {
                position: 2,
                type: 'boolean',
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: '🚫 Скрыть издание от пользователей в TMA (издание останется в базе данных)',
            },
            edition_name_id: {
                position: 3,
                isRequired: true,
                type: 'reference',
                reference: 'EditionNames',
            },
            description: {
                position: 4,
                type: 'textarea',
                isRequired: true,
                custom: {
                    rows: 10,
                    placeholder:
                        'Введите описание издания...\nПример форматирования:\n\nПервый абзац\n\nВторой абзац\n\nТретий абзац',
                },
                description:
                    'Используйте двойной Enter между абзацами для лучшей читаемости текста на странице игры.',
                isTitle: false,
            },
            product_card_id: {
                position: 5,
                isRequired: true,
                type: 'reference',
                reference: 'ProductCards',
            },
            price: {
                position: 6,
                type: 'number',
                isRequired: true,
            },
            platforms: {
                position: 6,
                type: 'reference',
                reference: 'Platforms',
                isArray: true,
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: 'Выберите платформы для издания',
            },
            localizations: {
                position: 7,
                type: 'reference',
                reference: 'Localizations',
                isArray: true,
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: 'Выберите локализации для издания',
            },
            display_currency_id: {
                position: 8,
                type: 'reference',
                reference: 'Currencies',
            },
            image_url: {
                position: 9,
                type: 'string',
                isVisible: {
                    list: false,
                    filter: false,
                    show: true,
                    edit: true,
                },
                description: '🖼️ URL изображения для этого издания. Если пусто, используется изображение из ProductCard.',
            },
            collections: {
                position: 10,
                type: 'reference',
                reference: 'ProductCollections',
                isArray: true,
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: 'Коллекции, в которых участвует издание',
            },
            discount_amount: {
                position: 11,
                type: 'number',
                description:
                    'Цена со скидкой (финальная цена товара с учетом скидки)',
            },
            discount_percentage: {
                position: 12,
                type: 'number',
                isVisible: {
                    list: false,
                    filter: false,
                    show: false,
                    edit: true,
                },
                description:
                    'Процент скидки (например, 20 для скидки в 20%). При заполнении автоматически рассчитает цену со скидкой.',
            },
            ea_play_price: {
                position: 13,
                type: 'number',
            },
            ps_plus_price: {
                position: 14,
                type: 'number',
            },
            promotion_end_date: {
                position: 15,
                type: 'datetime',
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: 'Дата окончания акции для обычной скидки',
            },
            ps_plus_promotion_end_date: {
                position: 16,
                type: 'datetime',
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: 'Дата окончания акции для PS Plus скидки',
            },

            created_at: {
                position: 17,
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: false,
                },
            },
            updated_at: {
                position: 18,
                isVisible: {
                    list: false,
                    filter: false,
                    show: true,
                    edit: false,
                },
            },
            source: {
                position: 18,
                type: 'string',
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: false,
                },
                description: 'Источник добавления: parser или manual',
            },
            final_price: {
                position: 19,
                type: 'number',
                isVisible: {
                    list: true,
                    filter: false,
                    show: true,
                    edit: false,
                },
                description: 'Финальная цена с учетом скидки',
                isVirtual: true,
                components: {
                    list: admin => {
                        const { record } = admin;
                        const price = parseFloat(record.params.price) || 0;
                        const discountAmount =
                            parseFloat(record.params.discount_amount) || 0;

                        // Если есть discount_amount, возвращаем его, иначе возвращаем обычную цену
                        return discountAmount > 0
                            ? discountAmount.toFixed(2)
                            : price.toFixed(2);
                    },
                    show: admin => {
                        const { record } = admin;
                        const price = parseFloat(record.params.price) || 0;
                        const discountAmount =
                            parseFloat(record.params.discount_amount) || 0;

                        // Если есть discount_amount, возвращаем его, иначе возвращаем обычную цену
                        return discountAmount > 0
                            ? discountAmount.toFixed(2)
                            : price.toFixed(2);
                    },
                },
            },
            show_in_showcase: {
                position: 20,
                type: 'boolean',
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: 'Показывать в витрине коллекции (максимум 3 товара для каждого региона)',
            },
            showcase_collection_id: {
                position: 21,
                type: 'reference',  // ← Оставляем reference для UI
                reference: 'ProductCollections',
                isVisible: {
                    list: false,
                    filter: false,
                    show: true,
                    edit: true,
                },
                description: 'Выберите коллекцию для витрины (обязательно если включена витрина). ВАЖНО: Товар НЕ добавится в основную коллекцию, только в витрину!',
            },
            lock_price: {
                position: 22,
                type: 'boolean',
                isVisible: {
                    list: false,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: '🔒 Фиксация обычной цены. Если включено - парсер НЕ СМОЖЕТ изменить обычную цену (price). Промокоды продолжают работать.',
            },
            lock_discount_price: {
                position: 23,
                type: 'boolean',
                isVisible: {
                    list: false,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: '🔒 Фиксация цены со скидкой. Если включено - парсер НЕ СМОЖЕТ изменить цену со скидкой (discount_amount). Промокоды продолжают работать.',
            },
            lock_ps_plus_price: {
                position: 24,
                type: 'boolean',
                isVisible: {
                    list: false,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: '🔒 Фиксация цены PS Plus. Если включено - парсер НЕ СМОЖЕТ изменить цену PS Plus (ps_plus_price). Промокоды продолжают работать.',
            },
            lock_ea_play_price: {
                position: 25,
                type: 'boolean',
                isVisible: {
                    list: false,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: '🔒 Фиксация цены EA Play. Если включено - парсер НЕ СМОЖЕТ изменить цену EA Play (ea_play_price). Промокоды продолжают работать.',
            },
            allow_auto_update: {
                position: 26,
                type: 'boolean',
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: '✅ Разрешить автообновление цен. Если включено - update.py БУДЕТ обновлять цены этого товара. Если выключено - товар будет в update_info, но цены НЕ будут обновляться. ⚠️ Работает ТОЛЬКО для manual записей (source = manual)!',
            },
            product_store_url: {
                position: 27,
                type: 'string',
                isVisible: {
                    list: false,
                    filter: false,
                    show: true,
                    edit: true,
                },
                description: '🔗 Ссылка на товар в PlayStation Store. При наличии ссылки товар АВТОМАТИЧЕСКИ добавится в update_info (независимо от галочки allow_auto_update). Галочка контролирует только сам процесс обновления. Пример: https://store.playstation.com/ru-ua/product/EP9000-CUSA00123_00-GAMENAME0000000',
            },
        },
        actions: {
            new: {
                after: [
                    handleLocalizations,
                    handleCollections,
                    handlePlatforms,
                    handleShowcase,
                    handleUpdateInfo,
                    async (response, request, context) => {
                        // Если есть цена и цена со скидкой, рассчитываем процент скидки для отображения
                        if (response.record && response.record.params) {
                            const price = parseFloat(
                                response.record.params.price
                            );
                            const discountAmount = parseFloat(
                                response.record.params.discount_amount
                            );

                            if (
                                !isNaN(price) &&
                                !isNaN(discountAmount) &&
                                price > 0 &&
                                discountAmount > 0 &&
                                discountAmount < price // Цена со скидкой должна быть меньше обычной цены
                            ) {
                                // Рассчитываем процент скидки
                                const discountPercentage = Math.round(
                                    ((price - discountAmount) / price) * 100
                                );
                                response.record.params.discount_percentage =
                                    discountPercentage;

                                console.log(
                                    'Рассчитан процент скидки для новой записи:',
                                    {
                                        originalPrice: price,
                                        discountedPrice: discountAmount,
                                        discountPercentage,
                                    }
                                );
                            }
                        }

                        return response;
                    },
                ],
                before: async (request, context) => {
                    console.log('Edition new - payload:', request.payload);

                    // Устанавливаем source='manual' для записей, создаваемых через админку
                    request.payload.source = 'manual';

                    // Проверяем и обрабатываем цену со скидкой
                    if (request.payload.price !== undefined) {
                        const price = parseFloat(request.payload.price);

                        // Если указан процент скидки, рассчитываем цену со скидкой
                        if (
                            request.payload.discount_percentage !== undefined &&
                            request.payload.discount_percentage !== ''
                        ) {
                            const discountPercentage = parseFloat(
                                request.payload.discount_percentage
                            );
                            if (
                                !isNaN(discountPercentage) &&
                                discountPercentage > 0
                            ) {
                                // Рассчитываем цену со скидкой
                                const discountAmount =
                                    price * (1 - discountPercentage / 100);
                                request.payload.discount_amount =
                                    discountAmount.toFixed(2);
                                console.log(
                                    'Рассчитана цена со скидкой по проценту:',
                                    {
                                        originalPrice: price,
                                        discountPercentage,
                                        discountedPrice:
                                            request.payload.discount_amount,
                                    }
                                );
                            } else if (
                                discountPercentage === 0 ||
                                request.payload.discount_percentage === ''
                            ) {
                                // Если процент скидки равен 0 или пустой, удаляем скидку
                                request.payload.discount_amount = null;
                                console.log(
                                    'Скидка удалена, так как процент скидки равен 0 или пустой'
                                );
                            }
                        }

                        // Если указана цена со скидкой, проверяем её корректность
                        if (request.payload.discount_amount !== undefined) {
                            // Проверяем на пустую строку или null и устанавливаем null
                            if (
                                request.payload.discount_amount === '' ||
                                request.payload.discount_amount === null
                            ) {
                                request.payload.discount_amount = null;
                                console.log(
                                    'Скидка удалена, так как цена со скидкой пустая'
                                );
                            } else {
                                const discountAmount = parseFloat(
                                    request.payload.discount_amount
                                );

                                // Проверяем, что цена со скидкой не больше обычной цены
                                if (discountAmount > price) {
                                    request.payload.discount_amount = price;
                                    console.log(
                                        'Цена со скидкой была больше обычной цены, установлена равной обычной цене:',
                                        price
                                    );
                                }

                                console.log('Установлена цена со скидкой:', {
                                    originalPrice: price,
                                    discountedPrice:
                                        request.payload.discount_amount,
                                });
                            }
                        }
                    }

                    // Если дата окончания акции пустая или null, удаляем скидку
                    if (
                        request.payload.promotion_end_date === '' ||
                        request.payload.promotion_end_date === null
                    ) {
                        request.payload.discount_amount = null;
                        console.log(
                            'Скидка удалена, так как дата окончания акции пустая'
                        );
                    }

                    // Очищаем поля ea_play_price и ps_plus_price, если они пустые или null
                    if (
                        request.payload.ea_play_price === '' ||
                        request.payload.ea_play_price === null
                    ) {
                        request.payload.ea_play_price = null;
                        console.log(
                            'EA Play цена очищена, так как поле пустое'
                        );
                    }

                    if (
                        request.payload.ps_plus_price === '' ||
                        request.payload.ps_plus_price === null
                    ) {
                        request.payload.ps_plus_price = null;
                        request.payload.ps_plus_promotion_end_date = null;
                        console.log(
                            'PS Plus цена очищена, так как поле пустое'
                        );
                    }

                    // Если дата окончания акции для PS Plus пустая или null, удаляем дату
                    if (
                        request.payload.ps_plus_promotion_end_date === '' ||
                        request.payload.ps_plus_promotion_end_date === null
                    ) {
                        request.payload.ps_plus_promotion_end_date = null;
                        console.log(
                            'PS Plus дата акции очищена, так как поле пустое'
                        );
                    }

                    return request;
                },
            },
            edit: {
                after: [
                    handleLocalizations,
                    handleCollections,
                    handlePlatforms,
                    handleShowcase,
                    handleUpdateInfo,
                    async (response, request, context) => {
                        // Если есть цена и цена со скидкой, рассчитываем процент скидки для отображения
                        if (response.record && response.record.params) {
                            const price = parseFloat(
                                response.record.params.price
                            );
                            const discountAmount = parseFloat(
                                response.record.params.discount_amount
                            );

                            if (
                                !isNaN(price) &&
                                !isNaN(discountAmount) &&
                                price > 0 &&
                                discountAmount > 0 &&
                                discountAmount < price // Цена со скидкой должна быть меньше обычной цены
                            ) {
                                // Рассчитываем процент скидки
                                const discountPercentage = Math.round(
                                    ((price - discountAmount) / price) * 100
                                );
                                response.record.params.discount_percentage =
                                    discountPercentage;

                                console.log(
                                    'Рассчитан процент скидки для формы редактирования:',
                                    {
                                        originalPrice: price,
                                        discountedPrice: discountAmount,
                                        discountPercentage,
                                    }
                                );
                            }
                        }

                        return response;
                    },
                ],
                before: async (request, context) => {
                    console.log('Edition edit - payload:', request.payload);
                    console.log('Edition edit - params:', request.params);

                    // При редактировании через админку НЕ меняем source, так как можем редактировать и записи парсера

                    // Проверяем и обрабатываем цену со скидкой
                    if (request.payload.price !== undefined) {
                        const price = parseFloat(request.payload.price);

                        // Если указан процент скидки, рассчитываем цену со скидкой
                        if (
                            request.payload.discount_percentage !== undefined &&
                            request.payload.discount_percentage !== ''
                        ) {
                            const discountPercentage = parseFloat(
                                request.payload.discount_percentage
                            );
                            if (
                                !isNaN(discountPercentage) &&
                                discountPercentage > 0
                            ) {
                                // Рассчитываем цену со скидкой
                                const discountAmount =
                                    price * (1 - discountPercentage / 100);
                                request.payload.discount_amount =
                                    discountAmount.toFixed(2);
                                console.log(
                                    'Рассчитана цена со скидкой по проценту:',
                                    {
                                        originalPrice: price,
                                        discountPercentage,
                                        discountedPrice:
                                            request.payload.discount_amount,
                                    }
                                );
                            } else if (
                                discountPercentage === 0 ||
                                request.payload.discount_percentage === ''
                            ) {
                                // Если процент скидки равен 0 или пустой, удаляем скидку
                                request.payload.discount_amount = null;
                                console.log(
                                    'Скидка удалена, так как процент скидки равен 0 или пустой'
                                );
                            }
                        }

                        // Если указана цена со скидкой, проверяем её корректность
                        if (request.payload.discount_amount !== undefined) {
                            // Проверяем на пустую строку или null и устанавливаем null
                            if (
                                request.payload.discount_amount === '' ||
                                request.payload.discount_amount === null
                            ) {
                                request.payload.discount_amount = null;
                                console.log(
                                    'Скидка удалена, так как цена со скидкой пустая'
                                );
                            } else {
                                const discountAmount = parseFloat(
                                    request.payload.discount_amount
                                );

                                // Проверяем, что цена со скидкой не больше обычной цены
                                if (discountAmount > price) {
                                    request.payload.discount_amount = price;
                                    console.log(
                                        'Цена со скидкой была больше обычной цены, установлена равной обычной цене:',
                                        price
                                    );
                                }

                                console.log('Обновлена цена со скидкой:', {
                                    originalPrice: price,
                                    discountedPrice:
                                        request.payload.discount_amount,
                                });
                            }
                        }
                    }

                    // Если дата окончания акции пустая или null, удаляем скидку
                    if (
                        request.payload.promotion_end_date === '' ||
                        request.payload.promotion_end_date === null
                    ) {
                        request.payload.discount_amount = null;
                        console.log(
                            'Скидка удалена, так как дата окончания акции пустая'
                        );
                    }

                    // Очищаем поля ea_play_price и ps_plus_price, если они пустые или null
                    if (
                        request.payload.ea_play_price === '' ||
                        request.payload.ea_play_price === null
                    ) {
                        request.payload.ea_play_price = null;
                        console.log(
                            'EA Play цена очищена, так как поле пустое'
                        );
                    }

                    if (
                        request.payload.ps_plus_price === '' ||
                        request.payload.ps_plus_price === null
                    ) {
                        request.payload.ps_plus_price = null;
                        request.payload.ps_plus_promotion_end_date = null;
                        console.log(
                            'PS Plus цена очищена, так как поле пустое'
                        );
                    }

                    // Если дата окончания акции для PS Plus пустая или null, удаляем дату
                    if (
                        request.payload.ps_plus_promotion_end_date === '' ||
                        request.payload.ps_plus_promotion_end_date === null
                    ) {
                        request.payload.ps_plus_promotion_end_date = null;
                        console.log(
                            'PS Plus дата акции очищена, так как поле пустое'
                        );
                    }

                    // Проверяем наличие данных о связанных сущностях
                    const platformKeys = Object.keys(request.payload).filter(
                        key => key.startsWith('platforms.')
                    );
                    const localizationKeys = Object.keys(
                        request.payload
                    ).filter(key => key.startsWith('localizations.'));
                    const collectionKeys = Object.keys(request.payload).filter(
                        key => key.startsWith('collections.')
                    );

                    console.log('Platform keys in payload:', platformKeys);
                    console.log(
                        'Localization keys in payload:',
                        localizationKeys
                    );
                    console.log('Collection keys in payload:', collectionKeys);

                    return request;
                },
            },
            list: {
                before: async (request, context) => {
                    const { query = {} } = request;
                    const { filters = {} } = query;

                    if (filters.description) {
                        filters.description = {
                            $iLike: `%${filters.description}%`,
                        };
                    }

                    context.query = {
                        ...context.query,
                        include: ['collections', 'localizations', 'platforms'],
                    };
                    return request;
                },
                after: async (response, request, context) => {
                    // Добавляем информацию о процентах скидки для каждой записи
                    if (response.records && response.records.length > 0) {
                        response.records.forEach(record => {
                            if (record.params) {
                                const price = parseFloat(record.params.price);
                                const discountAmount = parseFloat(
                                    record.params.discount_amount
                                );

                                if (
                                    !isNaN(price) &&
                                    !isNaN(discountAmount) &&
                                    price > 0 &&
                                    discountAmount > 0 &&
                                    discountAmount < price
                                ) {
                                    const discountPercentage = Math.round(
                                        ((price - discountAmount) / price) * 100
                                    );
                                    record.params.discount_percentage =
                                        discountPercentage;
                                }
                            }
                        });
                    }

                    return response;
                },
            },
            show: {
                before: async (request, context) => {
                    context.query = {
                        ...context.query,
                        include: ['collections', 'localizations', 'platforms'],
                    };
                    return request;
                },
                after: async (response, request, context) => {
                    // Если есть цена и цена со скидкой, рассчитываем процент скидки для отображения
                    if (response.record && response.record.params) {
                        const price = parseFloat(response.record.params.price);
                        const discountAmount = parseFloat(
                            response.record.params.discount_amount
                        );

                        if (
                            !isNaN(price) &&
                            !isNaN(discountAmount) &&
                            price > 0 &&
                            discountAmount > 0 &&
                            discountAmount < price // Цена со скидкой должна быть меньше обычной цены
                        ) {
                            // Рассчитываем процент скидки
                            const discountPercentage = Math.round(
                                ((price - discountAmount) / price) * 100
                            );
                            response.record.params.discount_percentage =
                                discountPercentage;

                            console.log(
                                'Рассчитан процент скидки для отображения:',
                                {
                                    originalPrice: price,
                                    discountedPrice: discountAmount,
                                    discountPercentage,
                                }
                            );
                        }
                    }

                    return response;
                },
            },
            delete: {
                isAccessible: true,
            },
            checkExpiredDiscounts: {
                actionType: 'resource',
                icon: 'Clock',
                component: false,
                handler: async (request, response, context) => {
                    try {
                        const currentDate = new Date();
                        let totalUpdated = 0;

                        // 1. Обновляем обычные скидки
                        const [updatedDiscounts] = await Edition.update(
                            { discount_amount: null },
                            {
                                where: {
                                    discount_amount: {
                                        [Op.ne]: null,
                                        [Op.gt]: 0,
                                    },
                                    promotion_end_date: {
                                        [Op.lt]: currentDate,
                                    },
                                },
                            }
                        );
                        totalUpdated += updatedDiscounts;

                        // 2. Обновляем PS Plus скидки
                        const [updatedPsPlus] = await Edition.update(
                            { ps_plus_price: null, ps_plus_promotion_end_date: null },
                            {
                                where: {
                                    ps_plus_price: {
                                        [Op.ne]: null,
                                        [Op.gt]: 0,
                                    },
                                    ps_plus_promotion_end_date: {
                                        [Op.lt]: currentDate,
                                    },
                                },
                            }
                        );
                        totalUpdated += updatedPsPlus;

                        if (totalUpdated === 0) {
                            return {
                                notice: {
                                    message: 'Истекших акций не найдено',
                                    type: 'success',
                                },
                            };
                        }

                        return {
                            notice: {
                                message: `Обновлено ${totalUpdated} изданий с истекшими акциями (обычных: ${updatedDiscounts}, PS Plus: ${updatedPsPlus})`,
                                type: 'success',
                            },
                        };
                    } catch (error) {
                        console.error(
                            'Ошибка при проверке истекших скидок:',
                            error
                        );
                        return {
                            notice: {
                                message: `Ошибка при проверке истекших скидок: ${error.message}`,
                                type: 'error',
                            },
                        };
                    }
                },
            },
            massAddToCollection: {
                actionType: 'bulk',
                icon: 'Archive',
                variant: 'primary',
                component: 'BulkAddToCollectionAction',
                handler: async (request, response, context) => {
                    console.log('=== massAddToCollection bulk handler ===');
                    console.log('Request:', request);
                    console.log('Context records:', context.records);

                    // Для bulk actions AdminJS автоматически передает выбранные записи в context.records
                    // Просто возвращаем их для React компонента
                    return {
                        records: context.records || [],
                        notice: {
                            message: `Выбрано изданий: ${context.records?.length || 0}`,
                            type: 'info'
                        }
                    };
                },
            },
        },
        listProperties: [
            'id',
            'is_hidden',
            'edition_name_id',
            'product_card_id',
            'price',
            'discount_amount',
            'final_price',
            'platforms',
            'collections',
            'promotion_end_date',
            'source',
            'show_in_showcase',
            'allow_auto_update',
            'created_at',
        ],
        filterProperties: [
            'is_hidden',
            'edition_name_id',
            'description',
            'product_card_id',
            'price',
            'platforms',
            'collections',
            'promotion_end_date',
            'discount_amount',
            'source',
            'show_in_showcase',
            'lock_price',
            'lock_discount_price',
            'lock_ps_plus_price',
            'lock_ea_play_price',
            'allow_auto_update',
            'created_at',
        ],
        editProperties: [
            'is_hidden',
            'edition_name_id',
            'description',
            'product_card_id',
            'price',
            'display_currency_id',
            'image_url',
            'discount_amount',
            'discount_percentage',
            'ea_play_price',
            'ps_plus_price',
            'promotion_end_date',
            'ps_plus_promotion_end_date',
            'platforms',
            'collections',
            'localizations',
            'show_in_showcase',
            'showcase_collection_id',
            'lock_price',
            'lock_discount_price',
            'lock_ps_plus_price',
            'lock_ea_play_price',
            'allow_auto_update',
            'product_store_url',
        ],
        showProperties: [
            'id',
            'is_hidden',
            'edition_name_id',
            'description',
            'product_card_id',
            'price',
            'display_currency_id',
            'image_url',
            'discount_amount',
            'discount_percentage',
            'final_price',
            'ea_play_price',
            'ps_plus_price',
            'promotion_end_date',
            'ps_plus_promotion_end_date',
            'platforms',
            'collections',
            'localizations',
            'source',
            'show_in_showcase',
            'showcase_collection_id',
            'lock_price',
            'lock_discount_price',
            'lock_ps_plus_price',
            'lock_ea_play_price',
            'allow_auto_update',
            'product_store_url',
            'created_at',
            'updated_at',
        ],
    },
};
