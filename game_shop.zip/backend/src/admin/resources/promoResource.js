import Promo from '../../models/promo.js';

export const promoResource = {
    resource: Promo,
    options: {
        navigation: {
            name: 'Промокоды',
            icon: 'Tag',
        },
        properties: {
            id: {
                position: 1,
            },
            name: {
                position: 2,
                isTitle: true,
            },
            discount: {
                position: 3,
            },
            isActive: {
                position: 4,
            },
            createdAt: {
                position: 5,
                isVisible: { list: true, filter: true, show: true, edit: false },
            },
            updatedAt: {
                position: 6,
                isVisible: { list: true, filter: true, show: true, edit: false },
            },
        },
    },
};
