import { Op } from 'sequelize';
import Currency from '../../models/currency.js';
import { createBaseResource } from './baseResource.js';
import { uploadFile } from '../../utils/uploadFile.js';

const baseResource = createBaseResource(Currency);

export const currencyResource = {
    ...baseResource,
    options: {
        ...baseResource.options,
        navigation: {
            name: 'Валюты',
            icon: 'Price',
        },
        properties: {
            id: {
                position: 1,
            },
            name: {
                position: 2,
                isTitle: true,
                isRequired: true,
            },
            code: {
                position: 3,
                isRequired: true,
            },
            symbol: {
                position: 4,
                isRequired: true,
            },
            icon: {
                position: 5,
                components: {
                    edit: 'ImageUpload',
                    show: 'ImagePreview',
                    list: 'ImagePreview',
                },
                isVisible: {
                    list: true,
                    filter: false,
                    show: true,
                    edit: true,
                },
            },
            exchange_rate: {
                position: 6,
                type: 'number',
                isRequired: true,
                description: 'Курс относительно рубля. 1 RUB = X единиц валюты',
            },
            is_default: {
                position: 7,
                type: 'boolean',
                description: 'Является ли валютой по умолчанию – рубль',
                defaultValue: false,
            },
            createdAt: {
                position: 8,
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: false,
                },
            },
            updatedAt: {
                position: 9,
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: false,
                },
            },
        },
        actions: {
            new: {
                before: async (request) => {
                    const { payload } = request;

                    console.log('Currency new payload:', {
                        name: payload.name,
                        code: payload.code,
                        symbol: payload.symbol,
                        exchange_rate: payload.exchange_rate,
                        icon: payload.icon,
                        iconFile: payload['icon.file']
                    });

                    // Validate required fields
                    if (!payload.name?.trim()) {
                        throw new Error('Название валюты обязательно');
                    }
                    if (!payload.code?.trim()) {
                        throw new Error('Код валюты обязателен');
                    }
                    if (!payload.symbol?.trim()) {
                        throw new Error('Символ валюты обязателен');
                    }
                    
                    // Convert exchange_rate to number and validate
                    payload.exchange_rate = Number(payload.exchange_rate);
                    if (isNaN(payload.exchange_rate)) {
                        throw new Error('Курс обмена должен быть числом');
                    }
                    if (payload.exchange_rate <= 0) {
                        throw new Error('Курс обмена должен быть больше 0');
                    }

                    // Handle file upload
                    if (payload['icon.file']) {
                        try {
                            const fileData = {
                                name: payload['icon.name'],
                                size: payload['icon.size'],
                                type: payload['icon.mime'],
                                file: payload['icon.file'],
                            };
                            console.log('Trying to upload file:', {
                                name: fileData.name,
                                size: fileData.size,
                                type: fileData.type,
                                hasFile: !!fileData.file
                            });
                            const uploadPath = await uploadFile(fileData, 'currencies');

                            // Clean up temporary fields
                            delete payload['icon.name'];
                            delete payload['icon.size'];
                            delete payload['icon.mime'];
                            delete payload['icon.file'];
                            payload.icon = uploadPath;
                        } catch (error) {
                            console.error('Error uploading file:', error);
                            throw new Error('Ошибка при загрузке файла: ' + error.message);
                        }
                    }

                    // Set default value for is_default if not provided
                    payload.is_default = Boolean(payload.is_default);

                    if (payload.is_default) {
                        await Currency.update(
                            { is_default: false },
                            { where: { is_default: true } }
                        );
                    }

                    return request;
                },
            },
            edit: {
                before: async (request) => {
                    const { payload } = request;

                    console.log('Currency edit payload:', {
                        name: payload.name,
                        code: payload.code,
                        symbol: payload.symbol,
                        exchange_rate: payload.exchange_rate,
                        icon: payload.icon,
                        iconFile: payload['icon.file']
                    });

                    // Validate required fields
                    if (!payload.name?.trim()) {
                        throw new Error('Название валюты обязательно');
                    }
                    if (!payload.code?.trim()) {
                        throw new Error('Код валюты обязателен');
                    }
                    if (!payload.symbol?.trim()) {
                        throw new Error('Символ валюты обязателен');
                    }
                    
                    // Convert exchange_rate to number and validate
                    payload.exchange_rate = Number(payload.exchange_rate);
                    if (isNaN(payload.exchange_rate)) {
                        throw new Error('Курс обмена должен быть числом');
                    }
                    if (payload.exchange_rate <= 0) {
                        throw new Error('Курс обмена должен быть больше 0');
                    }

                    // Handle file upload
                    if (payload['icon.file']) {
                        try {
                            const fileData = {
                                name: payload['icon.name'],
                                size: payload['icon.size'],
                                type: payload['icon.mime'],
                                file: payload['icon.file'],
                            };
                            console.log('Trying to upload file:', {
                                name: fileData.name,
                                size: fileData.size,
                                type: fileData.type,
                                hasFile: !!fileData.file
                            });
                            const uploadPath = await uploadFile(fileData, 'currencies');

                            // Clean up temporary fields
                            delete payload['icon.name'];
                            delete payload['icon.size'];
                            delete payload['icon.mime'];
                            delete payload['icon.file'];
                            payload.icon = uploadPath;
                        } catch (error) {
                            console.error('Error uploading file:', error);
                            throw new Error('Ошибка при загрузке файла: ' + error.message);
                        }
                    }

                    // Set default value for is_default if not provided
                    payload.is_default = Boolean(payload.is_default);

                    if (payload.is_default) {
                        await Currency.update(
                            { is_default: false },
                            {
                                where: {
                                    id: { [Op.ne]: request.params.recordId },
                                    is_default: true,
                                },
                            }
                        );
                    }

                    return request;
                },
            },
            delete: {
                isAccessible: true,
                before: async (request) => {
                    const currency = await Currency.findByPk(request.params.recordId);
                    if (currency?.is_default) {
                        throw new Error('Нельзя удалить валюту по умолчанию');
                    }
                    return request;
                },
            },
        },
    },
};
