import { Box } from '@adminjs/design-system';
import React from 'react';

const ImagePreview = props => {
	const { record, property } = props;
	const imageUrl = record?.params[property.path];

	if (!imageUrl) return null;

	// Если URL начинается с http или https, используем как есть
	const fullUrl = imageUrl.startsWith('http')
		? imageUrl
		: `/uploads/${imageUrl}`;

	return (
		<Box>
			<img
				src={fullUrl}
				alt={property.label}
				style={{ maxWidth: '200px', maxHeight: '200px' }}
			/>
		</Box>
	);
};

export default ImagePreview;
