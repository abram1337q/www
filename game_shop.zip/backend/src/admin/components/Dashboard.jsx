import { Box, H2, Text } from '@adminjs/design-system';
import { ApiClient } from 'adminjs';
import React, { useEffect, useState } from 'react';
import styled, { keyframes } from 'styled-components';

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;

const DashboardContainer = styled.div`
	font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto',
		'Helvetica', 'Arial', sans-serif;
	background-color: #f5f5f7;
	color: #1d1d1f;
	padding: 40px;
	border-radius: 18px;
	box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
	animation: ${fadeIn} 0.6s ease-out;
`;

const Title = styled.h1`
	font-size: 32px;
	font-weight: 600;
	color: #1d1d1f;
	margin-bottom: 20px;
	letter-spacing: -0.5px;
`;

const Subtitle = styled.p`
	font-size: 18px;
	color: #484848;
	margin-bottom: 30px;
	letter-spacing: -0.2px;
	line-height: 1.5;
`;

const SectionsGrid = styled.div`
	display: grid;
	grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
	gap: 20px;
	margin-top: 40px;
`;

const SectionCard = styled.a`
	background-color: #ffffff;
	border-radius: 14px;
	padding: 24px;
	text-align: center;
	transition: all 0.3s ease;
	cursor: pointer;
	text-decoration: none;
	color: inherit;
	animation: ${fadeIn} 0.6s ease-out;
	animation-delay: ${props => props.delay}s;
	opacity: 0;
	animation-fill-mode: forwards;

	&:hover {
		transform: translateY(-5px);
		box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
		background-color: #f0f0f0;
	}
`;

const SectionIcon = styled.div`
	font-size: 36px;
	margin-bottom: 15px;
`;

const SectionTitle = styled.h2`
	font-size: 18px;
	font-weight: 600;
	color: #1d1d1f;
	margin-bottom: 10px;
`;

const SectionDescription = styled.p`
	font-size: 14px;
	color: #484848;
`;

const api = new ApiClient();

const Dashboard = () => {
	const [data, setData] = useState({});

	useEffect(() => {
		api.getDashboard().then(response => {
			setData(response.data);
		});
	}, []);

	const sections = [
		{
			icon: '⚙️',
			title: 'Настройки',
			description: 'Управление настройками магазина',
			link: '/admin/resources/Settings',
		},
		{
			icon: '🏷️',
			title: 'Коллекции',
			description: 'Управление коллекциями продуктов',
			link: '/admin/resources/ProductCollections',
		},
		{
			icon: '🎮',
			title: 'Продукты',
			description: 'Управление карточками продуктов',
			link: '/admin/resources/ProductCards',
		},
		{
			icon: '📦',
			title: 'Издания',
			description: 'Управление изданиями продуктов',
			link: '/admin/resources/Editions',
		},
		{
			icon: '🏷️',
			title: 'Типы изданий',
			description: 'Управление типами изданий',
			link: '/admin/resources/EditionTypes',
		},
		{
			icon: '💻',
			title: 'Платформы',
			description: 'Управление игровыми платформами',
			link: '/admin/resources/Platforms',
		},
		{
			icon: '🎲',
			title: 'Жанры',
			description: 'Управление жанрами игр',
			link: '/admin/resources/Genres',
		},
		{
			icon: '🌐',
			title: 'Локализации',
			description: 'Управление локализациями',
			link: '/admin/resources/Localizations',
		},
		{
			icon: '💰',
			title: 'Валюты',
			description: 'Управление валютами',
			link: '/admin/resources/Currencies',
		},
		{
			icon: '📧',
			title: 'Рассылки',
			description: 'Управление email-рассылками',
			link: '/admin/resources/Mailings',
		},
		{
			icon: '👥',
			title: 'Пользователи',
			description: 'Управление аккаунтами пользователей',
			link: '/admin/resources/Users',
		},
		{
			icon: '📰',
			title: 'Лента',
			description: 'Управление элементами ленты',
			link: '/admin/resources/FeedItems',
		},
	];

	return (
		<DashboardContainer>
			<Title>Панель управления</Title>
			<Subtitle>
				Добро пожаловать в панель управления магазином. Выберите раздел
				для начала работы.
			</Subtitle>
			<Box variant='white'>
				<H2>Статистика:</H2>
				<Box>
					<Text>Всего товаров: {data.totalProducts}</Text>
				</Box>
				<Box>
					<Text>Всего коллекций: {data.totalCollections}</Text>
				</Box>
				<Box>
					<Text>Всего изданий: {data.totalEditions}</Text>
				</Box>
				<Box>
					<Text>Всего типов изданий: {data.totalEditionTypes}</Text>
				</Box>
				<Box>
					<Text>Всего рассылок: {data.totalMailings}</Text>
				</Box>
				<Box>
					<Text>Всего пользователей: {data.totalUsers}</Text>
				</Box>
			</Box>
			<SectionsGrid>
				{sections.map((section, index) => (
					<SectionCard
						key={index}
						delay={0.1 * (index + 1)}
						href={section.link}
					>
						<SectionIcon>{section.icon}</SectionIcon>
						<SectionTitle>{section.title}</SectionTitle>
						<SectionDescription>
							{section.description}
						</SectionDescription>
					</SectionCard>
				))}
			</SectionsGrid>
		</DashboardContainer>
	);
};

export default Dashboard;
