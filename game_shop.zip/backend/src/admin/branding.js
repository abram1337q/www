export const branding = {
	companyName: '@',
	theme: {
		colors: {
			primary100: '#4268F6',
			primary80: '#5A7BF7',
			primary60: '#728DF8',
			primary40: '#8AA0F9',
			primary20: '#A2B3FA',
			accent: '#38B2AC',
			love: '#E11D48',
		},
	},
};
