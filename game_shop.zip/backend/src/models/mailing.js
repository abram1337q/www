import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class Mailing extends Model {
	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				content: {
					type: DataTypes.TEXT,
					allowNull: false,
					validate: {
						notNull: {
							msg: 'Содержание рассылки обязательно для заполнения',
						},
						notEmpty: {
							msg: 'Содержание рассылки не может быть пустым',
						},
						len: {
							args: [1, 4096],
							msg: 'Длина сообщения должна быть от 1 до 4096 символов',
						},
					},
				},
				imageUrl: {
					type: DataTypes.STRING,
					allowNull: true,
					validate: {
						isUrlIfPresent(value) {
							if (value && value.trim() !== '') {
								try {
									new URL(value);
								} catch (e) {
									throw new Error(
										'Некорректный URL изображения'
									);
								}
							}
						},
					},
				},
				status: {
					type: DataTypes.ENUM(
						'draft',
						'scheduled',
						'processing',
						'sent',
						'cancelled',
						'error'
					),
					defaultValue: 'draft',
					validate: {
						isIn: {
							args: [
								[
									'draft',
									'scheduled',
									'processing',
									'sent',
									'cancelled',
									'error',
								],
							],
							msg: 'Некорректный статус рассылки',
						},
					},
				},
				scheduledAt: {
					type: DataTypes.DATE,
					allowNull: true,
					validate: {
						isDate: {
							msg: 'Некорректный формат даты',
						},
					},
				},
				sentAt: {
					type: DataTypes.DATE,
					allowNull: true,
				},
				createdBy: {
					type: DataTypes.INTEGER,
					allowNull: true,
				},
			},
			{
				sequelize,
				modelName: 'Mailing',
				tableName: 'Mailings',
				underscored: true,
				timestamps: true,
				hooks: {
					beforeCreate: async (instance, options) => {
						console.log('Before creating mailing instance:', {
							content: instance.content,
							status: instance.status,
							scheduledAt: instance.scheduledAt,
						});
					},
					afterCreate: async (instance, options) => {
						console.log(
							'After creating mailing instance:',
							instance.toJSON()
						);
					},
					beforeValidate: async (instance, options) => {
						console.log('Before validating mailing instance:', {
							content: instance.content,
							status: instance.status,
							scheduledAt: instance.scheduledAt,
						});
					},
					afterValidate: async (instance, options) => {
						console.log('After validating mailing instance:', {
							content: instance.content,
							status: instance.status,
							scheduledAt: instance.scheduledAt,
						});
					},
				},
				validate: {
					scheduledStatusValidation() {
						if (this.status === 'scheduled' && !this.scheduledAt) {
							throw new Error(
								'Для запланированной рассылки необходимо указать дату отправки'
							);
						}
					},
				},
			}
		);
		return this;
	}
}

Mailing.init(sequelize);
