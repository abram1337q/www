import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class UserRegionData extends Model {
    static init(sequelize) {
        super.init(
            {
                id: {
                    type: DataTypes.INTEGER,
                    primaryKey: true,
                    autoIncrement: true,
                },
                userId: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'Users',
                        key: 'id',
                    },
                    onUpdate: 'CASCADE',
                    onDelete: 'CASCADE',
                },
                currencyId: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'Currencies',
                        key: 'id',
                    },
                    onUpdate: 'CASCADE',
                    onDelete: 'CASCADE',
                },
                psStoreLogin: {
                    type: DataTypes.STRING,
                    allowNull: true,
                },
                psStorePassword: {
                    type: DataTypes.STRING,
                    allowNull: true,
                },
                psBackupCodes: {
                    type: DataTypes.TEXT,
                    allowNull: true,
                },
                email: {
                    type: DataTypes.STRING,
                    allowNull: true,
                    validate: {
                        customEmailValidation(value) {
                            // Проверяем только если значение не пустое
                            if (value && value.trim() !== '') {
                                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                                if (!emailRegex.test(value)) {
                                    throw new Error('Неверный формат email');
                                }
                            }
                        },
                    },
                },
            },
            {
                sequelize,
                modelName: 'UserRegionData',
                tableName: 'UserRegionData',
                timestamps: true,
                indexes: [
                    {
                        unique: true,
                        fields: ['userId', 'currencyId'],
                    },
                ],
            }
        );
    }

    static associate(models) {
        UserRegionData.belongsTo(models.User, {
            foreignKey: 'userId',
            as: 'User',
        });
        UserRegionData.belongsTo(models.Currency, {
            foreignKey: 'currencyId',
            as: 'Currency',
        });
    }
}

UserRegionData.init(sequelize);
