import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class Edition extends Model {
    static associate(models) {
        Edition.belongsTo(models.ProductCard, {
            foreignKey: 'product_card_id',
            targetKey: 'id',
            as: 'productCard',
        });

        Edition.belongsTo(models.EditionName, {
            foreignKey: 'edition_name_id',
            as: 'editionName',
        });

        Edition.belongsTo(models.Currency, {
            foreignKey: 'display_currency_id',
            as: 'currency',
        });

        Edition.belongsToMany(models.Platform, {
            through: 'edition_platforms',
            foreignKey: 'edition_id',
            otherKey: 'platform_id',
            as: 'platforms',
            timestamps: false,
        });

        Edition.belongsToMany(models.Localization, {
            through: 'edition_localizations',
            foreignKey: 'edition_id',
            otherKey: 'localization_id',
            as: 'localizations',
            timestamps: true,
            createdAt: 'createdAt',
            updatedAt: 'updatedAt',
        });

        Edition.belongsToMany(models.ProductCollection, {
            through: models.ProductCollectionEdition,
            foreignKey: 'edition_id',
            otherKey: 'product_collection_id',
            as: 'collections',
            timestamps: true,
            // Важно: в этой таблице поля называются created_at и updated_at (snake_case)
            createdAt: 'created_at',
            updatedAt: 'updated_at',
        });

        Edition.hasMany(models.ProductCollectionEdition, {
            foreignKey: 'edition_id',
            as: 'collectionLinks',
        });

        Edition.hasMany(models.CollectionShowcaseEdition, {
            foreignKey: 'edition_id',
            as: 'showcaseEntries',
        });
    }

    static init(sequelize) {
        super.init(
            {
                id: {
                    type: DataTypes.INTEGER,
                    primaryKey: true,
                    autoIncrement: true,
                },
                edition_name_id: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'EditionNames',
                        key: 'id',
                    },
                },
                description: {
                    type: DataTypes.TEXT,
                    allowNull: false,
                },
                product_card_id: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'ProductCards',
                        key: 'id',
                    },
                },
                price: {
                    type: DataTypes.DECIMAL(10, 2),
                    allowNull: false,
                },
                display_currency_id: {
                    type: DataTypes.INTEGER,
                    allowNull: true,
                    references: {
                        model: 'Currencies',
                        key: 'id',
                    },
                },
                discount_amount: {
                    type: DataTypes.DECIMAL(10, 2),
                    allowNull: true,
                },
                ea_play_price: {
                    type: DataTypes.DECIMAL(10, 2),
                    allowNull: true,
                },
                ps_plus_price: {
                    type: DataTypes.DECIMAL(10, 2),
                    allowNull: true,
                },
                promotion_end_date: {
                    type: DataTypes.DATE,
                    allowNull: true,
                },
                ps_plus_promotion_end_date: {
                    type: DataTypes.DATE,
                    allowNull: true,
                },
                rating: {
                    type: DataTypes.DOUBLE,
                    allowNull: true,
                },
                source: {
                    type: DataTypes.ENUM('parser', 'manual'),
                    allowNull: false,
                    defaultValue: 'manual',
                },
                show_in_showcase: {
                    type: DataTypes.BOOLEAN,
                    allowNull: true,
                    defaultValue: false,
                },
                showcase_collection_id: {
                    type: DataTypes.INTEGER,
                    allowNull: true,
                    references: {
                        model: 'ProductCollections',
                        key: 'id',
                    },
                },
                image_url: {
                    type: DataTypes.STRING(500),
                    allowNull: true,
                    comment: 'URL изображения для конкретного издания. Если NULL, используется image_url из ProductCard.',
                },
                lock_price: {
                    type: DataTypes.BOOLEAN,
                    allowNull: false,
                    defaultValue: false,
                    field: 'lock_price',
                    comment: '🔒 Фиксация обычной цены. Если true, парсер НЕ может изменить price. Промокоды продолжают работать.',
                },
                lock_discount_price: {
                    type: DataTypes.BOOLEAN,
                    allowNull: false,
                    defaultValue: false,
                    field: 'lock_discount_price',
                    comment: '🔒 Фиксация цены со скидкой. Если true, парсер НЕ может изменить discount_amount. Промокоды продолжают работать.',
                },
                lock_ps_plus_price: {
                    type: DataTypes.BOOLEAN,
                    allowNull: false,
                    defaultValue: false,
                    field: 'lock_ps_plus_price',
                    comment: '🔒 Фиксация цены PS Plus. Если true, парсер НЕ может изменить ps_plus_price. Промокоды продолжают работать.',
                },
                lock_ea_play_price: {
                    type: DataTypes.BOOLEAN,
                    allowNull: false,
                    defaultValue: false,
                    field: 'lock_ea_play_price',
                    comment: '🔒 Фиксация цены EA Play. Если true, парсер НЕ может изменить ea_play_price. Промокоды продолжают работать.',
                },
                allow_auto_update: {
                    type: DataTypes.BOOLEAN,
                    allowNull: false,
                    defaultValue: false,
                    field: 'allow_auto_update',
                    comment: '✅ Разрешить автообновление цен для manual записей. Если true, update.py может менять цены.',
                },
                product_store_url: {
                    type: DataTypes.STRING(500),
                    allowNull: true,
                    field: 'product_store_url',
                    comment: '🔗 Ссылка на товар в PlayStation Store для автообновления цен (например: https://store.playstation.com/ru-ua/product/EP9000-CUSA00123_00-GAMENAME0000000)',
                },
                is_hidden: {
                    type: DataTypes.BOOLEAN,
                    allowNull: false,
                    defaultValue: false,
                    field: 'is_hidden',
                    comment: '🚫 Скрыть издание. Если true, издание НЕ отображается пользователям в TMA, но остаётся в базе данных.',
                },
            },
            {
                sequelize,
                modelName: 'Edition',
                tableName: 'Editions',
                timestamps: true,
                underscored: true,
                hooks: {
                    /**
                     * Хук beforeFind вызывается перед каждым запросом к модели Edition
                     * Он автоматически проверяет и обнуляет скидки для изданий с истекшим сроком акции
                     * Это обеспечивает актуальность данных даже если cron-задача не сработала
                     */
                    beforeFind: async options => {
                        try {
                            // Проверяем флаг для предотвращения рекурсии
                            if (options && options.skipBeforeFindHook) {
                                return;
                            }

                            const currentDate = new Date();
                            let totalUpdated = 0;

                            // 1. Проверяем и обновляем истекшие обычные скидки
                            const [expiredEditions] = await sequelize.query(`
                                SELECT id, price, discount_amount, promotion_end_date
                                FROM "Editions"
                                WHERE discount_amount IS NOT NULL
                                AND discount_amount > 0
                                AND promotion_end_date < '${currentDate.toISOString()}'
                            `);

                            if (expiredEditions.length > 0) {
                                console.log(
                                    `Найдено ${expiredEditions.length} изданий с истекшими обычными скидками при запросе данных`
                                );

                                await sequelize.query(`
                                    UPDATE "Editions"
                                    SET discount_amount = NULL
                                    WHERE discount_amount IS NOT NULL
                                    AND discount_amount > 0
                                    AND promotion_end_date < '${currentDate.toISOString()}'
                                `);

                                expiredEditions.forEach(edition => {
                                    console.log(
                                        `Удалена обычная скидка для издания ID ${edition.id}:`,
                                        {
                                            originalPrice: edition.price,
                                            removedDiscountPrice:
                                                edition.discount_amount,
                                            promotionEndDate:
                                                edition.promotion_end_date,
                                        }
                                    );
                                });

                                totalUpdated += expiredEditions.length;
                            }

                            // 2. Проверяем и обновляем истекшие PS Plus скидки
                            const [expiredPsPlusEditions] = await sequelize.query(`
                                SELECT id, ps_plus_price, ps_plus_promotion_end_date
                                FROM "Editions"
                                WHERE ps_plus_price IS NOT NULL
                                AND ps_plus_price > 0
                                AND ps_plus_promotion_end_date < '${currentDate.toISOString()}'
                            `);

                            if (expiredPsPlusEditions.length > 0) {
                                console.log(
                                    `Найдено ${expiredPsPlusEditions.length} изданий с истекшими PS Plus скидками при запросе данных`
                                );

                                await sequelize.query(`
                                    UPDATE "Editions"
                                    SET ps_plus_price = NULL, ps_plus_promotion_end_date = NULL
                                    WHERE ps_plus_price IS NOT NULL
                                    AND ps_plus_price > 0
                                    AND ps_plus_promotion_end_date < '${currentDate.toISOString()}'
                                `);

                                expiredPsPlusEditions.forEach(edition => {
                                    console.log(
                                        `Удалена PS Plus скидка для издания ID ${edition.id}:`,
                                        {
                                            removedPsPlusPrice:
                                                edition.ps_plus_price,
                                            psPlusPromotionEndDate:
                                                edition.ps_plus_promotion_end_date,
                                        }
                                    );
                                });

                                totalUpdated += expiredPsPlusEditions.length;
                            }

                            if (totalUpdated > 0) {
                                console.log(
                                    `Обновлено ${totalUpdated} изданий с истекшими акциями`
                                );
                            }
                        } catch (error) {
                            console.error(
                                'Ошибка при проверке истекших скидок:',
                                error
                            );
                        }
                    },
                },
            }
        );
        return this;
    }
}

Edition.init(sequelize);
