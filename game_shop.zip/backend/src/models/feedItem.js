import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class FeedItem extends Model {
	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				type: {
					type: DataTypes.STRING,
					allowNull: false,
				},
				position: {
					type: DataTypes.INTEGER,
					allowNull: false,
				},
				title: {
					type: DataTypes.STRING,
					allowNull: true,
				},
			},
			{
				sequelize,
				modelName: 'FeedItem',
				tableName: 'FeedItems',
				underscored: true,
			}
		);
		return this;
	}

	static associate(models) {
		FeedItem.belongsToMany(models.ProductCollection, {
			through: 'FeedItemCollections',
			as: 'collections',
			foreignKey: 'feed_item_id',
			otherKey: 'collection_id',
			timestamps: false,
			underscored: true
		});
	}
}

FeedItem.init(sequelize);
