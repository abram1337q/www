import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

export default class Genre extends Model {
	static associate(models) {
		this.belongsToMany(models.ProductCard, {
			through: 'ProductCardGenres',
			foreignKey: 'genre_id',
			otherKey: 'product_card_id',
			as: 'products'
		});
	}

	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				name: {
					type: DataTypes.STRING,
					allowNull: false,
					unique: true,
				},
			},
			{
				sequelize,
				modelName: 'Genre',
				tableName: 'Genres',
				underscored: true,
			}
		);
		return this;
	}
}

Genre.init(sequelize);
