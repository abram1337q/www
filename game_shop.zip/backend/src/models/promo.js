import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class Promo extends Model {
	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				name: {
					type: DataTypes.STRING,
					allowNull: false,
					unique: true,
					validate: {
						notEmpty: true,
					},
				},
				discount: {
					type: DataTypes.INTEGER,
					allowNull: false,
					validate: {
						min: 0,
						max: 100,
					},
				},
				isActive: {
					type: DataTypes.BOOLEAN,
					allowNull: false,
					defaultValue: true,
				},
			},
			{
				sequelize,
				modelName: 'Promo',
			}
		);
	}
}

Promo.init(sequelize);
