import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class Settings extends Model {
    static init(sequelize) {
        super.init(
            {
                id: {
                    type: DataTypes.INTEGER,
                    primaryKey: true,
                    autoIncrement: true,
                },
                welcomeMessage: {
                    type: DataTypes.TEXT,
                    allowNull: false,
                    defaultValue:
                        'Добро пожаловать! Нажмите кнопку ниже, чтобы открыть мини-приложение.',
                    field: 'welcome_message'
                },
                maintenanceMode: {
                    type: DataTypes.BOOLEAN,
                    allowNull: false,
                    defaultValue: false,
                    field: 'maintenance_mode',
                },
                maintenanceMessage: {
                    type: DataTypes.TEXT,
                    allowNull: false,
                    defaultValue:
                        '⚙️ Бот временно недоступен.\n\nВ данный момент проводятся технические работы. Пожалуйста, попробуйте позже.',
                    field: 'maintenance_message',
                },
                globalPriceLock: {
                    type: DataTypes.BOOLEAN,
                    allowNull: false,
                    defaultValue: false,
                    field: 'global_price_lock',
                    comment: '🔒 ГЛОБАЛЬНАЯ ФИКСАЦИЯ ЦЕН: Если true, цены ВСЕХ товаров заблокированы (парсер не может менять). Промокоды продолжают работать.',
                },
            },
            {
                sequelize,
                modelName: 'Settings',
                tableName: 'Settings',
                underscored: true,
                timestamps: true
            }
        );
        return this;
    }
}

Settings.init(sequelize);
