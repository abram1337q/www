import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

class CollectionShowcaseEdition extends Model {
    static associate(models) {
        CollectionShowcaseEdition.belongsTo(models.ProductCollection, {
            foreignKey: 'collection_id',
            as: 'collection',
        });

        CollectionShowcaseEdition.belongsTo(models.Edition, {
            foreignKey: 'edition_id',
            as: 'edition',
        });

        CollectionShowcaseEdition.belongsTo(models.Currency, {
            foreignKey: 'currency_id',
            as: 'currency',
        });
    }

    static init(sequelize) {
        super.init(
            {
                id: {
                    type: DataTypes.INTEGER,
                    primaryKey: true,
                    autoIncrement: true,
                },
                collection_id: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'ProductCollections',
                        key: 'id',
                    },
                    onDelete: 'CASCADE',
                },
                edition_id: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'Editions',
                        key: 'id',
                    },
                    onDelete: 'CASCADE',
                },
                currency_id: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'Currencies',
                        key: 'id',
                    },
                    onDelete: 'CASCADE',
                },
                position: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                    validate: {
                        min: 1,
                        max: 3,
                    },
                },
                was_in_collection_before: {
                    type: DataTypes.BOOLEAN,
                    allowNull: false,
                    defaultValue: false,
                    comment: 'Был ли товар в основной коллекции до добавления в витрину',
                },
            },
            {
                sequelize,
                modelName: 'CollectionShowcaseEdition',
                tableName: 'CollectionShowcaseEditions',
                timestamps: true,
                underscored: true,
            }
        );

        return CollectionShowcaseEdition;
    }
}

CollectionShowcaseEdition.init(sequelize);

export default CollectionShowcaseEdition;
