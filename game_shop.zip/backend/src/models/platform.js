import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class Platform extends Model {
	static associate(models) {
		Platform.belongsToMany(models.Edition, {
			through: 'edition_platforms',
			foreignKey: 'platform_id',
			otherKey: 'edition_id',
			as: 'editions',
			timestamps: false,
		});
	}

	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				name: {
					type: DataTypes.STRING,
					allowNull: false,
					unique: true,
				},
				icon_url: {
					type: DataTypes.STRING,
					allowNull: true,
					field: 'icon_url',
				},
			},
			{
				sequelize,
				modelName: 'Platform',
				tableName: 'Platforms',
				underscored: true,
				timestamps: false,
			}
		);
		return this;
	}
}

Platform.init(sequelize);
