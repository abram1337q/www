import { getUserByTelegramId, updateUser, createUser, getUserRegionData, updateUserRegionData } from '../services/userService.js';

export const getUser = async (req, res) => {
  try {
    const { telegramId } = req.params;

    if (!telegramId) {
      return res.status(400).json({ error: 'Telegram ID is required' });
    }

    console.log('Getting user with telegramId:', telegramId);
    let user = await getUserByTelegramId(telegramId);

    // Если пользователь не найден, создаем нового
    if (!user) {
      console.log('User not found, creating new user');
      user = await createUser({
        telegramId,
        psStoreLogin: '',
        psStorePassword: '',
        psBackupCodes: '',
        email: ''
      });
    }

    res.json(user);
  } catch (error) {
    console.error('Error in getUser:', error);
    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
};

export const updateUserProfile = async (req, res) => {
  try {
    const { telegramId } = req.params;
    const userData = req.body;

    console.log('Updating user profile:', { telegramId, userData });

    if (!telegramId) {
      return res.status(400).json({ error: 'Telegram ID is required' });
    }

    // Validate allowed fields
    const allowedFields = ['psStoreLogin', 'psStorePassword', 'psBackupCodes', 'email'];
    const updateData = {};

    // Проверяем, что хотя бы одно поле для обновления присутствует
    let hasUpdateField = false;
    for (const field of allowedFields) {
      if (userData[field] !== undefined) {
        updateData[field] = userData[field];
        hasUpdateField = true;
      }
    }

    if (!hasUpdateField) {
      return res.status(400).json({ error: 'No valid fields to update' });
    }

    const updatedUser = await updateUser(telegramId, updateData);

    if (!updatedUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(updatedUser);
  } catch (error) {
    console.error('Error in updateUserProfile:', error);
    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
};

export const updateUserCurrency = async (req, res) => {
  try {
    const { telegramId } = req.params;
    const { currencyId } = req.body;

    console.log('Updating user currency:', { telegramId, currencyId });

    if (!telegramId) {
      return res.status(400).json({ error: 'Telegram ID is required' });
    }

    if (!currencyId) {
      return res.status(400).json({ error: 'Currency ID is required' });
    }

    const updatedUser = await updateUser(telegramId, { currencyId });

    if (!updatedUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(updatedUser);
  } catch (error) {
    console.error('Error in updateUserCurrency:', error);
    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
};

export const getRegionData = async (req, res) => {
  try {
    const { telegramId, currencyId } = req.params;

    console.log('Getting region data:', { telegramId, currencyId });

    if (!telegramId) {
      return res.status(400).json({ error: 'Telegram ID is required' });
    }

    if (!currencyId) {
      return res.status(400).json({ error: 'Currency ID is required' });
    }

    const regionData = await getUserRegionData(telegramId, parseInt(currencyId));

    res.json(regionData || {
      psStoreLogin: '',
      psStorePassword: '',
      psBackupCodes: '',
      email: ''
    });
  } catch (error) {
    console.error('Error in getRegionData:', error);
    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
};

export const updateRegionData = async (req, res) => {
  try {
    const { telegramId, currencyId } = req.params;
    const regionData = req.body;

    console.log('Updating region data:', { telegramId, currencyId, regionData });

    if (!telegramId) {
      return res.status(400).json({ error: 'Telegram ID is required' });
    }

    if (!currencyId) {
      return res.status(400).json({ error: 'Currency ID is required' });
    }

    // Validate allowed fields
    const allowedFields = ['psStoreLogin', 'psStorePassword', 'psBackupCodes', 'email'];
    const updateData = {};

    // Проверяем, что хотя бы одно поле для обновления присутствует
    let hasUpdateField = false;
    for (const field of allowedFields) {
      if (regionData[field] !== undefined) {
        updateData[field] = regionData[field];
        hasUpdateField = true;
      }
    }

    if (!hasUpdateField) {
      return res.status(400).json({ error: 'No valid fields to update' });
    }

    const updatedRegionData = await updateUserRegionData(
      telegramId,
      parseInt(currencyId),
      updateData
    );

    res.json(updatedRegionData);
  } catch (error) {
    console.error('Error in updateRegionData:', error);
    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
};


