import dotenv from 'dotenv';
import { Sequelize } from 'sequelize';

// Загрузка переменных окружения из файла .env
dotenv.config();

const { DB_NAME, DB_USER, DB_PASSWORD, DB_HOST, DB_PORT, NODE_ENV } =
	process.env;

const sequelize = new Sequelize(DB_NAME, DB_USER, DB_PASSWORD, {
	host: DB_HOST,
	port: DB_PORT,
	dialect: 'postgres',
	logging: NODE_ENV === 'development' ? console.log : false,
	pool: {
		max: 5,
		min: 0,
		acquire: 30000,
		idle: 10000,
	},
});

// Функция для проверки подключения
async function testConnection() {
	try {
		await sequelize.authenticate();
		console.log(
			'Connection to the database has been established successfully.'
		);
	} catch (error) {
		console.error('Unable to connect to the database:', error);
	}
}

// Вызов функции проверки подключения
testConnection();

console.log('Sequelize config:', JSON.stringify(sequelize.config, null, 2));

export default sequelize;
