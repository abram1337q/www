import { scheduleJob } from 'node-schedule';
import { Op } from 'sequelize';
import Edition from '../models/edition.js';

/**
 * Задача для проверки и удаления истекших скидок
 * Запускается каждый день в 00:05
 */
export const setupDiscountExpirationJob = () => {
	// Запускаем задачу каждый день в 00:05
	scheduleJob('5 0 * * *', async () => {
		try {
			console.log('Запуск задачи проверки истекших скидок:', new Date());

			const currentDate = new Date();
			let totalProcessed = 0;

			// 1. Проверяем обычные скидки (discount_amount)
			const expiredDiscounts = await Edition.findAll({
				where: {
					discount_amount: { [Op.ne]: null, [Op.gt]: 0 },
					promotion_end_date: { [Op.lt]: currentDate },
				},
			});

			if (expiredDiscounts.length > 0) {
				console.log(
					`Найдено ${expiredDiscounts.length} изданий с истекшими обычными скидками`
				);

				for (const edition of expiredDiscounts) {
					const originalPrice = edition.price;
					const discountAmount = edition.discount_amount;

					edition.discount_amount = null;
					await edition.save();

					console.log(`Удалена обычная скидка для издания ID ${edition.id}:`, {
						originalPrice,
						removedDiscountPrice: discountAmount,
						promotionEndDate: edition.promotion_end_date,
					});
					totalProcessed++;
				}
			}

			// 2. Проверяем PS Plus скидки
			const expiredPsPlusDiscounts = await Edition.findAll({
				where: {
					ps_plus_price: { [Op.ne]: null, [Op.gt]: 0 },
					ps_plus_promotion_end_date: { [Op.lt]: currentDate },
				},
			});

			if (expiredPsPlusDiscounts.length > 0) {
				console.log(
					`Найдено ${expiredPsPlusDiscounts.length} изданий с истекшими PS Plus скидками`
				);

				for (const edition of expiredPsPlusDiscounts) {
					const psPlusPrice = edition.ps_plus_price;

					edition.ps_plus_price = null;
					edition.ps_plus_promotion_end_date = null;
					await edition.save();

					console.log(`Удалена PS Plus скидка для издания ID ${edition.id}:`, {
						removedPsPlusPrice: psPlusPrice,
						psPlusPromotionEndDate: edition.ps_plus_promotion_end_date,
					});
					totalProcessed++;
				}
			}

			if (totalProcessed === 0) {
				console.log('Истекших акций не найдено');
			} else {
				console.log(
					`Успешно обработано ${totalProcessed} изданий с истекшими акциями`
				);
			}
		} catch (error) {
			console.error('Ошибка при обработке истекших скидок:', error);
		}
	});

	console.log('Задача проверки истекших скидок настроена');
};
