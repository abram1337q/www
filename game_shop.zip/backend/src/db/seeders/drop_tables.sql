-- Отключаем проверку внешних ключей
SET session_replication_role = 'replica';

-- Удаляем все таблицы
DROP TABLE IF EXISTS "CollectionProducts" CASCADE;
DROP TABLE IF EXISTS "ProductCardGenres" CASCADE;
DROP TABLE IF EXISTS "ProductCardLocalizations" CASCADE;
DROP TABLE IF EXISTS "ProductCardPlatforms" CASCADE;
DROP TABLE IF EXISTS "FeedItems" CASCADE;
DROP TABLE IF EXISTS "Editions" CASCADE;
DROP TABLE IF EXISTS "ProductCards" CASCADE;
DROP TABLE IF EXISTS "ProductCollections" CASCADE;
DROP TABLE IF EXISTS "Genres" CASCADE;
DROP TABLE IF EXISTS "Localizations" CASCADE;
DROP TABLE IF EXISTS "Platforms" CASCADE;
DROP TABLE IF EXISTS "Mailings" CASCADE;
DROP TABLE IF EXISTS "Users" CASCADE;
DROP TABLE IF EXISTS "EditionTypes" CASCADE;
DROP TABLE IF EXISTS "BotMessages" CASCADE;
DROP TABLE IF EXISTS "CurrencyRanges" CASCADE;
DROP TABLE IF EXISTS "Currencies" CASCADE;

-- Включаем обратно проверку внешних ключей
SET session_replication_role = 'origin';
