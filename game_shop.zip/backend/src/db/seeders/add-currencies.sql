INSERT INTO "Currencies" (code, name, symbol, exchange_rate, is_default, icon, "createdAt", "updatedAt")
VALUES 
    ('RUB', 'Российский рубль', '₽', 1.0, true, '/images/flags/ruflag.png', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('GBP', 'Британский фунт', '£', 112.5, false, '/images/flags/enflag.png', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (code) DO UPDATE 
SET 
    name = EXCLUDED.name,
    symbol = EXCLUDED.symbol,
    exchange_rate = EXCLUDED.exchange_rate,
    is_default = EXCLUDED.is_default,
    icon = EXCLUDED.icon,
    "updatedAt" = CURRENT_TIMESTAMP;
