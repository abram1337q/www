import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';
import db from '../../models/index.js';
import pkg from 'pg';
const { Pool } = pkg;

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

async function seedDatabase() {
    try {
        const pool = new Pool({
            connectionString: process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/game_shop'
        });

        console.log('Reading SQL file...');
        const sqlFile = join(__dirname, 'testData.sql');
        const sql = fs.readFileSync(sqlFile, 'utf8');

        console.log('Executing SQL...');
        await pool.query(sql);

        console.log('Database seeded successfully!');
        await pool.end();
    } catch (error) {
        console.error('Error seeding database:', error);
        process.exit(1);
    }
}

// Запускаем сидирование
seedDatabase();
