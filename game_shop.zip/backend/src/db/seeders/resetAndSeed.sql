-- Отключаем внешние ключи
SET session_replication_role = 'replica';

-- Очищаем таблицы
TRUNCATE TABLE "ProductCardGenres" CASCADE;
TRUNCATE TABLE "ProductCollectionCards" CASCADE;
TRUNCATE TABLE "ProductCards" CASCADE;
TRUNCATE TABLE "ProductCollections" CASCADE;
TRUNCATE TABLE "Genres" CASCADE;

-- Включаем внешние ключи
SET session_replication_role = 'origin';

-- Сбрасываем автоинкремент
ALTER SEQUENCE "ProductCards_id_seq" RESTART WITH 1;
ALTER SEQUENCE "ProductCollections_id_seq" RESTART WITH 1;
ALTER SEQUENCE "Genres_id_seq" RESTART WITH 1;
