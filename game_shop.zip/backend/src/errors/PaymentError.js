class PaymentError extends Error {
	constructor(message, status = 500) {
		super(message);
		this.name = 'PaymentError';
		this.status = status;
	}
}

export default PaymentError;
