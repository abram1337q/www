import { Op } from 'sequelize';
import { botApi } from '../bot/api.js';
import sequelize from '../config/database.js';
import Mailing from '../models/mailing.js';
import User from '../models/user.js';
import logger from '../utils/logger.js';

class MailingService {
	// Очищаем HTML-теги из текста, сохраняя форматирование для Telegram HTML форматирования
	cleanHtml(text) {
		if (!text) return '';

		// Предобработка: заменяем некоторые блочные элементы на соответствующие с сохранением содержимого
		let result = text
			// Замена списков на специальный маркер
			.replace(/<ul>(.*?)<\/ul>/gs, function (match, listContent) {
				return listContent
					.replace(/<li>(.*?)<\/li>/gs, '\n• $1')
					.replace(/<[^>]*>/g, '');
			})
			.replace(/<ol>(.*?)<\/ol>/gs, function (match, listContent) {
				let index = 1;
				return listContent
					.replace(
						/<li>(.*?)<\/li>/gs,
						function (match, itemContent) {
							return '\n' + index++ + '. ' + itemContent;
						}
					)
					.replace(/<[^>]*>/g, '');
			});

		// Преобразуем HTML в Telegram-поддерживаемую HTML-разметку
		result = result
			// Заменяем тегами Telegram HTML
			.replace(/<b>(.*?)<\/b>/gs, '<b>$1</b>')
			.replace(/<strong>(.*?)<\/strong>/gs, '<b>$1</b>')
			.replace(/<i>(.*?)<\/i>/gs, '<i>$1</i>')
			.replace(/<em>(.*?)<\/em>/gs, '<i>$1</i>')
			.replace(/<u>(.*?)<\/u>/gs, '<u>$1</u>')
			.replace(/<s>(.*?)<\/s>/gs, '<s>$1</s>')
			.replace(/<strike>(.*?)<\/strike>/gs, '<s>$1</s>')
			.replace(/<del>(.*?)<\/del>/gs, '<s>$1</s>')
			.replace(/<code>(.*?)<\/code>/gs, '<code>$1</code>')
			.replace(/<pre>(.*?)<\/pre>/gs, '<pre>$1</pre>')
			// Обрабатываем ссылки
			.replace(
				/<a\s+href=["'](.*?)["']\s*.*?>(.*?)<\/a>/gs,
				'<a href="$1">$2</a>'
			)
			// Преобразуем отступы и переносы строк
			.replace(/<p\s*.*?>(.*?)<\/p>/gs, '$1\n\n')
			.replace(/<h1\s*.*?>(.*?)<\/h1>/gs, '<b>$1</b>\n\n')
			.replace(/<h2\s*.*?>(.*?)<\/h2>/gs, '<b>$1</b>\n\n')
			.replace(/<h3\s*.*?>(.*?)<\/h3>/gs, '<b>$1</b>\n\n')
			.replace(/<h4\s*.*?>(.*?)<\/h4>/gs, '<b>$1</b>\n\n')
			.replace(/<h5\s*.*?>(.*?)<\/h5>/gs, '<b>$1</b>\n\n')
			.replace(/<h6\s*.*?>(.*?)<\/h6>/gs, '<b>$1</b>\n\n')
			.replace(/<br\s*\/?>/gs, '\n')
			.replace(/<hr\s*\/?>/gs, '\n-----\n')
			.replace(/<div\s*.*?>(.*?)<\/div>/gs, '$1\n');

		// Удаляем все оставшиеся HTML-теги, которые не поддерживаются Telegram
		result = result.replace(/<[^>]*>/gs, '');

		// Многократно заменяем множественные переносы строк на двойной перенос
		while (result.includes('\n\n\n')) {
			result = result.replace(/\n\n\n/g, '\n\n');
		}

		return result.trim();
	}

	// Метод для подготовки HTML-контента для Telegram
	// Telegram поддерживает ограниченный набор HTML-тегов: <b>, <i>, <u>, <s>, <code>, <pre>, <a>
	prepareForTelegram(text) {
		if (!text) return '';

		// Экранируем спецсимволы в HTML для Telegram
		// Telegram требует экранирования <, > за пределами тегов
		let result = text;

		// Найдем и сохраним все поддерживаемые HTML-теги
		const allowedTags = [
			'<b>',
			'</b>',
			'<i>',
			'</i>',
			'<u>',
			'</u>',
			'<s>',
			'</s>',
			'<code>',
			'</code>',
			'<pre>',
			'</pre>',
		];

		// Экранируем отдельно открывающиеся и закрывающиеся теги <a>
		const tagRegex = /<a\s+href="([^"]+)">|<\/a>/g;
		const matches = [...result.matchAll(tagRegex)];
		const placeholders = [];

		// Заменяем теги на плейсхолдеры
		for (let i = 0; i < matches.length; i++) {
			const match = matches[i];
			const placeholder = `___TELEGRAM_TAG_${i}___`;
			placeholders.push({
				placeholder,
				original: match[0],
			});
			result = result.replace(match[0], placeholder);
		}

		// Экранируем символы '<' и '>'
		result = result.replace(/</g, '&lt;').replace(/>/g, '&gt;');

		// Возвращаем разрешенные HTML-теги
		for (const tag of allowedTags) {
			const escaped = tag.replace(/</g, '&lt;').replace(/>/g, '&gt;');
			result = result.replace(new RegExp(escaped, 'g'), tag);
		}

		// Восстанавливаем теги <a> из плейсхолдеров
		for (const { placeholder, original } of placeholders) {
			result = result.replace(placeholder, original);
		}

		return result;
	}

	// Преобразуем текст для использования в Markdown формате
	escapeMarkdown(text) {
		if (!text) return '';

		// Экранируем специальные символы Markdown
		return (
			text
				.replace(/([_*[\]()~`>#+\-=|{}.!])/g, '\\$1')
				// Не экранируем спецсимволы внутри форматированного текста
				.replace(/\\\*([^*]+)\\\*/g, '*$1*')
				.replace(/\\_([^_]+)\\_/g, '_$1_')
				.replace(/\\~([^~]+)\\~/g, '~$1~')
				.replace(/\\`([^`]+)\\`/g, '`$1`')
				.replace(/\\\[([^\]]+)\\\]\\\(([^)]+)\\\)/g, '[$1]($2)')
		);
	}

	async processScheduledMailings() {
		try {
			const now = new Date();
			logger.info('Checking scheduled mailings at:', {
				utc: now.toISOString(),
				local: now.toString(),
			});

			// Получаем все запланированные рассылки, время которых наступило
			const scheduledMailings = await Mailing.findAll({
				where: {
					status: 'scheduled',
					scheduledAt: {
						[Op.lte]: now,
					},
				},
			});

			logger.info('Found scheduled mailings:', scheduledMailings.length);

			for (const mailing of scheduledMailings) {
				try {
					// Используем транзакцию для атомарной обработки рассылки
					await sequelize.transaction(async t => {
						// Получаем актуальные данные рассылки с блокировкой строки
						const freshMailing = await Mailing.findByPk(
							mailing.id,
							{
								transaction: t,
								lock: true, // блокировка записи для предотвращения параллельной обработки
							}
						);

						// Проверяем, что рассылка всё ещё в статусе scheduled
						if (
							!freshMailing ||
							freshMailing.status !== 'scheduled'
						) {
							logger.info(
								`Mailing ${mailing.id} already processed or status changed. Current status: ${freshMailing?.status}`
							);
							return;
						}

						// Меняем статус на "processing" до начала отправки
						await freshMailing.update(
							{
								status: 'processing',
							},
							{ transaction: t }
						);

						logger.info('Processing mailing:', {
							id: freshMailing.id,
							scheduledAt: freshMailing.scheduledAt,
							content:
								freshMailing.content.substring(0, 100) + '...',
						});

						// Отправляем рассылку внутри транзакции
						await this._sendMailingWithTransaction(freshMailing, t);
					});
				} catch (error) {
					logger.error(
						`Transaction error for mailing ${mailing.id}:`,
						error
					);
				}
			}
		} catch (error) {
			logger.error('Error processing scheduled mailings:', error);
		}
	}

	// Новый приватный метод для отправки рассылки внутри транзакции
	async _sendMailingWithTransaction(mailing, transaction) {
		try {
			// Получаем пользователей для рассылки
			// Если указан testTelegramId, отправляем только этому пользователю
			let users;
			if (mailing.testTelegramId) {
				users = await User.findAll({
					where: { telegramId: mailing.testTelegramId },
					transaction,
				});
				if (users.length === 0) {
					throw new Error(
						`Пользователь с Telegram ID ${mailing.testTelegramId} не найден`
					);
				}
			} else {
				// Получаем всех пользователей для обычной рассылки
				users = await User.findAll({ transaction });
			}

			// Очищаем контент от HTML-тегов, сохраняя форматирование
			const cleanContent = this.cleanHtml(mailing.content);

			// Проверяем длину сообщения (лимит Telegram - 4096 символов)
			if (cleanContent.length > 4096) {
				throw new Error(
					'Сообщение слишком длинное для отправки в Telegram'
				);
			}

			// Подготавливаем текст для отправки, выбираем HTML режим как более простой
			const telegramContent = this.prepareForTelegram(cleanContent);

			// Проверяем доступность изображения, если оно есть
			let imageAvailable = false;
			if (mailing.imageUrl) {
				imageAvailable = await this.checkImageUrl(mailing.imageUrl);
				if (!imageAvailable) {
					logger.warn(
						`Image not available for mailing ${mailing.id}, sending without image`
					);
				}
			}

			// Подготавливаем инлайн кнопку если она включена
			let replyMarkup = undefined;
			if (
				mailing.buttonEnabled &&
				mailing.buttonText &&
				mailing.buttonUrl
			) {
				replyMarkup = {
					inline_keyboard: [
						[
							{
								text: mailing.buttonText,
								web_app: { url: mailing.buttonUrl },
							},
						],
					],
				};
			}

			for (const user of users) {
				try {
					// Отправляем сообщение через бота
					if (mailing.imageUrl && imageAvailable) {
						await botApi.sendPhoto(
							user.telegramId,
							mailing.imageUrl,
							{
								caption: telegramContent,
								parse_mode: 'HTML',
								reply_markup: replyMarkup,
							}
						);
					} else {
						await botApi.sendMessage(
							user.telegramId,
							telegramContent,
							{
								parse_mode: 'HTML',
								reply_markup: replyMarkup,
							}
						);
					}
				} catch (userError) {
					logger.error(
						`Failed to send mailing to user ${user.telegramId}:`,
						userError
					);
				}
			}

			// Обновляем статус рассылки
			await mailing.update(
				{
					status: 'sent',
					sentAt: new Date(),
				},
				{ transaction }
			);

			logger.info(`Mailing ${mailing.id} sent successfully`);
		} catch (error) {
			logger.error(`Error sending mailing ${mailing.id}:`, error);

			// Помечаем рассылку как проблемную
			await mailing.update(
				{
					status: 'error',
				},
				{ transaction }
			);

			throw error; // Пробрасываем ошибку дальше для обработки в админ-панели
		}
	}

	// Публичный метод для обеспечения обратной совместимости
	async sendMailing(mailing) {
		return sequelize.transaction(async t => {
			return this._sendMailingWithTransaction(mailing, t);
		});
	}

	// Проверяем доступность изображения
	async checkImageUrl(url) {
		try {
			const response = await fetch(url, { method: 'HEAD' });
			if (!response.ok) {
				throw new Error(`HTTP error! status: ${response.status}`);
			}
			const contentType = response.headers.get('content-type');
			if (!contentType || !contentType.startsWith('image/')) {
				throw new Error('URL не является изображением');
			}
			return true;
		} catch (error) {
			logger.error(`Error checking image URL ${url}:`, error);
			return false;
		}
	}

	// Метод для немедленной отправки рассылки из админ-панели
	async sendMailingNow(mailingId) {
		// Используем транзакцию для безопасной отправки
		return sequelize.transaction(async t => {
			const mailing = await Mailing.findByPk(mailingId, {
				transaction: t,
				lock: true, // Блокируем запись для предотвращения параллельной обработки
			});

			if (!mailing) {
				throw new Error('Рассылка не найдена');
			}

			// Проверяем, что рассылка не отправляется и не отправлена
			if (['processing', 'sent'].includes(mailing.status)) {
				throw new Error(
					`Рассылка уже ${
						mailing.status === 'processing'
							? 'отправляется'
							: 'отправлена'
					}`
				);
			}

			// Меняем статус перед отправкой
			await mailing.update({ status: 'processing' }, { transaction: t });

			// Отправляем рассылку
			return this._sendMailingWithTransaction(mailing, t);
		});
	}
}

export default new MailingService();
