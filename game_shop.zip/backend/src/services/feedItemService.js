import db from '../models/index.js';

export const getFeedItems = async () => {
  try {
    return await db.FeedItem.findAll({
      include: [
        {
          model: db.ProductCollection,
          as: 'collection',
          include: [
            {
              model: db.ProductCard,
              as: 'products',
              through: { attributes: [] },
              include: [
                {
                  model: db.Edition,
                  as: 'editions',
                },
              ],
            },
          ],
        },
      ],
      order: [['position', 'ASC']],
    });
  } catch (error) {
    console.error('Error in getFeedItems:', error);
    throw error;
  }
};

export const getFeedItemById = async (id) => {
  try {
    return await db.FeedItem.findByPk(id, {
      include: [
        {
          model: db.ProductCollection,
          as: 'collection',
          include: [
            {
              model: db.ProductCard,
              as: 'products',
              through: { attributes: [] },
              include: [
                {
                  model: db.Edition,
                  as: 'editions',
                },
              ],
            },
          ],
        },
      ],
    });
  } catch (error) {
    console.error(`Error in getFeedItemById for id ${id}:`, error);
    throw error;
  }
};