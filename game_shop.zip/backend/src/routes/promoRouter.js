// backend/src/routes/promoRouter.js
import { Router } from 'express';
import db from '../models/index.js';

const router = Router();

// GET / - Получить все активные промокоды
router.get('/', async (req, res) => {
	try {
		const promos = await db.Promo.findAll({
			where: { isActive: true },
			attributes: ['id', 'name', 'discount'],
			order: [['name', 'ASC']],
		});
		res.json(promos);
	} catch (error) {
		console.error('Error fetching promos:', error);
		res.status(500).json({ error: 'Internal server error' });
	}
});

// GET /:name - Проверить промокод по названию
router.get('/:name', async (req, res) => {
	try {
		// Получаем userId из Telegram WebApp
		const userId = req.headers['x-telegram-user-id'];
		// Получаем currencyId из заголовка или query параметра
		const currencyId = req.headers['x-currency-id'] || req.query.currencyId || 1;

		if (!userId) {
			return res.status(401).json({
				error: 'Unauthorized: User ID not provided',
			});
		}

		const promo = await db.Promo.findOne({
			where: {
				name: req.params.name,
				isActive: true,
			},
		});

		if (!promo) {
			return res.status(404).json({
				error: 'Промокод не найден или неактивен',
			});
		}

		// Проверяем, использовал ли пользователь этот промокод в данном регионе
		const usedPromo = await db.UsedPromo.findOne({
			where: {
				userId: userId,
				promoId: promo.id,
				currencyId: parseInt(currencyId),
			},
		});

		if (usedPromo) {
			return res.status(400).json({
				error: 'Вы уже использовали этот промокод в этом регионе',
			});
		}

		// НЕ создаем запись об использовании здесь!
		// Запись будет создана только при успешной оплате

		res.json({
			id: promo.id,
			name: promo.name,
			discount: promo.discount,
		});
	} catch (error) {
		console.error('Error checking promo:', error);
		res.status(500).json({ error: 'Internal server error' });
	}
});

export default router;


