import axios from 'axios';
import crypto from 'crypto';
import express from 'express';
import multer from 'multer';
import PaymentError from '../errors/PaymentError.js';
import Payment from '../models/Payment.js';
import { Currency, Edition, Promo, UsedPromo } from '../models/index.js';

const router = express.Router();

// Настройка multer для обработки multipart/form-data
const upload = multer({
    limits: {
        fileSize: 5 * 1024 * 1024, // 5MB limit
    },
});

// Life-Pay API configuration
const LIFEPAY_CONFIG = {
    apikey: '24ce157c42c081aedd7ac217927c6810',
    login: '79289366631',
};

// Life-Pay API endpoints
const LIFEPAY_API = {
    CREATE_BILL: 'https://api.life-pay.ru/v1/bill',
    CHECK_STATUS: 'https://api.life-pay.ru/v1/bill/status',
    CANCEL_BILL: 'https://api.life-pay.ru/v1/bill/cancellation',
};

// Проверяем наличие необходимых переменных окружения
const requiredEnvVars = {
    TELEGRAM_WEB_APP_URL: process.env.TELEGRAM_WEB_APP_URL,
    VITE_API_BASE_URL: process.env.VITE_API_BASE_URL,
    BOT_URL: process.env.BOT_URL,
};

const missingVars = Object.entries(requiredEnvVars)
    .filter(([_, value]) => !value)
    .map(([key]) => key);

if (missingVars.length > 0) {
    console.error('Missing required environment variables:', {
        missing: missingVars,
        current: requiredEnvVars,
    });
    throw new Error(
        `Missing required environment variables: ${missingVars.join(', ')}`
    );
}

// Функция для формирования подписи
const generateSignature = (data, apiKey) => {
    const signatureFields = ['login', 'amount', 'order_id', 'version'];
    const values = [];

    // Собираем значения в правильном порядке
    for (const field of signatureFields) {
        const value = data[field];
        if (value !== undefined && value !== null && value !== '') {
            values.push(value);
        }
    }

    const signatureString = values.join(':') + ':' + apiKey;
    console.log('Signature string:', signatureString);

    return crypto.createHash('md5').update(signatureString).digest('hex');
};

// Создание счета в Life-Pay
router.post('/create-bill', async (req, res, next) => {
    console.log('Received create-bill request:', req.body);
    try {
        const {
            amount,
            email,
            description,
            telegramUsername,
            telegramId,
            checkoutWithoutAccount,
            psLogin,
            psPassword,
            psBackupCodes,
            firstName,
            lastName,
            customerEmail,
            birthDate,
            gameInfo,
            currency,
            promoCode,
        } = req.body;

        console.log('Game info received:', {
            count: gameInfo?.length,
            games: gameInfo,
            currency,
        });

        // Получаем информацию о изданиях из базы данных
        const editionIds = gameInfo.map(game => game.editionId);
        const editions = await Edition.findAll({
            where: {
                id: editionIds,
            },
            include: [
                {
                    model: Currency,
                    as: 'currency',
                },
            ],
        });

        // Добавляем оригинальные цены к gameInfo
        const editionMap = new Map(
            editions.map(edition => [edition.id, edition])
        );
        const enrichedGameInfo = gameInfo.map(game => {
            const edition = editionMap.get(game.editionId);
            // Определяем какую оригинальную цену показывать
            // Если есть discount_amount - это цена со скидкой, иначе обычная price
            const baseOriginalPrice = edition?.discount_amount || edition?.price;

            return {
                ...game,
                originalPrice: baseOriginalPrice, // Цена со скидкой (если есть) или обычная
                originalCurrency: edition?.currency?.symbol || '₽',
                originalPsPlusPrice: edition?.ps_plus_price,
                originalEaPlayPrice: edition?.ea_play_price,
            };
        });

        // Подробная валидация входных данных
        const validationErrors = [];

        if (!email) validationErrors.push('email is required');

        if (validationErrors.length > 0) {
            console.error('Validation errors:', validationErrors);
            throw new PaymentError(
                `Missing required fields: ${validationErrors.join(', ')}`,
                400
            );
        }

        // Валидация суммы и округление в меньшую сторону
        const parsedAmount = parseFloat(amount);
        if (
            isNaN(parsedAmount) ||
            parsedAmount <= 0 ||
            parsedAmount > 1000000
        ) {
            throw new PaymentError('Invalid amount', 400);
        }

        // Округляем сумму в меньшую сторону (убираем копейки)
        const roundedAmount = Math.floor(parsedAmount);

        // Создаем запись в БД
        const orderId = crypto.randomUUID();

        // Логируем данные для отладки (без вывода полного пароля)
        console.log('Creating payment record with PS Store credentials:', {
            psLogin: psLogin || 'not provided',
            psPassword: psPassword
                ? `${psPassword.length} chars`
                : 'not provided',
            psPasswordType: typeof psPassword,
            psBackupCodes: psBackupCodes ? 'provided' : 'not provided',
        });

        const payment = new Payment({
            orderId,
            amount: roundedAmount,
            email,
            description,
            telegramUsername,
            telegramId,
            checkoutWithoutAccount,
            psLogin: psLogin || null,
            psPassword: psPassword ? String(psPassword) : null,
            psBackupCodes: psBackupCodes || null,
            firstName: firstName || null,
            lastName: lastName || null,
            customerEmail: customerEmail || null,
            birthDate: birthDate || null,
            gameInfo: enrichedGameInfo, // Используем обогащенный gameInfo
            currency,
            promoCode: promoCode || null, // Сохраняем промокод
            status: 'pending',
            createdAt: new Date(),
        });

        // Сохраняем платеж в базу данных
        await payment.save();

        console.log('Payment created in database:', payment.orderId);

        // Формируем данные для запроса к Life-Pay
        const baseUrl = process.env.VITE_API_BASE_URL || 'pwstore.ru';
        const requestData = {
            login: LIFEPAY_CONFIG.login,
            apikey: LIFEPAY_CONFIG.apikey,
            amount: roundedAmount.toString(),
            order_id: payment.orderId,
            description: description,
            customer_email: email,
            method: 'sbp',
            callback_url: `${baseUrl}/api/payment/lifepay-webhook`,
            version: '1.0',
        };

        // Генерируем подпись
        console.log('Generating signature with data:', {
            login: requestData.login,
            amount: requestData.amount,
            order_id: requestData.order_id,
            version: requestData.version,
        });

        const signature = generateSignature(requestData, LIFEPAY_CONFIG.apikey);
        requestData.signature = signature;

        console.log('Final request data:', requestData);

        // Отправляем запрос в Life-Pay
        const response = await axios.post(
            LIFEPAY_API.CREATE_BILL,
            requestData,
            {
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                },
            }
        );

        console.log('Life-Pay response:', response.data);

        // Проверяем ответ
        if (response.data.code !== 0) {
            throw new PaymentError(
                `Life-Pay error: ${response.data.message}`,
                400
            );
        }

        // Обновляем платеж с данными от Life-Pay
        await Payment.update(
            {
                paymentUrl: response.data.data.paymentUrlWeb,
                lifepayNumber: response.data.data.number,
            },
            {
                where: { orderId: payment.orderId },
            }
        );

        console.log(
            'Payment updated with URL:',
            response.data.data.paymentUrlWeb
        );

        // Отправляем уведомление в бот
        try {
            console.log('Sending notification to bot:', {
                telegramUsername,
                gameInfo: enrichedGameInfo,
                telegramId,
                checkoutWithoutAccount,
            });

            const botResponse = await axios.post(
                `${process.env.BOT_URL}/payment-notification`,
                {
                    telegramUsername,
                    gameInfo: enrichedGameInfo,
                    telegramId,
                    checkoutWithoutAccount,
                    psLogin,
                    psPassword,
                    psBackupCodes,
                    firstName,
                    lastName,
                    customerEmail,
                    birthDate,
                }
            );
            console.log('Bot notification sent:', botResponse.data);
        } catch (error) {
            console.error('Error sending bot notification:', error.message);
            // Продолжаем выполнение даже если уведомление не отправилось
        }

        res.json({
            success: true,
            paymentUrl: response.data.data.paymentUrlWeb,
            orderId: payment.orderId,
        });
    } catch (error) {
        next(error);
    }
});

// Проверка статуса платежа
router.get('/check-status/:billNumber', async (req, res) => {
    try {
        const { billNumber } = req.params;

        const requestData = {
            ...LIFEPAY_CONFIG,
            bill_id: billNumber,
        };

        const response = await axios.post(
            LIFEPAY_API.CHECK_STATUS,
            JSON.stringify(requestData),
            {
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                },
            }
        );

        res.json({
            success: true,
            status: response.data.data.status,
        });
    } catch (error) {
        console.error(
            'Life-Pay Status Check Error:',
            error.response?.data || error.message
        );
        res.status(500).json({
            success: false,
            message: 'Failed to check payment status',
        });
    }
});

router.post('/process-payment', async (req, res) => {
    console.log('Received payment request:', {
        telegramUsername: req.body.telegramUsername,
        email: req.body.email,
        itemsCount: req.body.items?.length,
        totalAmount: req.body.totalAmount,
    });

    try {
        const {
            psLogin,
            psPassword,
            telegramUsername,
            email,
            items,
            totalAmount,
        } = req.body;

        // Проверяем наличие всех необходимых данных
        if (
            !psLogin ||
            !psPassword ||
            !telegramUsername ||
            !email ||
            !items ||
            !totalAmount
        ) {
            console.error('Missing required fields in payment request');
            return res.status(400).json({
                success: false,
                message: 'Missing required fields',
            });
        }

        console.log('Sending notifications to bot for items:', items.length);

        // For each item in the cart, send notification to the bot
        for (const item of items) {
            try {
                console.log('Sending notification for item:', item.title);
                const finalPrice = item.discount_amount
                    ? item.price - item.discount_amount
                    : item.price;

                const botResponse = await axios.post(
                    `${process.env.BOT_URL}/payment-notification`,
                    {
                        telegramUsername,
                        gameInfo: {
                            title: item.title,
                            type: item.type,
                            edition: item.edition,
                            originalPrice: item.price,
                            discount: item.discount_amount,
                            finalPrice: finalPrice,
                        },
                    }
                );
                console.log('Bot response:', botResponse.data);
            } catch (error) {
                console.error('Error sending bot notification:', {
                    error: error.message,
                    item: item.title,
                    botUrl: process.env.BOT_URL,
                });
                // Continue processing other items even if one fails
            }
        }

        console.log('Payment processed successfully');
        res.json({ success: true, message: 'Payment processed successfully' });
    } catch (error) {
        console.error('Payment processing error:', {
            error: error.message,
            stack: error.stack,
        });
        res.status(500).json({
            success: false,
            message: 'Error processing payment',
            error: error.message,
        });
    }
});

// Life-Pay webhook handler
router.post('/lifepay-webhook', upload.none(), async (req, res) => {
    const timestamp = new Date().toISOString();
    console.log('==========================================');
    console.log(`Webhook received at ${timestamp}`);
    console.log('Headers:', JSON.stringify(req.headers, null, 2));

    try {
        // Парсим JSON из поля data
        const webhookData = JSON.parse(req.body.data);
        console.log('Parsed webhook data:', webhookData);

        // Проверяем наличие необходимых полей
        const requiredFields = [
            'number',
            'status',
            'type',
            'method',
            'amount',
            'description',
            'email',
            'created',
        ];
        const missingFields = requiredFields.filter(
            field => !webhookData[field]
        );

        if (missingFields.length > 0) {
            console.error('Missing required fields:', missingFields);
            return res.status(400).json({
                error: `Missing required fields: ${missingFields.join(', ')}`,
            });
        }

        // Ищем платеж в базе данных
        const payment = await Payment.findOne({
            where: {
                lifepayNumber: webhookData.number,
            },
        });

        if (!payment) {
            console.error('Payment not found:', webhookData.number);
            return res.status(404).json({ error: 'Payment not found' });
        }

        // Обновляем статус платежа
        const paymentStatus =
            webhookData.status === 'success' ? 'paid' : 'failed';

        await payment.update({
            status: paymentStatus,
            lifepayStatus: webhookData.status,
            paymentMethod: webhookData.method,
            lastWebhookAt: new Date(),
            completedAt: paymentStatus === 'paid' ? new Date() : null,
            errorMessage:
                webhookData.status === 'fail' ? webhookData.description : null,
        });

        // Если платеж успешный и был использован промокод, помечаем его как использованный
        if (paymentStatus === 'paid' && payment.promoCode && payment.telegramId) {
            try {
                // Находим промокод
                const promo = await Promo.findOne({
                    where: {
                        name: payment.promoCode,
                        isActive: true,
                    },
                });

                if (promo) {
                    // Получаем currencyId из информации о валюте платежа
                    const currencyId = payment.currency?.id || 1; // По умолчанию 1, если не указано

                    // Проверяем, не создана ли уже запись об использовании
                    const existingUsed = await UsedPromo.findOne({
                        where: {
                            userId: payment.telegramId,
                            promoId: promo.id,
                            currencyId: currencyId,
                        },
                    });

                    if (!existingUsed) {
                        // Создаем запись об использовании промокода
                        await UsedPromo.create({
                            userId: payment.telegramId,
                            promoId: promo.id,
                            currencyId: currencyId,
                        });
                        console.log(`Promo code ${payment.promoCode} marked as used by user ${payment.telegramId} for currency ${currencyId}`);
                    } else {
                        console.log(`Promo code ${payment.promoCode} was already marked as used by user ${payment.telegramId} for currency ${currencyId}`);
                    }
                } else {
                    console.log(`Promo code ${payment.promoCode} not found or inactive`);
                }
            } catch (error) {
                console.error('Error marking promo code as used:', error);
            }
        }

        // Если платеж успешный, отправляем уведомление в бот
        if (paymentStatus === 'paid' && !payment.notificationSent) {
            try {
                // Проверяем наличие gameInfo
                if (
                    !payment.gameInfo ||
                    !Array.isArray(payment.gameInfo) ||
                    payment.gameInfo.length === 0
                ) {
                    console.error('Invalid gameInfo for payment:', {
                        paymentId: payment.id,
                        gameInfo: payment.gameInfo,
                    });
                    return;
                }

                // Логируем данные для отладки (без вывода полного пароля)
                console.log(
                    'Sending payment notification to bot with PS Store credentials:',
                    {
                        psLogin: payment.psLogin || 'not provided',
                        psPassword: payment.psPassword
                            ? `${payment.psPassword.length} chars`
                            : 'not provided',
                        psPasswordType: typeof payment.psPassword,
                        psBackupCodes: payment.psBackupCodes
                            ? 'provided'
                            : 'not provided',
                    }
                );

                // Убедимся, что все данные передаются корректно
                const notificationData = {
                    telegramUsername: payment.telegramUsername,
                    telegramId: payment.telegramId,
                    gameInfo: payment.gameInfo, // отправляем весь массив
                    checkoutWithoutAccount: payment.checkoutWithoutAccount,
                    psLogin: payment.psLogin,
                    psPassword: payment.psPassword
                        ? String(payment.psPassword)
                        : null,
                    psBackupCodes: payment.psBackupCodes,
                    firstName: payment.firstName,
                    lastName: payment.lastName,
                    customerEmail: payment.customerEmail,
                    birthDate: payment.birthDate,
                    paymentStatus: paymentStatus, // Добавляем статус платежа
                    currency: payment.currency,
                    promoCode: payment.promoCode, // Добавляем промокод
                };

                console.log('Notification data prepared:', {
                    ...notificationData,
                    psPassword: notificationData.psPassword
                        ? 'provided'
                        : 'not provided',
                });

                const botResponse = await axios.post(
                    `${process.env.BOT_URL}/payment-notification`,
                    notificationData
                );

                if (botResponse.status === 200) {
                    await payment.update({ notificationSent: true });
                    console.log('Payment notification sent successfully:', {
                        paymentId: payment.id,
                        gameInfo: payment.gameInfo,
                    });
                }
            } catch (error) {
                console.error('Failed to send notification to bot:', {
                    error: error.message,
                    paymentId: payment.id,
                    gameInfo: payment.gameInfo,
                });
            }
        }

        return res.status(200).json({ status: 'success' });
    } catch (error) {
        console.error('Error processing webhook:', error);
        return res.status(500).json({ error: 'Internal server error' });
    }
});

// Получение статуса платежа
router.get('/status/:orderId', async (req, res, next) => {
    try {
        const { orderId } = req.params;

        // Проверяем статус в нашей БД
        const payment = await Payment.findOne({
            where: { orderId },
        });

        if (!payment) {
            throw new PaymentError('Payment not found', 404);
        }

        // Проверяем статус в Life-Pay
        const lifepayData = {
            apikey: LIFEPAY_CONFIG.apikey,
            login: LIFEPAY_CONFIG.login,
            number: payment.lifepayNumber,
        };

        let status = payment.status;
        let message = payment.message || '';

        try {
            // Формируем URL с параметрами для GET запроса
            const url = `${LIFEPAY_API.CHECK_STATUS}?${new URLSearchParams(
                lifepayData
            )}`;
            console.log('Checking Life-Pay status:', url);

            const response = await axios.get(url);

            console.log('Life-Pay status response:', {
                code: response.data.code,
                message: response.data.message,
                data: response.data.data,
            });

            // Если платеж уже помечен как completed в нашей БД
            if (payment.status === 'completed') {
                status = 'paid';
                message = 'Оплата успешно завершена';
            }
            // Если получили успешный ответ от Life-Pay (code === 0)
            else if (response.data.code === 0) {
                const lifepayStatus =
                    response.data.data?.[payment.lifepayNumber]?.status;
                const lifepayMessage =
                    response.data.data?.[payment.lifepayNumber]?.msg;

                console.log(
                    'Life-Pay status:',
                    lifepayStatus,
                    'message:',
                    lifepayMessage
                );

                if (lifepayStatus === 10) {
                    // успешная оплата
                    status = 'paid';
                    message = 'Оплата успешно завершена';

                    if (payment.status !== 'completed') {
                        await payment.update({
                            status: 'completed',
                            lifepayStatus: lifepayStatus,
                            completedAt: new Date(),
                        });
                    }
                } else if (lifepayStatus === 20 || lifepayStatus === 30) {
                    // неуспешная или отмененная
                    status = 'error';
                    message = lifepayMessage || 'Ошибка при оплате';

                    await payment.update({
                        status: 'failed',
                        lifepayStatus: lifepayStatus,
                        errorMessage: message,
                    });
                } else if (lifepayStatus === 15) {
                    // ожидает подтверждения
                    status = 'pending';
                    message = 'Ожидает подтверждения';
                } else if (lifepayStatus === 0) {
                    // инициирована
                    status = 'pending';
                    message = 'Платеж инициирован';
                } else if (!lifepayStatus) {
                    // не найден
                    status = 'error';
                    message = lifepayMessage || 'Платеж не найден';
                }
            }
            // Если получили ошибку от Life-Pay
            else {
                console.error('Invalid Life-Pay response:', response.data);
                // Если платеж уже помечен как completed в нашей БД
                if (payment.status === 'completed') {
                    status = 'paid';
                    message = 'Оплата успешно завершена';
                } else {
                    status = 'pending';
                    message = 'Проверка статуса платежа';
                }
            }
        } catch (error) {
            console.error(
                'Error checking Life-Pay status:',
                error.response?.data || error.message
            );
            // Если платеж уже помечен как completed в нашей БД
            if (payment.status === 'completed') {
                status = 'paid';
                message = 'Оплата успешно завершена';
            } else {
                status = 'pending';
                message = 'Проверка статуса платежа';
            }
        }

        // Отправляем статус клиенту
        console.log('Sending payment status:', { status, message });
        res.json({
            status,
            message,
            orderId,
            amount: payment.amount,
        });
    } catch (error) {
        next(error);
    }
});

// Проверка статуса платежа
router.post('/verify', async (req, res, next) => {
    try {
        const { orderId } = req.body;

        const payment = await Payment.findOne({
            where: { orderId },
        });

        if (!payment) {
            throw new PaymentError('Payment not found', 404);
        }

        // Проверяем статус в Life-Pay
        const response = await axios.post(LIFEPAY_API.CHECK_STATUS, {
            login: LIFEPAY_CONFIG.login,
            apikey: LIFEPAY_CONFIG.apikey,
            order_id: orderId,
        });

        const lifePayStatus = response.data.status;

        // Обновляем статус если он изменился
        if (lifePayStatus === 'success' && payment.status === 'pending') {
            await payment.update({
                status: 'paid',
                completedAt: new Date(),
            });
        } else if (lifePayStatus === 'fail' && payment.status === 'pending') {
            await payment.update({
                status: 'failed',
                errorMessage: 'Payment failed in Life-Pay',
            });
        }

        res.json({
            success: true,
            status: payment.status,
            orderId: payment.orderId,
        });
    } catch (error) {
        next(
            error instanceof PaymentError
                ? error
                : new PaymentError(error.message)
        );
    }
});

export default router;
