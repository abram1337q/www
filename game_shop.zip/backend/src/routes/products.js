import { Router } from 'express';
import { Op } from 'sequelize';
import sequelize from '../config/database.js';
import db from '../models/index.js';

const router = Router();

router.get('/', async (req, res) => {
    try {
        const { currency_id } = req.query;

        const products = await db.ProductCard.findAll({
            include: [
                {
                    model: db.Genre,
                    through: { attributes: [] },
                    as: 'genres',
                },
                {
                    model: db.Platform,
                    as: 'platforms',
                    through: { attributes: [] },
                },
                {
                    model: db.Edition,
                    as: 'editions',
                    where: currency_id
                        ? {
                                display_currency_id: currency_id,
                                is_hidden: false,
                          }
                        : {
                                is_hidden: false,
                          },
                    required: currency_id ? true : false,
                    attributes: [
                        'id',
                        'description',
                        'price',
                        'discount_amount',
                        'ea_play_price',
                        'ps_plus_price',
                        'promotion_end_date',
                        'rating',
                        'image_url',
                        'display_currency_id',
                    ],
                    include: [
                        {
                            model: db.EditionName,
                            as: 'editionName',
                            attributes: ['id', 'name'],
                        },
                        {
                            model: db.Currency,
                            as: 'displayCurrency',
                            attributes: ['id', 'code', 'symbol'],
                        },
                        {
                            model: db.Localization,
                            as: 'localizations',
                            through: { attributes: [] },
                        },
                        {
                            model: db.Platform,
                            as: 'platforms',
                            through: { attributes: [] },
                        },
                    ],
                },
            ],
            order: [['id', 'DESC']],
            attributes: [
                'id',
                'name',
                'image_url',
                'rating',
                'edition_type',
                'tags',
                'created_at',
                'updated_at',
            ],
            group: currency_id
                ? [
                        'ProductCard.id',
                        'genres.id',
                        'platforms.id',
                        'editions.id',
                        'editions->editionName.id',
                        'editions->displayCurrency.id',
                        'editions->localizations.id',
                        'editions->platforms.id',
                  ]
                : undefined,
        });

        res.json(products);
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

router.get('/search', async (req, res) => {
    try {
        // Включаем детальное логирование SQL-запросов
        // ОТКЛЮЧЕНО: SQL логирование создает огромное количество логов и нагружает систему
        // const originalLogging = sequelize.options.logging;
        // sequelize.options.logging = console.log;

        const { query, genres, priceFrom, priceTo, rating, currency_id } =
            req.query;

        // Получаем валюту пользователя
        let userCurrency;
        if (currency_id) {
            userCurrency = await db.Currency.findByPk(currency_id);
        } else {
            // Если валюта не указана, используем валюту по умолчанию
            userCurrency = await db.Currency.findOne({
                where: { is_default: true },
            });
        }

        if (!userCurrency) {
            return res.status(400).json({ error: 'Currency not found' });
        }

        // Получаем диапазоны валют для конвертации
        const currencyRanges = await db.CurrencyRange.findAll({
            where: {
                currencyId: userCurrency.id,
            },
            order: [['amountFrom', 'ASC']],
        });

        // Функция для получения множителя курса на основе диапазона
        const getRateMultiplier = amount => {
            if (!currencyRanges || currencyRanges.length === 0) return 1.0;

            const numericAmount = Number(amount);
            if (isNaN(numericAmount)) return 1.0;

            const range = currencyRanges.find(
                range =>
                    numericAmount >= Number(range.amountFrom) &&
                    numericAmount <= Number(range.amountTo)
            );

            return range ? Number(range.rate_multiplier) : 1.0;
        };

        const whereConditions = {};
        const editionWhereConditions = {
            is_hidden: false,
        };

        // Фильтр по валюте
        if (currency_id) {
            editionWhereConditions.display_currency_id = currency_id;
        }

        // ВАЖНО: Фильтрация по цене происходит ПОСЛЕ конвертации валют (строки 623-675)
        // Не фильтруем по цене в SQL, так как цены конвертируются с exchange_rate и rate_multiplier
        // и фактические цены отличаются от тех, что в базе данных

        // Фильтр по поисковому запросу
        if (query) {
            // Экранируем спецсимволы в запросе для предотвращения SQL-инъекций
            const safeQuery = query.replace(/[%_'"\\\x00-\x1F\x7F]/g, '');

            // Проверка минимальной длины запроса (минимум 3 символа)
            if (safeQuery.length < 3) {
                return res.status(200).json([]);
            }

            // Функция нормализации текста - удаляет специальные символы для сравнения
            const normalizeText = (text) => {
                return text
                    .toLowerCase()
                    .replace(/[^\w\sа-яё]/gi, '') // Удаляем все специальные символы, оставляя только буквы, цифры и пробелы
                    .replace(/\s+/g, ' ') // Заменяем множественные пробелы на одиночные
                    .trim();
            };

            // Список артиклей и предлогов для игнорирования
            const articles = ['the', 'a', 'an', 'of', 'and', 'or'];

            // Нормализованный поисковый запрос
            const normalizedQuery = normalizeText(safeQuery);

            // Преобразуем запрос в массив для поиска по тегам
            const searchTerms = safeQuery
                .split(/\s+/)
                .filter(term => term.length > 0);

            const conditions = [
                // 1. Поиск по названию игры с начала строки (основная логика)
                { name: { [Op.iLike]: `${safeQuery}%` } },
                // 2. Поиск по нормализованному названию с начала строки
                sequelize.literal(`
                    LOWER(REGEXP_REPLACE("ProductCard"."name", '[^\\w\\sа-яё]', '', 'gi'))
                    LIKE LOWER('${normalizedQuery}%')
                `),
            ];

            // 3. Прямой поиск по массиву тегов, если поле tags существует и является массивом
            try {
                // Стандартный поиск по тегам с начала строки
                conditions.push(
                    sequelize.literal(`
                        CASE WHEN "ProductCard"."tags" IS NOT NULL AND array_length("ProductCard"."tags", 1) > 0
                        THEN EXISTS (
                            SELECT 1 FROM unnest("ProductCard"."tags") AS tag
                            WHERE tag ILIKE '${safeQuery}%'
                        )
                        ELSE false
                        END
                    `)
                );

                // Нормализованный поиск по тегам с начала строки
                conditions.push(
                    sequelize.literal(`
                        CASE WHEN "ProductCard"."tags" IS NOT NULL AND array_length("ProductCard"."tags", 1) > 0
                        THEN EXISTS (
                            SELECT 1 FROM unnest("ProductCard"."tags") AS tag
                            WHERE LOWER(REGEXP_REPLACE(tag, '[^\\w\\sа-яё]', '', 'gi'))
                            LIKE LOWER('${normalizedQuery}%')
                        )
                        ELSE false
                        END
                    `)
                );

                // 4. Поиск конкретных тегов (точное совпадение с элементами массива)
                conditions.push({
                    tags: {
                        [Op.overlap]: searchTerms,
                    },
                });
            } catch (error) {
                console.error(
                    'Ошибка при создании условия для поиска по тегам:',
                    error
                );
            }

            // ========== ДОПОЛНИТЕЛЬНАЯ ЛОГИКА: УМНЫЙ ПОИСК С ИГНОРИРОВАНИЕМ АРТИКЛЕЙ ==========

            // Проверяем, не является ли запрос самим артиклем
            const isQueryAnArticle = articles.includes(normalizedQuery.toLowerCase());

            // 5. Поиск игр, которые начинаются с артикля + запрос
            // Например: запрос "Witcher" найдет "The Witcher", запрос "Walking" найдет "The Walking Dead"
            if (!isQueryAnArticle) {
                // Поиск названий, которые начинаются с артикля, за которым следует наш запрос
                conditions.push(
                    sequelize.literal(`
                        LOWER(REGEXP_REPLACE("ProductCard"."name", '[^\\w\\sа-яё]', '', 'gi'))
                        ~ LOWER('^(the|a|an|of|and|or)\\s+${normalizedQuery}')
                    `)
                );

                // Аналогичный поиск по тегам
                conditions.push(
                    sequelize.literal(`
                        CASE WHEN "ProductCard"."tags" IS NOT NULL AND array_length("ProductCard"."tags", 1) > 0
                        THEN EXISTS (
                            SELECT 1 FROM unnest("ProductCard"."tags") AS tag
                            WHERE LOWER(REGEXP_REPLACE(tag, '[^\\w\\sа-яё]', '', 'gi'))
                            ~ LOWER('^(the|a|an|of|and|or)\\s+${normalizedQuery}')
                        )
                        ELSE false
                        END
                    `)
                );
            }

            // ========== НОВАЯ ЛОГИКА: ПОИСК ПО ЛЮБОМУ СЛОВУ В НАЗВАНИИ ==========
            // Например: запрос "Durchen" найдет "Approve Durchen"

            // 6. Поиск по любому слову в названии (не только с начала)
            // Используем границы слов \\m для точного совпадения слов
            conditions.push(
                sequelize.literal(`
                    LOWER(REGEXP_REPLACE("ProductCard"."name", '[^\\w\\sа-яё]', '', 'gi'))
                    ~ LOWER('\\m${normalizedQuery}')
                `)
            );

            // 7. Поиск по любому слову в тегах
            conditions.push(
                sequelize.literal(`
                    CASE WHEN "ProductCard"."tags" IS NOT NULL AND array_length("ProductCard"."tags", 1) > 0
                    THEN EXISTS (
                        SELECT 1 FROM unnest("ProductCard"."tags") AS tag
                        WHERE LOWER(REGEXP_REPLACE(tag, '[^\\w\\sа-яё]', '', 'gi'))
                        ~ LOWER('\\m${normalizedQuery}')
                    )
                    ELSE false
                    END
                `)
            );

            // 8. Дополнительный поиск по части слова (для случаев вроде "Durch" найдет "Durchen")
            // Это более гибкий поиск, работает с подстроками внутри слов
            if (normalizedQuery.length >= 4) {
                conditions.push(
                    sequelize.literal(`
                        LOWER(REGEXP_REPLACE("ProductCard"."name", '[^\\w\\sа-яё]', '', 'gi'))
                        LIKE LOWER('%${normalizedQuery}%')
                    `)
                );

                conditions.push(
                    sequelize.literal(`
                        CASE WHEN "ProductCard"."tags" IS NOT NULL AND array_length("ProductCard"."tags", 1) > 0
                        THEN EXISTS (
                            SELECT 1 FROM unnest("ProductCard"."tags") AS tag
                            WHERE LOWER(REGEXP_REPLACE(tag, '[^\\w\\sа-яё]', '', 'gi'))
                            LIKE LOWER('%${normalizedQuery}%')
                        )
                        ELSE false
                        END
                    `)
                );
            }

            whereConditions[Op.or] = conditions;
        }

        // Фильтр по рейтингу
        if (rating) {
            whereConditions.rating = {
                [Op.gte]: rating,
            };
        }

        // Фильтр по жанрам с поддержкой AND логики
        if (genres) {
            const genreIds = genres.split(',').map(Number);

            // Если выбрано несколько жанров, используем логику AND (игра должна содержать ВСЕ жанры)
            if (genreIds.length > 1) {
                // Добавляем подзапрос, который проверяет наличие всех жанров
                whereConditions.id = {
                    [Op.in]: sequelize.literal(`(
                        SELECT product_card_id
                        FROM "ProductCardGenres"
                        WHERE genre_id IN (${genreIds.join(',')})
                        GROUP BY product_card_id
                        HAVING COUNT(DISTINCT genre_id) = ${genreIds.length}
                    )`)
                };
            }
        }

        const products = await db.ProductCard.findAll({
            where: whereConditions,
            include: [
                {
                    model: db.Genre,
                    through: { attributes: [] },
                    as: 'genres',
                    // Для одного жанра используем простой фильтр
                    // Для нескольких - уже отфильтровали через whereConditions
                    ...(genres && genres.split(',').length === 1 && {
                        where: {
                            id: {
                                [Op.in]: genres.split(',').map(Number),
                            },
                        },
                        required: true,
                    }),
                },
                {
                    model: db.Edition,
                    as: 'editions',
                    where: editionWhereConditions,
                    required: Object.keys(editionWhereConditions).length > 0,
                    attributes: [
                        'id',
                        'description',
                        'price',
                        'discount_amount',
                        'ea_play_price',
                        'ps_plus_price',
                        'promotion_end_date',
                        'rating',
                        'display_currency_id',
                        'image_url',
                    ],
                    include: [
                        {
                            model: db.EditionName,
                            as: 'editionName',
                            attributes: ['id', 'name'],
                        },
                        {
                            model: db.Currency,
                            as: 'currency',
                            attributes: ['id', 'code', 'exchange_rate'],
                        },
                        {
                            model: db.Localization,
                            as: 'localizations',
                            through: { attributes: [] },
                        },
                        {
                            model: db.Platform,
                            as: 'platforms',
                            through: { attributes: [] },
                        },
                    ],
                },
            ],
            attributes: [
                'id',
                'name',
                'image_url',
                'rating',
                'edition_type',
                'tags',
                'created_at',
                'updated_at',
            ],
            order: [
                // Сначала игры (Game), потом дополнения (DLC, Add-on и т.д.)
                [sequelize.literal(`CASE WHEN "ProductCard"."edition_type" = 'Игра' THEN 0 ELSE 1 END`), 'ASC'],
                ['id', 'DESC']
            ],
        });

        // Фильтруем по цене и конвертируем цены
        const filteredProducts = products
            .map(product => {
                const productJson = product.toJSON();

                // Логируем найденный продукт и его теги для отладки
                // console.log(`Найден продукт: ${productJson.name}`, {
                //     id: productJson.id,
                //     tags: productJson.tags || 'Отсутствуют',
                //     hasTagsField: 'tags' in productJson,
                // });

                if (productJson.editions) {
                    productJson.editions = productJson.editions.map(edition => {
                        if (edition.price && edition.currency) {
                            // Сохраняем оригинальные цены
                            edition.original_price = edition.price;
                            edition.original_discount_price =
                                edition.discount_amount;
                            edition.original_eaplay_price =
                                edition.ea_play_price;
                            edition.original_psplus_price =
                                edition.ps_plus_price;

                            // Конвертируем цену из валюты издания в валюту пользователя
                            const exchangeRate = edition.currency.exchange_rate;

                            // Конвертируем основную цену
                            const convertedPrice = edition.price * exchangeRate;
                            const baseMultiplier =
                                getRateMultiplier(convertedPrice);
                            edition.convertedPrice =
                                convertedPrice * baseMultiplier;

                            // Для цены со скидкой (если есть)
                            if (edition.discount_amount) {
                                // Проверяем, что скидка действительная
                                const originalPrice = parseFloat(edition.price);
                                const discountAmount = parseFloat(
                                    edition.discount_amount
                                );

                                if (
                                    !isNaN(originalPrice) &&
                                    !isNaN(discountAmount) &&
                                    discountAmount < originalPrice
                                ) {
                                    // Вычисляем скидку в процентах от оригинальной цены
                                    const discountPercent =
                                        ((originalPrice - discountAmount) /
                                            originalPrice) *
                                        100;

                                    // Рассчитываем конвертированную цену со скидкой
                                    const rawDiscountAmount =
                                        discountAmount * exchangeRate;

                                    // Получаем множитель для цены со скидкой на основе её величины
                                    const discountMultiplier =
                                        getRateMultiplier(rawDiscountAmount);

                                    // Применяем множитель к цене со скидкой
                                    const convertedDiscountAmount =
                                        rawDiscountAmount * discountMultiplier;

                                    // Устанавливаем конвертированную цену со скидкой
                                    edition.discount_amount =
                                        convertedDiscountAmount;
                                } else {
                                    // console.log(
                                    //     `Invalid discount for edition ${edition.id}, clearing discount amount`
                                    // );
                                    edition.discount_amount = null;
                                }
                            }

                            // Для PS Plus цены (если есть)
                            if (edition.ps_plus_price) {
                                // Проверяем, что PS Plus цена действительно меньше обычной
                                const originalPrice = parseFloat(edition.price);
                                const psPlusPrice = parseFloat(
                                    edition.ps_plus_price
                                );

                                if (
                                    !isNaN(originalPrice) &&
                                    !isNaN(psPlusPrice) &&
                                    psPlusPrice < originalPrice
                                ) {
                                    const convertedPsPlusPrice =
                                        edition.ps_plus_price * exchangeRate;
                                    const psPlusMultiplier =
                                        getRateMultiplier(convertedPsPlusPrice);
                                    edition.ps_plus_price =
                                        convertedPsPlusPrice * psPlusMultiplier;
                                } else {
                                    // console.log(
                                    //     `Invalid PS Plus price for edition ${edition.id}, clearing PS Plus price`
                                    // );
                                    edition.ps_plus_price = null;
                                }
                            }

                            // Для EA Play цены (если есть)
                            if (edition.ea_play_price) {
                                // Проверяем, что EA Play цена действительно меньше обычной
                                const originalPrice = parseFloat(edition.price);
                                const eaPlayPrice = parseFloat(
                                    edition.ea_play_price
                                );

                                if (
                                    !isNaN(originalPrice) &&
                                    !isNaN(eaPlayPrice) &&
                                    eaPlayPrice < originalPrice
                                ) {
                                    const convertedEaPlayPrice =
                                        edition.ea_play_price * exchangeRate;
                                    const eaPlayMultiplier =
                                        getRateMultiplier(convertedEaPlayPrice);
                                    edition.ea_play_price =
                                        convertedEaPlayPrice * eaPlayMultiplier;
                                } else {
                                    // console.log(
                                    //     `Invalid EA Play price for edition ${edition.id}, clearing EA Play price`
                                    // );
                                    edition.ea_play_price = null;
                                }
                            }
                        }
                        return edition;
                    });

                    // Фильтруем по цене после конвертации для дополнительной проверки
                    const beforeFilter = productJson.editions
                        ? productJson.editions.length
                        : 0;

                    if (priceFrom || priceTo) {
                        productJson.editions = productJson.editions.filter(
                            edition => {
                                // Определяем цену: со скидкой, если есть, иначе обычную
                                const price =
                                    edition.discount_amount !== null
                                        ? edition.discount_amount
                                        : edition.convertedPrice;

                                // Преобразуем значения в числа для сравнения
                                const numericPriceFrom = priceFrom
                                    ? parseFloat(priceFrom)
                                    : undefined;
                                const numericPriceTo = priceTo
                                    ? parseFloat(priceTo)
                                    : undefined;

                                // Проверяем валидность преобразованных значений
                                const validPriceFrom =
                                    numericPriceFrom !== undefined &&
                                    !isNaN(numericPriceFrom);
                                const validPriceTo =
                                    numericPriceTo !== undefined &&
                                    !isNaN(numericPriceTo);

                                // Проверяем условия фильтрации
                                const matchesMin =
                                    !validPriceFrom ||
                                    price >= numericPriceFrom;
                                const matchesMax =
                                    !validPriceTo || price <= numericPriceTo;

                                // Дополнительное логирование для отладки
                                // if (!matchesMin || !matchesMax) {
                                //     console.log(
                                //         `Издание ${edition.id} не прошло фильтр по цене:`,
                                //         {
                                //             фактическаяЦена: price,
                                //             минЦена: validPriceFrom
                                //                 ? numericPriceFrom
                                //                 : 'не задана',
                                //             максЦена: validPriceTo
                                //                 ? numericPriceTo
                                //                 : 'не задана',
                                //             соответствуетМин: matchesMin,
                                //             соответствуетМакс: matchesMax,
                                //         }
                                //     );
                                // }

                                return matchesMin && matchesMax;
                            }
                        );

                        const afterFilter = productJson.editions
                            ? productJson.editions.length
                            : 0;
                        // if (beforeFilter !== afterFilter) {
                        //     console.log(
                        //         `Вторичная фильтрация изменила количество изданий для продукта ${productJson.id}: ${beforeFilter} -> ${afterFilter}`
                        //     );
                        // }
                    }
                }

                return {
                    ...productJson,
                    title: productJson.name,
                };
            })
            .filter(product => product.editions?.length > 0);

        // Восстанавливаем исходное значение логирования
        // sequelize.options.logging = originalLogging;

        // console.log(`Found ${filteredProducts.length} products`);
        res.json(filteredProducts);
    } catch (error) {
        console.error('Search error:', error);
        res.status(500).json({
            error: 'Internal server error',
            details: error.message,
        });
    }
});

// Роут для получения игр с EA Play - должен быть перед роутом с :id
router.get('/subscription/ea-play', async (req, res) => {
    try {
        // console.log('EA Play route called with query:', req.query);
        const { currency_id } = req.query;

        // Получаем валюту пользователя
        let userCurrency;
        if (currency_id) {
            userCurrency = await db.Currency.findByPk(currency_id);
        } else {
            // Если валюта не указана, используем валюту по умолчанию
            userCurrency = await db.Currency.findOne({
                where: { is_default: true },
            });
        }

        if (!userCurrency) {
            return res.status(400).json({ error: 'Currency not found' });
        }

        // Получаем диапазоны валют для конвертации
        const currencyRanges = await db.CurrencyRange.findAll({
            where: {
                currencyId: userCurrency.id,
            },
            order: [['amountFrom', 'ASC']],
        });

        // Функция для получения множителя курса на основе диапазона
        const getRateMultiplier = amount => {
            if (!currencyRanges || currencyRanges.length === 0) return 1.0;

            const numericAmount = Number(amount);
            if (isNaN(numericAmount)) return 1.0;

            const range = currencyRanges.find(
                range =>
                    numericAmount >= Number(range.amountFrom) &&
                    numericAmount <= Number(range.amountTo)
            );

            return range ? Number(range.rate_multiplier) : 1.0;
        };

        const products = await db.ProductCard.findAll({
            where: {
                free_with_ea_play: true,
            },
            include: [
                {
                    model: db.Genre,
                    through: { attributes: [] },
                    as: 'genres',
                },
                {
                    model: db.Edition,
                    as: 'editions',
                    where: currency_id
                        ? {
                                display_currency_id: currency_id,
                          }
                        : {},
                    required: currency_id ? true : false,
                    attributes: [
                        'id',
                        'description',
                        'price',
                        'discount_amount',
                        'ea_play_price',
                        'ps_plus_price',
                        'promotion_end_date',
                        'rating',
                        'image_url',
                        'display_currency_id',
                    ],
                    include: [
                        {
                            model: db.EditionName,
                            as: 'editionName',
                            attributes: ['id', 'name'],
                        },
                        {
                            model: db.Currency,
                            as: 'currency',
                            attributes: [
                                'id',
                                'code',
                                'symbol',
                                'exchange_rate',
                            ],
                        },
                        {
                            model: db.Platform,
                            as: 'platforms',
                            through: { attributes: [] },
                        },
                    ],
                },
            ],
            attributes: [
                'id',
                'name',
                'image_url',
                'rating',
                'edition_type',
                'created_at',
                'updated_at',
            ],
        });

        // Конвертируем цены для каждого продукта и его изданий
        const productsWithConvertedPrices = products.map(product => {
            const productJson = product.toJSON();

            if (productJson.editions) {
                productJson.editions = productJson.editions.map(edition => {
                    if (edition.price && edition.currency) {
                        // Сохраняем оригинальные цены
                        edition.original_price = edition.price;
                        edition.original_discount_price =
                            edition.discount_amount;
                        edition.original_eaplay_price = edition.ea_play_price;
                        edition.original_psplus_price = edition.ps_plus_price;

                        // Конвертируем цену из валюты издания в валюту пользователя
                        const exchangeRate = edition.currency.exchange_rate;

                        // ИСПРАВЛЕННАЯ ЛОГИКА: Всегда конвертируем базовую цену отдельно
                        const basePrice = Number(edition.price) * exchangeRate;
                        const baseMultiplier = getRateMultiplier(basePrice);
                        edition.convertedPrice = basePrice * baseMultiplier;

                        // Для цены со скидкой (если есть)
                        if (edition.discount_amount) {
                            const discountPrice =
                                Number(edition.discount_amount) * exchangeRate;
                            const discountMultiplier =
                                getRateMultiplier(discountPrice);
                            edition.discount_amount =
                                discountPrice * discountMultiplier;

                            // console.log(
                            //     `Converted prices for edition ${edition.id}:`,
                            //     {
                            //         original: edition.original_price,
                            //         discounted: edition.original_discount_price,
                            //         convertedBase: edition.convertedPrice,
                            //         convertedDiscount: edition.discount_amount,
                            //     }
                            // );
                        }

                        // Для PS Plus цены (если есть)
                        if (edition.ps_plus_price) {
                            const psPlusPrice =
                                Number(edition.ps_plus_price) * exchangeRate;
                            const psPlusMultiplier =
                                getRateMultiplier(psPlusPrice);
                            edition.ps_plus_price =
                                psPlusPrice * psPlusMultiplier;
                        }

                        // Для EA Play цены (если есть)
                        if (edition.ea_play_price) {
                            const eaPlayPrice =
                                Number(edition.ea_play_price) * exchangeRate;
                            const eaPlayMultiplier =
                                getRateMultiplier(eaPlayPrice);
                            edition.ea_play_price =
                                eaPlayPrice * eaPlayMultiplier;
                        }

                        // Добавляем информацию о валюте пользователя
                        edition.displayCurrency = {
                            code: userCurrency.code,
                            id: userCurrency.id,
                            symbol: userCurrency.symbol,
                        };
                    }
                    return edition;
                });
            }

            return productJson;
        });

        res.json({ data: productsWithConvertedPrices });
    } catch (error) {
        console.error('Error fetching EA Play games:', error);
        res.status(500).json({
            error: 'Internal server error',
            details: error.message,
        });
    }
});

router.get('/subscription/ps-plus-essential', async (req, res) => {
    try {
        // console.log('PS Plus Essential route called with query:', req.query);
        const { currency_id } = req.query;

        // Получаем валюту пользователя
        let userCurrency;
        if (currency_id) {
            userCurrency = await db.Currency.findByPk(currency_id);
        } else {
            // Если валюта не указана, используем валюту по умолчанию
            userCurrency = await db.Currency.findOne({
                where: { is_default: true },
            });
        }

        if (!userCurrency) {
            return res.status(400).json({ error: 'Currency not found' });
        }

        // Получаем диапазоны валют для конвертации
        const currencyRanges = await db.CurrencyRange.findAll({
            where: {
                currencyId: userCurrency.id,
            },
            order: [['amountFrom', 'ASC']],
        });

        // Функция для получения множителя курса на основе диапазона
        const getRateMultiplier = amount => {
            if (!currencyRanges || currencyRanges.length === 0) return 1.0;

            const numericAmount = Number(amount);
            if (isNaN(numericAmount)) return 1.0;

            const range = currencyRanges.find(
                range =>
                    numericAmount >= Number(range.amountFrom) &&
                    numericAmount <= Number(range.amountTo)
            );

            return range ? Number(range.rate_multiplier) : 1.0;
        };

        const products = await db.ProductCard.findAll({
            where: {
                free_with_ps_plus_essential: true,
            },
            include: [
                {
                    model: db.Genre,
                    through: { attributes: [] },
                    as: 'genres',
                },
                {
                    model: db.Edition,
                    as: 'editions',
                    where: currency_id
                        ? {
                                display_currency_id: currency_id,
                          }
                        : {},
                    required: currency_id ? true : false,
                    attributes: [
                        'id',
                        'description',
                        'price',
                        'discount_amount',
                        'ea_play_price',
                        'ps_plus_price',
                        'promotion_end_date',
                        'rating',
                        'image_url',
                        'display_currency_id',
                    ],
                    include: [
                        {
                            model: db.EditionName,
                            as: 'editionName',
                            attributes: ['id', 'name'],
                        },
                        {
                            model: db.Currency,
                            as: 'currency',
                            attributes: [
                                'id',
                                'code',
                                'symbol',
                                'exchange_rate',
                            ],
                        },
                        {
                            model: db.Platform,
                            as: 'platforms',
                            through: { attributes: [] },
                        },
                    ],
                },
            ],
            attributes: [
                'id',
                'name',
                'image_url',
                'rating',
                'edition_type',
                'created_at',
                'updated_at',
            ],
        });

        // Конвертируем цены для каждого продукта и его изданий
        const productsWithConvertedPrices = products.map(product => {
            const productJson = product.toJSON();

            if (productJson.editions) {
                productJson.editions = productJson.editions.map(edition => {
                    if (edition.price && edition.currency) {
                        // Сохраняем оригинальные цены
                        edition.original_price = edition.price;
                        edition.original_discount_price =
                            edition.discount_amount;
                        edition.original_eaplay_price = edition.ea_play_price;
                        edition.original_psplus_price = edition.ps_plus_price;

                        // Конвертируем цену из валюты издания в валюту пользователя
                        const exchangeRate = edition.currency.exchange_rate;

                        // ИСПРАВЛЕННАЯ ЛОГИКА: Всегда конвертируем базовую цену отдельно
                        const basePrice = Number(edition.price) * exchangeRate;
                        const baseMultiplier = getRateMultiplier(basePrice);
                        edition.convertedPrice = basePrice * baseMultiplier;

                        // Для цены со скидкой (если есть)
                        if (edition.discount_amount) {
                            const discountPrice =
                                Number(edition.discount_amount) * exchangeRate;
                            const discountMultiplier =
                                getRateMultiplier(discountPrice);
                            edition.discount_amount =
                                discountPrice * discountMultiplier;

                            // console.log(
                            //     `Converted prices for edition ${edition.id}:`,
                            //     {
                            //         original: edition.original_price,
                            //         discounted: edition.original_discount_price,
                            //         convertedBase: edition.convertedPrice,
                            //         convertedDiscount: edition.discount_amount,
                            //     }
                            // );
                        }

                        // Для PS Plus цены (если есть)
                        if (edition.ps_plus_price) {
                            const psPlusPrice =
                                Number(edition.ps_plus_price) * exchangeRate;
                            const psPlusMultiplier =
                                getRateMultiplier(psPlusPrice);
                            edition.ps_plus_price =
                                psPlusPrice * psPlusMultiplier;
                        }

                        // Для EA Play цены (если есть)
                        if (edition.ea_play_price) {
                            const eaPlayPrice =
                                Number(edition.ea_play_price) * exchangeRate;
                            const eaPlayMultiplier =
                                getRateMultiplier(eaPlayPrice);
                            edition.ea_play_price =
                                eaPlayPrice * eaPlayMultiplier;
                        }

                        // Добавляем информацию о валюте пользователя
                        edition.displayCurrency = {
                            code: userCurrency.code,
                            id: userCurrency.id,
                            symbol: userCurrency.symbol,
                        };
                    }
                    return edition;
                });
            }

            return productJson;
        });

        res.json({ data: productsWithConvertedPrices });
    } catch (error) {
        console.error('Error fetching PS Plus Essential games:', error);
        res.status(500).json({
            error: 'Internal server error',
            details: error.message,
        });
    }
});

router.get('/subscription/ps-plus-extra', async (req, res) => {
    try {
        // console.log('PS Plus Extra route called with query:', req.query);
        const { currency_id } = req.query;

        // Получаем валюту пользователя
        let userCurrency;
        if (currency_id) {
            userCurrency = await db.Currency.findByPk(currency_id);
        } else {
            // Если валюта не указана, используем валюту по умолчанию
            userCurrency = await db.Currency.findOne({
                where: { is_default: true },
            });
        }

        if (!userCurrency) {
            return res.status(400).json({ error: 'Currency not found' });
        }

        // Получаем диапазоны валют для конвертации
        const currencyRanges = await db.CurrencyRange.findAll({
            where: {
                currencyId: userCurrency.id,
            },
            order: [['amountFrom', 'ASC']],
        });

        // Функция для получения множителя курса на основе диапазона
        const getRateMultiplier = amount => {
            if (!currencyRanges || currencyRanges.length === 0) return 1.0;

            const numericAmount = Number(amount);
            if (isNaN(numericAmount)) return 1.0;

            const range = currencyRanges.find(
                range =>
                    numericAmount >= Number(range.amountFrom) &&
                    numericAmount <= Number(range.amountTo)
            );

            return range ? Number(range.rate_multiplier) : 1.0;
        };

        const products = await db.ProductCard.findAll({
            where: {
                free_with_ps_plus_extra: true,
            },
            include: [
                {
                    model: db.Genre,
                    through: { attributes: [] },
                    as: 'genres',
                },
                {
                    model: db.Edition,
                    as: 'editions',
                    where: currency_id
                        ? {
                                display_currency_id: currency_id,
                          }
                        : {},
                    required: currency_id ? true : false,
                    attributes: [
                        'id',
                        'description',
                        'price',
                        'discount_amount',
                        'ea_play_price',
                        'ps_plus_price',
                        'promotion_end_date',
                        'rating',
                        'image_url',
                        'display_currency_id',
                    ],
                    include: [
                        {
                            model: db.EditionName,
                            as: 'editionName',
                            attributes: ['id', 'name'],
                        },
                        {
                            model: db.Currency,
                            as: 'currency',
                            attributes: [
                                'id',
                                'code',
                                'symbol',
                                'exchange_rate',
                            ],
                        },
                        {
                            model: db.Platform,
                            as: 'platforms',
                            through: { attributes: [] },
                        },
                    ],
                },
            ],
            attributes: [
                'id',
                'name',
                'image_url',
                'rating',
                'edition_type',
                'created_at',
                'updated_at',
            ],
        });

        // Конвертируем цены для каждого продукта и его изданий
        const productsWithConvertedPrices = products.map(product => {
            const productJson = product.toJSON();

            if (productJson.editions) {
                productJson.editions = productJson.editions.map(edition => {
                    if (edition.price && edition.currency) {
                        // Сохраняем оригинальные цены
                        edition.original_price = edition.price;
                        edition.original_discount_price =
                            edition.discount_amount;
                        edition.original_eaplay_price = edition.ea_play_price;
                        edition.original_psplus_price = edition.ps_plus_price;

                        // Конвертируем цену из валюты издания в валюту пользователя
                        const exchangeRate = edition.currency.exchange_rate;

                        // ИСПРАВЛЕННАЯ ЛОГИКА: Всегда конвертируем базовую цену отдельно
                        const basePrice = Number(edition.price) * exchangeRate;
                        const baseMultiplier = getRateMultiplier(basePrice);
                        edition.convertedPrice = basePrice * baseMultiplier;

                        // Для цены со скидкой (если есть)
                        if (edition.discount_amount) {
                            const discountPrice =
                                Number(edition.discount_amount) * exchangeRate;
                            const discountMultiplier =
                                getRateMultiplier(discountPrice);
                            edition.discount_amount =
                                discountPrice * discountMultiplier;

                            // console.log(
                            //     `Converted prices for edition ${edition.id}:`,
                            //     {
                            //         original: edition.original_price,
                            //         discounted: edition.original_discount_price,
                            //         convertedBase: edition.convertedPrice,
                            //         convertedDiscount: edition.discount_amount,
                            //     }
                            // );
                        }

                        // Для PS Plus цены (если есть)
                        if (edition.ps_plus_price) {
                            const psPlusPrice =
                                Number(edition.ps_plus_price) * exchangeRate;
                            const psPlusMultiplier =
                                getRateMultiplier(psPlusPrice);
                            edition.ps_plus_price =
                                psPlusPrice * psPlusMultiplier;
                        }

                        // Для EA Play цены (если есть)
                        if (edition.ea_play_price) {
                            const eaPlayPrice =
                                Number(edition.ea_play_price) * exchangeRate;
                            const eaPlayMultiplier =
                                getRateMultiplier(eaPlayPrice);
                            edition.ea_play_price =
                                eaPlayPrice * eaPlayMultiplier;
                        }

                        // Добавляем информацию о валюте пользователя
                        edition.displayCurrency = {
                            code: userCurrency.code,
                            id: userCurrency.id,
                            symbol: userCurrency.symbol,
                        };
                    }
                    return edition;
                });
            }

            return productJson;
        });

        res.json({ data: productsWithConvertedPrices });
    } catch (error) {
        console.error('Error fetching PS Plus Extra games:', error);
        res.status(500).json({
            error: 'Internal server error',
            details: error.message,
        });
    }
});

router.get('/subscription/ps-plus-deluxe', async (req, res) => {
    try {
        // console.log('PS Plus Deluxe route called with query:', req.query);
        const { currency_id } = req.query;

        // Получаем валюту пользователя
        let userCurrency;
        if (currency_id) {
            userCurrency = await db.Currency.findByPk(currency_id);
        } else {
            // Если валюта не указана, используем валюту по умолчанию
            userCurrency = await db.Currency.findOne({
                where: { is_default: true },
            });
        }

        if (!userCurrency) {
            return res.status(400).json({ error: 'Currency not found' });
        }

        // Получаем диапазоны валют для конвертации
        const currencyRanges = await db.CurrencyRange.findAll({
            where: {
                currencyId: userCurrency.id,
            },
            order: [['amountFrom', 'ASC']],
        });

        // Функция для получения множителя курса на основе диапазона
        const getRateMultiplier = amount => {
            if (!currencyRanges || currencyRanges.length === 0) return 1.0;

            const numericAmount = Number(amount);
            if (isNaN(numericAmount)) return 1.0;

            const range = currencyRanges.find(
                range =>
                    numericAmount >= Number(range.amountFrom) &&
                    numericAmount <= Number(range.amountTo)
            );

            return range ? Number(range.rate_multiplier) : 1.0;
        };

        const products = await db.ProductCard.findAll({
            where: {
                free_with_ps_plus_deluxe: true,
            },
            include: [
                {
                    model: db.Genre,
                    through: { attributes: [] },
                    as: 'genres',
                },
                {
                    model: db.Edition,
                    as: 'editions',
                    where: currency_id
                        ? {
                                display_currency_id: currency_id,
                          }
                        : {},
                    required: currency_id ? true : false,
                    attributes: [
                        'id',
                        'description',
                        'price',
                        'discount_amount',
                        'ea_play_price',
                        'ps_plus_price',
                        'promotion_end_date',
                        'rating',
                        'image_url',
                        'display_currency_id',
                    ],
                    include: [
                        {
                            model: db.EditionName,
                            as: 'editionName',
                            attributes: ['id', 'name'],
                        },
                        {
                            model: db.Currency,
                            as: 'currency',
                            attributes: [
                                'id',
                                'code',
                                'symbol',
                                'exchange_rate',
                            ],
                        },
                        {
                            model: db.Platform,
                            as: 'platforms',
                            through: { attributes: [] },
                        },
                    ],
                },
            ],
            attributes: [
                'id',
                'name',
                'image_url',
                'rating',
                'edition_type',
                'created_at',
                'updated_at',
            ],
        });

        // Конвертируем цены для каждого продукта и его изданий
        const productsWithConvertedPrices = products.map(product => {
            const productJson = product.toJSON();

            if (productJson.editions) {
                productJson.editions = productJson.editions.map(edition => {
                    if (edition.price && edition.currency) {
                        // Сохраняем оригинальные цены
                        edition.original_price = edition.price;
                        edition.original_discount_price =
                            edition.discount_amount;
                        edition.original_eaplay_price = edition.ea_play_price;
                        edition.original_psplus_price = edition.ps_plus_price;

                        // Конвертируем цену из валюты издания в валюту пользователя
                        const exchangeRate = edition.currency.exchange_rate;

                        // ИСПРАВЛЕННАЯ ЛОГИКА: Всегда конвертируем базовую цену отдельно
                        const basePrice = Number(edition.price) * exchangeRate;
                        const baseMultiplier = getRateMultiplier(basePrice);
                        edition.convertedPrice = basePrice * baseMultiplier;

                        // Для цены со скидкой (если есть)
                        if (edition.discount_amount) {
                            const discountPrice =
                                Number(edition.discount_amount) * exchangeRate;
                            const discountMultiplier =
                                getRateMultiplier(discountPrice);
                            edition.discount_amount =
                                discountPrice * discountMultiplier;

                            // console.log(
                            //     `Converted prices for edition ${edition.id}:`,
                            //     {
                            //         original: edition.original_price,
                            //         discounted: edition.original_discount_price,
                            //         convertedBase: edition.convertedPrice,
                            //         convertedDiscount: edition.discount_amount,
                            //     }
                            // );
                        }

                        // Для PS Plus цены (если есть)
                        if (edition.ps_plus_price) {
                            const psPlusPrice =
                                Number(edition.ps_plus_price) * exchangeRate;
                            const psPlusMultiplier =
                                getRateMultiplier(psPlusPrice);
                            edition.ps_plus_price =
                                psPlusPrice * psPlusMultiplier;
                        }

                        // Для EA Play цены (если есть)
                        if (edition.ea_play_price) {
                            const eaPlayPrice =
                                Number(edition.ea_play_price) * exchangeRate;
                            const eaPlayMultiplier =
                                getRateMultiplier(eaPlayPrice);
                            edition.ea_play_price =
                                eaPlayPrice * eaPlayMultiplier;
                        }

                        // Добавляем информацию о валюте пользователя
                        edition.displayCurrency = {
                            code: userCurrency.code,
                            id: userCurrency.id,
                            symbol: userCurrency.symbol,
                        };
                    }
                    return edition;
                });
            }

            return productJson;
        });

        res.json({ data: productsWithConvertedPrices });
    } catch (error) {
        console.error('Error fetching PS Plus Deluxe games:', error);
        res.status(500).json({
            error: 'Internal server error',
            details: error.message,
        });
    }
});

// Refresh cart/favorites items with actual prices and discounts
router.post('/refresh-cart-items', async (req, res) => {
    try {
        const { editionIds, currencyId } = req.body;

        if (!editionIds || !Array.isArray(editionIds) || !currencyId) {
            return res.status(400).json({
                success: false,
                error: 'editionIds array and currencyId are required',
            });
        }

        // Получаем валюту пользователя
        const userCurrency = await db.Currency.findByPk(currencyId);
        if (!userCurrency) {
            return res.status(400).json({
                success: false,
                error: 'Currency not found',
            });
        }

        // Получаем диапазоны для валюты
        const currencyRanges = await db.CurrencyRange.findAll({
            where: { currencyId: userCurrency.id },
            order: [['amountFrom', 'ASC']],
        });

        // Функция для получения множителя курса
        const getRateMultiplier = (amount) => {
            if (!currencyRanges || currencyRanges.length === 0) return 1.0;
            const numericAmount = Number(amount);
            if (isNaN(numericAmount)) return 1.0;

            const range = currencyRanges.find(
                range =>
                    numericAmount >= Number(range.amountFrom) &&
                    numericAmount <= Number(range.amountTo)
            );
            return range ? Number(range.rate_multiplier) : 1.0;
        };

        // Получаем актуальные данные изданий из БД (исключаем скрытые)
        const editions = await db.Edition.findAll({
            where: {
                id: { [Op.in]: editionIds },
                is_hidden: false, // Фильтруем скрытые издания
            },
            include: [
                {
                    model: db.Currency,
                    as: 'currency',
                    attributes: ['id', 'code', 'symbol', 'exchange_rate'],
                },
                {
                    model: db.EditionName,
                    as: 'editionName',
                    attributes: ['id', 'name'],
                },
                {
                    model: db.ProductCard,
                    as: 'productCard',
                    attributes: ['id', 'name', 'image_url', 'rating'],
                    include: [
                        {
                            model: db.Genre,
                            through: { attributes: [] },
                            as: 'genres',
                        },
                    ],
                },
                {
                    model: db.Platform,
                    as: 'platforms',
                    through: { attributes: [] },
                },
            ],
        });

        // Обрабатываем каждое издание
        const refreshedItems = editions.map(edition => {
            const exchangeRate = edition.currency?.exchange_rate || 1.0;

            // Конвертируем основную цену
            const convertedPrice = edition.price * exchangeRate;
            const baseMultiplier = getRateMultiplier(convertedPrice);
            const finalConvertedPrice = convertedPrice * baseMultiplier;

            // Конвертируем цену со скидкой (если есть)
            let convertedDiscountAmount = null;
            if (edition.discount_amount) {
                const rawDiscountAmount = edition.discount_amount * exchangeRate;
                const discountMultiplier = getRateMultiplier(rawDiscountAmount);
                convertedDiscountAmount = rawDiscountAmount * discountMultiplier;
            }

            // Конвертируем PS Plus цену (если есть)
            let convertedPsPlusPrice = null;
            if (edition.ps_plus_price !== null) {
                const rawPsPlusPrice = edition.ps_plus_price * exchangeRate;
                const psPlusMultiplier = getRateMultiplier(rawPsPlusPrice);
                convertedPsPlusPrice = rawPsPlusPrice * psPlusMultiplier;
            }

            // Конвертируем EA Play цену (если есть)
            let convertedEaPlayPrice = null;
            if (edition.ea_play_price !== null) {
                const rawEaPlayPrice = edition.ea_play_price * exchangeRate;
                const eaPlayMultiplier = getRateMultiplier(rawEaPlayPrice);
                convertedEaPlayPrice = rawEaPlayPrice * eaPlayMultiplier;
            }

            return {
                id: edition.id,
                productId: edition.productCard?.id,
                title: edition.productCard?.name,
                image: edition.image_url || edition.productCard?.image_url,
                rating: edition.productCard?.rating,
                genres: edition.productCard?.genres || [],
                platforms: edition.platforms || [],
                editionName: edition.editionName?.name,
                // Конвертированные цены
                price: Math.floor(finalConvertedPrice),
                discount_amount: convertedDiscountAmount ? Math.floor(convertedDiscountAmount) : null,
                ps_plus_price: convertedPsPlusPrice ? Math.floor(convertedPsPlusPrice) : null,
                ea_play_price: convertedEaPlayPrice ? Math.floor(convertedEaPlayPrice) : null,
                // Оригинальные данные для справки
                original_price: edition.price,
                original_discount: edition.discount_amount,
                currency: edition.currency,
                promotion_end_date: edition.promotion_end_date,
            };
        });

        return res.json({
            success: true,
            items: refreshedItems,
        });
    } catch (error) {
        console.error('Error refreshing cart items:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to refresh cart items',
            details: error.message,
        });
    }
});

// Calculate cart total with currency range and promo code
router.post('/calculate-cart-total', async (req, res) => {
    try {
        const {
            editionIds,
            selectedCurrencyId,
            currentTotal,
            priceTypes,
            promoCode,
        } = req.body;

        if (
            !editionIds ||
            !Array.isArray(editionIds) ||
            !selectedCurrencyId ||
            currentTotal === undefined
        ) {
            return res.status(400).json({
                success: false,
                error: 'editionIds array, selectedCurrencyId and currentTotal are required',
            });
        }

        // Получаем издания с полем lock_price
        const editions = await db.Edition.findAll({
            where: {
                id: {
                    [Op.in]: editionIds,
                },
            },
            include: [
                {
                    model: db.Currency,
                    as: 'currency',
                    attributes: ['id', 'code', 'exchange_rate'],
                },
            ],
        });

        // Получаем диапазоны для выбранной валюты
        const currencyRanges = await db.CurrencyRange.findAll({
            where: {
                currencyId: selectedCurrencyId,
            },
            order: [['amountFrom', 'ASC']],
        });

        console.log('=== PRICE LOCK CART CALCULATION ===');
        console.log('Total editions:', editions.length);

        // Функция для получения множителя курса на основе суммы
        const getRateMultiplier = (amount) => {
            if (!currencyRanges || currencyRanges.length === 0) return 1.0;
            const numericAmount = Number(amount);
            if (isNaN(numericAmount)) return 1.0;

            const range = currencyRanges.find(
                range =>
                    numericAmount >= Number(range.amountFrom) &&
                    numericAmount <= Number(range.amountTo)
            );
            return range ? Number(range.rate_multiplier) : 1.0;
        };

        // Разделяем товары на две группы: с Price Lock и без
        const lockedItems = [];
        const unlockedItems = [];

        editions.forEach(edition => {
            const editionId = edition.id;
            const priceType = priceTypes && priceTypes[editionId];
            const exchangeRate = edition.currency?.exchange_rate || 1.0;

            // Определяем базовую цену с учетом скидок
            let basePrice = edition.price;
            if (edition.discount_amount) {
                basePrice = edition.discount_amount;
            }

            // Определяем финальную цену с учетом типа цены (PS Plus, EA Play и т.д.)
            let finalPrice = basePrice;
            if (priceType === 'ps_plus' && edition.ps_plus_price !== null) {
                finalPrice = edition.ps_plus_price;
            } else if (priceType === 'ea_play' && edition.ea_play_price !== null) {
                finalPrice = edition.ea_play_price;
            }

            // Конвертируем цену в валюту пользователя
            const convertedPrice = finalPrice * exchangeRate;

            const itemData = {
                editionId,
                originalPrice: edition.price,
                discountedPrice: edition.discount_amount,
                finalPriceBeforeConversion: finalPrice,
                convertedPrice,
                exchangeRate,
                lockPrice: edition.lock_price || false,
            };

            // Разделяем по наличию Price Lock
            if (edition.lock_price) {
                lockedItems.push(itemData);
            } else {
                unlockedItems.push(itemData);
            }
        });

        console.log('Locked items count:', lockedItems.length);
        console.log('Unlocked items count:', unlockedItems.length);

        let finalTotal = 0;
        let itemPrices = [];

        // 1. Обрабатываем товары БЕЗ Price Lock (суммируем вместе)
        if (unlockedItems.length > 0) {
            const unlockedSum = unlockedItems.reduce((sum, item) => sum + item.convertedPrice, 0);
            const unlockedMultiplier = getRateMultiplier(unlockedSum);
            const unlockedTotal = unlockedSum * unlockedMultiplier;

            console.log('Unlocked items:', {
                count: unlockedItems.length,
                sum: unlockedSum.toFixed(2),
                multiplier: unlockedMultiplier,
                total: unlockedTotal.toFixed(2),
            });

            finalTotal += unlockedTotal;

            // Добавляем информацию о диапазоне для unlocked товаров
            unlockedItems.forEach(item => {
                itemPrices.push({
                    ...item,
                    appliedMultiplier: unlockedMultiplier,
                    groupType: 'unlocked',
                    groupSum: unlockedSum,
                    finalPrice: item.convertedPrice * unlockedMultiplier,
                });
            });
        }

        // 2. Обрабатываем товары С Price Lock (каждый отдельно)
        if (lockedItems.length > 0) {
            console.log('Processing locked items separately:');

            lockedItems.forEach(item => {
                const itemMultiplier = getRateMultiplier(item.convertedPrice);
                const itemTotal = item.convertedPrice * itemMultiplier;

                console.log(`  - Edition ${item.editionId}: ${item.convertedPrice.toFixed(2)} * ${itemMultiplier} = ${itemTotal.toFixed(2)}`);

                finalTotal += itemTotal;

                itemPrices.push({
                    ...item,
                    appliedMultiplier: itemMultiplier,
                    groupType: 'locked',
                    groupSum: item.convertedPrice,
                    finalPrice: itemTotal,
                });
            });
        }

        console.log('Total before promo:', finalTotal.toFixed(2));

        // Применяем промокод, если он указан
        let promoDiscount = 0;
        let appliedPromo = null;

        if (promoCode) {
            try {
                const userId = req.headers['x-telegram-user-id'];

                if (userId) {
                    const promo = await db.Promo.findOne({
                        where: {
                            name: promoCode,
                            isActive: true,
                        },
                    });

                    if (promo) {
                        const usedPromo = await db.UsedPromo.findOne({
                            where: {
                                userId: userId,
                                promoId: promo.id,
                            },
                        });

                        if (!usedPromo) {
                            promoDiscount = promo.discount;
                            finalTotal = finalTotal * (1 - promoDiscount / 100);
                            appliedPromo = {
                                id: promo.id,
                                name: promo.name,
                                discount: promo.discount,
                            };
                            console.log(`Applied promo code ${promoCode}: -${promoDiscount}%`);
                        }
                    }
                }
            } catch (error) {
                console.error('Error applying promo code:', error);
            }
        }

        console.log('Final total:', finalTotal.toFixed(2));
        console.log('=== END PRICE LOCK CALCULATION ===\n');

        return res.json({
            success: true,
            total: Math.floor(finalTotal),
            itemPrices,
            appliedPromo: appliedPromo,
            priceLocksInfo: {
                lockedCount: lockedItems.length,
                unlockedCount: unlockedItems.length,
            },
        });
    } catch (error) {
        console.error('Error calculating cart total:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to calculate cart total',
            details: error.message,
        });
    }
});

// Роут для получения конкретной игры по id
router.get('/:id', async (req, res) => {
    try {
        const { currency_id, priceFrom, priceTo } = req.query;
        // console.log(
        //     'Fetching product with id:',
        //     req.params.id,
        //     'currency_id:',
        //     currency_id,
        //     'price filters:',
        //     { priceFrom, priceTo }
        // );

        // Получаем валюту по умолчанию
        const defaultCurrency = await db.Currency.findOne({
            where: { is_default: true },
        });

        if (!defaultCurrency) {
            throw new Error('Default currency not found');
        }

        // Получаем выбранную пользователем валюту
        const userCurrency = currency_id
            ? await db.Currency.findByPk(currency_id)
            : defaultCurrency;

        if (!userCurrency) {
            throw new Error('Selected currency not found');
        }

        // console.log(
        //     'Using currency:',
        //     userCurrency.code,
        //     'id:',
        //     userCurrency.id
        // );

        // Получаем диапазоны для валюты пользователя
        const currencyRanges = await db.CurrencyRange.findAll({
            where: {
                currencyId: userCurrency.id,
            },
            order: [['amountFrom', 'ASC']],
        });

        // console.log('Found currency ranges:', currencyRanges.length);

        // Функция для получения множителя курса на основе диапазона
        const getRateMultiplier = amount => {
            if (!currencyRanges || currencyRanges.length === 0) return 1.0;

            const numericAmount = Number(amount);
            if (isNaN(numericAmount)) return 1.0;

            const range = currencyRanges.find(
                range =>
                    numericAmount >= Number(range.amountFrom) &&
                    numericAmount <= Number(range.amountTo)
            );

            return range ? Number(range.rate_multiplier) : 1.0;
        };

        // Сначала проверим, есть ли такой продукт
        const productExists = await db.ProductCard.findByPk(req.params.id);
        // console.log('Product exists:', !!productExists);

        // Проверим, есть ли издания для этого продукта
        const editions = await db.Edition.findAll({
            where: { product_card_id: req.params.id },
        });
        // console.log('Found editions:', editions.length);

        const product = await db.ProductCard.findByPk(req.params.id, {
            include: [
                {
                    model: db.Genre,
                    through: { attributes: [] },
                    as: 'genres',
                },
                {
                    model: db.Edition,
                    as: 'editions',
                    include: [
                        {
                            model: db.EditionName,
                            as: 'editionName',
                            attributes: ['id', 'name'],
                        },
                        {
                            model: db.Currency,
                            as: 'currency',
                            attributes: ['id', 'code', 'exchange_rate'],
                        },
                        {
                            model: db.Platform,
                            as: 'platforms',
                            through: { attributes: [] },
                        },
                        {
                            model: db.Localization,
                            as: 'localizations',
                            through: { attributes: [] },
                        },
                    ],
                },
            ],
        });

        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }

        const productJson = product.toJSON();

        // Конвертируем цены для каждого издания
        if (productJson.editions) {
            productJson.editions = productJson.editions.map(edition => {
                if (edition.price && edition.currency) {
                    // console.log(`Processing edition ${edition.id} prices:`, {
                    //     original_price: edition.price,
                    //     discount_amount: edition.discount_amount,
                    //     ps_plus_price: edition.ps_plus_price,
                    //     ea_play_price: edition.ea_play_price,
                    // });

                    // Сохраняем оригинальные цены
                    edition.original_price = edition.price;
                    edition.original_discount_price = edition.discount_amount;
                    edition.original_eaplay_price = edition.ea_play_price;
                    edition.original_psplus_price = edition.ps_plus_price;

                    // Конвертируем цену из валюты издания в валюту пользователя
                    const exchangeRate = edition.currency.exchange_rate;
                    // console.log(
                    //     `Exchange rate for edition ${edition.id}:`,
                    //     exchangeRate
                    // );

                    // Конвертируем основную цену
                    const convertedPrice = edition.price * exchangeRate;
                    const baseMultiplier = getRateMultiplier(convertedPrice);
                    edition.convertedPrice = convertedPrice * baseMultiplier;

                    // console.log(`Price conversion for edition ${edition.id}:`, {
                    //     basePrice: edition.price,
                    //     exchangeRate,
                    //     convertedPrice,
                    //     baseMultiplier,
                    //     finalPrice: edition.convertedPrice,
                    //     is_discounted: !!edition.discount_amount,
                    //     diff_percent: edition.discount_amount
                    //         ? Math.round(
                    //                 ((edition.price - edition.discount_amount) /
                    //                     edition.price) *
                    //                     100
                    //           )
                    //         : 0,
                    // });

                    // Для цены со скидкой (если есть)
                    if (edition.discount_amount) {
                        // Проверяем, что скидка действительная
                        const originalPrice = parseFloat(edition.price);
                        const discountAmount = parseFloat(
                            edition.discount_amount
                        );

                        if (
                            !isNaN(originalPrice) &&
                            !isNaN(discountAmount) &&
                            discountAmount < originalPrice
                        ) {
                            // Вычисляем скидку в процентах от оригинальной цены
                            const discountPercent =
                                ((originalPrice - discountAmount) /
                                    originalPrice) *
                                100;
                            // console.log(
                            //     `Скидка в процентах для издания ${
                            //         edition.id
                            //     }: ${discountPercent.toFixed(2)}%`
                            // );

                            // Рассчитываем конвертированную цену со скидкой
                            const rawDiscountAmount =
                                discountAmount * exchangeRate;

                            // Получаем множитель для цены со скидкой на основе её величины
                            const discountMultiplier =
                                getRateMultiplier(rawDiscountAmount);

                            // Применяем множитель к цене со скидкой
                            const convertedDiscountAmount =
                                rawDiscountAmount * discountMultiplier;

                            // console.log(
                            //     `Конвертированные цены для издания ${edition.id}:`,
                            //     {
                            //         original: edition.convertedPrice,
                            //         rawDiscountAmount,
                            //         discountMultiplier,
                            //         withDiscount: convertedDiscountAmount,
                            //         difference:
                            //             edition.convertedPrice -
                            //             convertedDiscountAmount,
                            //         percent: discountPercent,
                            //     }
                            // );

                            // Устанавливаем конвертированную цену со скидкой
                            edition.discount_amount = convertedDiscountAmount;

                            // console.log(
                            //     `Discount amount conversion for edition ${edition.id}:`,
                            //     {
                            //         original: edition.original_discount_price,
                            //         originalPrice: edition.price,
                            //         exchangeRate,
                            //         discountPercent:
                            //             discountPercent.toFixed(2) + '%',
                            //         final: edition.discount_amount,
                            //         difference:
                            //             edition.convertedPrice -
                            //             edition.discount_amount,
                            //     }
                            // );
                        } else {
                            // console.log(
                            //     `Invalid discount for edition ${edition.id}, clearing discount amount`
                            // );
                            edition.discount_amount = null;
                        }
                    }

                    // Для PS Plus цены (если есть)
                    if (edition.ps_plus_price) {
                        // Проверяем, что PS Plus цена действительно меньше обычной
                        const originalPrice = parseFloat(edition.price);
                        const psPlusPrice = parseFloat(edition.ps_plus_price);

                        if (
                            !isNaN(originalPrice) &&
                            !isNaN(psPlusPrice) &&
                            psPlusPrice < originalPrice
                        ) {
                            const convertedPsPlusPrice =
                                edition.ps_plus_price * exchangeRate;
                            const psPlusMultiplier =
                                getRateMultiplier(convertedPsPlusPrice);
                            edition.ps_plus_price =
                                convertedPsPlusPrice * psPlusMultiplier;

                            // console.log(
                            //     `PS Plus price conversion for edition ${edition.id}:`,
                            //     {
                            //         original: edition.original_psplus_price,
                            //         exchangeRate,
                            //         psPlusMultiplier,
                            //         final: edition.ps_plus_price,
                            //         discount:
                            //             Math.round(
                            //                 ((originalPrice - psPlusPrice) /
                            //                     originalPrice) *
                            //                     100
                            //             ) + '%',
                            //     }
                            // );
                        } else {
                            // console.log(
                            //     `Invalid PS Plus price for edition ${edition.id}, clearing PS Plus price`
                            // );
                            edition.ps_plus_price = null;
                        }
                    }

                    // Для EA Play цены (если есть)
                    if (edition.ea_play_price) {
                        // Проверяем, что EA Play цена действительно меньше обычной
                        const originalPrice = parseFloat(edition.price);
                        const eaPlayPrice = parseFloat(edition.ea_play_price);

                        if (
                            !isNaN(originalPrice) &&
                            !isNaN(eaPlayPrice) &&
                            eaPlayPrice < originalPrice
                        ) {
                            const convertedEaPlayPrice =
                                edition.ea_play_price * exchangeRate;
                            const eaPlayMultiplier =
                                getRateMultiplier(convertedEaPlayPrice);
                            edition.ea_play_price =
                                convertedEaPlayPrice * eaPlayMultiplier;

                            // console.log(
                            //     `EA Play price conversion for edition ${edition.id}:`,
                            //     {
                            //         original: edition.original_eaplay_price,
                            //         exchangeRate,
                            //         eaPlayMultiplier,
                            //         final: edition.ea_play_price,
                            //         discount:
                            //             Math.round(
                            //                 ((originalPrice - eaPlayPrice) /
                            //                     originalPrice) *
                            //                     100
                            //             ) + '%',
                            //     }
                            // );
                        } else {
                            // console.log(
                            //     `Invalid EA Play price for edition ${edition.id}, clearing EA Play price`
                            // );
                            edition.ea_play_price = null;
                        }
                    }
                }
                return edition;
            });

            // Выводим итоговую структуру изданий с ценами
            // console.log(
            //     'Final editions structure:',
            //     productJson.editions.map(edition => ({
            //         id: edition.id,
            //         name: edition.editionName?.name,
            //         price: edition.price,
            //         convertedPrice: edition.convertedPrice,
            //         discount_amount: edition.discount_amount,
            //         original_price: edition.original_price,
            //         is_discount_valid:
            //             edition.price &&
            //             edition.discount_amount &&
            //             parseFloat(edition.price) >
            //                 parseFloat(edition.discount_amount),
            //     }))
            // );
        }

        // Фильтруем по цене после конвертации для дополнительной проверки
        const beforeFilter = productJson.editions
            ? productJson.editions.length
            : 0;

        // Проверяем, что параметры фильтрации цены переданы и имеют значения
        const hasPriceFromFilter =
            priceFrom !== undefined && priceFrom !== null && priceFrom !== '';
        const hasPriceToFilter =
            priceTo !== undefined && priceTo !== null && priceTo !== '';

        if (hasPriceFromFilter || hasPriceToFilter) {
            // Преобразуем значения в числа, если они определены
            const numericPriceFrom = hasPriceFromFilter
                ? parseFloat(priceFrom)
                : undefined;
            const numericPriceTo = hasPriceToFilter
                ? parseFloat(priceTo)
                : undefined;

            // Проверяем, что значения валидные числа
            const validPriceFrom =
                numericPriceFrom !== undefined && !isNaN(numericPriceFrom);
            const validPriceTo =
                numericPriceTo !== undefined && !isNaN(numericPriceTo);

            // Для корректной работы с ценами со скидкой используем сложные условия
            const priceConditions = [];

            if (validPriceFrom) {
                priceConditions.push(edition => {
                    const price =
                        edition.discount_amount !== null
                            ? edition.discount_amount
                            : edition.convertedPrice;
                    return price >= numericPriceFrom;
                });
            }

            if (validPriceTo) {
                priceConditions.push(edition => {
                    const price =
                        edition.discount_amount !== null
                            ? edition.discount_amount
                            : edition.convertedPrice;
                    return price <= numericPriceTo;
                });
            }

            productJson.editions = productJson.editions.filter(edition =>
                priceConditions.every(condition => condition(edition))
            );

            const afterFilter = productJson.editions
                ? productJson.editions.length
                : 0;
            // if (beforeFilter !== afterFilter) {
            //     console.log(
            //         `Вторичная фильтрация изменила количество изданий для продукта ${productJson.id}: ${beforeFilter} -> ${afterFilter}`
            //     );
            // }
        }

        res.json({ data: productJson });
    } catch (error) {
        console.error('Error fetching product:', error);
        res.status(500).json({ error: error.message });
    }
});

export default router;
