const { Client } = require('pg');

const DB_CONFIG = {
  database: 'game_shop_db',
  user: 'nkarasyov',
  password: 'pAssW_ord123',
  host: '193.17.92.132',
  port: 5432,
};

async function addManualProtectionTrigger() {
  const client = new Client(DB_CONFIG);

  try {
    console.log('🔌 Подключение к базе данных...');
    await client.connect();
    console.log('✅ Подключение успешно!\n');

    // 1. Создаём функцию триггера для защиты manual записей от изменения цен
    console.log('📝 Создаём функцию protect_manual_prices()...');
    await client.query(`
      CREATE OR REPLACE FUNCTION protect_manual_prices()
      RETURNS TRIGGER AS $$
      BEGIN
        -- Если запись manual, блокируем изменение цен
        IF OLD.source = 'manual' THEN
          -- Блокируем изменение обычной цены
          IF NEW.price IS DISTINCT FROM OLD.price THEN
            RAISE NOTICE '🔒 Блокировка: Нельзя изменить price для manual записи (Edition ID: %). Изменение отменено.', OLD.id;
            NEW.price := OLD.price;
          END IF;

          -- Блокируем изменение цены со скидкой
          IF NEW.discount_amount IS DISTINCT FROM OLD.discount_amount THEN
            RAISE NOTICE '🔒 Блокировка: Нельзя изменить discount_amount для manual записи (Edition ID: %). Изменение отменено.', OLD.id;
            NEW.discount_amount := OLD.discount_amount;
          END IF;

          -- Блокируем изменение PS Plus цены
          IF NEW.ps_plus_price IS DISTINCT FROM OLD.ps_plus_price THEN
            RAISE NOTICE '🔒 Блокировка: Нельзя изменить ps_plus_price для manual записи (Edition ID: %). Изменение отменено.', OLD.id;
            NEW.ps_plus_price := OLD.ps_plus_price;
          END IF;

          -- Блокируем изменение EA Play цены
          IF NEW.ea_play_price IS DISTINCT FROM OLD.ea_play_price THEN
            RAISE NOTICE '🔒 Блокировка: Нельзя изменить ea_play_price для manual записи (Edition ID: %). Изменение отменено.', OLD.id;
            NEW.ea_play_price := OLD.ea_play_price;
          END IF;

          -- Блокируем изменение promotion_end_date
          IF NEW.promotion_end_date IS DISTINCT FROM OLD.promotion_end_date THEN
            RAISE NOTICE '🔒 Блокировка: Нельзя изменить promotion_end_date для manual записи (Edition ID: %). Изменение отменено.', OLD.id;
            NEW.promotion_end_date := OLD.promotion_end_date;
          END IF;
        END IF;

        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql;
    `);
    console.log('✅ Функция protect_manual_prices() создана\n');

    // 2. Проверяем, есть ли уже такой триггер
    console.log('🔍 Проверяем наличие триггера...');
    const checkTrigger = await client.query(`
      SELECT tgname
      FROM pg_trigger
      WHERE tgname = 'trigger_protect_manual_prices'
      AND tgrelid = '"Editions"'::regclass;
    `);

    if (checkTrigger.rows.length > 0) {
      console.log('⚠️  Триггер уже существует, удаляем старый...');
      await client.query(`DROP TRIGGER IF EXISTS trigger_protect_manual_prices ON "Editions";`);
      console.log('✅ Старый триггер удалён\n');
    }

    // 3. Создаём триггер
    console.log('📝 Создаём триггер trigger_protect_manual_prices...');
    await client.query(`
      CREATE TRIGGER trigger_protect_manual_prices
      BEFORE UPDATE ON "Editions"
      FOR EACH ROW
      EXECUTE FUNCTION protect_manual_prices();
    `);
    console.log('✅ Триггер trigger_protect_manual_prices создан!\n');

    // 4. Также создадим триггер для индивидуальных блокировок (lock_* поля)
    console.log('📝 Создаём триггер для индивидуальных блокировок (lock_*)...');

    const checkLockTrigger = await client.query(`
      SELECT tgname
      FROM pg_trigger
      WHERE tgname = 'trigger_prevent_locked_price_update'
      AND tgrelid = '"Editions"'::regclass;
    `);

    if (checkLockTrigger.rows.length > 0) {
      console.log('⚠️  Триггер уже существует, пропускаем...\n');
    } else {
      await client.query(`
        CREATE TRIGGER trigger_prevent_locked_price_update
        BEFORE UPDATE ON "Editions"
        FOR EACH ROW
        EXECUTE FUNCTION prevent_locked_price_update();
      `);
      console.log('✅ Триггер trigger_prevent_locked_price_update создан!\n');
    }

    // 5. Проверяем результат
    console.log('═'.repeat(80));
    console.log('📊 ПРОВЕРКА УСТАНОВЛЕННЫХ ТРИГГЕРОВ:');
    console.log('═'.repeat(80));

    const allTriggers = await client.query(`
      SELECT
        t.tgname AS trigger_name,
        p.proname AS function_name,
        CASE
          WHEN t.tgtype & 2 = 2 THEN 'BEFORE'
          WHEN t.tgtype & 64 = 64 THEN 'INSTEAD OF'
          ELSE 'AFTER'
        END AS timing,
        CASE
          WHEN t.tgtype & 16 = 16 THEN 'UPDATE'
          ELSE 'OTHER'
        END AS event
      FROM pg_trigger t
      JOIN pg_class c ON t.tgrelid = c.oid
      JOIN pg_proc p ON t.tgfoid = p.oid
      WHERE c.relname = 'Editions'
      AND t.tgisinternal = false
      AND t.tgtype & 16 = 16
      ORDER BY t.tgname;
    `);

    console.log('\nТриггеры на UPDATE таблицы Editions:');
    allTriggers.rows.forEach((trigger, index) => {
      console.log(`\n${index + 1}. ${trigger.trigger_name}`);
      console.log(`   Функция: ${trigger.function_name}()`);
      console.log(`   Событие: ${trigger.timing} ${trigger.event}`);
    });

    console.log('\n' + '═'.repeat(80));
    console.log('✅ УСПЕШНО! Защита manual записей установлена!');
    console.log('═'.repeat(80));
    console.log('\n📋 Теперь работают следующие механизмы защиты:');
    console.log('   1. protect_manual_prices() - блокирует изменение цен у manual записей');
    console.log('   2. prevent_locked_price_update() - блокирует по полям lock_*');
    console.log('   3. protect_global_locked_prices() - глобальная блокировка через Settings');
    console.log('\n🔒 UPDATE в update.py больше НЕ СМОЖЕТ изменить цены у manual записей!\n');

  } catch (error) {
    console.error('❌ Ошибка:', error.message);
    console.error(error.stack);
  } finally {
    await client.end();
    console.log('🔌 Подключение закрыто');
  }
}

addManualProtectionTrigger();
