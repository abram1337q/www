import asyncio
import aiohttp
from json import dumps, loads
from random import choice
import asyncpg
from dotenv import load_dotenv
from datetime import datetime
import os, sys
from time import sleep


def get_params(url: str):
    product_type, sku = url.split("/")[-2:]
    queries = {
        "concept": {
                "operationName": "conceptRetrieveForCtasWithPrice",
                "variables": dumps({"conceptId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "eab9d873f90d4ad98fd55f07b6a0a606e6b3925f2d03b70477234b79c1df30b5"
                    }
                })
            }
        ,
        "product": [
            {
                "operationName": "productRetrieveForCtasWithPrice",
                "variables": dumps({"productId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "8872b0419dcab2fea5916ef698544c237b1096f9e76acc6aacf629551adee8cd"
                    }
                })
            },
            {
                "operationName": "productRetrieveForUpsellWithCtas",
                "variables": dumps({"productId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "fb0bfa0af4d8dc42b28fa5c077ed715543e7fb8a3deff8117a50b99864d246f1"
                    }
                })
            }
        ]
    }
    return queries[product_type]


header=lambda: choice([
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15'
                ])


json_headers = lambda x: {
    "Accept": "application/json",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "en-US",
    "apollographql-client-name": "@sie-private/web-commerce-anywhere",
    "apollographql-client-version": "3.23.0",
    "Cache-Control": "no-cache",
    "Content-Type": "application/json",
    "disable_query_whitelist": "false",
    "Origin": "https://store.playstation.com",
    "Pragma": "no-cache",
    "Priority": "u=1, i",
    "Referer": "https://store.playstation.com/",
    "sec-ch-ua": '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "User-Agent": header(),
    "x-psn-app-ver": "@sie-private/web-commerce-anywhere/3.23.0-d3947b39a30477ef83ad9e5fc7f3f6a72e17bb6b",
    "x-psn-store-locale-override": x.split("/")[-3]
}


async def update_single_edition(session: aiohttp.ClientSession, pool: asyncpg.Pool, product_id: str, edition_id: int, currency: int, is_auto_mode: bool = True, verbose: bool = False):
    """Универсальная функция обновления одного edition (работает для обоих режимов)"""
    # Маппинг валют: 2 = TRY, 3 = UAH
    currency_map = {2: "TRY", 3: "UAH"}

    if currency not in currency_map:
        if verbose:
            print(f"[WARNING] Unknown currency code: {currency} for edition {edition_id}")
        return

    currency_str = currency_map[currency]
    if verbose:
        print(f"[INFO] Обработка {currency_str} edition {edition_id}, product_id: {product_id}")

    # Определяем URL в зависимости от валюты
    if currency_str == "UAH":
        store_url = f"https://store.playstation.com/ru-ua/product/{product_id}"
    elif currency_str == "TRY":
        store_url = f"https://store.playstation.com/en-tr/product/{product_id}"
    else:
        if verbose:
            print(f"[WARNING] Unknown currency: {currency_str} for edition {edition_id}")
        return

    params_result = get_params(store_url)
    # Для product типа get_params возвращает список, берем первый элемент
    if isinstance(params_result, list):
        params = params_result[0]
    else:
        params = params_result

    data = None
    counter = 0

    # Пытаемся получить данные с API
    while not data and counter < 3:
        try:
            async with session.get("https://web.np.playstation.com/api/graphql/v1/op", params=params, headers=json_headers(store_url)) as resp:
                response_text = await resp.text()
                data = loads(response_text)
                if "errors" in data:
                    if verbose:
                        print(f"[ERROR] API returned errors for {currency_str} edition {edition_id}: {data.get('errors')}")
                    return
                data = data["data"]["productRetrieve"]
            counter += 1
        except (asyncio.CancelledError, KeyboardInterrupt):
            return
        except Exception as e:
            if verbose:
                print(f"[ERROR] Request failed for {currency_str} edition {edition_id}, attempt {counter+1}: {e}")
            counter += 1
            await asyncio.sleep(5)

    if not data:
        if verbose:
            print(f"[WARNING] No data retrieved for {currency_str} edition {edition_id} after 3 attempts")
        return

    # Парсим цены
    price = None
    old_price = None
    discount_end = None
    ps_price = None
    ea_price = None

    if data.get("webctas"):
        if verbose:
            print(f"[INFO] Found {len(data['webctas'])} CTAs for {currency_str} edition {edition_id}")
        for cta in data["webctas"]:
            if cta["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] or ("UPSELL" in cta["type"] and ("EA_ACCESS" in cta["type"] or "PS_PLUS" in cta["type"]) and "TRIAL" not in cta["type"]):
                if cta["price"]["discountedPrice"] and cta["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and not price:
                    price = cta["price"]["discountedValue"]/100
                if cta["price"]["basePrice"] and cta["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and not old_price:
                    old_price = cta["price"]["basePriceValue"]/100
                if "UPSELL_PS_PLUS_DISCOUNT" == cta["type"]:
                    ps_price = cta["price"]["discountedValue"]/100
                if "UPSELL_EA_ACCESS_DISCOUNT" == cta["type"]:
                    ea_price = cta["price"]["discountedValue"]/100
                if cta["price"]["endTime"] and cta["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"]:
                    discount_end = datetime.fromtimestamp(int(cta["price"]["endTime"])//1000)

    # Обновляем цены в БД
    if price:
        if verbose:
            print(f"[VERBOSE] {currency_str} данные получены - Base: {old_price}, Discount: {price}, PS+: {ps_price}, EA: {ea_price}")
        print(f"[DEBUG] Обновление {currency_str} - Edition ID: {edition_id}, Price: {old_price}, Discount: {price}")
        async with pool.acquire(timeout=600) as conn:
            async with conn.transaction():
                await conn.execute(f"SET LOCAL myapp.is_auto_update = {str(is_auto_mode).lower()}")

                notices = []
                def notice_receiver(connection, message):
                    notices.append(message.message)
                conn.add_log_listener(notice_receiver)

                result = await conn.execute("""
                                        UPDATE "Editions"
                                        SET
                                            price = $2,
                                            discount_amount = $3,
                                            ea_play_price = $4,
                                            ps_plus_price = $5,
                                            promotion_end_date = $6,
                                            updated_at = $7
                                        WHERE id = $1
                                    """, edition_id, old_price, price if price != old_price else None, ea_price, ps_price, discount_end, datetime.now())

                # Удаляем обработчик уведомлений
                conn.remove_log_listener(notice_receiver)

                if notices:
                    print(f"[NOTICE] {notices}")
                if verbose:
                    print(f"[DEBUG] {currency_str} Update result: {result}")
    else:
        if verbose:
            print(f"[WARNING] No price data found for {currency_str} edition {edition_id}")


async def main():
    load_dotenv()

    timeout = -1
    mode = None

    # Интерактивный выбор режима
    print("=" * 50)
    print("ОБНОВЛЕНИЕ ЦЕН PLAYSTATION STORE")
    print("=" * 50)
    print("\nВыберите режим работы:")
    print("  1. Обновление товаров с allow_auto_update = FALSE (галочка НЕ стоит)")
    print("  2. Обновление товаров с allow_auto_update = TRUE (галочка стоит)")
    print()

    while mode not in ["1", "2"]:
        mode = input("Введите номер режима (1 или 2): ").strip()
        if mode not in ["1", "2"]:
            print("[!] Ошибка: выберите 1 или 2")

    # Режим 1: allow_auto_update = false → нужен is_auto_update = false
    # Режим 2: allow_auto_update = true → нужен is_auto_update = true
    is_auto_mode = mode == "2"

    # Подрежим для первого режима (тестовый или полный)
    test_mode = False
    if mode == "1":
        print()
        print("Выберите подрежим:")
        print("  1. Полный парсинг всех товаров")
        print("  2. Тестовый парсинг 10 разных товаров")
        print()

        submode = None
        while submode not in ["1", "2"]:
            submode = input("Введите номер подрежима (1 или 2): ").strip()
            if submode not in ["1", "2"]:
                print("[!] Ошибка: выберите 1 или 2")

        test_mode = submode == "2"

    mode_name = "allow_auto_update = TRUE" if is_auto_mode else "allow_auto_update = FALSE"
    if test_mode:
        mode_name += " (ТЕСТОВЫЙ РЕЖИМ - 10 товаров)"

    print()
    print("Настройка интервала обновления:")
    print("  Введите количество секунд для повторного запуска")
    print("  Или нажмите Enter для однократного выполнения")
    print()

    timeout_input = input("Интервал (секунды) или Enter: ").strip()
    if timeout_input:
        try:
            timeout = int(timeout_input)
            if timeout <= 0:
                print("[!] Ошибка: интервал должен быть больше 0")
                return
        except ValueError:
            print("[!] Ошибка: введите число")
            return

    print()
    print("=" * 50)
    print(f"[*] Режим работы: {mode_name} обновление цен")
    print(f"[*] Интервал обновления: {'единожды' if timeout == -1 else f'{timeout} секунд'}")
    print("=" * 50)
    print()

    while True:
        try:
            async with asyncpg.create_pool(
                                        user=os.getenv("DB_USER"),
                                        password=os.getenv("DB_PASSWORD"),
                                        database=os.getenv("DB_NAME"),
                                        host="193.17.92.132",
                                        port=5432
                                        ) as pool:

                # Теперь оба режима используют одинаковую логику - обработка каждого edition отдельно
                # Это позволяет корректно обрабатывать товары с разными ID в разных регионах

                if is_auto_mode:
                    # Режим 2: allow_auto_update = TRUE
                    if test_mode:
                        query = '''
                            SELECT ui.id, e.id as edition_id, ui.currency
                            FROM "update_info" ui
                            JOIN "Editions" e ON ui.edition_id = e.id
                            WHERE e.allow_auto_update = true
                            LIMIT 10
                        '''
                        print("[*] Режим 2 (ТЕСТОВЫЙ): Обновление 10 editions с allow_auto_update = TRUE")
                    else:
                        query = '''
                            SELECT ui.id, e.id as edition_id, ui.currency
                            FROM "update_info" ui
                            JOIN "Editions" e ON ui.edition_id = e.id
                            WHERE e.allow_auto_update = true
                        '''
                        print("[*] Режим 2: Обновление товаров с allow_auto_update = TRUE (галочка стоит)")
                    print("[*] is_auto_update = true → цены ОБНОВЯТСЯ ✅")
                else:
                    # Режим 1: allow_auto_update = FALSE (ИСПРАВЛЕННЫЙ)
                    # Теперь каждый edition обрабатывается отдельно с его собственным product_id
                    if test_mode:
                        query = '''
                            SELECT ui.id, e.id as edition_id, ui.currency
                            FROM "update_info" ui
                            JOIN "Editions" e ON ui.edition_id = e.id
                            WHERE e.allow_auto_update = false
                            LIMIT 10
                        '''
                        print("[*] Режим 1 (ТЕСТОВЫЙ): Обновление 10 editions с allow_auto_update = FALSE")
                    else:
                        query = '''
                            SELECT ui.id, e.id as edition_id, ui.currency
                            FROM "update_info" ui
                            JOIN "Editions" e ON ui.edition_id = e.id
                            WHERE e.allow_auto_update = false
                        '''
                        print("[*] Режим 1: Обновление товаров с allow_auto_update = FALSE (галочка НЕ стоит)")
                    print("[*] Каждый edition обрабатывается отдельно (поддержка разных ID в разных регионах)")
                    print("[*] is_auto_update = false → цены ОБНОВЯТСЯ ✅")

                # Получаем список всех editions
                editions = [[p["id"], p["edition_id"], p["currency"]] for p in await pool.fetch(query)]
                print(f"[*] Найдено editions для обновления: {len(editions)}")

                if test_mode and editions:
                    print("[*] Список editions для обновления:")
                    for idx, ed in enumerate(editions, 1):
                        currency_name = {2: "TRY", 3: "UAH"}.get(ed[2], f"Unknown({ed[2]})")
                        print(f"    {idx}. Product: {ed[0]} | Edition ID: {ed[1]} | Currency: {currency_name}")

                if not editions:
                    print("[*] Нет товаров для обновления")
                else:
                    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(120)) as session:
                        # Каждый edition обрабатывается независимо с его собственным product_id
                        tasks = [update_single_edition(session, pool, ed[0], ed[1], ed[2], is_auto_mode, verbose=test_mode) for ed in editions]

                        shift = 500
                        if not test_mode:
                            print("Updating data...", end="", flush=True)
                        else:
                            print("\n[*] Начинаем обновление цен...")

                        for i in range(0, len(editions), shift):
                            await asyncio.gather(*tasks[i:i+shift])
                            await asyncio.sleep(5)
                            if not test_mode:
                                print(f"\nUpdating data: {(min(len(editions), i+shift))*100/len(editions):.2f}%", end="", flush=True)
                            else:
                                print(f"[*] Прогресс: {min(len(editions), i+shift)}/{len(editions)} editions обработано")

                        if not test_mode:
                            print("\nUpdating data: done")
                        else:
                            print("[*] Обновление завершено!")

                print("[*] Data updated:", datetime.now())
                if timeout == -1:
                    break
            sleep(timeout)
        except asyncio.CancelledError:
            return
        except KeyboardInterrupt:
            return


if __name__ == "__main__":
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        pass
    finally:
        print("\nGoodbye")
