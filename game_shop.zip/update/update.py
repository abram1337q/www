import asyncio
import aiohttp
from json import dumps, loads
from random import choice
import asyncpg
from dotenv import load_dotenv
from datetime import datetime
import os, sys
from time import sleep


# ANSI цвета для терминала
class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    GRAY = "\033[90m"


def get_params(url: str):
    product_type, sku = url.split("/")[-2:]
    queries = {
        "concept": {
                "operationName": "conceptRetrieveForCtasWithPrice",
                "variables": dumps({"conceptId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "eab9d873f90d4ad98fd55f07b6a0a606e6b3925f2d03b70477234b79c1df30b5"
                    }
                })
            }
        ,
        "product": [
            {
                "operationName": "productRetrieveForCtasWithPrice",
                "variables": dumps({"productId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "8872b0419dcab2fea5916ef698544c237b1096f9e76acc6aacf629551adee8cd"
                    }
                })
            },
            {
                "operationName": "productRetrieveForUpsellWithCtas",
                "variables": dumps({"productId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "fb0bfa0af4d8dc42b28fa5c077ed715543e7fb8a3deff8117a50b99864d246f1"
                    }
                })
            }
        ]
    }
    return queries[product_type]


header=lambda: choice([
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15'
                ])


json_headers = lambda x: {
    "Accept": "application/json",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "en-US",
    "apollographql-client-name": "@sie-private/web-commerce-anywhere",
    "apollographql-client-version": "3.23.0",
    "Cache-Control": "no-cache",
    "Content-Type": "application/json",
    "disable_query_whitelist": "false",
    "Origin": "https://store.playstation.com",
    "Pragma": "no-cache",
    "Priority": "u=1, i",
    "Referer": "https://store.playstation.com/",
    "sec-ch-ua": '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "User-Agent": header(),
    "x-psn-app-ver": "@sie-private/web-commerce-anywhere/3.23.0-d3947b39a30477ef83ad9e5fc7f3f6a72e17bb6b",
    "x-psn-store-locale-override": x.split("/")[-3]
}


def format_price(price, currency_str):
    """Форматирование цены с валютой"""
    if price is None:
        return "N/A"
    symbol = "₴" if currency_str == "UAH" else "₺"
    return f"{price:.2f} {symbol}"


def print_price_change(edition_id, currency_str, old_data, new_data, verbose=True):
    """Выводит информацию об изменении цен"""
    if not verbose:
        return

    c = Colors
    symbol = "₴" if currency_str == "UAH" else "₺"

    changes = []
    no_changes = []

    # Проверяем базовую цену
    old_price = old_data.get('price')
    new_price = new_data.get('price')
    if old_price != new_price:
        old_str = f"{old_price:.2f}" if old_price else "N/A"
        new_str = f"{new_price:.2f}" if new_price else "N/A"
        changes.append(f"Цена: {old_str} → {c.GREEN}{new_str}{c.RESET} {symbol}")
    else:
        no_changes.append(f"Цена: {new_price:.2f} {symbol}" if new_price else "Цена: N/A")

    # Проверяем скидку
    old_discount = old_data.get('discount')
    new_discount = new_data.get('discount')
    if old_discount != new_discount:
        old_str = f"{old_discount:.2f}" if old_discount else "N/A"
        new_str = f"{new_discount:.2f}" if new_discount else "N/A"
        changes.append(f"Скидка: {old_str} → {c.GREEN}{new_str}{c.RESET} {symbol}")
    elif new_discount:
        no_changes.append(f"Скидка: {new_discount:.2f} {symbol}")

    # Проверяем PS+ цену
    old_ps = old_data.get('ps_plus')
    new_ps = new_data.get('ps_plus')
    if old_ps != new_ps:
        old_str = f"{old_ps:.2f}" if old_ps else "N/A"
        new_str = f"{new_ps:.2f}" if new_ps else "N/A"
        changes.append(f"PS+: {old_str} → {c.MAGENTA}{new_str}{c.RESET} {symbol}")
    elif new_ps:
        no_changes.append(f"PS+: {new_ps:.2f} {symbol}")

    # Проверяем EA Play цену
    old_ea = old_data.get('ea_play')
    new_ea = new_data.get('ea_play')
    if old_ea != new_ea:
        old_str = f"{old_ea:.2f}" if old_ea else "N/A"
        new_str = f"{new_ea:.2f}" if new_ea else "N/A"
        changes.append(f"EA Play: {old_str} → {c.CYAN}{new_str}{c.RESET} {symbol}")
    elif new_ea:
        no_changes.append(f"EA Play: {new_ea:.2f} {symbol}")

    # Выводим результат
    header = f"{c.BOLD}[{currency_str}] Edition #{edition_id}{c.RESET}"

    if changes:
        print(f"{header} {c.YELLOW}ИЗМЕНЕНО{c.RESET}")
        for change in changes:
            print(f"  {c.YELLOW}↳{c.RESET} {change}")
    else:
        print(f"{header} {c.GRAY}без изменений{c.RESET} ({', '.join(no_changes)})")


async def update_single_edition(session: aiohttp.ClientSession, pool: asyncpg.Pool, product_id: str, edition_id: int, currency: int, is_auto_mode: bool = True, verbose: bool = False):
    """Универсальная функция обновления одного edition (работает для обоих режимов)"""
    # Маппинг валют: 2 = TRY, 3 = UAH
    currency_map = {2: "TRY", 3: "UAH"}

    if currency not in currency_map:
        if verbose:
            print(f"{Colors.RED}[WARNING] Unknown currency code: {currency} for edition {edition_id}{Colors.RESET}")
        return

    currency_str = currency_map[currency]

    # Определяем URL в зависимости от валюты
    if currency_str == "UAH":
        store_url = f"https://store.playstation.com/ru-ua/product/{product_id}"
    elif currency_str == "TRY":
        store_url = f"https://store.playstation.com/en-tr/product/{product_id}"
    else:
        if verbose:
            print(f"{Colors.RED}[WARNING] Unknown currency: {currency_str} for edition {edition_id}{Colors.RESET}")
        return

    params_result = get_params(store_url)
    # Для product типа get_params возвращает список, берем первый элемент
    if isinstance(params_result, list):
        params = params_result[0]
    else:
        params = params_result

    data = None
    counter = 0

    # Пытаемся получить данные с API
    while not data and counter < 3:
        try:
            async with session.get("https://web.np.playstation.com/api/graphql/v1/op", params=params, headers=json_headers(store_url)) as resp:
                response_text = await resp.text()
                data = loads(response_text)
                if "errors" in data:
                    if verbose:
                        print(f"{Colors.RED}[ERROR] API returned errors for {currency_str} edition {edition_id}: {data.get('errors')}{Colors.RESET}")
                    return
                data = data["data"]["productRetrieve"]
            counter += 1
        except (asyncio.CancelledError, KeyboardInterrupt):
            return
        except Exception as e:
            if verbose:
                print(f"{Colors.RED}[ERROR] Request failed for {currency_str} edition {edition_id}, attempt {counter+1}: {e}{Colors.RESET}")
            counter += 1
            await asyncio.sleep(5)

    if not data:
        if verbose:
            print(f"{Colors.YELLOW}[WARNING] No data retrieved for {currency_str} edition {edition_id} after 3 attempts{Colors.RESET}")
        return

    # Парсим цены
    price = None
    old_price = None
    discount_end = None
    ps_price = None
    ea_price = None

    if data.get("webctas"):
        for cta in data["webctas"]:
            if cta["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] or ("UPSELL" in cta["type"] and ("EA_ACCESS" in cta["type"] or "PS_PLUS" in cta["type"]) and "TRIAL" not in cta["type"]):
                if cta["price"]["discountedPrice"] and cta["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and not price:
                    price = cta["price"]["discountedValue"]/100
                if cta["price"]["basePrice"] and cta["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and not old_price:
                    old_price = cta["price"]["basePriceValue"]/100
                if "UPSELL_PS_PLUS_DISCOUNT" == cta["type"]:
                    ps_price = cta["price"]["discountedValue"]/100
                if "UPSELL_EA_ACCESS_DISCOUNT" == cta["type"]:
                    ea_price = cta["price"]["discountedValue"]/100
                if cta["price"]["endTime"] and cta["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"]:
                    discount_end = datetime.fromtimestamp(int(cta["price"]["endTime"])//1000)

    # Получаем текущие данные из БД для сравнения
    async with pool.acquire(timeout=600) as conn:
        current_data = await conn.fetchrow("""
            SELECT price, discount_amount, ps_plus_price, ea_play_price
            FROM "Editions"
            WHERE id = $1
        """, edition_id)

    if not current_data:
        if verbose:
            print(f"{Colors.RED}[ERROR] Edition {edition_id} not found in database{Colors.RESET}")
        return

    # Подготавливаем данные для сравнения
    old_data = {
        'price': float(current_data['price']) if current_data['price'] else None,
        'discount': float(current_data['discount_amount']) if current_data['discount_amount'] else None,
        'ps_plus': float(current_data['ps_plus_price']) if current_data['ps_plus_price'] else None,
        'ea_play': float(current_data['ea_play_price']) if current_data['ea_play_price'] else None,
    }

    new_data = {
        'price': old_price,  # base price
        'discount': price if price != old_price else None,  # discounted price
        'ps_plus': ps_price,
        'ea_play': ea_price,
    }

    # Обновляем цены в БД
    if price:
        # Показываем изменения
        print_price_change(edition_id, currency_str, old_data, new_data, verbose)

        async with pool.acquire(timeout=600) as conn:
            async with conn.transaction():
                await conn.execute(f"SET LOCAL myapp.is_auto_update = {str(is_auto_mode).lower()}")

                await conn.execute("""
                                        UPDATE "Editions"
                                        SET
                                            price = $2,
                                            discount_amount = $3,
                                            ea_play_price = $4,
                                            ps_plus_price = $5,
                                            promotion_end_date = $6,
                                            updated_at = $7
                                        WHERE id = $1
                                    """, edition_id, old_price, price if price != old_price else None, ea_price, ps_price, discount_end, datetime.now())
    else:
        if verbose:
            print(f"{Colors.YELLOW}[WARNING] No price data found for {currency_str} edition {edition_id}{Colors.RESET}")


async def main():
    load_dotenv()

    timeout = -1
    mode = None

    # Интерактивный выбор режима
    print("=" * 60)
    print(f"{Colors.BOLD}ОБНОВЛЕНИЕ ЦЕН PLAYSTATION STORE{Colors.RESET}")
    print("=" * 60)
    print("\nВыберите режим работы:")
    print(f"  {Colors.CYAN}1.{Colors.RESET} Обновление товаров с allow_auto_update = FALSE (галочка НЕ стоит)")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Обновление товаров с allow_auto_update = TRUE (галочка стоит)")
    print()

    while mode not in ["1", "2"]:
        mode = input("Введите номер режима (1 или 2): ").strip()
        if mode not in ["1", "2"]:
            print(f"{Colors.RED}[!] Ошибка: выберите 1 или 2{Colors.RESET}")

    # Режим 1: allow_auto_update = false → нужен is_auto_update = false
    # Режим 2: allow_auto_update = true → нужен is_auto_update = true
    is_auto_mode = mode == "2"

    # Подрежим для первого режима (тестовый или полный)
    test_mode = False
    if mode == "1":
        print()
        print("Выберите подрежим:")
        print(f"  {Colors.CYAN}1.{Colors.RESET} Полный парсинг всех товаров")
        print(f"  {Colors.CYAN}2.{Colors.RESET} Тестовый парсинг 10 разных товаров")
        print()

        submode = None
        while submode not in ["1", "2"]:
            submode = input("Введите номер подрежима (1 или 2): ").strip()
            if submode not in ["1", "2"]:
                print(f"{Colors.RED}[!] Ошибка: выберите 1 или 2{Colors.RESET}")

        test_mode = submode == "2"

    mode_name = "allow_auto_update = TRUE" if is_auto_mode else "allow_auto_update = FALSE"
    if test_mode:
        mode_name += " (ТЕСТОВЫЙ РЕЖИМ - 10 товаров)"

    print()
    print("Настройка интервала обновления:")
    print("  Введите количество секунд для повторного запуска")
    print("  Или нажмите Enter для однократного выполнения")
    print()

    timeout_input = input("Интервал (секунды) или Enter: ").strip()
    if timeout_input:
        try:
            timeout = int(timeout_input)
            if timeout <= 0:
                print(f"{Colors.RED}[!] Ошибка: интервал должен быть больше 0{Colors.RESET}")
                return
        except ValueError:
            print(f"{Colors.RED}[!] Ошибка: введите число{Colors.RESET}")
            return

    print()
    print("=" * 60)
    print(f"{Colors.GREEN}[*] Режим работы:{Colors.RESET} {mode_name}")
    print(f"{Colors.GREEN}[*] Интервал обновления:{Colors.RESET} {'единожды' if timeout == -1 else f'{timeout} секунд'}")
    print("=" * 60)
    print()

    while True:
        try:
            async with asyncpg.create_pool(
                                        user=os.getenv("DB_USER"),
                                        password=os.getenv("DB_PASSWORD"),
                                        database=os.getenv("DB_NAME"),
                                        host="193.17.92.132",
                                        port=5432
                                        ) as pool:

                if is_auto_mode:
                    # Режим 2: allow_auto_update = TRUE
                    if test_mode:
                        query = '''
                            SELECT ui.id, e.id as edition_id, ui.currency
                            FROM "update_info" ui
                            JOIN "Editions" e ON ui.edition_id = e.id
                            WHERE e.allow_auto_update = true
                            LIMIT 10
                        '''
                        print(f"{Colors.CYAN}[*] Режим 2 (ТЕСТОВЫЙ): Обновление 10 editions с allow_auto_update = TRUE{Colors.RESET}")
                    else:
                        query = '''
                            SELECT ui.id, e.id as edition_id, ui.currency
                            FROM "update_info" ui
                            JOIN "Editions" e ON ui.edition_id = e.id
                            WHERE e.allow_auto_update = true
                        '''
                        print(f"{Colors.CYAN}[*] Режим 2: Обновление товаров с allow_auto_update = TRUE{Colors.RESET}")
                    print(f"{Colors.GREEN}[*] is_auto_update = true → цены ОБНОВЯТСЯ ✓{Colors.RESET}")
                else:
                    if test_mode:
                        query = '''
                            SELECT ui.id, e.id as edition_id, ui.currency
                            FROM "update_info" ui
                            JOIN "Editions" e ON ui.edition_id = e.id
                            WHERE e.allow_auto_update = false
                            LIMIT 10
                        '''
                        print(f"{Colors.CYAN}[*] Режим 1 (ТЕСТОВЫЙ): Обновление 10 editions с allow_auto_update = FALSE{Colors.RESET}")
                    else:
                        query = '''
                            SELECT ui.id, e.id as edition_id, ui.currency
                            FROM "update_info" ui
                            JOIN "Editions" e ON ui.edition_id = e.id
                            WHERE e.allow_auto_update = false
                        '''
                        print(f"{Colors.CYAN}[*] Режим 1: Обновление товаров с allow_auto_update = FALSE{Colors.RESET}")
                    print(f"{Colors.GREEN}[*] is_auto_update = false → цены ОБНОВЯТСЯ ✓{Colors.RESET}")

                # Получаем список всех editions
                editions = [[p["id"], p["edition_id"], p["currency"]] for p in await pool.fetch(query)]
                print(f"{Colors.BOLD}[*] Найдено editions для обновления: {len(editions)}{Colors.RESET}")
                print()

                if not editions:
                    print(f"{Colors.YELLOW}[*] Нет товаров для обновления{Colors.RESET}")
                else:
                    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(120)) as session:
                        tasks = [update_single_edition(session, pool, ed[0], ed[1], ed[2], is_auto_mode, verbose=True) for ed in editions]

                        shift = 500
                        total = len(editions)

                        print(f"{Colors.BOLD}{'─' * 60}{Colors.RESET}")
                        print(f"{Colors.BOLD}Начало обновления цен...{Colors.RESET}")
                        print(f"{Colors.BOLD}{'─' * 60}{Colors.RESET}")

                        for i in range(0, total, shift):
                            batch_end = min(total, i + shift)
                            await asyncio.gather(*tasks[i:batch_end])
                            await asyncio.sleep(5)

                            progress = batch_end * 100 / total
                            print(f"\n{Colors.BLUE}[Прогресс: {batch_end}/{total} ({progress:.1f}%)]{Colors.RESET}\n")

                        print(f"{Colors.BOLD}{'─' * 60}{Colors.RESET}")
                        print(f"{Colors.GREEN}✓ Обновление завершено!{Colors.RESET}")
                        print(f"{Colors.BOLD}{'─' * 60}{Colors.RESET}")

                print(f"\n{Colors.GRAY}[*] Время завершения: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Colors.RESET}")
                if timeout == -1:
                    break
            sleep(timeout)
        except asyncio.CancelledError:
            return
        except KeyboardInterrupt:
            return


if __name__ == "__main__":
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        pass
    finally:
        print(f"\n{Colors.GRAY}Goodbye{Colors.RESET}")
