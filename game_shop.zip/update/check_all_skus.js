const { Client } = require('pg');
const https = require('https');
const zlib = require('zlib');
const fs = require('fs');

// === НАСТРОЙКИ ===
const CONFIG = {
  DB_HOST: '193.17.92.132',
  DB_PORT: 5432,
  DB_NAME: 'game_shop_db',
  DB_USER: 'nkarasyov',
  DB_PASSWORD: 'pAssW_ord123',

  BATCH_SIZE: 20,           // Сколько проверять параллельно
  DELAY_BETWEEN_BATCHES: 500, // Пауза между батчами (мс)
  SAVE_EVERY: 1000,         // Сохранять прогресс каждые N записей

  PROGRESS_FILE: 'check_progress.json',
  RESULTS_FILE: 'invalid_skus_full.json',
};

const Colors = {
  RESET: '\x1b[0m',
  RED: '\x1b[91m',
  GREEN: '\x1b[92m',
  YELLOW: '\x1b[93m',
  BLUE: '\x1b[94m',
  CYAN: '\x1b[96m',
  BOLD: '\x1b[1m',
};

async function checkSku(sku, currency) {
  const locale = currency === 2 ? 'en-tr' : 'ru-ua';

  const params = new URLSearchParams({
    operationName: 'productRetrieveForCtasWithPrice',
    variables: JSON.stringify({ productId: sku }),
    extensions: JSON.stringify({
      persistedQuery: { version: 1, sha256Hash: '8872b0419dcab2fea5916ef698544c237b1096f9e76acc6aacf629551adee8cd' }
    })
  });

  return new Promise((resolve) => {
    const req = https.get(`https://web.np.playstation.com/api/graphql/v1/op?${params}`, {
      headers: {
        'Accept': 'application/json',
        'Accept-Encoding': 'gzip, deflate, br',
        'Content-Type': 'application/json',
        'apollographql-client-name': '@sie-private/web-commerce-anywhere',
        'apollographql-client-version': '3.23.0',
        'apollo-require-preflight': 'true',
        'Origin': 'https://store.playstation.com',
        'Referer': 'https://store.playstation.com/',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'x-psn-store-locale-override': locale
      }
    }, (res) => {
      let chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => {
        const buffer = Buffer.concat(chunks);
        const encoding = res.headers['content-encoding'];

        try {
          let decompressed;
          if (encoding === 'gzip') decompressed = zlib.gunzipSync(buffer).toString();
          else if (encoding === 'br') decompressed = zlib.brotliDecompressSync(buffer).toString();
          else decompressed = buffer.toString();

          const data = JSON.parse(decompressed);

          if (data.errors) {
            const err = data.errors[0]?.message || '';
            if (err.includes('not available')) resolve({ status: 'invalid' });
            else resolve({ status: 'error', error: err });
          } else if (data.data?.productRetrieve) {
            resolve({ status: 'valid' });
          } else {
            resolve({ status: 'error', error: 'No data' });
          }
        } catch (e) {
          resolve({ status: 'error', error: e.message });
        }
      });
    });

    req.on('error', () => resolve({ status: 'error', error: 'Network' }));
    req.setTimeout(10000, () => { req.destroy(); resolve({ status: 'error', error: 'Timeout' }); });
  });
}

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function loadProgress() {
  try {
    if (fs.existsSync(CONFIG.PROGRESS_FILE)) {
      return JSON.parse(fs.readFileSync(CONFIG.PROGRESS_FILE, 'utf8'));
    }
  } catch (e) {}
  return { lastIndex: 0, invalidSkus: [], stats: { valid: 0, invalid: 0, errors: 0 } };
}

function saveProgress(progress) {
  fs.writeFileSync(CONFIG.PROGRESS_FILE, JSON.stringify(progress, null, 2));
}

function saveResults(invalidSkus) {
  fs.writeFileSync(CONFIG.RESULTS_FILE, JSON.stringify(invalidSkus, null, 2));
}

async function main() {
  const client = new Client({
    host: CONFIG.DB_HOST,
    port: CONFIG.DB_PORT,
    database: CONFIG.DB_NAME,
    user: CONFIG.DB_USER,
    password: CONFIG.DB_PASSWORD,
  });

  await client.connect();
  console.log(`${Colors.GREEN}Подключено к БД!${Colors.RESET}\n`);

  // Загружаем прогресс
  let progress = loadProgress();

  if (progress.lastIndex > 0) {
    console.log(`${Colors.YELLOW}Продолжаю с позиции ${progress.lastIndex}${Colors.RESET}`);
    console.log(`${Colors.YELLOW}Уже найдено невалидных: ${progress.invalidSkus.length}${Colors.RESET}\n`);
  }

  // Получаем все SKU
  const result = await client.query(`
    SELECT ui.id as sku, ui.edition_id, ui.currency
    FROM "update_info" ui
    ORDER BY ui.edition_id
  `);

  const allItems = result.rows;

  // Закрываем соединение сразу — данные уже в памяти
  await client.end();
  console.log(`${Colors.CYAN}Соединение с БД закрыто${Colors.RESET}`);

  console.log(`${Colors.BOLD}Всего SKU в базе: ${allItems.length}${Colors.RESET}`);
  console.log(`${Colors.BOLD}Осталось проверить: ${allItems.length - progress.lastIndex}${Colors.RESET}`);
  console.log(`${'='.repeat(60)}\n`);

  const startTime = Date.now();
  const startIndex = progress.lastIndex;

  // Обработка Ctrl+C
  process.on('SIGINT', () => {
    console.log(`\n\n${Colors.YELLOW}Прерывание... Сохраняю прогресс...${Colors.RESET}`);
    saveProgress(progress);
    saveResults(progress.invalidSkus);
    console.log(`${Colors.GREEN}Прогресс сохранён. Запустите скрипт снова для продолжения.${Colors.RESET}`);
    process.exit(0);
  });

  for (let i = progress.lastIndex; i < allItems.length; i += CONFIG.BATCH_SIZE) {
    const batch = allItems.slice(i, i + CONFIG.BATCH_SIZE);

    const results = await Promise.all(batch.map(async (row) => {
      const result = await checkSku(row.sku, row.currency);
      return { ...row, result };
    }));

    for (const item of results) {
      if (item.result.status === 'valid') {
        progress.stats.valid++;
      } else if (item.result.status === 'invalid') {
        progress.stats.invalid++;
        const curr = item.currency === 2 ? 'TRY' : 'UAH';
        progress.invalidSkus.push({
          edition_id: item.edition_id,
          sku: item.sku,
          currency: curr
        });
        console.log(`${Colors.RED}✗ [${curr}] #${item.edition_id}: ${item.sku}${Colors.RESET}`);
      } else {
        progress.stats.errors++;
      }
    }

    progress.lastIndex = Math.min(i + CONFIG.BATCH_SIZE, allItems.length);

    // Прогресс
    const done = progress.lastIndex;
    const total = allItems.length;
    const percent = ((done / total) * 100).toFixed(1);
    const elapsed = ((Date.now() - startTime) / 1000).toFixed(0);
    const rate = (done - startIndex) / (elapsed || 1);
    const eta = Math.round((total - done) / rate);
    const etaMin = Math.floor(eta / 60);
    const etaSec = eta % 60;

    process.stdout.write(`\r${Colors.BLUE}[${done}/${total}] ${percent}% | ✓${progress.stats.valid} ✗${progress.stats.invalid} | ETA: ${etaMin}m ${etaSec}s${Colors.RESET}     `);

    // Сохраняем прогресс
    if (done % CONFIG.SAVE_EVERY === 0) {
      saveProgress(progress);
      saveResults(progress.invalidSkus);
    }

    if (i + CONFIG.BATCH_SIZE < allItems.length) {
      await sleep(CONFIG.DELAY_BETWEEN_BATCHES);
    }
  }

  // Финальное сохранение
  saveProgress(progress);
  saveResults(progress.invalidSkus);

  const totalTime = ((Date.now() - startTime) / 1000 / 60).toFixed(1);

  console.log(`\n\n${'='.repeat(60)}`);
  console.log(`${Colors.BOLD}ГОТОВО! (${totalTime} минут)${Colors.RESET}`);
  console.log(`${Colors.GREEN}✓ Валидных: ${progress.stats.valid}${Colors.RESET}`);
  console.log(`${Colors.RED}✗ Невалидных: ${progress.stats.invalid}${Colors.RESET}`);
  console.log(`${Colors.YELLOW}? Ошибок: ${progress.stats.errors}${Colors.RESET}`);

  if (progress.invalidSkus.length > 0) {
    console.log(`\n${Colors.CYAN}Результаты сохранены в ${CONFIG.RESULTS_FILE}${Colors.RESET}`);
  }

  // Удаляем файл прогресса после успешного завершения
  if (fs.existsSync(CONFIG.PROGRESS_FILE)) {
    fs.unlinkSync(CONFIG.PROGRESS_FILE);
  }
}

main().catch(console.error);
