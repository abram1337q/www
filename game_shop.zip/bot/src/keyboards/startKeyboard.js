import { getSettings, BOT_USERNAME } from '../config/constants.js';

const getStartKeyboard = async () => {
	const settings = await getSettings();
	return {
		reply_markup: {
			inline_keyboard: [
				[
					{
						text: '🎮 Открыть магазин',
						web_app: { url: settings.shopButtonUrl },
					},
				],
				[
					{
						text: '❓ Поддержка',
						url: 'https://t.me/psworld_store',
					},
				],
				[
					{
						text: '📝 Отзывы',
						url: settings.reviewsButtonUrl,
					},
				],
			],
		},
	};
};

export default getStartKeyboard;
