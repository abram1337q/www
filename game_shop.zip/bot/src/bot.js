import dotenv from 'dotenv';
import express from 'express';
import bot from './config/botConfig.js';
import handleStart from './handlers/startHandler.js';
import { SupportHandler } from './handlers/supportHandler.js';
import paymentRoutes from './routes/paymentRoutes.js';
import paymentService from './services/paymentService.js';

// Загружаем переменные окружения
dotenv.config();

// Initialize Express app
const app = express();
const PORT = process.env.BOT_API_PORT || 3001;

// Express middleware
app.use(express.json());

// Express routes
app.use('/', paymentRoutes);

// Start Express server
app.listen(PORT, () => {
	console.log(`Bot API server is running on port ${PORT}`);
});

// Initialize handlers
const supportHandler = new SupportHandler(bot);

// Регистрируем обработчик команды /start
// bot.onText(/^\/start$/, handleStart);

// Обработчик всех сообщений
bot.on('message', async msg => {
	if (!msg.text) return;

	console.log('Received message:', msg.text);

	// Проверяем, является ли это командой /start
	if (msg.text.startsWith('/start')) {
		const fullCommand = msg.text.substring('/start'.length).trim();
		console.log('Start command params:', fullCommand);

		if (fullCommand.startsWith('account_')) {
			try {
				// Получаем данные после account_
				const data = decodeURIComponent(fullCommand);
				console.log('Account data:', data);

				// Разбиваем данные на части (имя фамилия email дата)
				const [_, firstName, lastName, email, birthDate] =
					data.split('_');

				if (!firstName || !lastName || !email || !birthDate) {
					throw new Error('Missing required fields');
				}

				console.log('Parsed fields:', {
					firstName,
					lastName,
					email,
					birthDate,
				});

				// Создаем сообщение для топика
				const message = `#аккаунт\nЗапрос на создание аккаунта PS:\n\nИмя: ${firstName}\nФамилия: ${lastName}\nEmail: ${email}\nДата рождения: ${birthDate}`;

				// Отправляем сообщение пользователю о начале обработки
				await bot.sendMessage(
					msg.chat.id,
					'Создаю запрос на создание аккаунта...'
				);

				// Создаем новый топик напрямую
				const userId = msg.from.id;
				const username =
					msg.from.username || 'Неизвестный пользователь';

				try {
					// Создаем топик в форуме
					const topic = await bot.createForumTopic(
						supportHandler.SUPPORT_CHAT_ID,
						`👤 Создание аккаунта PS от ${username}`
					);

					console.log('Created topic:', topic);

					// Отправляем первое сообщение в топик
					await bot.sendMessage(
						supportHandler.SUPPORT_CHAT_ID,
						message,
						{ message_thread_id: topic.message_thread_id }
					);

					// Сохраняем информацию о чате
					supportHandler.activeChats.set(userId, {
						status: 'active',
						username,
						topicId: topic.message_thread_id,
						chatId: msg.chat.id,
					});

					// Отправляем сообщение пользователю
					await bot.sendMessage(
						msg.chat.id,
						'Запрос на создание аккаунта создан. Я уведомлю вас, когда появится ответ от поддержки.',
						{
							reply_markup: {
								keyboard: [['Завершить диалог']],
								resize_keyboard: true,
								one_time_keyboard: false,
							},
						}
					);
				} catch (error) {
					console.error('Error creating topic:', error);
					await bot.sendMessage(
						msg.chat.id,
						'Произошла ошибка при создании запроса. Пожалуйста, попробуйте позже.'
					);
				}
			} catch (error) {
				console.error('Error handling account creation:', error);
				console.error('Error details:', error.message);
				await bot.sendMessage(
					msg.chat.id,
					'Произошла ошибка при обработке данных. Пожалуйста, попробуйте еще раз.'
				);
			}
		} else if (msg.text === '/start support') {
			await supportHandler.handleSupportCommand(msg);
		} else if (msg.text === '/start') {
			await handleStart(msg);
		}
	} else {
		// Если это не команда /start, проверяем, находится ли пользователь в активном диалоге
		const userId = msg.from.id;
		const supportChatInfo = supportHandler.activeChats.get(userId);
		const paymentChatInfo = paymentService.activeChats.get(userId);

		// Если пользователь НЕ в активном диалоге (ни с поддержкой, ни по покупке) - отправляем приветственное сообщение
		if (!supportChatInfo && !paymentChatInfo && msg.chat?.type === 'private') {
			await handleStart(msg);
		}
	}
});

// Остальные обработчики
bot.on('callback_query', async query => {
	if (query.data === 'help') {
		try {
			// Создаем полное сообщение для эмуляции команды /support
			const fakeMessage = {
				chat: query.message.chat,
				from: query.from,
				text: '/support',
				message_id: query.message.message_id,
				date: Math.floor(Date.now() / 1000),
			};

			// Вызываем обработчик support напрямую
			await supportHandler.handleSupportCommand(fakeMessage);

			// Answer callback query
			await bot.answerCallbackQuery(query.id);
		} catch (error) {
			console.error('Error handling help callback:', error);
			await bot.answerCallbackQuery(query.id, {
				text: 'Произошла ошибка. Пожалуйста, попробуйте позже.',
				show_alert: true,
			});
		}
	}
});

// Setup support handler
supportHandler.setup();

console.log('Бот запущен');

// Проверяем, что бот запущен
bot.getMe()
	.then(botInfo => {
		console.log('Bot initialized successfully:', botInfo.username);
	})
	.catch(error => {
		console.error('Error initializing bot:', error);
	});
