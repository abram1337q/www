import axios from 'axios';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const rootDir = path.resolve(__dirname, '../../../');

dotenv.config({ path: path.join(rootDir, '.env') });

const API_URL = process.env.VITE_API_BASE_URL;
export const WEBAPP_URL = process.env.TELEGRAM_WEB_APP_URL;
export const BOT_USERNAME = process.env.VITE_BOT_USERNAME;
export const REVIEWS_URL = 'https://t.me/psworldstore/408';

export const BUTTONS = {
	ru: {
		shopButton: '🎮 Магазин',
		reviewsButton: '📝 Отзывы',
		helpButton: '❓ Помощь',
		shopButtonUrl: WEBAPP_URL,
		helpButtonUrl: WEBAPP_URL,
		reviewsButtonUrl: REVIEWS_URL,
	},
	en: {
		shopButton: '🎮 Shop',
		reviewsButton: '📝 Reviews',
		helpButton: '❓ Help',
		shopButtonUrl: WEBAPP_URL,
		helpButtonUrl: WEBAPP_URL,
		reviewsButtonUrl: REVIEWS_URL,
	},
};

console.log('Loading environment variables:');
console.log('BOT_USERNAME:', BOT_USERNAME);
console.log('API_URL:', API_URL);
console.log('WEBAPP_URL:', WEBAPP_URL);

export const getSettings = async () => {
	try {
		const response = await axios.get(`${API_URL}/api/settings`);
		return {
			welcomeMessage:
				response.data.welcomeMessage ||
				'Добро пожаловать в магазин игр!',
			shopButtonUrl: WEBAPP_URL,
			helpButtonUrl: WEBAPP_URL,
			reviewsButtonUrl: REVIEWS_URL,
		};
	} catch (error) {
		console.error('Error fetching settings:', error);
		return {
			welcomeMessage:
				'👋 Добро пожаловать в PWStore! Нажмите кнопку ниже, чтобы открыть мини-приложение.\n\n👨‍💻 Если нужна помощь, то обратитесь в поддержку.\n🤩 А если хочется сказать спасибо, то ниже есть ссылка на пост с отзывами.',
			shopButtonUrl: WEBAPP_URL,
			helpButtonUrl: WEBAPP_URL,
			reviewsButtonUrl: REVIEWS_URL,
		};
	}
};
