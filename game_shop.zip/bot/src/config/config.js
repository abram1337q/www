import 'dotenv/config';

export const config = {
	BOT_TOKEN: process.env.BOT_TOKEN,
	BACKEND_URL: process.env.VITE_API_BASE_URL,
	DB_NAME: process.env.DB_NAME,
	DB_USER: process.env.DB_USER,
	DB_PASSWORD: process.env.DB_PASSWORD,
	DB_HOST: process.env.DB_HOST,
	DB_PORT: parseInt(process.env.DB_PORT, 10),
};
