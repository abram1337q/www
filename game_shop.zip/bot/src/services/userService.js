import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

// Определяем модели
const User = sequelize.define(
	'User',
	{
		id: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		telegramId: {
			type: DataTypes.STRING,
			unique: true,
			allowNull: false,
		},
		telegramUsername: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		currencyId: {
			type: DataTypes.INTEGER,
			allowNull: true,
		}
	},
	{
		tableName: 'Users',
		timestamps: true,
	}
);

const Currency = sequelize.define(
	'Currency',
	{
		id: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		code: {
			type: DataTypes.STRING,
			allowNull: false,
			unique: true,
		},
		name: {
			type: DataTypes.STRING,
			allowNull: false,
		},
		is_default: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		}
	},
	{
		tableName: 'Currencies',
		timestamps: false, // Меняем на false, так как в таблице нет этих колонок
	}
);

export const saveOrUpdateTelegramUser = async (
	telegramId,
	telegramUsername
) => {
	try {
		// Получаем первую доступную валюту
		const defaultCurrency = await Currency.findOne({
			order: [['id', 'ASC']]
		});

		if (!defaultCurrency) {
			throw new Error('No currencies available in the database');
		}

		const [user, created] = await User.findOrCreate({
			where: { telegramId },
			defaults: {
				telegramId,
				telegramUsername,
				currencyId: defaultCurrency.id
			},
		});

		if (!created && user.telegramUsername !== telegramUsername) {
			user.telegramUsername = telegramUsername;
			await user.save();
		}

		return user;
	} catch (error) {
		console.error('Error in saveOrUpdateTelegramUser:', error);
		throw error;
	}
};

export const getUserByUsername = async username => {
	try {
		const user = await User.findOne({
			where: { telegramUsername: username },
		});
		return user;
	} catch (error) {
		console.error('Error in getUserByUsername:', error);
		throw error;
	}
};
