import axios from 'axios';
import { getSettings } from '../config/constants.js';

const API_URL = 'http://your-backend-url/api'; // Замените на URL вашего API

export const verifyWebAppData = async initData => {
	try {
		const response = await axios.post(`${API_URL}/verify-webapp-data`, {
			initData,
		});
		return response.data.isValid;
	} catch (error) {
		console.error('Error verifying Web App data:', error);
		return false;
	}
};

export const processOrder = async (orderData, userId) => {
	try {
		const response = await axios.post(`${API_URL}/process-order`, {
			orderData,
			userId,
		});
		return response.data;
	} catch (error) {
		console.error('Error processing order:', error);
		throw error;
	}
};

export const getUserInfo = async userId => {
	try {
		const response = await axios.get(`${API_URL}/user/${userId}`);
		return response.data;
	} catch (error) {
		console.error('Error fetching user info:', error);
		throw error;
	}
};

export const getWebAppUrl = async () => {
	const settings = await getSettings();
	return settings.shopButtonUrl;
};

export const handleWebAppQuery = async (queryId, userId, data) => {
	try {
		// Обработка входящего запроса от Web App
		const response = await axios.post(`${API_URL}/handle-webapp-query`, {
			queryId,
			userId,
			data,
		});
		return response.data;
	} catch (error) {
		console.error('Error handling Web App query:', error);
		throw error;
	}
};
