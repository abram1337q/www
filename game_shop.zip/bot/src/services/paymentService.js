import bot from '../config/botConfig.js';
import sequelize from '../config/database.js';

export const MANAGER_CHAT_ID = -1002272015106;

// Проверяем наличие необходимых переменных окружения
const { TELEGRAM_WEB_APP_URL } = process.env;

if (!TELEGRAM_WEB_APP_URL) {
    throw new Error(
        'Missing required environment variable: TELEGRAM_WEB_APP_URL'
    );
}

export class PaymentService {
    constructor(bot) {
        this.bot = bot;
        this.activeChats = new Map(); // Хранилище активных диалогов после покупки
        this.MANAGER_CHAT_ID = MANAGER_CHAT_ID;
    }

    // Поиск пользователя по ID топика
    findUserIdByTopicId(topicId) {
        for (const [userId, chatInfo] of this.activeChats.entries()) {
            if (chatInfo.topicId === topicId) {
                return userId;
            }
        }
        return null;
    }

    // Закрытие диалога
    async closeDialog(userId, initiator = 'user') {
        const chatInfo = this.activeChats.get(userId);
        if (!chatInfo) return;

        try {
            // Отправляем сообщение пользователю
            await this.bot.sendMessage(
                userId,
                'Диалог по вашему заказу завершен. Спасибо за покупку!',
                {
                    reply_markup: { remove_keyboard: true },
                }
            );

            // Отправляем сообщение в чат менеджеров
            if (chatInfo.topicId) {
                await this.bot.sendMessage(
                    this.MANAGER_CHAT_ID,
                    `Диалог с пользователем ${
                        chatInfo.username
                    } (${userId}) завершен ${
                        initiator === 'user' ? 'пользователем' : 'менеджером'
                    }.`,
                    { message_thread_id: chatInfo.topicId }
                );
            }
        } catch (error) {
            console.error('Error closing dialog:', error);
        } finally {
            this.activeChats.delete(userId);
        }
    }

    // Отправка уведомления менеджерам о новой покупке
    async sendManagerNotification({
        telegramUsername,
        telegramId,
        gameInfo,
        checkoutWithoutAccount,
        firstName,
        lastName,
        customerEmail,
        birthDate,
        psLogin,
        psPassword,
        psBackupCodes,
        currency,
        promoCode,
    }) {
        try {
            // Логируем входящие данные для отладки
            console.log('sendManagerNotification received data:', {
                telegramUsername,
                telegramId,
                gameInfoCount: gameInfo?.length || 0,
                checkoutWithoutAccount,
                firstName: firstName ? 'provided' : 'not provided',
                lastName: lastName ? 'provided' : 'not provided',
                customerEmail: customerEmail ? 'provided' : 'not provided',
                birthDate: birthDate ? 'provided' : 'not provided',
                psLogin: psLogin ? 'provided' : 'not provided',
                psPassword: psPassword ? 'provided' : 'not provided',
                psPasswordType: typeof psPassword,
                psPasswordLength: psPassword ? psPassword.length : 0,
                psBackupCodes: psBackupCodes ? 'provided' : 'not provided',
                currency: currency ? 'provided' : 'not provided',
                promoCode: promoCode ? 'provided' : 'not provided',
            });

            // Получаем дополнительные данные из БД
            let promoDiscount = 0;
            let editionsData = new Map();

            // Получаем информацию о промокоде
            if (promoCode) {
                try {
                    const [promoResults] = await sequelize.query(
                        `SELECT "discount" FROM "Promos" WHERE "name" = :promoCode AND "isActive" = true LIMIT 1`,
                        {
                            replacements: { promoCode },
                            type: sequelize.QueryTypes.SELECT
                        }
                    );
                    if (promoResults) {
                        promoDiscount = promoResults.discount || 0;
                        console.log(`Promo code ${promoCode} found with discount: ${promoDiscount}%`);
                    }
                } catch (error) {
                    console.error('Error fetching promo code:', error);
                }
            }

            // Получаем информацию об изданиях (локализации, платформы)
            const editionIds = gameInfo.map(game => game.editionId).filter(Boolean);
            if (editionIds.length > 0) {
                try {
                    const editions = await sequelize.query(
                        `SELECT
                            e.id,
                            e.ps_plus_price,
                            e.ea_play_price,
                            COALESCE(
                                json_agg(DISTINCT jsonb_build_object('name', l.name)) FILTER (WHERE l.id IS NOT NULL),
                                '[]'
                            ) as localizations,
                            COALESCE(
                                json_agg(DISTINCT jsonb_build_object('name', p.name)) FILTER (WHERE p.id IS NOT NULL),
                                '[]'
                            ) as platforms
                        FROM "Editions" e
                        LEFT JOIN edition_localizations el ON e.id = el.edition_id
                        LEFT JOIN "Localizations" l ON el.localization_id = l.id
                        LEFT JOIN edition_platforms ep ON e.id = ep.edition_id
                        LEFT JOIN "Platforms" p ON ep.platform_id = p.id
                        WHERE e.id IN (:editionIds)
                        GROUP BY e.id`,
                        {
                            replacements: { editionIds },
                            type: sequelize.QueryTypes.SELECT
                        }
                    );

                    editions.forEach(edition => {
                        // Парсим JSON строки в массивы, если нужно
                        if (typeof edition.localizations === 'string') {
                            edition.localizations = JSON.parse(edition.localizations);
                        }
                        if (typeof edition.platforms === 'string') {
                            edition.platforms = JSON.parse(edition.platforms);
                        }

                        editionsData.set(edition.id, edition);

                        console.log(`Edition ${edition.id} data:`, {
                            localizationsType: typeof edition.localizations,
                            localizationsLength: edition.localizations?.length,
                            localizations: edition.localizations,
                            platformsType: typeof edition.platforms,
                            platformsLength: edition.platforms?.length,
                            platforms: edition.platforms
                        });
                    });
                    console.log(`Fetched data for ${editions.length} editions`);
                } catch (error) {
                    console.error('Error fetching editions data:', error);
                }
            }

            // Словарь переводов типов изданий
            const editionTypeTranslations = {
                'Game': 'Игра',
                'DLC': 'Дополнение',
                'Add-On': 'Дополнение',
                'Expansion': 'Дополнение',
                'Season Pass': 'Сезонный пропуск',
                'Bundle': 'Набор'
            };

            // Создаем топик в чате менеджеров
            const gamesCount = gameInfo.length;
            const userIdentifier = telegramUsername
                ? `${telegramUsername}`
                : `ID:${telegramId}`;

            // Форматируем название игры для заголовка темы
            const formatGameTitle = game => {
                const editionTypeRaw = game.edition_type || 'Game';
                const editionType = editionTypeTranslations[editionTypeRaw] || editionTypeRaw;
                const title = game.title || '';
                const editionName = game.editionName || 'Standard Edition';

                return `${editionType} – ${title} ${
                    editionName !== 'Standard Edition' ? editionName : ''
                }`;
            };

            const topicTitle =
                gamesCount === 1
                    ? `🛒 Покупка – ${formatGameTitle(
                            gameInfo[0]
                      )} | ${userIdentifier}`
                    : `🛒 Покупка ${gamesCount} игр | ${userIdentifier}`;

            const topic = await this.bot.createForumTopic(
                this.MANAGER_CHAT_ID,
                topicTitle
            );
            const topicId = topic.message_thread_id;

            // Функция форматирования цены
            const formatPrice = price => {
                const num = Number(price);
                return Math.floor(num);
            };

            // Функция получения символа валюты
            const getCurrencySymbol = currencyObj => {
                if (typeof currencyObj === 'string') return currencyObj;
                if (currencyObj && typeof currencyObj === 'object') {
                    return currencyObj.symbol || currencyObj.code || 'руб.';
                }
                return 'руб.';
            };

            // Формируем детальную информацию о каждой игре
            const gamesDetails = gameInfo
                .map(game => {
                    const editionData = editionsData.get(game.editionId);

                    // Формируем первую строку: Тип (Платформа/ы) - Название / Издание
                    const editionTypeRaw = game.edition_type || 'Game';
                    const editionType = editionTypeTranslations[editionTypeRaw] || editionTypeRaw;
                    const platforms = editionData?.platforms || [];
                    // Формируем строку с платформами: если их несколько, объединяем через запятую
                    const platformsStr = platforms.length > 0
                        ? ` (${platforms.map(p => p.name).filter(Boolean).join(', ')})`
                        : '';
                    const title = game.title || '';
                    const editionName = game.editionName || 'Standard';

                    let result = `━━━━━━━━━━━━━━━━━━━━━━\n${editionType}${platformsStr} - ${title} / ${editionName}`;

                    // Добавляем локализации (если есть)
                    if (editionData?.localizations && editionData.localizations.length > 0) {
                        const localizationsStr = editionData.localizations
                            .map(loc => loc.name)
                            .filter(Boolean)
                            .join(', ');
                        if (localizationsStr) {
                            result += `\n${localizationsStr}`;
                        }
                    }

                    // Формируем строку с ценой
                    let priceStr = '';
                    let priceTypeLabel = '';

                    // Определяем тип цены и берем соответствующую оригинальную цену
                    if (game.priceType === 'ps_plus' && game.originalPsPlusPrice) {
                        // Если покупка с PS Plus - показываем оригинальную PS Plus цену и сконвертированную финальную цену
                        if (game.originalCurrency && game.originalCurrency !== '₽') {
                            priceStr = `${game.originalPsPlusPrice} ${game.originalCurrency} / ${formatPrice(game.finalPrice)} руб.`;
                        } else {
                            priceStr = `${game.originalPsPlusPrice} руб. / ${formatPrice(game.finalPrice)} руб.`;
                        }
                        priceTypeLabel = ' - цена по скидке за PS Plus';
                    } else if (game.priceType === 'ea_play' && game.originalEaPlayPrice) {
                        // Если покупка с EA Play - показываем оригинальную EA Play цену и сконвертированную финальную цену
                        if (game.originalCurrency && game.originalCurrency !== '₽') {
                            priceStr = `${game.originalEaPlayPrice} ${game.originalCurrency} / ${formatPrice(game.finalPrice)} руб.`;
                        } else {
                            priceStr = `${game.originalEaPlayPrice} руб. / ${formatPrice(game.finalPrice)} руб.`;
                        }
                        priceTypeLabel = ' - цена по скидке за EA Play';
                    } else {
                        // Обычная цена без PS Plus / EA Play
                        if (game.originalPrice && game.originalCurrency && game.originalCurrency !== '₽') {
                            priceStr = `${game.originalPrice} ${game.originalCurrency} / ${formatPrice(game.finalPrice)} руб.`;
                        } else {
                            priceStr = `${formatPrice(game.finalPrice)} руб.`;
                        }
                    }

                    result += `\n${priceStr}${priceTypeLabel}`;

                    // Добавляем ссылку на товар в админ-панели
                    result += `\nТовар в админ-панели: ${TELEGRAM_WEB_APP_URL}admin/resources/Editions/records/${game.editionId}/show`;

                    return result;
                })
                .join('\n\n');

            // Проверяем наличие данных аккаунта
            const hasAccountData =
                // Проверяем, что это НЕ оформление без аккаунта
                !(
                    checkoutWithoutAccount === true ||
                    checkoutWithoutAccount === 'true'
                ) &&
                // И есть логин
                psLogin &&
                psLogin.trim() !== '';

            // Выводим больше диагностической информации
            console.log('Account data check details:', {
                checkoutWithoutAccount,
                checkoutWithoutAccountType: typeof checkoutWithoutAccount,
                psLogin,
                psPassword: psPassword ? 'exists' : 'missing',
                psPasswordType: typeof psPassword,
                psPasswordLength: psPassword ? psPassword.length : 0,
                hasLoginValue: Boolean(psLogin && psLogin.trim() !== ''),
                finalDecision: hasAccountData,
            });

            // Подготовка ссылки на пользователя
            const userLink = telegramUsername
                ? `<a href="https://t.me/${telegramUsername}">Перейти</a>`
                : `<a href="tg://user?id=${telegramId}">Перейти</a>`;

            // Подсчитываем итоговую сумму
            const totalBeforePromo = gameInfo.reduce((sum, game) => {
                return sum + parseFloat(game.finalPrice || 0);
            }, 0);

            const totalAfterPromo = promoDiscount > 0
                ? totalBeforePromo * (1 - promoDiscount / 100)
                : totalBeforePromo;

            const totalStr = formatPrice(totalAfterPromo);

            // Формируем блок с промокодом и итоговой суммой
            let summaryBlock = '\n\n━━━━━━━━━━━━━━━━━━━━━━\n\n';
            if (promoCode && promoDiscount > 0) {
                summaryBlock += `Применен промокод «${promoCode}» (скидка ${promoDiscount}%)\n`;
            }
            summaryBlock += `Итого: ${totalStr} руб.`;

            // Prepare purchase details based on checkout type
            let purchaseDetails;
            if (hasAccountData) {
                console.log(
                    'Creating notification for checkout with existing account'
                );
                // Убедимся, что psPassword обрабатывается как строка
                const passwordToShow = psPassword
                    ? String(psPassword)
                    : 'Не указано';

                purchaseDetails = `
Аккаунт PS Store:
Логин: ${psLogin}
Пароль: ${passwordToShow}
Резервные коды: ${psBackupCodes || 'Не указано'}

Данные заказа:
Telegram ID: ${telegramId}
Юзернейм: ${userLink}

Информация об играх:

${gamesDetails}${summaryBlock}`;
            } else {
                console.log(
                    'Creating notification for checkout without account',
                    {
                        checkoutWithoutAccount,
                        hasAccountData,
                        firstName,
                        lastName,
                        customerEmail,
                    }
                );
                purchaseDetails = `
Новая покупка!
Нужно создать аккаунт 👤

Личные данные:
Имя: ${firstName || 'Не указано'}
Фамилия: ${lastName || 'Не указано'}
Email: ${customerEmail || 'Не указано'}
Дата рождения: ${birthDate || 'Не указано'}

Данные заказа:
Telegram ID: ${telegramId}
Юзернейм: ${userLink}

Информация об играх:

${gamesDetails}${summaryBlock}`;
            }

            // Добавляем потерянный лог перед отправкой сообщения
            console.log('Generated purchase details with type:', {
                hasAccountData,
                checkoutWithoutAccount,
                hasLogin: Boolean(psLogin),
            });

            // Отправляем детальную информацию о заказе
            await this.bot.sendMessage(this.MANAGER_CHAT_ID, purchaseDetails, {
                message_thread_id: topicId,
                parse_mode: 'HTML',
            });

            // Сообщение о команде закрытия диалога
            await this.bot.sendMessage(
                this.MANAGER_CHAT_ID,
                'Для завершения диалога используйте команду /close',
                {
                    message_thread_id: topicId,
                }
            );

            // Возвращаем ID топика для сохранения в activeChats
            return topicId;
        } catch (error) {
            console.error('Error sending manager notification:', error);
            throw error;
        }
    }

    async sendPaymentNotification(
        telegramUsername,
        gameInfo,
        telegramId,
        checkoutWithoutAccount,
        psLogin,
        psPassword,
        psBackupCodes,
        firstName,
        lastName,
        customerEmail,
        birthDate,
        paymentStatus,
        currency,
        promoCode
    ) {
        try {
            // Проверяем, что платеж действительно оплачен
            if (paymentStatus !== 'paid') {
                console.log('Payment not yet completed, skipping notification');
                return;
            }

            console.log('Sending payment notification:', {
                username: telegramUsername,
                gamesCount: gameInfo.length,
                telegramId: telegramId,
                telegramIdType: typeof telegramId,
                checkoutWithoutAccount,
                psLogin: psLogin ? 'provided' : 'not provided',
                psPassword: psPassword ? 'provided' : 'not provided',
                psPasswordType: typeof psPassword,
                psPasswordLength: psPassword ? psPassword.length : 0,
                status: paymentStatus,
            });

            // Функция форматирования цены
            const formatPrice = price => {
                const num = Number(price);
                return Math.floor(num);
            };

            // Функция получения символа валюты
            const getCurrencySymbol = currencyObj => {
                if (typeof currencyObj === 'string') return currencyObj;
                if (currencyObj && typeof currencyObj === 'object') {
                    return currencyObj.symbol || currencyObj.code || 'руб.';
                }
                return 'руб.';
            };

            // Словарь переводов типов изданий
            const editionTypeTranslations = {
                'Game': 'Игра',
                'DLC': 'Дополнение',
                'Add-On': 'Дополнение',
                'Expansion': 'Дополнение',
                'Season Pass': 'Сезонный пропуск',
                'Bundle': 'Набор'
            };

            // Формируем список игр для сообщения пользователю
            const gamesList = gameInfo
                .map(game => {
                    const editionTypeRaw = game.edition_type || 'Game';
                    const editionType = editionTypeTranslations[editionTypeRaw] || editionTypeRaw;
                    const title = game.title || '';
                    const editionName = game.editionName || 'Standard Edition';

                    // Формируем строку с названием игры
                    let gameString = `${editionType} – ${title} / ${editionName}`;

                    return gameString;
                })
                .join('\n\n');

            // Send message to user with keyboard
            await this.bot.sendMessage(
                telegramId,
                `✅ Покупка успешно оформлена!\n\nКуплено:\n${gamesList}\n\nМенеджер скоро свяжется с вами.\n\nПоддержка: @psworld_store`,
                {
                    reply_markup: {
                        keyboard: [['Завершить диалог']],
                        resize_keyboard: true,
                        one_time_keyboard: false,
                    },
                }
            );

            // Отправляем сообщение в чат менеджеров
            console.log('Preparing notification with data:', {
                checkoutWithoutAccount,
                firstName,
                lastName,
                customerEmail,
                birthDate,
                psLogin,
                psPassword,
                psBackupCodes,
            });

            // Отправляем сообщение в чат менеджеров и получаем ID топика
            const topicId = await this.sendManagerNotification({
                telegramUsername,
                telegramId,
                gameInfo,
                checkoutWithoutAccount,
                firstName,
                lastName,
                customerEmail,
                birthDate,
                psLogin,
                psPassword,
                psBackupCodes,
                currency,
                promoCode,
            });

            // Проверяем, что topicId получен
            if (!topicId) {
                console.error(
                    'Failed to get topicId from sendManagerNotification'
                );
                return;
            }

            // Преобразуем telegramId в число, если это строка
            // Telegram API всегда использует числовые ID пользователей
            const userIdKey = Number(telegramId);

            // Сохраняем информацию о диалоге
            this.activeChats.set(userIdKey, {
                status: 'active',
                username: telegramUsername || userIdKey.toString(),
                topicId: topicId,
                chatId: userIdKey,
            });

            console.log('Saved active chat info:', {
                telegramId: userIdKey,
                telegramIdType: typeof userIdKey,
                username: telegramUsername || userIdKey.toString(),
                topicId,
                activeChatsSize: this.activeChats.size,
                activeChatsKeys: Array.from(this.activeChats.keys()),
            });
        } catch (error) {
            console.error('Error sending payment notification:', error);
            throw error;
        }
    }

    setup() {
        // Handle all incoming messages
        this.bot.on('message', async msg => {
            try {
                const userId = Number(msg.from?.id);
                if (!userId) return;

                // Добавляем логирование для диагностики
                console.log('Received message in paymentService:', {
                    userId: userId,
                    userIdType: typeof userId,
                    chatType: msg.chat?.type,
                    isPrivate: msg.chat?.type === 'private',
                    hasChatInfo: Boolean(this.activeChats.get(userId)),
                    chatInfo: this.activeChats.get(userId),
                    chatId: msg.chat?.id,
                    messageText:
                        msg.text?.substring(0, 30) +
                        (msg.text?.length > 30 ? '...' : ''),
                    hasPhoto: !!msg.photo,
                    hasDocument: !!msg.document,
                    hasVideo: !!msg.video,
                    hasAudio: !!msg.audio,
                    hasVoice: !!msg.voice,
                    hasVideoNote: !!msg.video_note,
                    activeChatsSize: this.activeChats.size,
                    activeChatsKeys: Array.from(this.activeChats.keys()),
                });

                // Проверяем наличие чата в Map
                let chatInfo = this.activeChats.get(userId);

                // Если не нашли по числовому ID, попробуем найти по строковому
                if (!chatInfo && typeof userId === 'number') {
                    chatInfo = this.activeChats.get(String(userId));

                    // Если нашли по строковому ID, обновим Map с числовым ключом
                    if (chatInfo) {
                        console.log(
                            `Found chat info by string ID, updating to numeric ID: ${userId}`
                        );
                        this.activeChats.delete(String(userId));
                        this.activeChats.set(userId, chatInfo);
                    }
                }

                // Обработка сообщений от пользователя в приватном чате
                if (msg.chat?.type === 'private' && chatInfo) {
                    if (msg.text === 'Завершить диалог') {
                        await this.closeDialog(userId);
                        return;
                    }

                    console.log('Forwarding message from user to managers:', {
                        userId,
                        userIdType: typeof userId,
                        managerChatId: this.MANAGER_CHAT_ID,
                        topicId: chatInfo.topicId,
                        messageText:
                            msg.text?.substring(0, 30) +
                            (msg.text?.length > 30 ? '...' : ''),
                    });

                    // Пересылаем сообщение в топик менеджеров
                    try {
                        await this.forwardUserMessageToManagers(msg, chatInfo.topicId);
                        console.log(
                            'Successfully forwarded user message to managers'
                        );
                    } catch (forwardError) {
                        console.error(
                            'Error forwarding message to managers:',
                            forwardError,
                            {
                                managerChatId: this.MANAGER_CHAT_ID,
                                topicId: chatInfo.topicId,
                            }
                        );
                    }
                    return;
                } else if (msg.chat?.type === 'private') {
                    console.log(
                        'Received private message but no active chat found:',
                        {
                            userId,
                            userIdType: typeof userId,
                            messageText:
                                msg.text?.substring(0, 30) +
                                (msg.text?.length > 30 ? '...' : ''),
                            activeChatsKeys: Array.from(
                                this.activeChats.keys()
                            ),
                            activeChatsKeysTypes: Array.from(
                                this.activeChats.keys()
                            ).map(key => typeof key),
                        }
                    );
                }

                // Обработка сообщений от менеджеров
                if (
                    msg.chat.id === this.MANAGER_CHAT_ID &&
                    msg.message_thread_id
                ) {
                    const topicId = msg.message_thread_id;
                    const userIdFromTopic = this.findUserIdByTopicId(topicId);

                    console.log('Processing manager message:', {
                        topicId,
                        foundUserId: userIdFromTopic,
                        messageText:
                            msg.text?.substring(0, 30) +
                            (msg.text?.length > 30 ? '...' : ''),
                    });

                    if (userIdFromTopic) {
                        if (msg.text === '/close') {
                            await this.closeDialog(userIdFromTopic, 'manager');
                            return;
                        }

                        console.log(
                            'Forwarding message from manager to user:',
                            {
                                userId: userIdFromTopic,
                                topicId,
                                messageText:
                                    msg.text?.substring(0, 30) +
                                    (msg.text?.length > 30 ? '...' : ''),
                            }
                        );

                        // Пересылаем сообщение пользователю
                        try {
                            await this.forwardManagerMessageToUser(msg, userIdFromTopic, topicId);
                            console.log(
                                'Successfully forwarded manager message to user'
                            );
                        } catch (forwardError) {
                            console.error(
                                'Error forwarding message to user:',
                                forwardError
                            );
                        }
                    }
                }
            } catch (error) {
                console.error('Error handling message:', error);
            }
        });

        // Handle callback queries
        this.bot.on('callback_query', async query => {
            if (!query.data.startsWith('close_dialog:')) return;

            try {
                const threadId = query.data.split(':')[1];
                const userIdFromTopic = this.findUserIdByTopicId(threadId);

                if (userIdFromTopic) {
                    await this.closeDialog(userIdFromTopic, 'manager');
                }

                // Acknowledge callback
                await this.bot.answerCallbackQuery(query.id, {
                    text: 'Диалог успешно завершен',
                });
            } catch (error) {
                console.error('Error closing dialog:', error);
                await this.bot.answerCallbackQuery(query.id, {
                    text: 'Ошибка при закрытии диалога',
                });
            }
        });

        console.log('Payment service message handler registered');
    }

    async forwardUserMessageToManagers(msg, topicId) {
        const options = { message_thread_id: topicId };
        const caption = msg.caption ? `Сообщение от пользователя:\n${msg.caption}` : 'Сообщение от пользователя:';

        if (msg.photo) {
            // Берем фото с максимальным разрешением
            const photo = msg.photo[msg.photo.length - 1];
            await this.bot.sendPhoto(this.MANAGER_CHAT_ID, photo.file_id, {
                ...options,
                caption: caption
            });
        } else if (msg.document) {
            await this.bot.sendDocument(this.MANAGER_CHAT_ID, msg.document.file_id, {
                ...options,
                caption: caption
            });
        } else if (msg.video) {
            await this.bot.sendVideo(this.MANAGER_CHAT_ID, msg.video.file_id, {
                ...options,
                caption: caption
            });
        } else if (msg.audio) {
            await this.bot.sendAudio(this.MANAGER_CHAT_ID, msg.audio.file_id, {
                ...options,
                caption: caption
            });
        } else if (msg.voice) {
            await this.bot.sendVoice(this.MANAGER_CHAT_ID, msg.voice.file_id, {
                ...options,
                caption: caption
            });
        } else if (msg.video_note) {
            await this.bot.sendVideoNote(this.MANAGER_CHAT_ID, msg.video_note.file_id, options);
            if (msg.text || msg.caption) {
                await this.bot.sendMessage(this.MANAGER_CHAT_ID, caption, options);
            }
        } else if (msg.sticker) {
            await this.bot.sendSticker(this.MANAGER_CHAT_ID, msg.sticker.file_id, options);
            if (msg.text || msg.caption) {
                await this.bot.sendMessage(this.MANAGER_CHAT_ID, caption, options);
            }
        } else if (msg.text) {
            await this.bot.sendMessage(
                this.MANAGER_CHAT_ID,
                `Сообщение от пользователя:\n${msg.text}`,
                options
            );
        }
    }

    async forwardManagerMessageToUser(msg, userId, topicId) {
        const caption = msg.caption ? `Сообщение от менеджера:\n${msg.caption}` : 'Сообщение от менеджера:';

        try {
            if (msg.photo) {
                const photo = msg.photo[msg.photo.length - 1];
                await this.bot.sendPhoto(userId, photo.file_id, {
                    caption: caption
                });
            } else if (msg.document) {
                await this.bot.sendDocument(userId, msg.document.file_id, {
                    caption: caption
                });
            } else if (msg.video) {
                await this.bot.sendVideo(userId, msg.video.file_id, {
                    caption: caption
                });
            } else if (msg.audio) {
                await this.bot.sendAudio(userId, msg.audio.file_id, {
                    caption: caption
                });
            } else if (msg.voice) {
                await this.bot.sendVoice(userId, msg.voice.file_id, {
                    caption: caption
                });
            } else if (msg.video_note) {
                await this.bot.sendVideoNote(userId, msg.video_note.file_id);
                if (msg.text || msg.caption) {
                    await this.bot.sendMessage(userId, caption);
                }
            } else if (msg.sticker) {
                await this.bot.sendSticker(userId, msg.sticker.file_id);
                if (msg.text || msg.caption) {
                    await this.bot.sendMessage(userId, caption);
                }
            } else if (msg.text) {
                await this.bot.sendMessage(userId, `Сообщение от менеджера:\n${msg.text}`);
            }
        } catch (error) {
            console.error('Error forwarding message to user:', error);
            throw error;
        }
    }
}

// Создаем экземпляр сервиса и инициализируем его
const paymentService = new PaymentService(bot);
paymentService.setup();

// Экспортируем экземпляр для использования в других модулях
export default paymentService;
