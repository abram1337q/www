import vue from '@vitejs/plugin-vue';
import path from 'path';
import { defineConfig, loadEnv } from 'vite';

export default defineConfig(({ mode }) => {
	const env = loadEnv(mode, process.cwd(), '');
	const apiBaseUrl = env.VITE_API_BASE_URL;

	console.log('API Base URL:', apiBaseUrl);

	return {
		plugins: [vue()],
		define: {
			'process.env': env,
		},
		server: {
			host: true,
			port: 5312,
			cors: {
				origin: [
					'https://pwstore.ru',
					'https://eyes-injection-strengthening-negotiation.trycloudflare.com',
					'https://request-medications-patio-onion.trycloudflare.com',
					'http://localhost:5312',
					'http://127.0.0.1:5312',
				],
				credentials: true,
				methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
				allowedHeaders: [
					'Origin',
					'X-Requested-With',
					'Content-Type',
					'Accept',
					'Authorization',
					'CF-Connecting-IP',
					'CF-IPCountry',
					'CF-RAY',
					'CF-Visitor',
					'CF-Worker',
				],
			},
			proxy: {
				'/api': {
					target: apiBaseUrl,
					changeOrigin: true,
					secure: false, // Отключаем проверку SSL для разработки
					ws: true,
					rewrite: path => path,
					headers: {
						Origin: apiBaseUrl,
					},
					configure: (proxy, options) => {
						proxy.on('error', (err, req, res) => {
							console.log('proxy error', err);
						});
						proxy.on('proxyReq', (proxyReq, req, res) => {
							console.log('Proxy request to:', proxyReq.path);
						});
					},
				},
			},
			hmr: {
				port: 5312,
				protocol: 'ws', // Используем ws вместо wss для локальной разработки
				clientPort: 5312,
				overlay: true,
			},
		},
		preview: {
			port: 5312,
			proxy: {
				'/api': {
					target: apiBaseUrl,
					changeOrigin: true,
					secure: true,
					rewrite: path => path,
				},
			},
		},
		resolve: {
			alias: {
				'@': path.resolve(__dirname, './src'),
			},
		},
		build: {
			outDir: 'dist',
			assetsDir: 'assets',
			rollupOptions: {
				output: {
					assetFileNames: assetInfo => {
						if (assetInfo.name.endsWith('.png')) {
							return 'assets/img/[name][extname]';
						}
						return 'assets/[name]-[hash][extname]';
					},
				},
			},
		},
		publicDir: 'public',
	};
});
