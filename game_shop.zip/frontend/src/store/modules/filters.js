const state = {
    selectedEdition: null,
    selectedPrices: {}, // Будем хранить как обычный объект, так как Map не сериализуется
};

const mutations = {
    SET_SELECTED_EDITION(state, edition) {
        state.selectedEdition = edition;
    },
    SET_SELECTED_PRICES(state, { editionId, priceType }) {
        state.selectedPrices = { [editionId]: priceType }; // Храним только один выбор
    },
    CLEAR_FILTERS(state) {
        state.selectedEdition = null;
        state.selectedPrices = {};
    },
};

const actions = {
    selectEditionAndPrice({ commit }, { edition, priceType }) {
        commit('SET_SELECTED_EDITION', edition);
        commit('SET_SELECTED_PRICES', { editionId: edition.id, priceType });
    },
    clearFilters({ commit }) {
        commit('CLEAR_FILTERS');
    },
};

const getters = {
    getSelectedEdition: state => state.selectedEdition,
    getSelectedPriceType: state => editionId => state.selectedPrices[editionId],
    isEditionPriceSelected: state => (edition, type) => {
        return state.selectedPrices[edition.id] === type;
    },
};

export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters,
};
