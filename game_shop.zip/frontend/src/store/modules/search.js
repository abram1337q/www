// Модуль Vuex для хранения состояния поиска
export default {
	namespaced: true,

	state: () => ({
		searchQuery: '',
		searchResults: [],
		selectedGenres: [],
		priceFrom: '',
		priceTo: '',
		isFiltersOpen: false,
		isLoading: false,
		error: null,
		// Кеш результатов поиска (ограничен 50 запросами)
		searchCache: new Map(),
		maxCacheSize: 50, // Максимум 50 результатов в кеше
		cacheTTL: 5 * 60 * 1000, // TTL кеша: 5 минут в миллисекундах
		// Пагинация
		currentPage: 1,
		itemsPerPage: 20,
		scrollPosition: 0,
	}),

	mutations: {
		SET_SEARCH_QUERY(state, query) {
			state.searchQuery = query;
		},
		SET_SEARCH_RESULTS(state, results) {
			state.searchResults = results;
		},
		SET_SELECTED_GENRES(state, genres) {
			state.selectedGenres = genres;
		},
		SET_PRICE_FROM(state, price) {
			state.priceFrom = price;
		},
		SET_PRICE_TO(state, price) {
			state.priceTo = price;
		},
		SET_FILTERS_OPEN(state, isOpen) {
			state.isFiltersOpen = isOpen;
		},
		SET_LOADING(state, isLoading) {
			state.isLoading = isLoading;
		},
		SET_ERROR(state, error) {
			state.error = error;
		},
		// Добавление результатов в кеш с ограничением размера (LRU - Least Recently Used)
		ADD_TO_CACHE(state, { key, results }) {
			// Если кеш переполнен, удаляем самый старый элемент
			if (state.searchCache.size >= state.maxCacheSize) {
				const firstKey = state.searchCache.keys().next().value;
				state.searchCache.delete(firstKey);
			}
			// Сохраняем результаты с timestamp для TTL
			state.searchCache.set(key, {
				results,
				timestamp: Date.now(),
			});
		},
		// Очистка кеша
		CLEAR_CACHE(state) {
			state.searchCache.clear();
		},
		// Пагинация
		SET_CURRENT_PAGE(state, page) {
			state.currentPage = page;
		},
		SET_SCROLL_POSITION(state, position) {
			state.scrollPosition = position;
		},
		RESET_FILTERS(state) {
			state.selectedGenres = [];
			state.priceFrom = '';
			state.priceTo = '';
			state.error = null;
		},
		RESET_ALL(state) {
			state.searchQuery = '';
			state.searchResults = [];
			state.selectedGenres = [];
			state.priceFrom = '';
			state.priceTo = '';
			state.isFiltersOpen = false;
			state.error = null;
			state.currentPage = 1;
			state.scrollPosition = 0;
			// Очищаем кеш при полном сбросе
			state.searchCache.clear();
		},
	},

	actions: {
		setSearchQuery({ commit }, query) {
			commit('SET_SEARCH_QUERY', query);
		},
		setSearchResults({ commit }, results) {
			commit('SET_SEARCH_RESULTS', results);
		},
		setSelectedGenres({ commit }, genres) {
			commit('SET_SELECTED_GENRES', genres);
		},
		setPriceFrom({ commit }, price) {
			commit('SET_PRICE_FROM', price);
		},
		setPriceTo({ commit }, price) {
			commit('SET_PRICE_TO', price);
		},
		toggleFilters({ commit, state }) {
			commit('SET_FILTERS_OPEN', !state.isFiltersOpen);
		},
		setLoading({ commit }, isLoading) {
			commit('SET_LOADING', isLoading);
		},
		setError({ commit }, error) {
			commit('SET_ERROR', error);
		},
		addToCache({ commit }, { key, results }) {
			commit('ADD_TO_CACHE', { key, results });
		},
		clearCache({ commit }) {
			commit('CLEAR_CACHE');
		},
		// Пагинация
		setCurrentPage({ commit }, page) {
			commit('SET_CURRENT_PAGE', page);
		},
		setScrollPosition({ commit }, position) {
			commit('SET_SCROLL_POSITION', position);
		},
		resetFilters({ commit }) {
			commit('RESET_FILTERS');
		},
		resetAll({ commit }) {
			commit('RESET_ALL');
		},
	},

	getters: {
		getSearchQuery: state => state.searchQuery,
		getSearchResults: state => state.searchResults,
		getSelectedGenres: state => state.selectedGenres,
		getPriceFrom: state => state.priceFrom,
		getPriceTo: state => state.priceTo,
		isFiltersOpen: state => state.isFiltersOpen,
		isLoading: state => state.isLoading,
		getError: state => state.error,
		getFromCache: state => key => {
			const cached = state.searchCache.get(key);
			if (!cached) return null;

			// Проверяем, не истёк ли TTL
			const isExpired = (Date.now() - cached.timestamp) > state.cacheTTL;
			if (isExpired) {
				state.searchCache.delete(key);
				return null;
			}

			return cached.results;
		},
		hasCache: state => key => {
			const cached = state.searchCache.get(key);
			if (!cached) return false;

			// Проверяем, не истёк ли TTL
			const isExpired = (Date.now() - cached.timestamp) > state.cacheTTL;
			if (isExpired) {
				state.searchCache.delete(key);
				return false;
			}

			return true;
		},
		getCacheSize: state => state.searchCache.size,
		// Пагинация
		getCurrentPage: state => state.currentPage,
		getItemsPerPage: state => state.itemsPerPage,
		getScrollPosition: state => state.scrollPosition,
		activeFiltersCount: state => {
			let count = 0;
			if (state.selectedGenres.length > 0) count++;
			if (state.priceFrom || state.priceTo) count++;
			return count || null;
		},
		expandedSearchResults: state => {
			const expanded = state.searchResults.flatMap(product => {
				if (!product.editions || product.editions.length === 0) {
					return [product];
				}

				return product.editions.map(edition => ({
					...product,
					edition,
					title: product.title,
					price: edition.convertedPrice || edition.price,
					discount_amount: edition.discount_amount,
					edition_type: product.edition_type,
					editions: [edition],
				}));
			});

			// Сортируем товары
			return expanded.sort((a, b) => {
				// Сначала по типу: игры идут первыми, потом дополнения
				if (a.edition_type !== b.edition_type) {
					if (a.edition_type === 'Игра') {
						return -1;
					}
					if (b.edition_type === 'Игра') {
						return 1;
					}
					return a.edition_type.localeCompare(b.edition_type);
				}

				// Внутри одного типа сортируем по цене (от меньшей к большей)
				const priceA = a.discount_amount !== null && a.discount_amount !== undefined
					? a.discount_amount
					: (a.price || 0);
				const priceB = b.discount_amount !== null && b.discount_amount !== undefined
					? b.discount_amount
					: (b.price || 0);

				return priceA - priceB;
			});
		},
		// Товары для текущей страницы
		paginatedSearchResults: (state, getters) => {
			const allResults = getters.expandedSearchResults;
			const startIndex = (state.currentPage - 1) * state.itemsPerPage;
			const endIndex = startIndex + state.itemsPerPage;
			return allResults.slice(startIndex, endIndex);
		},
		// Общее количество страниц
		getTotalPages: (state, getters) => {
			return Math.max(1, Math.ceil(getters.expandedSearchResults.length / state.itemsPerPage));
		},
	},
};
