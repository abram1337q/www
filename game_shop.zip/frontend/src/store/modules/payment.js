// payment.js
const state = {
	paymentData: {
		checkoutWithoutAccount: false,
		psLogin: null,
		psPassword: null,
		psBackupCodes: null,
		firstName: null,
		lastName: null,
		customerEmail: null,
		birthDate: null,
		email: null,
		telegramUsername: null,
		telegramId: null,
		gameInfo: null
	},
	paymentStatus: null,
	isProcessing: false,
};

const mutations = {
	SET_PAYMENT_DATA(state, data) {
		state.paymentData = { ...state.paymentData, ...data };
	},
	SET_PAYMENT_STATUS(state, status) {
		state.paymentStatus = status;
	},
	SET_PROCESSING(state, status) {
		state.isProcessing = status;
	},
	RESET_PAYMENT_DATA(state) {
		state.paymentData = {
			checkoutWithoutAccount: false,
			psLogin: null,
			psPassword: null,
			psBackupCodes: null,
			firstName: null,
			lastName: null,
			customerEmail: null,
			birthDate: null,
			email: null,
			telegramUsername: null,
			telegramId: null,
			gameInfo: null
		};
		state.paymentStatus = null;
		state.isProcessing = false;
	}
};

const actions = {
	savePaymentData({ commit }, data) {
		commit('SET_PAYMENT_DATA', data);
	},
	setPaymentStatus({ commit }, status) {
		commit('SET_PAYMENT_STATUS', status);
	},
	setProcessing({ commit }, status) {
		commit('SET_PROCESSING', status);
	},
	resetPaymentData({ commit }) {
		commit('RESET_PAYMENT_DATA');
	},
	async submitPayment({ state, commit }) {
		try {
			commit('SET_PROCESSING', true);
			const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/payment/create-bill`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
				},
				body: JSON.stringify(state.paymentData),
			});

			if (!response.ok) {
				const error = await response.json();
				throw new Error(error.message || 'Failed to create payment');
			}

			const result = await response.json();
			commit('SET_PAYMENT_STATUS', 'success');
			return result;
		} catch (error) {
			commit('SET_PAYMENT_STATUS', 'error');
			throw error;
		} finally {
			commit('SET_PROCESSING', false);
		}
	}
};

const getters = {
	getPaymentData: state => state.paymentData,
	getPaymentStatus: state => state.paymentStatus,
	isProcessing: state => state.isProcessing,
};

export default {
	namespaced: true,
	state,
	mutations,
	actions,
	getters,
};
