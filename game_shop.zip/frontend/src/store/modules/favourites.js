export default {
  namespaced: true,
  state: {
    favouriteItems: [],
    currencyId: null, // Добавляем поле для хранения ID валюты избранного
  },
  mutations: {
    ADD_TO_FAVOURITES(state, item) {
      // console.log('Adding to favourites, received item:', item);
      // console.log('Price in item:', item.price);
      // console.log('Edition in item:', item.edition);
      // console.log('Price in edition:', item.edition?.price);
      // console.log(
      //   'convertedPrice in edition:',
      //   item.edition?.convertedPrice
      // );

      const newItems = [...state.favouriteItems];
      const editionId = item.edition?.id;

      // Проверяем наличие издания в избранном
      if (
        !newItems.some(
          favItem =>
            favItem.title === item.title &&
            favItem.editionId === editionId
        )
      ) {
        // Получаем корректные значения цены и скидки
        const price =
          item.edition?.convertedPrice ||
          item.edition?.price ||
          item.price ||
          0;
        const discountAmount =
          item.edition?.discount_amount || item.discount_amount || 0;

        // console.log('Calculated price for favorite:', price);
        // console.log(
        //   'Calculated discount for favorite:',
        //   discountAmount
        // );

        const gameData = {
          id: item.id, // ID игры (ProductCard)
          productId: item.productId || item.id, // Явно сохраняем productId для ссылок
          image: item.image,
          title: item.title,
          genres: item.genres,
          rating: item.rating,
          ratingCount: item.ratingCount,
          platforms: item.edition?.platforms || [],
          editions: item.editions,
          editionId: editionId,
          editionName: item.edition?.editionName?.name || null,
          subtitle: item.subtitle || '',
          edition: {
            ...item.edition,
            convertedPrice: price, // Устанавливаем корректную цену
            price: price, // Дублируем для надежности
            currency: item.edition?.currency,
            displayCurrency: item.edition?.displayCurrency,
            discount_amount: discountAmount, // Устанавливаем корректную скидку
          },
          // Сохраняем и на верхнем уровне для совместимости с разными компонентами
          price: price,
          discount_amount: discountAmount,
          edition_type:
            item.product_card?.edition_type || item.edition_type,
          product_card: {
            ...item.product_card,
          },
          currencyId: state.currencyId || item.edition?.displayCurrency?.id, // Добавляем ID валюты
        };

        // console.log(
        //   'Final gameData before adding to favorites:',
        //   gameData
        // );
        // console.log('Price in gameData:', gameData.price);
        // console.log(
        //   'Price in gameData.edition:',
        //   gameData.edition.price
        // );

        newItems.push(gameData);
        state.favouriteItems = newItems;
        // console.log('Added game data:', gameData);
      }
      // console.log('Current favourites after add:', state.favouriteItems);
    },
    REMOVE_FROM_FAVOURITES(state, { title, editionId }) {
      // console.log('Removing from favourites:', title, editionId);
      state.favouriteItems = [...state.favouriteItems].filter(
        item => !(item.title === title && item.editionId === editionId)
      );
      // console.log(
      //   'Current favourites after remove:',
      //   state.favouriteItems
      // );
    },
    SET_FAVOURITES(state, items) {
      // console.log('Setting favourites from storage:', items);
      state.favouriteItems = [...items];
    },
    SET_FAVOURITES_CURRENCY_ID(state, currencyId) {
      state.currencyId = currencyId;
    },
  },
  actions: {
    addToFavourites({ commit, state, rootGetters }, item) {
      // Получаем текущую валюту пользователя
      const currentCurrency = rootGetters['user/currentCurrency'];

      if (!state.currencyId && currentCurrency?.id) {
        // Если ID валюты избранного не установлен, устанавливаем его
        commit('SET_FAVOURITES_CURRENCY_ID', currentCurrency.id);
      }

      commit('ADD_TO_FAVOURITES', item);
      try {
        // Сохраняем избранное для текущего региона
        const currencyId = state.currencyId || currentCurrency?.id;
        if (currencyId) {
          const favouritesKey = `favourites_region_${currencyId}`;
          localStorage.setItem(
            favouritesKey,
            JSON.stringify(state.favouriteItems)
          );
        }
        // console.log('Saved to localStorage:', state.favouriteItems);
      } catch (error) {
        console.error('Error saving to localStorage:', error);
      }
    },
    removeFromFavourites({ commit, state, rootGetters }, { title, editionId }) {
      commit('REMOVE_FROM_FAVOURITES', { title, editionId });
      try {
        // Сохраняем избранное для текущего региона
        const currentCurrency = rootGetters['user/currentCurrency'];
        const currencyId = state.currencyId || currentCurrency?.id;
        if (currencyId) {
          const favouritesKey = `favourites_region_${currencyId}`;
          localStorage.setItem(
            favouritesKey,
            JSON.stringify(state.favouriteItems)
          );
        }
        // console.log('Updated localStorage after remove');
      } catch (error) {
        console.error('Error saving to localStorage:', error);
      }
    },
    async loadFavourites({ commit, rootGetters }) {
      try {
        // Получаем текущую валюту пользователя
        const currentCurrency = rootGetters['user/currentCurrency'];
        const currencyId = currentCurrency?.id;

        if (!currencyId) {
          console.log('Currency not set, waiting for initialization');
          commit('SET_FAVOURITES', []);
          return;
        }

        // Формируем ключ для localStorage с учетом региона (валюты)
        const favouritesKey = `favourites_region_${currencyId}`;

        const savedFavourites = localStorage.getItem(favouritesKey);
        // console.log('Loading from localStorage:', savedFavourites);
        if (savedFavourites) {
          const items = JSON.parse(savedFavourites);

          // Валидируем избранное - проверяем, существуют ли издания в базе данных
          const { validateEdition, refreshCartItems } = await import('@/services/apiService');

          // Проверяем все товары параллельно для ускорения
          const validationPromises = items.map(async (item) => {
            // В избранном хранится editionId
            const editionId = item.editionId;
            if (!editionId) {
              return { item, isValid: true }; // Если нет editionId, пропускаем проверку
            }
            const isValid = await validateEdition(editionId);
            return { item, isValid };
          });

          const validationResults = await Promise.all(validationPromises);

          // Фильтруем только валидные товары
          const validatedItems = validationResults
            .filter(result => {
              if (!result.isValid) {
                console.log('Item removed from favourites (edition not found in database):', result.item.title);
              }
              return result.isValid;
            })
            .map(result => result.item);

          const hasRemovedItems = validatedItems.length < items.length;

          // Обновляем актуальные данные из БД (цены, скидки)
          let refreshedItems = validatedItems;
          if (validatedItems.length > 0) {
            try {
              const editionIds = validatedItems.map(item => item.editionId).filter(Boolean);
              if (editionIds.length > 0) {
                const refreshResult = await refreshCartItems(editionIds, currencyId);

                if (refreshResult.success && refreshResult.items) {
                  // Создаем Map для быстрого поиска обновленных данных
                  const refreshedMap = new Map(refreshResult.items.map(item => [item.id, item]));

                  // Объединяем старые данные с обновленными
                  refreshedItems = validatedItems.map(oldItem => {
                    const newData = refreshedMap.get(oldItem.editionId);
                    if (newData) {
                      // Обновляем данные, сохраняя структуру избранного
                      return {
                        ...oldItem,
                        image: newData.image || oldItem.image,
                        title: newData.title || oldItem.title,
                        rating: newData.rating || oldItem.rating,
                        genres: newData.genres || oldItem.genres,
                        platforms: newData.platforms || oldItem.platforms,
                        editionName: newData.editionName || oldItem.editionName,
                        price: newData.price,
                        discount_amount: newData.discount_amount,
                        edition: {
                          ...oldItem.edition,
                          price: newData.price,
                          convertedPrice: newData.price,
                          discount_amount: newData.discount_amount,
                          ps_plus_price: newData.ps_plus_price,
                          ea_play_price: newData.ea_play_price,
                          promotion_end_date: newData.promotion_end_date,
                        },
                      };
                    }
                    return oldItem;
                  });

                  console.log(`Refreshed prices for ${refreshedItems.length} favourite items`);
                }
              }
            } catch (error) {
              console.error('Error refreshing favourites prices:', error);
              // Если обновление не удалось, используем валидированные данные как есть
            }
          }

          // Если были удалены товары или обновлены цены, обновляем localStorage
          if (hasRemovedItems || refreshedItems !== validatedItems) {
            localStorage.setItem(favouritesKey, JSON.stringify(refreshedItems));
            if (hasRemovedItems) {
              console.log(`Removed ${items.length - validatedItems.length} invalid items from favourites`);
            }
          }

          commit('SET_FAVOURITES', refreshedItems);
          commit('SET_FAVOURITES_CURRENCY_ID', currencyId);
          // console.log('Loaded favourites:', validatedItems);
        } else {
          commit('SET_FAVOURITES', []);
          commit('SET_FAVOURITES_CURRENCY_ID', currencyId);
        }
      } catch (error) {
        console.error('Error loading from localStorage:', error);
        commit('SET_FAVOURITES', []);
      }
    },
  },
  getters: {
    isFavourite: state => (title, editionId) => {
      const result = state.favouriteItems.some(
        item => item.title === title && item.editionId === editionId
      );
      // console.log(
      //   'Checking if favourite:',
      //   title,
      //   editionId,
      //   'Result:',
      //   result
      // );
      return result;
    },
    getFavouriteItems: (state, getters, rootState, rootGetters) => {
      // Получаем только те товары, которые соответствуют текущей валюте
      const currentCurrency = rootGetters['user/currentCurrency'];
      if (
        !currentCurrency ||
        !state.currencyId ||
        currentCurrency.id === state.currencyId
      ) {
        // console.log('Getting all favourites:', state.favouriteItems);
        return state.favouriteItems;
      }
      // Если валюта пользователя не совпадает с валютой избранного, возвращаем пустой массив
      return [];
    },
    favouritesCurrencyId: state => state.currencyId,
    hasFavouritesCurrencyMismatch: (state, getters, rootState, rootGetters) => {
      // Если избранное пусто или нет ID валюты избранного, нет несоответствия
      if (state.favouriteItems.length === 0 || !state.currencyId) {
        return false;
      }
      const currentCurrency = rootGetters['user/currentCurrency'];
      return (
        currentCurrency &&
        state.currencyId &&
        currentCurrency.id !== state.currencyId
      );
    },
  },
};
