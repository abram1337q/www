const state = {
	telegramId: null,
	telegramUsername: null,
	isAuthenticated: false,
	initData: null,
};

const mutations = {
	SET_TELEGRAM_ID(state, id) {
		state.telegramId = id;
		state.isAuthenticated = !!id;
	},
	SET_TELEGRAM_USERNAME(state, username) {
		state.telegramUsername = username;
	},
	SET_INIT_DATA(state, data) {
		state.initData = data;
	},
};

const actions = {
	initAuth({ commit }) {
		if (window.Telegram && window.Telegram.WebApp) {
			const webAppData = window.Telegram.WebApp.initDataUnsafe;
			if (webAppData && webAppData.user) {
				const telegramId = webAppData.user.id.toString();
				const username = webAppData.user.username || '';

				commit('SET_TELEGRAM_ID', telegramId);
				commit('SET_TELEGRAM_USERNAME', username);
				commit('SET_INIT_DATA', webAppData);

				localStorage.setItem('telegramId', telegramId);
				localStorage.setItem('telegramUsername', username);
			}
		} else {
			// Для разработки или тестирования можно использовать сохраненный telegramId
			const savedTelegramId = localStorage.getItem('telegramId');
			const savedUsername = localStorage.getItem('telegramUsername');
			if (savedTelegramId) {
				commit('SET_TELEGRAM_ID', savedTelegramId);
				commit('SET_TELEGRAM_USERNAME', savedUsername);
			}
		}
	},

	logout({ commit }) {
		commit('SET_TELEGRAM_ID', null);
		commit('SET_TELEGRAM_USERNAME', null);
		commit('SET_INIT_DATA', null);
		localStorage.removeItem('telegramId');
		localStorage.removeItem('telegramUsername');
	},
};

const getters = {
	isAuthenticated: state => state.isAuthenticated,
	telegramId: state => state.telegramId,
	telegramUsername: state => state.telegramUsername,
	initData: state => state.initData,
};

export default {
	namespaced: true,
	state,
	mutations,
	actions,
	getters,
};
