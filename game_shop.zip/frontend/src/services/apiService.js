import axios from 'axios';

const API_BASE_URL =
    import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';
console.log('API Base URL:', API_BASE_URL);

// Life-Pay API configuration
const LIFEPAY_CONFIG = {
    apikey: '24ce157c42c081aedd7ac217927c6810',
    login: '79289366631',
};

const apiClient = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
    withCredentials: true,
});

// Add request interceptor
apiClient.interceptors.request.use(
    config => {
        // Добавляем Telegram User ID в заголовки
        const userId = getTelegramUserId();
        if (userId) {
            config.headers['x-telegram-user-id'] = userId;
        }

        // Убедимся, что путь начинается с /api
        if (!config.url.startsWith('/api')) {
            config.url = `/api${config.url}`;
        }
        console.log('Making request to:', config.url);
        return config;
    },
    error => {
        console.error('Request error:', error);
        return Promise.reject(error);
    }
);

// Add response interceptor
apiClient.interceptors.response.use(
    response => {
        console.log('Response received:', {
            url: response.config.url,
            status: response.status,
            data: response.data,
        });
        return response;
    },
    error => {
        if (error.response) {
            console.error('API Error:', {
                status: error.response.status,
                data: error.response.data,
                url: error.config.url,
            });
        } else if (error.request) {
            console.error('Network Error:', {
                request: error.request,
                url: error.config?.url,
            });
        } else {
            console.error('Error:', error.message);
        }
        return Promise.reject(error);
    }
);

// Функция получения Telegram User ID
export const getTelegramUserId = () => {
    if (window.Telegram?.WebApp?.initDataUnsafe?.user?.id) {
        return window.Telegram.WebApp.initDataUnsafe.user.id;
    }
    return null;
};

// Feed API methods
export const getFeedItems = async (params = {}) => {
    try {
        console.log('Fetching feed items with params:', params);
        const response = await apiClient.get('/feed', { params });
        const feedItems = response.data;

        // Преобразуем данные для совместимости с текущим интерфейсом
        feedItems.forEach(item => {
            console.log('Processing feed item:', item);

            // Обработка для типа 'list'
            if (item.type === 'list') {
                const collection = item.collections?.[0] || item.collection;
                if (collection) {
                    console.log('List type collection:', collection);

                    // Создаем продукты из editions
                    const products =
                        collection.editions?.map(edition => ({
                            id: edition.productCard.id,
                            name: edition.productCard.name,
                            image_url: edition.productCard.image_url,
                            edition: edition,
                            edition_type: edition.productCard.edition_type,
                            ProductCollectionEdition: edition.ProductCollectionEdition, // Копируем позицию
                        })) || [];

                    item.collection = {
                        ...collection,
                        products: products,
                    };
                    console.log(
                        'Processed collection with products:',
                        item.collection
                    );
                }
                delete item.collections;
            }
            // Обработка для типа 'banner'
            else if (item.type === 'banner' && item.collections) {
                item.collections = item.collections.map(collection => ({
                    ...collection,
                    image_url: collection.banner_image || collection.image_url,
                    products:
                        collection.editions?.map(edition => ({
                            ...edition.productCard,
                            edition: {
                                ...edition,
                                editionName: edition.editionName,
                            },
                            ProductCollectionEdition: edition.ProductCollectionEdition, // Копируем позицию
                        })) || [],
                }));
            }
        });

        return feedItems;
    } catch (error) {
        console.error('Error fetching feed items:', error);
        throw error;
    }
};

// Game API methods
export const getGameById = async (id, currency_id) => {
    try {
        console.log('Fetching game by id:', id, 'currency_id:', currency_id);
        const response = await apiClient.get(`/products/${id}`, {
            params: { currency_id },
        });
        const game = response.data.data;

        // Преобразуем данные для фронтенда
        return {
            ...game,
            description:
                game.editions?.[0]?.description || 'Описание отсутствует',
            editions: game.editions?.map(edition => ({
                ...edition,
                description: edition.description || 'Описание отсутствует',
            })),
        };
    } catch (error) {
        console.error('Error fetching game:', error);
        throw error;
    }
};

export const searchGames = async params => {
    try {
        console.log('Searching games with params:', params);
        const response = await apiClient.get('/products/search', {
            params,
            timeout: 30000,
        });
        console.log('Search response:', response.data);
        return response.data;
    } catch (error) {
        console.error('Error searching games:', error);
        if (error.code === 'ECONNABORTED') {
            return [];
        }
        if (error.response?.status === 404) {
            return [];
        }
        throw error;
    }
};

export const getEaPlayGames = async (params = {}) => {
    try {
        const response = await apiClient.get('/products/subscription/ea-play', {
            params,
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching EA Play games:', error);
        throw error;
    }
};

export const getPsPlusEssentialGames = async (params = {}) => {
    try {
        const response = await apiClient.get(
            '/products/subscription/ps-plus-essential',
            { params }
        );
        return response.data;
    } catch (error) {
        console.error('Error fetching PS Plus Essential games:', error);
        throw error;
    }
};

export const getPsPlusExtraGames = async (params = {}) => {
    try {
        const response = await apiClient.get(
            '/products/subscription/ps-plus-extra',
            { params }
        );
        return response.data;
    } catch (error) {
        console.error('Error fetching PS Plus Extra games:', error);
        throw error;
    }
};

export const getPsPlusDeluxeGames = async (params = {}) => {
    try {
        const response = await apiClient.get(
            '/products/subscription/ps-plus-deluxe',
            { params }
        );
        return response.data;
    } catch (error) {
        console.error('Error fetching PS Plus Deluxe games:', error);
        throw error;
    }
};

// Collection API methods
export const getCollection = async (id, params = {}) => {
    try {
        console.log('Fetching collection:', id, params);
        const response = await apiClient.get(`/collections/${id}`, { params });
        const collection = response.data;

        // Преобразуем данные для совместимости с текущим интерфейсом
        if (collection.editions) {
            collection.products = collection.editions.map(edition => ({
                ...edition.productCard,
                edition: {
                    ...edition,
                    editionName: edition.editionName,
                    convertedPrice: edition.convertedPrice,
                    displayCurrency: edition.displayCurrency,
                    discount_amount: edition.discount_amount,
                },
            }));
        }

        return collection;
    } catch (error) {
        console.error('Error fetching collection:', error);
        throw error;
    }
};

// Life-Pay API methods
export const createLifePayBill = async paymentData => {
    try {
        const response = await apiClient.post(
            '/payment/create-bill',
            paymentData
        );

        if (!response.data.success) {
            throw new Error(
                response.data.message || 'Failed to create payment'
            );
        }

        return {
            orderId: response.data.orderId,
            paymentUrl: response.data.paymentUrl,
        };
    } catch (error) {
        console.error('Error creating Life-Pay bill:', error);
        throw new Error(error.response?.data?.message || error.message);
    }
};

export const verifyPayment = async orderId => {
    try {
        const response = await apiClient.post('/payment/verify', { orderId });

        if (!response.data.success) {
            throw new Error(
                response.data.message || 'Failed to verify payment'
            );
        }

        return {
            status: response.data.status,
            orderId: response.data.orderId,
        };
    } catch (error) {
        console.error('Error verifying payment:', error);
        throw new Error(error.response?.data?.message || error.message);
    }
};

export const checkLifePayStatus = async number => {
    try {
        const response = await apiClient.get(`/payment/check-status/${number}`);
        return response.data;
    } catch (error) {
        console.error(
            'Life-Pay Status Check Error:',
            error.response?.data || error.message
        );
        throw error;
    }
};

export const checkPromo = async promoCode => {
    try {
        const response = await apiClient.get(`/promos/${promoCode}`);
        return response.data;
    } catch (error) {
        if (error.response?.status === 400) {
            throw new Error('Вы уже использовали этот промокод');
        } else if (error.response?.status === 404) {
            throw new Error('Промокод не найден или неактивен');
        } else if (error.response?.status === 401) {
            throw new Error('Необходима авторизация');
        }
        console.error('Error checking promo:', error);
        throw new Error('Ошибка при проверке промокода');
    }
};

export const getCurrencies = async () => {
    try {
        const response = await apiClient.get('/currencies');
        return response.data;
    } catch (error) {
        console.error('Ошибка получения валют:', error);
        throw error;
    }
};

export const getDefaultCurrency = async () => {
    try {
        const response = await apiClient.get('/currencies/default');
        return response.data;
    } catch (error) {
        console.error('Ошибка получения валюты по умолчанию:', error);
        throw error;
    }
};

// Genre API methods
export const getGenres = async () => {
    try {
        const response = await apiClient.get('/genres');
        return response.data;
    } catch (error) {
        console.error('Error fetching genres:', error);
        throw error;
    }
};

// User API methods
export const updateUserField = async (telegramId, field, value) => {
    try {
        console.log('Updating user field:', { telegramId, field, value });
        const response = await apiClient.put(`/users/${telegramId}`, {
            [field]: value,
        });
        return response.data;
    } catch (error) {
        console.error('Error updating user field:', error);
        throw error;
    }
};

export const getUser = async telegramId => {
    try {
        console.log('Getting user:', telegramId);
        const response = await apiClient.get(`/users/${telegramId}`);
        return response.data;
    } catch (error) {
        console.error('Error getting user:', error);
        throw error;
    }
};

export const getUserRegionData = async (telegramId, currencyId) => {
    try {
        console.log('Getting user region data:', { telegramId, currencyId });
        const response = await apiClient.get(`/users/${telegramId}/region/${currencyId}`);
        return response.data;
    } catch (error) {
        console.error('Error getting user region data:', error);
        throw error;
    }
};

export const updateUserRegionData = async (telegramId, currencyId, data) => {
    try {
        console.log('Updating user region data:', { telegramId, currencyId, data });
        const response = await apiClient.put(`/users/${telegramId}/region/${currencyId}`, data);
        return response.data;
    } catch (error) {
        console.error('Error updating user region data:', error);
        throw error;
    }
};

// Cart API methods
// Refresh cart/favorites items with actual prices and discounts
export const refreshCartItems = async (editionIds, currencyId) => {
    try {
        const response = await apiClient.post('/products/refresh-cart-items', {
            editionIds,
            currencyId,
        });
        return response.data;
    } catch (error) {
        console.error('Error refreshing cart items:', error);
        throw error;
    }
};

export const calculateCartTotal = async (
    editionIds,
    selectedCurrencyId,
    currentTotal,
    priceTypes = {}, // Добавляем новый параметр для типов цен
    promoCode = null // Добавляем параметр для промокода
) => {
    try {
        console.log('Calculating cart total:', {
            editionIds,
            selectedCurrencyId,
            currentTotal,
            priceTypes,
            promoCode,
        });
        const response = await apiClient.post(
            '/products/calculate-cart-total',
            {
                editionIds,
                selectedCurrencyId,
                currentTotal,
                priceTypes, // Передаем типы цен на бэкенд
                promoCode, // Передаем промокод на бэкенд
            }
        );
        console.log('Cart total response:', response.data);
        return response.data;
    } catch (error) {
        console.error('Error calculating cart total:', error);
        throw error;
    }
};

// Проверка существования товара в базе данных
export const validateCartItem = async (productId, currencyId) => {
    try {
        const response = await apiClient.get(`/products/${productId}`, {
            params: { currency_id: currencyId },
        });
        return response.data.data ? true : false;
    } catch (error) {
        // Если товар не найден (404), возвращаем false
        if (error.response?.status === 404) {
            return false;
        }
        console.error('Error validating cart item:', error);
        return false;
    }
};

// Проверка существования издания в базе данных
export const validateEdition = async (editionId) => {
    try {
        const response = await apiClient.get(`/editions/${editionId}`);
        return response.data ? true : false;
    } catch (error) {
        // Если издание не найдено (404), возвращаем false
        if (error.response?.status === 404) {
            return false;
        }
        console.error('Error validating edition:', error);
        return false;
    }
};

export default apiClient;
