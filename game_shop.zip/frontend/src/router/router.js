import { createRouter, createWebHistory } from 'vue-router';
import CollectionScreen from '../components/screens/CollectionScreen.vue';
import CreatePSAccountScreen from '../components/screens/CreatePSAccountScreen.vue';
import EaPlayCollectionScreen from '../components/screens/EaPlayCollectionScreen.vue';
import FailurePayment from '../components/screens/FailurePayment.vue';
import FavouritesScreen from '../components/screens/FavouritesScreen.vue';
import HomeScreen from '../components/screens/HomeScreen.vue';
import ItemCardScreen from '../components/screens/ItemCardScreen.vue';
import PaymentScreen from '../components/screens/PaymentScreen.vue';
import ProfileScreen from '../components/screens/ProfileScreen.vue';
import PsPlusDeluxeCollectionScreen from '../components/screens/PsPlusDeluxeCollectionScreen.vue';
import PsPlusEssentialCollectionScreen from '../components/screens/PsPlusEssentialCollectionScreen.vue';
import PsPlusExtraCollectionScreen from '../components/screens/PsPlusExtraCollectionScreen.vue';
import SearchResultsScreen from '../components/screens/SearchResultsScreen.vue';
import ShopBagScreen from '../components/screens/ShopBagScreen.vue';
import SuccessPayment from '../components/screens/SuccessPayment.vue';
import SupportScreen from '../components/screens/SupportScreen.vue';

const routes = [
	{
		path: '/',
		name: 'Home',
		component: HomeScreen,
		meta: { depth: 0 },
	},
	{
		path: '/profile',
		name: 'Profile',
		component: ProfileScreen,
		meta: { depth: 1 },
	},
	{
		path: '/favourites',
		name: 'Favourites',
		component: FavouritesScreen,
		meta: { depth: 1 },
	},
	{
		path: '/create-ps-account',
		name: 'CreatePSAccount',
		component: CreatePSAccountScreen,
		meta: { depth: 2 },
	},
	{
		path: '/shop-bag',
		name: 'ShopBag',
		component: ShopBagScreen,
		meta: { depth: 1 },
	},
	{
		path: '/search-results',
		name: 'SearchResults',
		component: SearchResultsScreen,
		meta: { depth: 1 },
	},
	{
		path: '/payment',
		name: 'Payment',
		component: PaymentScreen,
		meta: { depth: 2 },
	},
	{
		path: '/support',
		name: 'Support',
		component: SupportScreen,
		meta: { depth: 1 },
	},
	{
		path: '/collection/:id',
		name: 'Collection',
		component: CollectionScreen,
		meta: { depth: 2 },
	},
	{
		path: '/item/:id',
		name: 'ItemCard',
		component: ItemCardScreen,
		meta: { depth: 2 },
		props: true,
	},
	{
		path: '/success-payment',
		name: 'SuccessPayment',
		component: SuccessPayment,
		meta: { depth: 3 },
	},
	{
		path: '/failure-payment',
		name: 'FailurePayment',
		component: FailurePayment,
		meta: { depth: 3 },
	},
	{
		path: '/ea-play-collection',
		name: 'ea-play-collection',
		component: EaPlayCollectionScreen,
		meta: { depth: 3 },
	},
	{
		path: '/ps-plus-extra-collection',
		name: 'ps-plus-extra-collection',
		component: PsPlusExtraCollectionScreen,
		meta: { depth: 3 },
	},
	{
		path: '/ps-plus-essential-collection',
		name: 'ps-plus-essential-collection',
		component: PsPlusEssentialCollectionScreen,
		meta: { depth: 3 },
	},
	{
		path: '/ps-plus-deluxe-collection',
		name: 'ps-plus-deluxe-collection',
		component: PsPlusDeluxeCollectionScreen,
		meta: { depth: 3 },
	},
];

const router = createRouter({
	history: createWebHistory(),
	routes,
});

// Стек навигации для отслеживания истории в приложении
let navigationStack = ['/'];
let backButtonInitialized = false;

function initTelegramBackButton() {
	if (window.Telegram && window.Telegram.WebApp && !backButtonInitialized) {
		const tgApp = window.Telegram.WebApp;

		// Устанавливаем обработчик кнопки Back только один раз
		tgApp.BackButton.onClick(() => {
			console.log('Back button clicked, navigation stack:', navigationStack);

			// Убираем текущую страницу из стека
			if (navigationStack.length > 1) {
				navigationStack.pop();
				const previousRoute = navigationStack[navigationStack.length - 1];
				console.log('Navigating back to:', previousRoute);
				router.push(previousRoute);
			} else {
				// Если в стеке только главная страница или стек пуст
				console.log('No previous route, going to home');
				navigationStack = ['/'];
				router.push('/');
			}
		});

		backButtonInitialized = true;
		console.log('Telegram Back Button initialized');
	}
}

router.beforeEach((to, from, next) => {
	// Инициализируем кнопку Back только один раз
	if (!backButtonInitialized) {
		initTelegramBackButton();
	}

	// Отслеживаем навигацию в стеке
	// Если переходим не через кнопку Back (обычная навигация)
	if (from.path && from.path !== to.path) {
		// Проверяем, не возвращаемся ли мы назад через браузерную навигацию
		const lastInStack = navigationStack[navigationStack.length - 1];
		const secondLastInStack = navigationStack[navigationStack.length - 2];

		if (to.path === secondLastInStack && from.path === lastInStack) {
			// Это навигация назад, убираем последний элемент
			navigationStack.pop();
		} else if (to.path !== lastInStack) {
			// Это обычная навигация вперед, добавляем в стек
			navigationStack.push(to.path);
		}
	} else if (navigationStack.length === 0 || navigationStack[0] !== '/') {
		// Инициализируем стек если он пуст
		navigationStack = ['/'];
		if (to.path !== '/') {
			navigationStack.push(to.path);
		}
	}

	// Управляем видимостью кнопки Back
	if (window.Telegram && window.Telegram.WebApp) {
		if (to.path !== '/') {
			window.Telegram.WebApp.BackButton.show();
		} else {
			window.Telegram.WebApp.BackButton.hide();
		}

		console.log(`Navigating to: ${to.path}`);
		console.log(`Navigation stack:`, navigationStack);
		console.log(`BackButton visibility: ${to.path !== '/'}`);
	}
	next();
});

router.afterEach((to, from) => {
	if (window.Telegram && window.Telegram.WebApp) {
		window.Telegram.WebApp.expand();
	}
});

export default router;
