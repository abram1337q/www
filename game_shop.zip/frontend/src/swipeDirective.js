// swipeDirective.js
export const swipe = {
	mounted(el, binding) {
		let touchstartX = 0;
		let touchendX = 0;

		const handleGesture = () => {
			if (touchendX < touchstartX) {
				// Свайп влево - игнорируем
			}
			if (touchendX > touchstartX) {
				// Свайп вправо - возврат назад
				if (typeof binding.value === 'function') {
					binding.value();
				}
			}
		};

		el.addEventListener(
			'touchstart',
			e => {
				touchstartX = e.changedTouches[0].screenX;
			},
			{ passive: true }
		);

		el.addEventListener(
			'touchend',
			e => {
				touchendX = e.changedTouches[0].screenX;
				handleGesture();
			},
			{ passive: true }
		);
	},
};
