<!-- EaPlayButton.vue -->
<template>
	<button
		:class="['ea-play-button', { 'ps-plus': isPsPlus }]"
		@click="$emit('click')"
	>
		<span class="button-text">{{ text }}</span>
		<img
			:src="
				isPsPlus
					? '/assets/img/psplussub.png'
					: '/assets/img/eaplaysub-white.png'
			"
			:alt="isPsPlus ? 'PS Plus' : 'EA Play'"
			class="subscription-logo"
		/>
	</button>
</template>

<script setup>
const props = defineProps({
	text: {
		type: String,
		default: 'Бесплатно с EA Play или PS Plus',
	},
	isPsPlus: {
		type: Boolean,
		default: false,
	},
});

defineEmits(['click']);
</script>

<style scoped>
.ea-play-button {
	width: 100%;
	padding: 15px;
	background-image: url('../../assets/img/eabutton.png');
	background-repeat: no-repeat;
	background-size: cover;
	color: white;
	border: none;
	border-radius: 13px;
	font-size: 15px;
	font-weight: bold;
	cursor: pointer;
	position: relative;
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 10px;
}

.subscription-logo {
	height: 40px;
	width: auto;
	object-fit: contain;
}

.button-text {
	text-align: left;
}

.ps-plus::before {
	content: '';
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background-color: rgba(255, 217, 0, 0.3);
	border-radius: 13px;
	pointer-events: none;
}
</style>
