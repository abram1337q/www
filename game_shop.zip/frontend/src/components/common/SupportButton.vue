<template>
    <div class="support-container">
        <p class="support-text">Не нашли нужный товар или возникли вопросы?</p>
        <button
            class="support-button"
            @click="handleClick"
        >
            Напишите нам
        </button>
    </div>
</template>

<script>
export default {
    name: 'SupportButton',
    computed: {
        supportLink() {
            return 'https://t.me/psworld_store';
        }
    },
    methods: {
        handleClick() {
            console.log('Support button clicked, opening:', this.supportLink);
            // Используем Telegram WebApp API для корректного открытия ссылки
            if (window.Telegram && window.Telegram.WebApp) {
                window.Telegram.WebApp.openTelegramLink(this.supportLink);
            } else {
                // Фоллбэк для браузера (на случай тестирования вне Telegram)
                window.open(this.supportLink, '_blank');
            }
        }
    }
};
</script>

<style scoped>
.support-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    padding: 24px 16px;
    margin-top: auto;
    padding-top: 48px;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 16px;
    border: 1px solid #dee2e6;
}

.support-text {
    margin: 0;
    font-size: 15px;
    font-weight: 500;
    color: #495057;
    text-align: center;
    line-height: 1.5;
}

.support-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 12px 28px;
    background: linear-gradient(135deg, #007aff 0%, #0056b3 100%);
    color: white;
    border: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 600;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(0, 122, 255, 0.25);
    min-width: 160px;
}

.support-button:hover {
    background: linear-gradient(135deg, #0056b3 0%, #004085 100%);
    box-shadow: 0 6px 16px rgba(0, 122, 255, 0.35);
    transform: translateY(-2px);
}

.support-button:active {
    transform: translateY(0);
    box-shadow: 0 2px 8px rgba(0, 122, 255, 0.25);
}

/* Мобильная адаптация */
@media (max-width: 350px) {
    .support-container {
        padding: 20px 12px;
        margin-top: 24px;
    }

    .support-text {
        font-size: 14px;
    }

    .support-button {
        padding: 10px 24px;
        font-size: 15px;
        min-width: 140px;
    }
}
</style>
