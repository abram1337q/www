<template>
  <button
    class="favorite-button"
    :class="{ active: isActive }"
    @click="toggleFavorite"
  >
    <img src="@/assets/img/favorits.svg" alt="Избранное" />
  </button>
</template>

<script setup>
import { computed, watch } from 'vue';
import { useStore } from 'vuex';

const props = defineProps({
  modelValue: {
    type: Boolean,
    required: true,
  },
  game: {
    type: Object,
    required: true,
  },
});

const emit = defineEmits(['update:modelValue']);
const store = useStore();

const isActive = computed(() => {
  const editionId = props.game.edition?.id;
  return store.getters['favourites/isFavourite'](props.game.title, editionId);
});

watch(
  () => props.modelValue,
  newValue => {
    console.log('FavoriteButton modelValue changed:', newValue);
  }
);

const toggleFavorite = async event => {
  // Stop event from bubbling up to parent elements
  event.preventDefault();
  event.stopPropagation();

  try {
    const editionId = props.game.edition?.id;
    const newValue = !isActive.value;

    if (newValue) {
      // Создаем объект с корректными данными о цене
      const gameWithCorrectPrice = {
        ...props.game,
        id: props.game.id, // ID игры (ProductCard)
        productId: props.game.productId || props.game.id, // Явно указываем productId
        // Обеспечиваем, что цена сохраняется корректно
        price:
          props.game.edition?.convertedPrice ||
          props.game.edition?.price ||
          props.game.price ||
          0,
        discount_amount:
          props.game.edition?.discount_amount ||
          props.game.discount_amount ||
          0,
        edition: props.game.edition
          ? {
              ...props.game.edition,
              // Гарантируем, что цена есть в объекте edition
              price:
                props.game.edition.convertedPrice ||
                props.game.edition.price ||
                0,
              convertedPrice:
                props.game.edition.convertedPrice ||
                props.game.edition.price ||
                0,
              discount_amount:
                props.game.edition.discount_amount || 0,
            }
          : null,
      };
      await store.dispatch(
        'favourites/addToFavourites',
        gameWithCorrectPrice
      );
    } else {
      await store.dispatch('favourites/removeFromFavourites', {
        title: props.game.title,
        editionId: editionId,
      });
    }
    emit('update:modelValue', newValue);
    console.log('Toggled favorite:', newValue);
  } catch (error) {
    console.error('Error toggling favorite:', error);
  }
};
</script>

<style scoped>
.favorite-button {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  background-color: #f2f2f2;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
}

.favorite-button img {
  width: 16px;
  height: 16px;
  transition: all 0.2s ease;
}

.favorite-button:hover {
  background-color: #e5e5e5;
  transform: scale(1.05);
}

.favorite-button.active {
  background-color: #007aff;
  animation: buttonPop 0.3s ease;
}

.favorite-button.active img {
  filter: brightness(0) invert(1);
  transform: scale(1.1);
}

@keyframes buttonPop {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.15);
  }
  100% {
    transform: scale(1);
  }
}
</style>
