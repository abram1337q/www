<template>
    <div class="product-item">
        <router-link
            :to="{
                path: '/item/' + product.id,
                query: product.edition?.id ? { editionId: product.edition.id } : {}
            }"
            class="product-link"
            @click="handleCardClick"
        >
            <div class="product-image-container">
                <img
                    :src="imageUrl"
                    :alt="product.name"
                    class="product-image"
                />
            </div>
            <div class="product-info">
                <h3>{{ product.name }}</h3>
                <p class="product-type" v-if="product.edition_type">
                    {{ product.edition_type }}
                </p>
                <div
                    class="edition-container"
                    v-if="product.edition?.editionName"
                >
                    <div class="edition-row">
                        <p class="product-subtitle">
                            {{ product.edition.editionName.name }}
                        </p>
                        <div class="platforms">
                            <img
                                v-for="platform in product.edition.platforms"
                                :key="platform.id"
                                :src="getPlatformIcon(platform)"
                                :alt="platform.name"
                                class="platform-icon"
                            />
                        </div>
                    </div>
                </div>
            </div>
            <div class="product-price-actions">
                <div class="price-container">
                    <template v-if="product.edition">
                        <div
                            class="original-price-container"
                            v-if="hasActiveDiscount"
                        >
                            <span class="discount-badge">
                                -{{ calculateDiscount(product.edition) }}%
                            </span>
                            <span class="product-price-original">
                                {{
                                    formatPrice(
                                        getOriginalPrice(product.edition)
                                    )
                                }}
                            </span>
                        </div>
                        <div class="current-price">
                            {{ formatPrice(hasActiveDiscount ? getFinalPrice(product.edition) : getOriginalPrice(product.edition)) }}
                        </div>
                    </template>
                    <div v-else class="no-price">Нет в наличии</div>
                </div>
            </div>
        </router-link>
        <div class="product-actions" @click.stop>
            <button
                class="action-button"
                :class="{ active: isInFavourites }"
                @click="toggleFavourite"
                v-if="product.edition"
            >
                <img src="/assets/img/favorits.svg" alt="В избранное" />
            </button>
            <button
                class="action-button"
                :class="{ active: isInCart }"
                @click="toggleCart"
                v-if="product.edition"
            >
                <img src="/assets/img/shopbag.svg" alt="В корзину" />
            </button>
        </div>
        <div class="divider"></div>
    </div>
</template>

<script setup>
import {
    calculateDiscount,
    formatPrice,
    getFinalPrice,
    getOriginalPrice,
    isPromotionExpired,
} from '@/utils/discount';
import { computed } from 'vue';
import { useStore } from 'vuex';

const props = defineProps({
    product: {
        type: Object,
        required: true,
    },
});

const store = useStore();

const imageUrl = computed(() => {
    // ПРИОРИТЕТ: сначала image_url из edition, потом из product
    const imageSource = props.product.edition?.image_url || props.product.image_url;

    // Если image_url начинается с http, значит это полный URL
    if (
        imageSource?.startsWith('http') ||
        imageSource?.startsWith('https')
    ) {
        return imageSource;
    }

    const baseUrl = import.meta.env.VITE_API_BASE_URL;
    if (!baseUrl) {
        console.error('VITE_API_BASE_URL не определен в переменных окружения');
        return imageSource || '';
    }

    const finalImageUrl = imageSource || '';
    return `${baseUrl}/uploads/${finalImageUrl.replace(/^\//, '')}`;
});

const getPlatformIcon = platform => {
    if (!platform?.icon_url) return null;

    const iconUrl = platform.icon_url;
    // Если URL уже полный, возвращаем как есть
    if (iconUrl.startsWith('http') || iconUrl.startsWith('https')) {
        return iconUrl;
    }
    // Иначе добавляем базовый URL
    const baseUrl = import.meta.env.VITE_API_BASE_URL;
    return `${baseUrl}/uploads/${iconUrl.replace(/^\//, '')}`;
};

const platformName = computed(() => {
    if (props.product.edition?.platforms?.[0]?.name) {
        return props.product.edition.platforms[0].name;
    }
    return '';
});

const hasActiveDiscount = computed(() => {
    if (!props.product.edition?.discount_amount) return false;
    if (!props.product.edition?.promotion_end_date) return true; // Если даты нет, показываем скидку
    return !isPromotionExpired(props.product.edition.promotion_end_date);
});

const isInFavourites = computed(() => {
    // console.log(
    //     'Checking favorites for:',
    //     props.product.name,
    //     props.product.edition?.id
    // );
    const result = store.getters['favourites/isFavourite'](
        props.product.name,
        props.product.edition?.id
    );
    // console.log('Is in favorites:', result);
    return result;
});

const isInCart = computed(() => {
    // console.log('Checking cart for edition:', props.product.edition?.id);
    const result = store.getters['cart/isInCart'](
        props.product.id,
        props.product.edition?.id
    );
    // console.log('Is in cart:', result);
    return result;
});

const toggleFavourite = () => {
    if (isInFavourites.value) {
        store.dispatch('favourites/removeFromFavourites', {
            title: props.product.name,
            editionId: props.product.edition?.id,
        });
    } else {
        // Получаем прямые значения цен без вычислений
        const price =
            props.product.edition?.convertedPrice ||
            props.product.edition?.price ||
            0;
        // Создаем объект напрямую, не полагаясь на функции, которые могут приводить к нулевым значениям
        // Используем изображение из edition, если оно есть
        const editionImageUrl = props.product.edition?.image_url || props.product.image_url || '';
        const favoriteItem = {
            id: props.product.id, // ID игры (ProductCard)
            productId: props.product.id, // Явно указываем productId для корректных ссылок
            title: props.product.name,
            name: props.product.name,
            image: editionImageUrl,
            genres: props.product.genres,
            rating: props.product.rating,
            ratingCount: props.product.ratingCount,
            platforms: props.product.platforms,
            edition: {
                ...props.product.edition,
                // Явно устанавливаем цену в объект edition
                convertedPrice: price,
                price: price,
                discount_amount: props.product.edition?.discount_amount || 0,
                // Сохраняем image_url в edition
                image_url: editionImageUrl,
            },
            editionName: props.product.edition?.editionName?.name,
            edition_type: props.product.edition_type,
            // Дублируем цены на верхнем уровне
            price: price,
            discount_amount: props.product.edition?.discount_amount || 0,
        };

        store.dispatch('favourites/addToFavourites', favoriteItem);
    }
};

const toggleCart = () => {
    if (isInCart.value) {
        store.dispatch('cart/removeFromCart', props.product.edition?.id);
    } else {
        // Используем изображение из edition, если оно есть, иначе из product
        const sourceImage = props.product.edition?.image_url || props.product.image_url;
        const imageUrl = sourceImage.replace(/^\/uploads\//, '');
        const edition = props.product.edition;
        const originalPrice = getOriginalPrice(edition);
        const finalPrice = getFinalPrice(edition);

        // Получаем текущую валюту пользователя
        const currentCurrency = store.getters['user/currentCurrency'];

        const cartItem = {
            id: edition?.id,
            editionId: edition?.id,
            productId: props.product.id,
            title: props.product.name,
            name: props.product.name,
            image: imageUrl,
            type: props.product.type,
            platforms: edition.platforms || [], // Добавляем платформы из издания
            edition: edition,
            editionName: edition?.editionName?.name,
            edition_type: props.product.edition_type,
            price: originalPrice,
            discount_amount: edition.discount_amount,
            priceType: 'standard',
            // Добавляем информацию о валюте
            currencyId: currentCurrency?.id,
        };
        store.dispatch('cart/addToCart', cartItem);
    }
};

const handleCartUpdate = async newValue => {
    if (newValue && props.product.editions?.[0]) {
        const edition = props.product.editions[0];
        const cartItem = {
            id: props.product.id,
            name: props.product.name,
            image: props.product.image,
            price: edition.convertedPrice || edition.price,
            discount_amount: edition.discount_amount,
            edition_type: edition.edition_type,
            editionName: edition.editionName,
            platforms: edition.platforms || [], // Добавляем платформы из издания
        };
        await store.dispatch('cart/addToCart', cartItem);
    }
};

const getCompleteGameData = product => {
    return {
        id: product.id,
        title: product.title || product.name,
        image: product.image_url || product.image,
        type: product.edition_type || 'Игра',
        editions: product.editions || [],
        platforms: product.platforms || ['PS5'],
    };
};

const emit = defineEmits(['card-click']);

const handleCardClick = () => {
    // console.log('Card clicked, navigating to game:', props.product);
    emit('card-click');
};
</script>

<style scoped>
.product-item {
    width: 100%;
    position: relative;
    /* padding: 12px 0 12px 0; */
    margin-bottom: 0;
}

.divider {
    position: absolute;
    bottom: -5px;
    left: 1px;
    right: 1px;
    height: 1px;
    background-color: #000000;
    opacity: 0.08;
}

.product-link {
    display: flex;
    text-decoration: none;
    color: inherit;
    gap: 12px;
}

.product-image-container {
    position: relative;
    width: 75px;
    height: 75px;
    flex-shrink: 0;
}

.product-image {
    top: 0;
    left: 0;
    width: 75px;
    height: 75px;
    position: absolute;
    border-radius: 12px;
    object-fit: cover;
}

.edition-container {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.edition-row {
    display: flex;
    align-items: center;
    gap: 5px;
    width: 100%;
}

.platforms {
    display: flex;
    align-items: center;
    gap: 4px;
}

.platform-icon {
    width: 16px;
    height: 16px;
    object-fit: contain;
}

.product-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.product-info h3 {
    margin: 0 0 4px 0;
    font-size: 15px;
    font-weight: 500;
}

.product-type {
    font-size: 13px;
    color: #666;
    margin: 0;
}

.product-price-actions {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}

.price-container {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}

.price-options {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.price-option {
    display: flex;
    align-items: center;
    gap: 8px;
}

.subscription-icon {
    width: 20px;
    height: 20px;
}

.price-info {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}

.original-price-container {
    display: flex;
    align-items: center;
    gap: 5px;
    flex-direction: row;
    justify-content: flex-end;
}

.product-price-original {
    text-decoration: line-through;
    color: rgba(138, 138, 138, 1);
    font-size: 10px;
    font-weight: 500;
    line-height: 22px;
}

.product-price-discounted {
    color: #000;
    font-size: 14px;
    font-weight: bold;
    line-height: 22px;
}

.discount-badge {
    height: 15px;
    display: flex;
    padding: 0 5px;
    overflow: hidden;
    background: linear-gradient(
        180deg,
        rgba(0, 122, 255, 1) 0%,
        rgba(0, 73, 153, 1) 100%
    );
    align-items: center;
    flex-shrink: 0;
    border-radius: 5px;
    justify-content: center;
    margin-right: 5px;
    color: #ffffff !important;
    font-size: 10px;
    font-weight: normal;
}

.discount-text {
    color: #ffffff;
    font-size: 10px;
    font-weight: normal;
}

.product-actions {
    display: flex;
    gap: 8px;
    position: absolute;
    bottom: 0;
    right: 0px;
    z-index: 2;
}

.action-button {
    width: 30px;
    height: 30px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #f2f2f2;
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
}

.action-button img {
    width: 16px;
    height: 16px;
    transition: all 0.2s ease;
}

.action-button:hover {
    background-color: #e5e5e5;
    transform: scale(1.05);
}

.action-button.active {
    background-color: #007aff !important;
}

.action-button.active img {
    filter: brightness(0) invert(1);
}

.product-subtitle {
    margin: 0;
    font-size: 14px;
    color: #000;
}

.no-editions {
    color: #666;
    font-style: italic;
    font-size: 0.9em;
}

.current-price {
    color: #000;
    font-size: 14px;
    font-weight: bold;
    line-height: 22px;
}

.no-price {
    color: #666;
    font-size: 13px;
    margin: 0;
}
</style>
