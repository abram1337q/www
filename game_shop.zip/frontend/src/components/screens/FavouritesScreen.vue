<template>
    <div class="favourites-screen">
        <section class="favourites-section">
            <div class="section-header">
                <h2 class="section-title">Избранное</h2>
            </div>
            <div class="favourites-content" v-if="!displayedItems.length">
                <img
                    src="/assets/img/file.png"
                    alt="Нет избранных"
                    class="empty-favourites-icon"
                />
                <p class="empty-favourites-text">
                    Пока нет избранных товаров
                </p>
                <router-link to="/" class="continue-shopping-btn"
                    >Перейти в каталог</router-link
                >
            </div>
            <div v-else>
                <TransitionGroup name="list" tag="ul" class="product-list">
                    <li
                        v-for="product in displayedItems"
                        :key="product.title"
                        class="product-item"
                    >
                        <div class="product-link">
                            <div class="product-image-container">
                                <router-link :to="{ path: '/item/' + (product.productId || product.id), query: product.editionId ? { editionId: product.editionId } : {} }">
                                    <img
                                        :src="getImageUrl(product)"
                                        :alt="product.title"
                                        class="product-image"
                                    />
                                </router-link>
                            </div>
                            <div class="product-info">
                                <h3>{{ product.title }}</h3>

                                <p
                                    class="product-type"
                                    v-if="product.edition_type"
                                >
                                    {{ product.edition_type }}
                                </p>
                                <p
                                    class="product-edition"
                                    v-if="product.editionName"
                                >
                                    <span class="edition-row">
                                        {{ product.editionName }}
                                        <div class="platforms">
                                            <img
                                                v-for="platform in product.platforms"
                                                :key="platform.id"
                                                :src="getPlatformIcon(platform)"
                                                :alt="platform.name"
                                                class="platform-icon"
                                            />
                                        </div>
                                    </span>
                                </p>

                                <div class="product-info-row">
                                    <!-- <p
                                        class="product-type"
                                        v-if="product.edition_type"
                                    >
                                        {{ product.edition_type }}
                                    </p>
                                    <p
                                        class="product-edition"
                                        v-if="product.editionName"
                                    >
                                        {{ product.editionName }}
                                    </p> -->
                                </div>
                            </div>
                            <div class="product-price-actions">
                                <div class="price-container">
                                    <div class="price-option">
                                        <div class="price-info">
                                            <template v-if="product.edition">
                                                <div
                                                    v-if="hasActiveDiscount(product)"
                                                    class="original-price-container"
                                                >
                                                    <span
                                                        class="discount-badge"
                                                    >
                                                        <span
                                                            class="discount-text"
                                                        >
                                                            -{{
                                                                calculateDiscount(
                                                                    product.edition
                                                                )
                                                            }}%
                                                        </span>
                                                    </span>
                                                    <span
                                                        class="product-price-original"
                                                    >
                                                        {{
                                                            formatPrice(
                                                                getOriginalPrice(
                                                                    product.edition
                                                                )
                                                            )
                                                        }}
                                                    </span>
                                                </div>
                                                <span
                                                    class="product-price-discounted"
                                                >
                                                    {{
                                                        formatPrice(
                                                            hasActiveDiscount(product) ? getFinalPrice(product.edition) : getOriginalPrice(product.edition)
                                                        )
                                                    }}
                                                </span>
                                            </template>
                                            <span v-else class="no-editions"
                                                >Нет в наличии</span
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="product-actions">
                                    <button
                                        class="action-button"
                                        :class="{
                                            active: isInCart(
                                                product.edition?.id
                                            ),
                                        }"
                                        @click.prevent="
                                            handleCartAction(product)
                                        "
                                    >
                                        <img
                                            src="/assets/img/shopbag.svg"
                                            alt="В корзину"
                                        />
                                    </button>
                                    <button
                                        class="action-button"
                                        @click="handleRemove(product)"
                                    >
                                        <img
                                            src="/assets/img/bin.svg"
                                            alt="Удалить"
                                        />
                                    </button>
                                </div>
                            </div>
                        </div>
                    </li>
                </TransitionGroup>
            </div>
        </section>

        <Transition name="modal">
            <div v-if="showConfirmModal" class="modal-overlay">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="modal-icon">
                            <img
                                :src="getImageUrl(productToRemove)"
                                alt="Game icon"
                                class="game-icon"
                            />
                        </div>
                        <div class="modal-text">
                            <h3>Убрать из избранного?</h3>
                            <p>{{ productToRemove?.title }}</p>
                        </div>
                        <div class="modal-actions">
                            <button
                                @click="confirmRemove"
                                class="modal-btn confirm-btn"
                            >
                                Да
                            </button>
                            <button
                                @click="cancelRemove"
                                class="modal-btn cancel-btn"
                            >
                                Нет
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </Transition>
    </div>
</template>

<script setup>
import {
    calculateDiscount,
    formatPrice,
    getFinalPrice,
    getOriginalPrice,
    isPromotionExpired,
} from '@/utils/discount';
import { computed, onMounted, ref, watch } from 'vue';
import { useStore } from 'vuex';

const store = useStore();
const showConfirmModal = ref(false);
const productToRemove = ref(null);
const apiBaseUrl = import.meta.env.VITE_API_BASE_URL;

onMounted(() => {
    store.dispatch('favourites/loadFavourites');
});

// Получаем текущую валюту пользователя
const currentCurrency = computed(() => {
    return store.getters['user/currentCurrency'];
});

// Все товары из избранного без фильтрации
const favouriteItems = computed(() => {
    const items = store.getters['favourites/getFavouriteItems'];
    console.log('Raw favourite items from store:', items);

    const mappedItems = items.map(item => {
        // Отладка цен в каждом элементе
        console.log('Processing favorite item:', item.title);
        console.log('- Item price:', item.price);
        console.log('- Item edition price:', item.edition?.price);
        console.log(
            '- Item edition convertedPrice:',
            item.edition?.convertedPrice
        );
        console.log(
            '- Item edition discount_amount:',
            item.edition?.discount_amount
        );

        // Оригинальная цена (без скидки)
        const originalPrice =
            item.price ||
            item.edition?.price ||
            item.edition?.convertedPrice ||
            0;

        // discount_amount должен быть скидочной ценой, которая меньше оригинальной
        const discountedPrice =
            item.edition?.discount_amount || item.discount_amount || 0;

        console.log('- Original price:', originalPrice);
        console.log('- Discounted price:', discountedPrice);

        // Проверяем, что скидочная цена действительно меньше оригинальной
        const validDiscountedPrice =
            discountedPrice > 0 && discountedPrice < originalPrice
                ? discountedPrice
                : null;

        console.log('- Valid discounted price:', validDiscountedPrice);

        return {
            ...item,
            // Сохраняем оригинальную структуру, но гарантируем, что price заполнен
            price: originalPrice,
            // Если edition существует, обновляем значения и там
            edition: item.edition
                ? {
                        ...item.edition,
                        price: originalPrice,
                        convertedPrice: originalPrice,
                        discount_amount: validDiscountedPrice,
                  }
                : null,
        };
    });

    console.log('Mapped favourite items with prices:', mappedItems);
    return mappedItems;
});

// Отфильтрованные товары по валюте (всегда активно)
const filteredItems = computed(() => {
    const currentCurrencyId = currentCurrency.value?.id;
    if (!currentCurrencyId) {
        return favouriteItems.value;
    }

    return favouriteItems.value.filter(item => {
        // Проверяем, есть ли у товара валюта и совпадает ли она с текущей
        const itemCurrencyId = item.edition?.currency?.id;
        if (!itemCurrencyId) return true; // Если у товара нет валюты, включаем его
        return itemCurrencyId === currentCurrencyId;
    });
});

// Итоговый список для отображения
const displayedItems = computed(() => {
    return filteredItems.value;
});

const isInCart = id => {
    return store.getters['cart/isInCart'](id);
};

const hasActiveDiscount = product => {
    if (!product?.edition?.discount_amount) return false;
    if (product.edition.discount_amount <= 0) return false;
    if (product.edition.discount_amount >= getOriginalPrice(product.edition)) return false;
    // Проверяем, не истекла ли акция
    if (product.edition?.promotion_end_date && isPromotionExpired(product.edition.promotion_end_date)) {
        return false;
    }
    return true;
};

const handleCartAction = product => {
    const edition = product.edition;
    const id = edition?.id;

    if (isInCart(id)) {
        store.dispatch('cart/removeFromCart', id);
    } else {
        // Используем изображение из edition, если оно есть, иначе из product
        const sourceImage = edition?.image_url || product.image;
        const imageUrl = sourceImage.replace(/^.*\/uploads\//, '').replace(/^\//, '');
        const originalPrice = getOriginalPrice(edition);
        const discountedPrice = getFinalPrice(edition);

        // Получаем текущую валюту пользователя
        const currentCurrency = store.getters['user/currentCurrency'];

        const cartItem = {
            id: id,
            editionId: id,
            title: product.title,
            name: product.title,
            image: imageUrl,
            // Передаем только один тип
            type: product.edition_type || 'Игра',
            platforms: edition.platforms || [],
            edition: edition,
            editionName: edition?.editionName?.name,
            price: originalPrice,
            // price - это оригинальная цена, discount_amount - цена со скидкой
            // Устанавливаем discount_amount только если он существует и меньше оригинальной цены
            discount_amount:
                edition?.discount_amount !== null &&
                edition?.discount_amount > 0 &&
                edition?.discount_amount < originalPrice
                    ? edition.discount_amount
                    : null,
            priceType: 'standard',
            currencyId: currentCurrency?.id, // Добавляем ID валюты
        };
        store.dispatch('cart/addToCart', cartItem);
    }
};

const handleRemove = product => {
    productToRemove.value = product;
    showConfirmModal.value = true;
};

const confirmRemove = async () => {
    if (productToRemove.value) {
        await store.dispatch('favourites/removeFromFavourites', {
            title: productToRemove.value.title,
            editionId: productToRemove.value.editionId,
        });
        showConfirmModal.value = false;
        productToRemove.value = null;
    }
};

const cancelRemove = () => {
    showConfirmModal.value = false;
    productToRemove.value = null;
};

const getImageUrl = product => {
    // Приоритет: изображение из edition, затем из самого product
    const sourceImageUrl = product.edition?.image_url || product.image;

    // Если image начинается с http, значит это полный URL
    if (
        sourceImageUrl?.startsWith('http') ||
        sourceImageUrl?.startsWith('https')
    ) {
        return sourceImageUrl;
    }

    if (!apiBaseUrl) {
        console.error('VITE_API_BASE_URL не определен в переменных окружения');
        return sourceImageUrl || '';
    }

    return `${apiBaseUrl.replace(/\/$/, '')}/${(sourceImageUrl || '').replace(/^\//, '')}`;
};

const getPlatformIcon = platform => {
    if (!platform?.icon_url) return null;

    const iconUrl = platform.icon_url;
    // Если URL уже полный, возвращаем как есть
    if (iconUrl.startsWith('http') || iconUrl.startsWith('https')) {
        return iconUrl;
    }
    // Иначе добавляем базовый URL
    return `${apiBaseUrl}/uploads/${iconUrl.replace(/^\//, '')}`;
};

// При изменении валюты пользователя, обновляем отображение
watch(
    () => currentCurrency.value,
    newCurrency => {
        console.log('Currency changed, updating favourites display');
    },
    { deep: true }
);
</script>

<style scoped>
.favourites-screen {
    padding: 25px 0;
    padding-bottom: 80px;
    background-color: #ffffff;
    max-width: 600px;
    margin: 0 auto;
    box-sizing: border-box;
}

.section-header {
    margin-bottom: 10px;
    padding: 0 15px;
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.section-title {
    font-size: 20px;
    font-weight: bold;
}

.favourites-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 40px;
    text-align: center;
    height: calc(100vh - 200px);
}

.empty-favourites-icon {
    width: 120px;
    height: 120px;
    margin-bottom: 20px;
    opacity: 0.6;
}

.empty-favourites-text {
    font-size: 18px;
    color: #666;
    margin-bottom: 20px;
}

.continue-shopping-btn {
    display: inline-block;
    padding: 12px 24px;
    background: #f3f4f6;
    color: #000;
    text-decoration: none;
    border-radius: 13px;
    font-weight: 500;
    transition: all 0.2s ease-in-out;
}

.continue-shopping-btn:hover {
    background-color: #e5e7eb;
    transform: scale(0.98);
}

.continue-shopping-btn:active {
    transform: scale(0.95);
}

.product-list {
    list-style: none;
    padding: 0;
    margin: 0;
    gap: 8px;
    display: flex;
    flex-direction: column;
    width: 100%;
}

.product-item {
    background: #ffffff;
    border-radius: 13px;
    margin-bottom: 0;
    position: relative;
}

.product-link {
    display: flex;
    text-decoration: none;
    color: inherit;
    gap: 12px;
    padding: 0 12px;
}

.product-image-container {
    position: relative;
    width: 75px;
    height: 75px;
    flex-shrink: 0;
}

.product-image {
    width: 75px;
    height: 75px;
    border-radius: 13px;
    object-fit: cover;
}

.product-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.product-info h3 {
    margin: 1px 0 4px 0;
    font-size: 15px;
    font-weight: 500;
}

.product-subtitle {
    color: #666;
    font-size: 13px;
    margin: 0 0 4px 0;
}

.product-type {
    font-size: 13px;
    color: #666;
    margin: 0;
}

.product-edition {
    margin: 4px 0;
    font-size: 14px;
    color: #000;
}

.edition-row {
    display: flex;
    align-items: center;
    gap: 5px;
}

.platforms {
    display: flex;
    align-items: center;
    gap: 4px;
}

.platform-icon {
    width: 16px;
    height: 16px;
    object-fit: contain;
}

.product-price-actions {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}

.price-container {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}

.price-option {
    display: flex;
    align-items: center;
    gap: 8px;
}

.price-info {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}

.original-price-container {
    display: flex;
    align-items: center;
    gap: 5px;
    flex-direction: row;
    justify-content: flex-end;
}

.product-price-original {
    text-decoration: line-through;
    color: rgba(138, 138, 138, 1);
    font-size: 10px;
    font-weight: 500;
    line-height: 22px;
}

.product-price-discounted {
    color: #000;
    font-size: 14px;
    font-weight: bold;
    line-height: 22px;
}

.discount-badge {
    height: 15px;
    display: flex;
    padding: 0 5px;
    overflow: hidden;
    background: linear-gradient(
        180deg,
        rgba(0, 122, 255, 1) 0%,
        rgba(0, 73, 153, 1) 100%
    );
    align-items: center;
    flex-shrink: 0;
    border-radius: 5px;
    justify-content: center;
    margin-right: 5px;
}

.discount-text {
    color: #ffffff;
    font-size: 10px;
    font-weight: normal;
}

.product-actions {
    display: flex;
    gap: 8px;
    position: absolute;
    bottom: 5px;
    right: 12px;
    z-index: 2;
}

.action-button {
    width: 30px;
    height: 30px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #f2f2f2;
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
}

.action-button img {
    width: 16px;
    height: 16px;
    transition: all 0.2s ease;
}

.action-button:hover {
    background-color: #e5e5e5;
    transform: scale(1.05);
}

.action-button.active {
    background-color: #007aff !important;
}

.action-button.active img {
    filter: brightness(0) invert(1);
}

.no-editions {
    color: #666;
    font-size: 13px;
    margin: 0;
}

/* Стили модального окна */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.modal-content {
    background: white;
    padding: 20px;
    border-radius: 15px;
    width: 90%;
    max-width: 400px;
}

.modal-body {
    text-align: center;
}

.modal-icon {
    width: 90px;
    height: 90px;
    margin: 0 auto 12px;
}

.game-icon {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 20px;
}

.modal-text {
    margin-bottom: 20px;
}

.modal-text h3 {
    margin: 0 0 8px 0;
    font-size: 18px;
}

.modal-text p {
    margin: 0;
    color: #666;
}

.modal-actions {
    display: flex;
    justify-content: center;
    gap: 10px;
}

.modal-btn {
    padding: 10px 20px;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.confirm-btn {
    background-color: #f3f4f6;
    color: #333;
}

.confirm-btn:hover {
    background-color: #e5e7eb;
}

.cancel-btn {
    background-color: #007aff;
    color: white;
}

.cancel-btn:hover {
    background-color: #0066cc;
}

/* Анимации */
.modal-enter-active,
.modal-leave-active {
    transition: opacity 0.3s ease;
}

.modal-enter-from,
.modal-leave-to {
    opacity: 0;
}

.list-move,
.list-enter-active,
.list-leave-active {
    transition: all 0.5s ease;
}

.list-enter-from,
.list-leave-to {
    opacity: 0;
    transform: translateX(30px);
}

.list-leave-active {
    position: absolute;
}

@keyframes buttonPop {
    0% {
        transform: scale(0.95);
    }
    50% {
        transform: scale(1.05);
    }
    100% {
        transform: scale(1);
    }
}

.currency-info {
    margin-top: 5px;
}

.currency-text {
    font-size: 13px;
    color: #666;
    margin: 0;
}
</style>
