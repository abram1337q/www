<template>
    <div class="profile-screen" v-close-keyboard>
        <h2 class="profile-title">Личный кабинет</h2>

        <div v-if="!isAuthenticated" class="auth-message">
            Для доступа к профилю необходимо открыть приложение через Telegram
        </div>

        <template v-else>
            <div
                v-if="error"
                class="message"
                :class="{ error: error.includes('Ошибка') }"
            >
                {{ error }}
            </div>

            <div v-if="isLoading" class="loading">Загрузка...</div>

            <template v-else>
                <div class="form-group">
                    <label for="ps-login">
                        Почта от вашего зарубежного аккаунта PlayStation</label
                    >
                    <input
                        type="text"
                        id="ps-login"
                        v-model="psLogin"
                        inputmode="email"
                        enterkeyhint="next"
                        @keyup.enter="focusNextField('psLogin')"
                    />
                    <div
                        v-if="saveError && editingField === 'psStoreLogin'"
                        class="error-message"
                    >
                        {{ saveError }}
                    </div>
                    <Transition name="slide-fade">
                        <button
                            v-if="editingField === 'psStoreLogin'"
                            @click="saveField('psStoreLogin')"
                            class="save-button"
                            :disabled="isLoading"
                        >
                            {{ isLoading ? 'Сохранение...' : 'Сохранить' }}
                        </button>
                    </Transition>
                </div>

                <div class="form-group">
                    <label for="ps-password"
                        >Пароль от вашего зарубежного аккаунта
                        PlayStation</label
                    >
                    <div class="password-input">
                        <input
                            :type="showPassword ? 'text' : 'password'"
                            id="ps-password"
                            v-model="psPassword"
                            enterkeyhint="next"
                            @keyup.enter="focusNextField('psPassword')"
                        />
                        <button @click="togglePassword" class="toggle-password">
                            <img
                                :src="
                                    showPassword
                                        ? '/assets/img/eye-open.svg'
                                        : '/assets/img/eye-closed.svg'
                                "
                                alt="Toggle password visibility"
                            />
                        </button>
                    </div>
                    <div
                        v-if="saveError && editingField === 'psStorePassword'"
                        class="error-message"
                    >
                        {{ saveError }}
                    </div>
                    <Transition name="slide-fade">
                        <button
                            v-if="editingField === 'psStorePassword'"
                            @click="saveField('psStorePassword')"
                            class="save-button"
                            :disabled="isLoading"
                        >
                            {{ isLoading ? 'Сохранение...' : 'Сохранить' }}
                        </button>
                    </Transition>
                </div>

                <div class="form-group">
                    <label for="ps-backup-codes"
                        >Резервные коды (если есть)</label
                    >
                    <input
                        type="text"
                        id="ps-backup-codes"
                        v-model="psBackupCodes"
                        enterkeyhint="next"
                        @keyup.enter="focusNextField('psBackupCodes')"
                    />
                    <div
                        v-if="saveError && editingField === 'psBackupCodes'"
                        class="error-message"
                    >
                        {{ saveError }}
                    </div>
                    <Transition name="slide-fade">
                        <button
                            v-if="editingField === 'psBackupCodes'"
                            @click="saveField('psBackupCodes')"
                            class="save-button"
                            :disabled="isLoading"
                        >
                            {{ isLoading ? 'Сохранение...' : 'Сохранить' }}
                        </button>
                    </Transition>
                </div>

                <!-- <router-link to="/create-ps-account" class="action-button">
                    <span>Помогите создать аккаунт PS</span>
                    <img
                        src="/assets/img/arrow-right.svg"
                        alt="Arrow right"
                        class="arrow-icon"
                    />
                </router-link> -->

                <div class="form-group">
                    <label for="tg-login">Логин в Telegram</label>
                    <input
                        type="text"
                        id="tg-login"
                        v-model="telegramUsername"
                        disabled
                    />
                </div>

                <div class="form-group">
                    <label for="email">Email для чека</label>
                    <input
                        type="email"
                        id="email"
                        v-model="email"
                        inputmode="email"
                        enterkeyhint="done"
                        @keyup.enter="focusNextField('email')"
                    />
                    <div
                        v-if="saveError && editingField === 'email'"
                        class="error-message"
                    >
                        {{ saveError }}
                    </div>
                    <Transition name="slide-fade">
                        <button
                            v-if="editingField === 'email'"
                            @click="saveField('email')"
                            class="save-button"
                            :disabled="isLoading"
                        >
                            {{ isLoading ? 'Сохранение...' : 'Сохранить' }}
                        </button>
                    </Transition>
                </div>

                <a href="https://t.me/psworld_store" target="_blank" class="action-button">
                    <span>Служба поддержки</span>
                    <img
                        src="/assets/img/arrow-right.svg"
                        alt="Support"
                        class="arrow-icon"
                    />
                </a>

                <div class="logout-section">
                    <!-- Logout section content -->
                </div>
            </template>
        </template>
    </div>
</template>

<script setup>
import { computed, onMounted, onActivated, ref, watch, nextTick } from 'vue';
import { useStore } from 'vuex';

const store = useStore();
const error = ref('');
const isLoading = ref(false);
const showPassword = ref(false);
const editingField = ref(null);
const saveError = ref(null);
const isLoadingData = ref(false); // Флаг для игнорирования watchers во время загрузки

const psLogin = ref('');
const psPassword = ref('');
const psBackupCodes = ref('');
const email = ref('');

const isAuthenticated = computed(() => store.state.auth.telegramId);
const telegramUsername = computed(
    () => store.state.auth.telegramUsername || 'Не указан'
);

// Отслеживаем изменения полей (только если это реальное изменение пользователем, а не загрузка данных)
watch(psLogin, (newValue, oldValue) => {
    if (!isLoadingData.value && oldValue !== undefined && newValue !== oldValue) {
        editingField.value = 'psStoreLogin';
        saveError.value = null;
    }
});

watch(psPassword, (newValue, oldValue) => {
    if (!isLoadingData.value && oldValue !== undefined && newValue !== oldValue) {
        editingField.value = 'psStorePassword';
        saveError.value = null;
    }
});

watch(psBackupCodes, (newValue, oldValue) => {
    if (!isLoadingData.value && oldValue !== undefined && newValue !== oldValue) {
        editingField.value = 'psBackupCodes';
        saveError.value = null;
    }
});

watch(email, (newValue, oldValue) => {
    if (!isLoadingData.value && oldValue !== undefined && newValue !== oldValue) {
        editingField.value = 'email';
        saveError.value = null;
    }
});

// Функция для загрузки данных профиля текущего региона
const loadRegionProfile = async () => {
    try {
        isLoading.value = true;
        isLoadingData.value = true; // Блокируем watchers

        // Загружаем данные профиля для текущего региона
        await store.dispatch('profile/loadProfileData');

        // Получаем данные из profile store
        const profileData = store.getters['profile/getProfileData'];
        psLogin.value = profileData.psLogin || '';
        psPassword.value = profileData.psPassword || '';
        psBackupCodes.value = profileData.psBackupCodes || '';
        email.value = profileData.email || '';

        // Сбрасываем editingField после загрузки
        editingField.value = null;

        // Ждем следующий тик, чтобы все обновления завершились
        await nextTick();

        // Небольшая задержка для гарантии
        await new Promise(resolve => setTimeout(resolve, 50));
    } catch (err) {
        error.value = 'Ошибка при загрузке данных профиля';
        console.error(err);
    } finally {
        isLoading.value = false;
        // Разблокируем watchers только после задержки
        await nextTick();
        isLoadingData.value = false;
    }
};

// Отслеживаем смену валюты (региона)
watch(
    () => store.getters['user/currentCurrency'],
    async (newCurrency, oldCurrency) => {
        if (newCurrency && oldCurrency && newCurrency.id !== oldCurrency.id) {
            console.log('Currency changed, reloading profile data');
            await loadRegionProfile();
        }
    }
);

onMounted(async () => {
    // Сбрасываем editingField при каждом монтировании
    editingField.value = null;
    saveError.value = null;

    try {
        await store.dispatch('auth/initAuth');

        if (isAuthenticated.value) {
            // Загружаем пользователя
            await store.dispatch('user/fetchUser', store.state.auth.telegramId);

            // Загружаем данные профиля для текущего региона
            await loadRegionProfile();
        }
    } catch (err) {
        error.value = 'Ошибка при загрузке данных профиля';
        console.error(err);
    }
});

// Сбрасываем editingField при каждой активации компонента (в том числе при возврате на страницу)
onActivated(async () => {
    // Сначала блокируем watchers
    isLoadingData.value = true;
    editingField.value = null;
    saveError.value = null;

    // Ждем чтобы все обновления завершились
    await nextTick();
    await new Promise(resolve => setTimeout(resolve, 100));

    // Теперь разблокируем watchers
    isLoadingData.value = false;
});

const saveField = async field => {
    if (!isAuthenticated.value) {
        saveError.value =
            'Для сохранения необходимо открыть приложение через Telegram';
        return;
    }

    try {
        isLoading.value = true;
        saveError.value = null;

        // Формируем данные профиля
        const profileData = {
            psLogin: psLogin.value,
            psPassword: psPassword.value,
            psBackupCodes: psBackupCodes.value,
            email: email.value
        };

        // Сохраняем через profile store (который теперь использует региональные данные)
        await store.dispatch('profile/saveProfileData', profileData);
        editingField.value = null;
    } catch (err) {
        saveError.value = err.message || 'Ошибка при сохранении';
        console.error('Save error:', err);
    } finally {
        isLoading.value = false;
    }
};

const togglePassword = () => {
    showPassword.value = !showPassword.value;
};

const focusNextField = currentField => {
    switch (currentField) {
        case 'psLogin':
            editingField.value = 'psStoreLogin';
            break;
        case 'psPassword':
            editingField.value = 'psStorePassword';
            break;
        case 'psBackupCodes':
            editingField.value = 'psBackupCodes';
            break;
        case 'email':
            editingField.value = 'email';
            break;
    }
};
</script>

<style scoped>
.profile-screen {
    padding: 25px 15px;
    padding-bottom: 250px;
    background-color: #ffffff;
    max-width: 600px;
    margin: 0 auto;
    box-sizing: border-box;
}

.profile-title {
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 30px;
    width: 100%;
    box-sizing: border-box;
    position: relative;
    transition: margin-bottom 0.3s ease-out;
}

label {
    display: block;
    margin-bottom: 10px;
    font-size: 15px;
    font-weight: 500;
}

input[type='text'],
input[type='password'],
input[type='email'] {
    width: 100%;
    height: 42px;
    padding: 0 15px;
    border: none;
    border-radius: 13px;
    background-color: #f8f8f8;
    font-size: 15px;
    font-weight: 400;
}

.password-input {
    position: relative;
    width: 100%;
    display: flex;
    align-items: center;
}

.toggle-password {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
    height: 42px;
    display: flex;
    align-items: center;
}

.toggle-password img {
    width: 20px;
    height: 20px;
}

.action-button {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    height: 42px;
    padding: 0 15px;
    background-color: #f8f8f8;
    border: none;
    border-radius: 13px;
    text-decoration: none;
    margin-bottom: 30px;
    box-sizing: border-box;
    cursor: pointer;
}

.action-button span {
    font-size: 15px;
    font-weight: 400;
    color: #037ee5;
}

.action-button:hover {
    background-color: #f0f0f0;
}

.arrow-icon {
    width: 16px;
    height: 16px;
}

.save-button {
    width: 100%;
    height: 42px;
    background-color: #f8f8f8;
    color: #037ee5;
    padding: 0 15px;
    border: none;
    border-radius: 13px;
    cursor: pointer;
    margin-top: 8px;
    font-size: 15px;
    font-weight: 400;
    display: block;
    text-align: center;
}

.save-button:disabled {
    color: #999999;
    cursor: not-allowed;
}

.save-button:hover:not(:disabled) {
    background-color: #f0f0f0;
}

.error-message {
    color: #ff0000;
    margin-bottom: 20px;
}

.loading {
    text-align: center;
    padding: 20px;
    color: #666;
}

.message {
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 8px;
    text-align: center;
}

.message.error {
    background-color: #ffebee;
    color: #c62828;
}

.message:not(.error) {
    background-color: #e8f5e9;
    color: #2e7d32;
}

/* Анимации для появления/исчезновения кнопки */
.slide-fade-enter-active {
    transition: all 0.3s ease-out;
}

.slide-fade-leave-active {
    transition: all 0.2s cubic-bezier(1, 0.5, 0.8, 1);
}

.slide-fade-enter-from,
.slide-fade-leave-to {
    transform: translateY(-10px);
    opacity: 0;
}

.slide-fade-enter-to,
.slide-fade-leave-from {
    transform: translateY(0);
    opacity: 1;
}
</style>
