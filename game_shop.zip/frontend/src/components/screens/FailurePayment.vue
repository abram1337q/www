<template>
    <div class="failure-payment">
        <div class="failure-content">
            <div class="failure-icon">
                <i class="fas fa-times-circle"></i>
            </div>
            <h1>Ошибка оплаты</h1>
            <p>К сожалению, произошла ошибка при оплате. Пожалуйста, попробуйте еще раз или свяжитесь с нашей поддержкой в Telegram.</p>
            <div class="buttons">
                <router-link to="/payment" class="retry-button">
                    Попробовать снова
                </router-link>
                <router-link to="/" class="home-button">
                    Вернуться на главную
                </router-link>
            </div>
        </div>
    </div>
</template>

<script setup>
import { onMounted } from 'vue';
import { useStore } from 'vuex';

const store = useStore();

onMounted(() => {
    // Очищаем данные об оплате при ошибке
    store.dispatch('payment/savePaymentData', null);
});
</script>

<style scoped>
.failure-payment {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    padding: 20px;
    background-color: #f8f9fa;
}

.failure-content {
    text-align: center;
    background: white;
    padding: 40px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    max-width: 500px;
    width: 100%;
}

.failure-icon {
    font-size: 80px;
    color: #dc3545;
    margin-bottom: 20px;
}

h1 {
    color: #dc3545;
    margin-bottom: 20px;
    font-size: 24px;
}

p {
    color: #6c757d;
    margin-bottom: 30px;
    line-height: 1.5;
}

.buttons {
    display: flex;
    gap: 15px;
    justify-content: center;
}

.retry-button,
.home-button {
    display: inline-block;
    padding: 12px 24px;
    border-radius: 5px;
    text-decoration: none;
    transition: background-color 0.2s;
}

.retry-button {
    background-color: #007bff;
    color: white;
}

.retry-button:hover {
    background-color: #0056b3;
}

.home-button {
    background-color: #6c757d;
    color: white;
}

.home-button:hover {
    background-color: #5a6268;
}
</style>
