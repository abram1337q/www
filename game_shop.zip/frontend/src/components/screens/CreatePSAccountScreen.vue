<template>
	<div class="create-ps-account-screen">
		<div class="form-container">
			<h2 class="profile-title">Создание аккаунта PS</h2>

			<div class="form-group">
				<label for="first-name">Имя</label>
				<input
					type="text"
					id="first-name"
					ref="firstNameInput"
					v-model="firstName"
					enterkeyhint="next"
					@keyup.enter="focusNextField('firstName')"
				/>
			</div>

			<div class="form-group">
				<label for="last-name">Фамилия</label>
				<input
					type="text"
					id="last-name"
					ref="lastNameInput"
					v-model="lastName"
					enterkeyhint="next"
					@keyup.enter="focusNextField('lastName')"
				/>
			</div>

			<div class="form-group">
				<label for="email">Email</label>
				<input
					type="email"
					id="email"
					ref="emailInput"
					v-model="email"
					enterkeyhint="next"
					@keyup.enter="focusNextField('email')"
				/>
			</div>

			<div class="form-group">
				<label for="birth-date">Дата рождения</label>
				<div class="date-input-wrapper">
					<input
						type="date"
						id="birth-date"
						ref="birthDateInput"
						v-model="birthDate"
						class="custom-input"
						:max="maxDate"
						enterkeyhint="done"
						@keyup.enter="focusNextField('birthDate')"
					/>
				</div>
			</div>

			<div class="action-button" @click="openSupport">
				<span>Служба поддержки</span>
				<img
					src="/assets/img/arrow-right.svg"
					alt="Arrow right"
					class="arrow-icon"
				/>
			</div>
		</div>
		<div class="submit-button-container">
			<Button
				text="Отправить данные"
				@buttonClicked="handleSubmit"
				:isFullWidth="true"
			/>
		</div>
	</div>
</template>

<script setup>
import Button from '@/components/common/Button.vue';
import { computed, onMounted, onUnmounted, ref, watch } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const firstName = ref('');
const lastName = ref('');
const email = ref('');
const birthDate = ref('');
const dateFocused = ref(false);

// Refs для полей ввода
const firstNameInput = ref(null);
const lastNameInput = ref(null);
const emailInput = ref(null);
const birthDateInput = ref(null);

const telegramAvailable = ref(false);
const backButtonVisible = ref(false);

const debugInfo = computed(() => {
	return `Telegram доступен: ${telegramAvailable.value}, Кнопка Back видима: ${backButtonVisible.value}`;
});

const logBirthDate = () => {
	console.log('Birth Date:', birthDate.value);
};

const maxDate = computed(() => {
	const today = new Date();
	return today.toISOString().split('T')[0];
});

const showBackButton = () => {
	if (window.Telegram && window.Telegram.WebApp) {
		window.Telegram.WebApp.BackButton.show();
		backButtonVisible.value = true;
	}
};

const hideBackButton = () => {
	if (window.Telegram && window.Telegram.WebApp) {
		window.Telegram.WebApp.BackButton.hide();
		backButtonVisible.value = false;
	}
};

const openSupport = () => {
	if (window.Telegram && window.Telegram.WebApp) {
		// Закрываем веб-приложение
		window.Telegram.WebApp.close();

		// Открываем бота с командой support
		// const botUsername = import.meta.env.VITE_BOT_USERNAME;
		// window.open(`https://t.me/${botUsername}?start=support`, '_blank');
		window.open(`https://t.me/psworld_store`, '_blank');
	}
};

// Функция для перехода между полями
const focusNextField = currentField => {
	switch (currentField) {
		case 'firstName':
			lastNameInput.value?.focus();
			break;
		case 'lastName':
			emailInput.value?.focus();
			break;
		case 'email':
			birthDateInput.value?.focus();
			break;
		case 'birthDate':
			handleSubmit();
			break;
	}
};

const handleSubmit = () => {
	if (
		!firstName.value ||
		!lastName.value ||
		!email.value ||
		!birthDate.value
	) {
		if (window.Telegram && window.Telegram.WebApp) {
			window.Telegram.WebApp.showPopup({
				title: 'Ошибка',
				message: 'Пожалуйста, заполните все поля формы',
				buttons: [{ type: 'close' }],
			});
		}
		return;
	}

	const botUsername = import.meta.env.VITE_BOT_USERNAME;
	const command = `account_${firstName.value}_${lastName.value}_${email.value}_${birthDate.value}`;
	const fullCommand = `/start ${command}`;

	if (window.Telegram && window.Telegram.WebApp) {
		// Сразу копируем команду в буфер обмена
		navigator.clipboard
			.writeText(fullCommand)
			.then(() => {
				window.Telegram.WebApp.showPopup(
					{
						title: 'Команда скопирована',
						message:
							'Команда уже скопирована в буфер обмена. После перехода в Telegram просто вставьте её в чат.',
						buttons: [
							{
								id: 'open',
								type: 'default',
								text: 'Перейти в Telegram',
							},
						],
					},
					buttonId => {
						if (buttonId === 'open') {
							window.open(
								`https://t.me/${botUsername}`,
								'_blank'
							);
							window.Telegram.WebApp.close();
						}
					}
				);
			})
			.catch(() => {
				// Если копирование не удалось, показываем команду для ручного копирования
				window.Telegram.WebApp.showPopup(
					{
						title: 'Создание аккаунта',
						message: `Скопируйте команду:\n${fullCommand}`,
						buttons: [
							{
								id: 'copy',
								type: 'default',
								text: 'Копировать',
							},
							{
								id: 'open',
								type: 'default',
								text: 'Перейти в Telegram',
							},
						],
					},
					buttonId => {
						if (buttonId === 'copy') {
							navigator.clipboard.writeText(fullCommand);
							window.Telegram.WebApp.showAlert(
								'Команда скопирована'
							);
						} else if (buttonId === 'open') {
							window.open(
								`https://t.me/${botUsername}`,
								'_blank'
							);
							window.Telegram.WebApp.close();
						}
					}
				);
			});
	} else {
		// Для случаев, когда WebApp недоступен
		const message = `Скопируйте команду:\n${fullCommand}`;
		if (navigator.clipboard) {
			navigator.clipboard
				.writeText(fullCommand)
				.then(() => {
					alert(
						'Команда скопирована в буфер обмена. Перейдите в Telegram и вставьте её в чат.'
					);
				})
				.catch(() => {
					alert(message);
				});
		} else {
			alert(message);
		}
		window.open(`https://t.me/${botUsername}`, '_blank');
	}
};

onMounted(() => {
	console.log('Component mounted');
	watch(birthDate, logBirthDate);
	if (window.Telegram && window.Telegram.WebApp) {
		console.log('Telegram WebApp is available');
		telegramAvailable.value = true;
		window.Telegram.WebApp.ready();
		window.Telegram.WebApp.expand();

		if (router.options.history.state.back) {
			showBackButton();
		}

		window.Telegram.WebApp.BackButton.onClick(() => {
			console.log('Back button clicked');
			router.back();
		});
	} else {
		console.log('Telegram WebApp is not available');
	}
});

onUnmounted(() => {
	console.log('Component unmounted');
	if (window.Telegram && window.Telegram.WebApp) {
		hideBackButton();
		window.Telegram.WebApp.BackButton.offClick();
	}
});
</script>

<style scoped>
.create-ps-account-screen {
	padding: 25px 15px;
	padding-bottom: 80px;
	background-color: #ffffff;
	max-width: 600px;
	margin: 0 auto;
	box-sizing: border-box;
}

.profile-title {
	font-size: 20px;
	font-weight: bold;
	margin-bottom: 30px;
}

.form-container {
	flex-grow: 1;
	max-width: 600px;
	margin: 0 auto;
	padding-bottom: 120px;
}

.form-group {
	margin-bottom: 30px;
	width: 100%;
	box-sizing: border-box;
	position: relative;
	transition: margin-bottom 0.3s ease-out;
}

label {
	display: block;
	margin-bottom: 10px;
	font-size: 15px;
	font-weight: 500;
}

input[type='text'],
input[type='email'],
input[type='date'] {
	width: 100%;
	height: 42px;
	padding: 0 15px;
	border: none;
	border-radius: 13px;
	background-color: #f8f8f8;
	font-size: 15px;
	font-weight: 400;
}

.action-button {
	display: flex;
	justify-content: space-between;
	align-items: center;
	width: 100%;
	height: 42px;
	padding: 0 15px;
	background-color: #f8f8f8;
	border: none;
	border-radius: 13px;
	text-decoration: none;
	margin-bottom: 30px;
	box-sizing: border-box;
	cursor: pointer;
}

.action-button span {
	font-size: 15px;
	font-weight: 400;
	color: #037ee5;
}

.arrow-icon {
	width: 16px;
	height: 16px;
}

.date-input-wrapper {
	position: relative;
}

.custom-input[type='date'] {
	width: 100%;
	height: 42px;
	padding: 0 15px;
	border: none;
	border-radius: 13px;
	background-color: #f8f8f8;
	color: #000000;
	font-size: 15px;
	font-weight: 400;
	box-sizing: border-box;
	appearance: none;
	-webkit-appearance: none;
	-moz-appearance: none;
}

.custom-input[type='date']::-webkit-calendar-picker-indicator {
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	width: auto;
	height: auto;
	color: transparent;
	background: transparent;
}

.date-placeholder {
	position: absolute;
	top: 50%;
	left: 15px;
	transform: translateY(-50%);
	color: #999;
	pointer-events: none;
}

.submit-button-container {
	position: fixed;
	bottom: 100px;
	left: 0;
	right: 0;
	padding: 0 15px;
}

:deep(.custom-button-container) {
	width: 100%;
}

:deep(.custom-button) {
	width: 100%;
	height: 42px;
	font-size: 15px;
	font-weight: 400;
	border-radius: 13px;
	background-color: #007bff;
	color: #ffffff;
}

:deep(.custom-button:hover:not(:disabled)) {
	background-color: #0056b3;
}

:deep(.custom-button:disabled) {
	opacity: 0.7;
	cursor: not-allowed;
}

:deep(.button-text) {
	width: 100%;
	text-align: center;
}
</style>
