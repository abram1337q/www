<template>
	<div class="maintenance-screen">
		<div class="maintenance-content">
			<div class="maintenance-icon">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
				</svg>
			</div>
			<div class="maintenance-message" v-html="formattedMessage"></div>
		</div>
	</div>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({
	message: {
		type: String,
		default: '⚙️ Бот временно недоступен.\n\nВ данный момент проводятся технические работы. Пожалуйста, попробуйте позже.',
	},
});

const formattedMessage = computed(() => {
	return props.message.replace(/\n/g, '<br>');
});
</script>

<style scoped>
.maintenance-screen {
	display: flex;
	align-items: center;
	justify-content: center;
	min-height: 100vh;
	background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
	padding: 20px;
}

.maintenance-content {
	text-align: center;
	max-width: 500px;
	background: white;
	border-radius: 20px;
	padding: 40px 30px;
	box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

.maintenance-icon {
	margin-bottom: 30px;
}

.maintenance-icon svg {
	width: 80px;
	height: 80px;
	color: #667eea;
	animation: rotate 3s linear infinite;
}

@keyframes rotate {
	0% {
		transform: rotate(0deg);
	}
	100% {
		transform: rotate(360deg);
	}
}

.maintenance-message {
	font-size: 18px;
	line-height: 1.6;
	color: #333;
	font-weight: 500;
}
</style>
