#!/bin/bash

# Получить последние изменения
git pull origin main

# Остановить все контейнеры
docker-compose down
docker system prune -f

# Загрузить переменные окружения из .env.prod
set -a
source .env.prod
set +a

# Проверить, что PORT установлен
if [ -z "$PORT" ]; then
    echo "Error: PORT is not set in .env.prod"
    exit 1
fi

# Запустить в production режиме
docker-compose up -d --build

# Проверить статус контейнеров
echo "Checking container status..."
docker-compose ps
