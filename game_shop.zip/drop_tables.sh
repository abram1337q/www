#!/bin/bash
export PGPASSWORD=pAssW_ord123
psql -h 79.174.88.163 -p 16763 -U nkarasyov -d game_shop_db -f drop_tables.sql
unset PGPASSWORD
