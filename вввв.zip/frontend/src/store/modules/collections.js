// Модуль Vuex для хранения состояния коллекций
export default {
	namespaced: true,

	state: () => ({
		// Хранение состояния для каждой коллекции по ID
		collectionStates: {},
		// Кеш данных коллекций
		collectionsCache: {},
	}),

	mutations: {
		// Сохранение состояния коллекции (страница, позиция прокрутки)
		SET_COLLECTION_STATE(state, { collectionId, pageState }) {
			state.collectionStates[collectionId] = {
				...state.collectionStates[collectionId],
				...pageState,
			};
		},

		// Сохранение данных коллекции в кеш
		CACHE_COLLECTION(state, { collectionId, data }) {
			state.collectionsCache[collectionId] = data;
		},

		// Очистка состояния коллекции
		CLEAR_COLLECTION_STATE(state, collectionId) {
			delete state.collectionStates[collectionId];
		},

		// Очистка кеша коллекции
		CLEAR_COLLECTION_CACHE(state, collectionId) {
			delete state.collectionsCache[collectionId];
		},
	},

	actions: {
		// Сохранить состояние страницы коллекции
		saveCollectionState({ commit }, { collectionId, pageState }) {
			commit('SET_COLLECTION_STATE', { collectionId, pageState });
		},

		// Сохранить данные коллекции в кеш
		cacheCollection({ commit }, { collectionId, data }) {
			commit('CACHE_COLLECTION', { collectionId, data });
		},

		// Очистить состояние коллекции
		clearCollectionState({ commit }, collectionId) {
			commit('CLEAR_COLLECTION_STATE', collectionId);
		},

		// Очистить кеш коллекции
		clearCollectionCache({ commit }, collectionId) {
			commit('CLEAR_COLLECTION_CACHE', collectionId);
		},

		// Инвалидировать кеш коллекции (очистить кеш для указанной коллекции)
		invalidateCache({ commit }, collectionId) {
			console.log('Invalidating cache for collection:', collectionId);
			commit('CLEAR_COLLECTION_CACHE', collectionId);
		},
	},

	getters: {
		// Получить состояние коллекции по ID
		getCollectionState: state => collectionId => {
			return (
				state.collectionStates[collectionId] || {
					currentPage: 1,
					scrollPosition: 0,
				}
			);
		},

		// Получить данные коллекции из кеша по ID
		getCachedCollection: state => collectionId => {
			return state.collectionsCache[collectionId] || null;
		},

		// Проверить наличие коллекции в кеше
		hasCollectionCache: state => collectionId => {
			return !!state.collectionsCache[collectionId];
		},
	},
};
