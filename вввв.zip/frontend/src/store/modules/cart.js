export default {
  namespaced: true,
  state: {
    items: [],
    promoDiscount: 0,
    appliedPromoCode: null,
    promoStatus: '', // Добавляем новое состояние
    serverCalculatedTotal: null, // Добавляем поле для хранения серверного расчета
    currencyId: null, // Добавляем поле для хранения ID валюты корзины
  },
  mutations: {
    SET_CART_ITEMS(state, items) {
      // Создаем новый массив для обеспечения реактивности
      state.items = [...items];
    },
    ADD_TO_CART(state, item) {
      const existingItem = state.items.find(i => i.id === item.id);
      if (!existingItem) {
        const itemWithDiscount = {
          ...item,
          discount_amount: item.discount_amount || 0,
          edition_type: item.edition_type,
          editionName: item.editionName,
          productId: item.productId, // Добавляем productId
          platforms: item.platforms || [], // добавляем платформы из издания
          priceType: item.priceType, // сохраняем тип цены (ea_play, ps_plus и т.д.)
          currencyId: state.currencyId, // Добавляем ID валюты при добавлении товара
        };
        state.items.push(itemWithDiscount);
      }
    },
    REMOVE_FROM_CART(state, itemId) {
      // Создаем новый массив для обеспечения реактивности
      const newItems = state.items.filter(item => item.id !== itemId);
      state.items = [...newItems];
      // Сбрасываем серверный расчет при изменении корзины
      state.serverCalculatedTotal = null;
    },
    CLEAR_CART(state) {
      state.items = [];
      state.promoDiscount = 0;
      state.appliedPromoCode = null;
      state.promoStatus = ''; // Очищаем статус
      state.serverCalculatedTotal = null; // Очищаем серверный расчет
      state.currencyId = null; // Сбрасываем ID валюты корзины
    },
    SET_PROMO_DISCOUNT(state, discount) {
      state.promoDiscount = discount;
      // Сбрасываем серверный расчет при изменении скидки
      state.serverCalculatedTotal = null;
    },
    SET_PROMO_CODE(state, code) {
      state.appliedPromoCode = code;
    },
    SET_PROMO_STATUS(state, status) {
      // Новая мутация
      state.promoStatus = status;
    },
    CLEAR_PROMO(state) {
      state.promoDiscount = 0;
      state.appliedPromoCode = null;
      state.promoStatus = ''; // Очищаем статус
      // Сбрасываем серверный расчет при очистке промокода
      state.serverCalculatedTotal = null;
    },
    // Добавляем новую мутацию для установки серверного расчета
    SET_SERVER_CALCULATED_TOTAL(state, total) {
      state.serverCalculatedTotal = total;
    },
    // Добавляем новую мутацию для установки ID валюты корзины
    SET_CART_CURRENCY_ID(state, currencyId) {
      state.currencyId = currencyId;
    },
  },
  actions: {
    async loadCart({ commit, dispatch, rootGetters }) {
      try {
        // Получаем текущую валюту пользователя
        const currentCurrency = rootGetters['user/currentCurrency'];
        const currencyId = currentCurrency?.id;

        if (!currencyId) {
          console.log('Currency not set, waiting for initialization');
          commit('SET_CART_ITEMS', []);
          return;
        }

        // Формируем ключи для localStorage с учетом региона (валюты)
        const cartKey = `cart_region_${currencyId}`;
        const promoDiscountKey = `promoDiscount_region_${currencyId}`;
        const promoCodeKey = `promoCode_region_${currencyId}`;
        const promoStatusKey = `promoStatus_region_${currencyId}`;

        const savedCart = localStorage.getItem(cartKey);
        const items = savedCart ? JSON.parse(savedCart) : [];
        const savedPromoDiscount = localStorage.getItem(promoDiscountKey);
        const savedPromoCode = localStorage.getItem(promoCodeKey);
        const savedPromoStatus = localStorage.getItem(promoStatusKey);

        // Валидируем и обновляем товары в корзине - получаем актуальные данные из базы
        const { getEditionData } = await import('@/services/apiService');

        // Проверяем все товары параллельно и получаем актуальные данные
        const validationPromises = items.map(async (item) => {
          // В корзине хранится ID издания (item.id)
          const editionId = item.id;
          const editionData = await getEditionData(editionId, currencyId);

          if (!editionData) {
            return { item, isValid: false, updatedItem: null };
          }

          // Обновляем данные товара актуальными из базы
          const updatedItem = {
            ...item,
            // Обновляем цены и скидки
            price: editionData.convertedPrice || editionData.price || item.price,
            discount_amount: editionData.discount_amount || 0,
            // Обновляем другие данные
            title: editionData.productCard?.title || item.title,
            image: editionData.productCard?.image || item.image,
            edition_type: editionData.productCard?.edition_type || item.edition_type,
            editionName: editionData.editionName?.name || item.editionName,
            platforms: editionData.platforms || item.platforms || [],
            // Сохраняем тип цены и валюту
            priceType: item.priceType,
            currencyId: currencyId,
          };

          return { item: updatedItem, isValid: true, updatedItem };
        });

        const validationResults = await Promise.all(validationPromises);

        // Фильтруем только валидные товары и используем обновленные данные
        const validatedItems = validationResults
          .filter(result => {
            if (!result.isValid) {
              console.log('Item removed from cart (not found in database):', result.item.title);
            }
            return result.isValid;
          })
          .map(result => result.updatedItem || result.item);

        const hasRemovedItems = validatedItems.length < items.length;
        const hasUpdatedItems = validatedItems.some((item, index) => {
          const originalItem = items.find(i => i.id === item.id);
          return originalItem && (
            originalItem.price !== item.price ||
            originalItem.discount_amount !== item.discount_amount
          );
        });

        // Если были удалены товары или обновлены данные, сохраняем в localStorage
        if (hasRemovedItems || hasUpdatedItems) {
          localStorage.setItem(cartKey, JSON.stringify(validatedItems));
          if (hasRemovedItems) {
            console.log(`Removed ${items.length - validatedItems.length} invalid items from cart`);
          }
          if (hasUpdatedItems) {
            console.log('Updated cart items with actual prices from database');
          }
        }

        commit('SET_CART_ITEMS', validatedItems);
        commit('SET_CART_CURRENCY_ID', currencyId);

        // Проверяем сохраненный промокод на валидность
        if (savedPromoDiscount && savedPromoCode && savedPromoStatus === 'success') {
          try {
            // Импортируем функцию проверки промокода
            const { checkPromo } = await import('@/services/apiService');
            await checkPromo(savedPromoCode);

            // Если промокод все еще валиден, применяем его
            commit('SET_PROMO_DISCOUNT', Number(savedPromoDiscount));
            commit('SET_PROMO_CODE', savedPromoCode);
            commit('SET_PROMO_STATUS', savedPromoStatus);
            console.log('Saved promo code validated successfully:', savedPromoCode);
          } catch (error) {
            // Если промокод уже использован или недействителен, очищаем его
            console.log('Saved promo code is no longer valid, clearing:', error.message);
            dispatch('clearPromoCode');
          }
        }
      } catch (error) {
        console.error('Error loading cart:', error);
        commit('SET_CART_ITEMS', []);
      }
    },
    addToCart({ commit, state, rootGetters }, item) {
      console.log('Adding item to cart:', item);

      // Получаем текущую валюту пользователя
      const currentCurrency = rootGetters['user/currentCurrency'];

      if (!state.currencyId && currentCurrency?.id) {
        // Если ID валюты корзины не установлен, устанавливаем его
        commit('SET_CART_CURRENCY_ID', currentCurrency.id);
      }

      commit('ADD_TO_CART', item);
      // Сбрасываем серверный расчет при добавлении товара
      commit('SET_SERVER_CALCULATED_TOTAL', null);

      // Сохраняем корзину для текущего региона
      const currencyId = state.currencyId || currentCurrency?.id;
      if (currencyId) {
        const cartKey = `cart_region_${currencyId}`;
        localStorage.setItem(cartKey, JSON.stringify(state.items));
      }
    },
    removeFromCart({ commit, state, rootGetters }, payload) {
      let itemId;
      if (typeof payload === 'object' && payload !== null) {
        // Если передан объект, используем id из него
        itemId = payload.id;
      } else {
        // Если передано просто значение, используем его как id
        itemId = payload;
      }
      commit('REMOVE_FROM_CART', itemId);

      // Сохраняем корзину для текущего региона
      const currentCurrency = rootGetters['user/currentCurrency'];
      const currencyId = state.currencyId || currentCurrency?.id;
      if (currencyId) {
        const cartKey = `cart_region_${currencyId}`;
        localStorage.setItem(cartKey, JSON.stringify(state.items));
      }
    },
    clearCart({ commit, state, rootGetters }) {
      // Получаем текущую валюту для очистки правильной корзины
      const currentCurrency = rootGetters['user/currentCurrency'];
      const currencyId = state.currencyId || currentCurrency?.id;

      commit('CLEAR_CART');

      // Удаляем данные для текущего региона
      if (currencyId) {
        const cartKey = `cart_region_${currencyId}`;
        const promoDiscountKey = `promoDiscount_region_${currencyId}`;
        const promoCodeKey = `promoCode_region_${currencyId}`;
        const promoStatusKey = `promoStatus_region_${currencyId}`;

        localStorage.removeItem(cartKey);
        localStorage.removeItem(promoDiscountKey);
        localStorage.removeItem(promoCodeKey);
        localStorage.removeItem(promoStatusKey);
      }
    },
    applyPromoCode({ commit, state, rootGetters }, { code, discount }) {
      commit('SET_PROMO_DISCOUNT', Number(discount));
      commit('SET_PROMO_CODE', code);
      commit('SET_PROMO_STATUS', 'success');

      // Сохраняем промокод для текущего региона
      const currentCurrency = rootGetters['user/currentCurrency'];
      const currencyId = state.currencyId || currentCurrency?.id;
      if (currencyId) {
        const promoDiscountKey = `promoDiscount_region_${currencyId}`;
        const promoCodeKey = `promoCode_region_${currencyId}`;
        const promoStatusKey = `promoStatus_region_${currencyId}`;

        localStorage.setItem(promoDiscountKey, discount);
        localStorage.setItem(promoCodeKey, code);
        localStorage.setItem(promoStatusKey, 'success');
      }
    },
    clearPromoCode({ commit, state, rootGetters }) {
      commit('CLEAR_PROMO');

      // Удаляем промокод для текущего региона
      const currentCurrency = rootGetters['user/currentCurrency'];
      const currencyId = state.currencyId || currentCurrency?.id;
      if (currencyId) {
        const promoDiscountKey = `promoDiscount_region_${currencyId}`;
        const promoCodeKey = `promoCode_region_${currencyId}`;
        const promoStatusKey = `promoStatus_region_${currencyId}`;

        localStorage.removeItem(promoDiscountKey);
        localStorage.removeItem(promoCodeKey);
        localStorage.removeItem(promoStatusKey);
      }
    },
    // Добавляем новое действие для установки серверного расчета
    setServerCalculatedTotal({ commit }, total) {
      commit('SET_SERVER_CALCULATED_TOTAL', total);
    },
    // Добавляем новое действие для установки ID валюты корзины
    setCartCurrencyId({ commit }, currencyId) {
      commit('SET_CART_CURRENCY_ID', currencyId);
    },
  },
  getters: {
    cartItems: state => [...state.items],
    // Получаем только те товары, которые соответствуют текущей валюте корзины
    filteredCartItems: (state, getters, rootState, rootGetters) => {
      const currentCurrency = rootGetters['user/currentCurrency'];
      if (
        !currentCurrency ||
        !state.currencyId ||
        currentCurrency.id === state.currencyId
      ) {
        return [...state.items];
      }
      // Если валюта пользователя не совпадает с валютой корзины, возвращаем пустой массив
      return [];
    },
    cartTotal: (state, getters) => {
      // Если есть серверный расчет, используем его
      if (state.serverCalculatedTotal !== null) {
        return state.serverCalculatedTotal;
      }

      // Иначе используем локальный расчет
      const subtotal = getters.filteredCartItems.reduce((total, item) => {
        const price = Number(item.price);
        const discount = Number(item.discount_amount) || 0;
        const finalPrice = Math.floor(price - discount);
        return total + finalPrice;
      }, 0);

      // Применяем скидку промокода, если есть
      if (state.promoDiscount) {
        const discountedPrice =
          subtotal * (1 - state.promoDiscount / 100);
        return Math.floor(discountedPrice);
      }
      return Math.floor(subtotal);
    },
    cartSubtotal: (state, getters) => {
      return getters.filteredCartItems.reduce((total, item) => {
        return total + Number(item.price);
      }, 0);
    },
    cartSavings: (state, getters) => {
      const subtotal = getters.cartSubtotal;
      const total = getters.cartTotal;
      return subtotal - total;
    },
    isInCart: state => (productId, editionId) => {
      // Проверяем по editionId (для обратной совместимости)
      if (editionId && !productId) {
        return state.items.some(item => item.id === editionId);
      }
      // Проверяем по productId и editionId
      return state.items.some(
        item => item.productId === productId && item.id === editionId
      );
    },
    promoDiscount: state => state.promoDiscount,
    appliedPromoCode: state => state.appliedPromoCode,
    promoStatus: state => state.promoStatus,
    cartCurrencyId: state => state.currencyId,
    hasCurrencyMismatch: (state, getters, rootState, rootGetters) => {
      // Если корзина пуста или нет ID валюты корзины, нет несоответствия
      if (state.items.length === 0 || !state.currencyId) {
        return false;
      }
      const currentCurrency = rootGetters['user/currentCurrency'];
      return (
        currentCurrency &&
        state.currencyId &&
        currentCurrency.id !== state.currencyId
      );
    },
  },
};
