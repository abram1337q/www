<template>
	<div class="payment-status" v-if="isVisible">
		<div class="payment-status__content">
			<div v-if="status === 'pending'" class="payment-status__pending">
				<h3>{{ pendingTitle }}</h3>
				<p>{{ message || 'Ожидание оплаты...' }}</p>
				<p v-if="!message && !isPaymentWindowClosed">
					Завершите оплату в открывшемся окне с QR-кодом СБП.
				</p>
				<p v-if="!message && isPaymentWindowClosed">
					Если окно оплаты закрылось, вы можете открыть его снова.
				</p>
				<div class="payment-status__loader"></div>
				<button
					v-if="isPaymentWindowClosed && paymentUrl"
					@click="reopenPayment"
					class="payment-status__retry-btn"
				>
					Открыть окно оплаты
				</button>
			</div>

			<div v-if="status === 'success'" class="payment-status__success">
				<h3>Оплата успешно завершена!</h3>
				<p>{{ message }}</p>
				<p>Перенаправление на страницу подтверждения...</p>
			</div>

			<div v-if="status === 'error'" class="payment-status__error">
				<h3>Ошибка при оплате</h3>
				<p>{{ message || errorMessage }}</p>
				<button
					@click="$emit('closeStatus')"
					class="payment-status__close-btn"
				>
					Закрыть
				</button>
			</div>
		</div>
	</div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

const props = defineProps({
	orderId: {
		type: String,
		required: true,
	},
	isVisible: {
		type: Boolean,
		default: true,
	},
});

const emit = defineEmits(['closeStatus']);
const router = useRouter();
const store = useStore();

const status = ref('pending');
const message = ref('');
const errorMessage = ref('');
const isPaymentWindowClosed = ref(false);
const paymentUrl = ref('');

let pollInterval = null;
let retryCount = 0;
const MAX_RETRIES = 60;

// Получаем WebApp
const telegram = computed(() => window.Telegram?.WebApp);
const isMobile = computed(() => {
	return (
		telegram.value?.platform !== 'desktop' &&
		telegram.value?.platform !== 'web'
	);
});

const pendingTitle = computed(() => {
	if (message.value === 'Ожидает подтверждения') {
		return 'Проверка платежа';
	} else if (message.value === 'Платеж инициирован') {
		return 'Ожидание оплаты';
	}
	return 'Ожидание оплаты';
});

// Функция для повторного открытия окна оплаты
const reopenPayment = () => {
	if (!paymentUrl.value) return;

	if (isMobile.value && telegram.value) {
		telegram.value.openLink(paymentUrl.value, {
			try_instant_view: false,
			open_in_browser: true,
		});
	} else {
		window.open(
			paymentUrl.value,
			'payment_window',
			'width=400,height=600,menubar=no,toolbar=no,location=no,status=no'
		);
	}
};

const checkPaymentStatus = async () => {
	try {
		console.log('Checking payment status for orderId:', props.orderId);
		const response = await fetch(`/api/payment/status/${props.orderId}`);

		if (!response.ok) {
			throw new Error(`HTTP error! status: ${response.status}`);
		}

		const data = await response.json();
		console.log('Payment status response:', data);

		if (!data || typeof data.status === 'undefined') {
			throw new Error('Invalid response format');
		}

		message.value = data.message || '';
		paymentUrl.value = data.paymentUrl || '';

		if (
			data.status === 'success' ||
			data.status === 'completed' ||
			data.status === 'paid'
		) {
			status.value = 'success';
			clearInterval(pollInterval);

			// Очищаем данные платежа и корзину
			await Promise.all([
				store.dispatch('payment/clearPaymentData'),
				store.dispatch('cart/clearCart'),
			]);

			// Перенаправляем на страницу успешной оплаты
			setTimeout(() => {
				router.push('/success-payment');
			}, 1500);
		} else if (data.status === 'error' || data.status === 'failed') {
			console.log('Payment failed:', data.message);
			status.value = 'error';
			errorMessage.value = data.message || 'Произошла ошибка при оплате';
			clearInterval(pollInterval);

			// Уведомляем родительский компонент о необходимости скрыть статус
			emit('closeStatus');

			setTimeout(() => {
				router.push('/failure-payment');
			}, 1500);
		} else {
			console.log('Payment status:', data.status);
			retryCount++;

			// Проверяем количество попыток
			if (retryCount >= MAX_RETRIES) {
				console.log('Max retries reached');
				status.value = 'error';
				errorMessage.value = 'Превышено время ожидания оплаты';
				clearInterval(pollInterval);

				// Уведомляем родительский компонент о необходимости скрыть статус
				emit('closeStatus');

				setTimeout(() => {
					router.push('/failure-payment');
				}, 1500);
			}
		}
	} catch (error) {
		console.error('Error checking payment status:', error);
		retryCount++;

		// При ошибках запроса тоже проверяем количество попыток
		if (retryCount >= MAX_RETRIES) {
			status.value = 'error';
			errorMessage.value = 'Ошибка при проверке статуса платежа';
			clearInterval(pollInterval);

			// Уведомляем родительский компонент о необходимости скрыть статус
			emit('closeStatus');

			setTimeout(() => {
				router.push('/failure-payment');
			}, 1500);
		}
	}
};

onMounted(() => {
	console.log('PaymentStatus component mounted, starting polling...');
	retryCount = 0;
	checkPaymentStatus(); // Первая проверка
	pollInterval = setInterval(checkPaymentStatus, 5000);

	if (!isMobile.value) {
		setInterval(checkPaymentWindow, 1000);
	}
});

onUnmounted(() => {
	console.log('PaymentStatus component unmounted, clearing interval...');
	if (pollInterval) {
		clearInterval(pollInterval);
	}
});
</script>

<style scoped>
.payment-status {
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(0, 0, 0, 0.5);
	display: flex;
	align-items: center;
	justify-content: center;
	z-index: 1000;
}

.payment-status__content {
	background: #fff;
	padding: 20px;
	border-radius: 12px;
	max-width: 90%;
	width: 400px;
	text-align: center;
}

.payment-status__loader {
	margin: 20px auto;
	width: 40px;
	height: 40px;
	border: 4px solid #3390ec;
	border-radius: 50%;
	border-top-color: transparent;
	animation: spin 1s linear infinite;
}

.payment-status__retry-btn,
.payment-status__close-btn {
	margin-top: 15px;
	padding: 10px 20px;
	background: var(--tg-theme-button-color, #3390ec);
	color: var(--tg-theme-button-text-color, #fff);
	border: none;
	border-radius: 8px;
	cursor: pointer;
}

@keyframes spin {
	to {
		transform: rotate(360deg);
	}
}
</style>
