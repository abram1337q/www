<template>
    <div class="collection-screen" ref="collectionScreenRef">
        <div v-if="loading" class="loading">Загрузка...</div>
        <template v-else>
            <div class="content-container">
                <h1 class="collection-title">{{ collectionTitle }}</h1>

                <section class="product-section">
                    <div v-if="games.length === 0" class="no-games">
                        Нет доступных игр с PS Plus Extra
                    </div>
                    <div v-else class="product-list">
                        <ProductCard
                            v-for="game in displayedGames"
                            :key="game.id"
                            :product="{
                                ...game,
                                title: game.name,
                                editions: game.editions || [],
                                edition: game.editions?.[0] || null,
                                edition_type: game.edition_type,
                            }"
                            @card-click="handleProductCardClick"
                        />
                    </div>
                </section>

                <!-- Кнопка обращения в поддержку -->
                <SupportButton v-if="games.length > 0" />

                <div v-if="totalPages > 1" class="pagination-container">
                    <button
                        class="pagination-btn"
                        @click="goToFirstPage"
                        :disabled="currentPage === 1"
                    >
                        «
                    </button>
                    <button
                        class="pagination-btn"
                        @click="goToPrevPage"
                        :disabled="currentPage === 1"
                    >
                        ‹
                    </button>

                    <div class="page-numbers">
                        <button
                            v-for="page in displayedPages"
                            :key="page"
                            class="page-number"
                            :class="{ active: currentPage === page }"
                            @click="goToPage(page)"
                        >
                            {{ page }}
                        </button>
                    </div>

                    <button
                        class="pagination-btn"
                        @click="goToNextPage"
                        :disabled="currentPage === totalPages"
                    >
                        ›
                    </button>
                    <button
                        class="pagination-btn"
                        @click="goToLastPage"
                        :disabled="currentPage === totalPages"
                    >
                        »
                    </button>
                </div>
            </div>
        </template>
    </div>
</template>

<script>
import ProductCard from '@/components/common/ProductCard.vue';
import SupportButton from '@/components/common/SupportButton.vue';
import { getPsPlusExtraGames } from '@/services/apiService';
import { onMounted } from 'vue';
import { mapState, useStore } from 'vuex';

export default {
    name: 'PsPlusExtraCollectionScreen',
    components: {
        ProductCard,
        SupportButton,
    },

    setup() {
        const store = useStore();

        onMounted(async () => {
            const webApp = window.Telegram?.WebApp;
            const initData = webApp?.initDataUnsafe;
            if (initData?.user?.id) {
                await store.dispatch('user/fetchUser', initData.user.id);
            }
        });

        return {};
    },

    data() {
        return {
            games: [],
            loading: true,
            currentPage: 1,
            itemsPerPage: 12,
            maxDisplayedPages: 5,
            initialLoadComplete: false,
            scrollTimeout: null,
        };
    },

    computed: {
        ...mapState('cart', {
            cartItems: state => state.items,
        }),
        ...mapState('user', {
            currentCurrency: state => state.currentCurrency,
        }),

        collectionTitle() {
            // Проверяем, есть ли переданные подписки через query параметр
            const subscriptions = this.$route.query.subs;
            if (subscriptions) {
                return `Входит в подписку PS Plus ${subscriptions}`;
            }
            return 'Входит в подписку PS Plus Extra';
        },

        totalPages() {
            return Math.max(
                1,
                Math.ceil(this.games.length / this.itemsPerPage)
            );
        },

        displayedGames() {
            const start = (this.currentPage - 1) * this.itemsPerPage;
            const end = start + this.itemsPerPage;

            if (this.currentPage > this.totalPages && this.totalPages > 0) {
                this.$nextTick(() => {
                    this.currentPage = this.totalPages;
                });
                return [];
            }

            return this.games.slice(start, end);
        },

        displayedPages() {
            const pages = [];
            const maxVisiblePages = 5;
            const halfVisible = Math.floor(maxVisiblePages / 2);

            let startPage = Math.max(this.currentPage - halfVisible, 1);
            let endPage = Math.min(
                startPage + maxVisiblePages - 1,
                this.totalPages
            );

            if (endPage - startPage + 1 < maxVisiblePages) {
                startPage = Math.max(endPage - maxVisiblePages + 1, 1);
            }

            for (let i = startPage; i <= endPage; i++) {
                pages.push(i);
            }

            return pages;
        },
    },

    methods: {
        async loadGames() {
            try {
                this.loading = true;
                const params = {};

                if (this.currentCurrency) {
                    params.currency_id = this.currentCurrency.id;
                }

                const response = await getPsPlusExtraGames(params);
                this.games = response.data.map(game => ({
                    ...game,
                    title: game.name,
                    editions: game.editions || [],
                    edition: game.editions?.[0] || null,
                }));

                this.initialLoadComplete = true;
            } catch (error) {
                console.error('Error loading PS Plus Extra games:', error);
            } finally {
                this.loading = false;
            }
        },

        savePageState() {
            if (!this.initialLoadComplete) return;

            const scrollPosition = this.$refs.collectionScreenRef
                ? this.$refs.collectionScreenRef.scrollTop
                : 0;

            this.$store.dispatch('collections/saveCollectionState', {
                collectionId: 'ps-plus-extra',
                pageState: {
                    currentPage: this.currentPage,
                    scrollPosition: scrollPosition,
                },
            });

            console.log('Saved PS Plus Extra collection state:', {
                currentPage: this.currentPage,
                scrollPosition: scrollPosition,
            });
        },

        handleScroll() {
            if (this.scrollTimeout) {
                clearTimeout(this.scrollTimeout);
            }

            this.scrollTimeout = setTimeout(() => {
                this.savePageState();
            }, 200);
        },

        // Обработчик клика на карточку продукта
        handleProductCardClick() {
            // Очищаем таймаут дебаунсинга
            if (this.scrollTimeout) {
                clearTimeout(this.scrollTimeout);
                this.scrollTimeout = null;
            }
            // Немедленно сохраняем позицию скролла перед переходом
            this.savePageState();
            console.log('Product card clicked, scroll position saved immediately (PS Plus Extra)');
        },

        goToPage(page) {
            this.currentPage = page;
            this.savePageState();
            if (this.$refs.collectionScreenRef) {
                this.$refs.collectionScreenRef.scrollTop = 0;
            }
        },

        goToFirstPage() {
            this.goToPage(1);
        },

        goToLastPage() {
            this.goToPage(this.totalPages);
        },

        goToPrevPage() {
            if (this.currentPage > 1) {
                this.goToPage(this.currentPage - 1);
            }
        },

        goToNextPage() {
            if (this.currentPage < this.totalPages) {
                this.goToPage(this.currentPage + 1);
            }
        },
    },

    watch: {
        currentCurrency() {
            this.currentPage = 1;
            this.loadGames();
        },
    },

    created() {
        const savedState =
            this.$store.getters['collections/getCollectionState'](
                'ps-plus-extra'
            );
        if (savedState && savedState.currentPage) {
            this.currentPage = savedState.currentPage;
        }

        this.loadGames();
    },

    mounted() {
        this.$refs.collectionScreenRef.addEventListener(
            'scroll',
            this.handleScroll
        );

        // Восстанавливаем позицию скролла
        // Используем requestAnimationFrame для более плавной работы
        const restoreScroll = () => {
            const savedState = this.$store.getters['collections/getCollectionState']('ps-plus-extra');
            if (savedState.scrollPosition && this.$refs.collectionScreenRef && !this.loading) {
                requestAnimationFrame(() => {
                    this.$refs.collectionScreenRef.scrollTop = savedState.scrollPosition;
                    console.log('Restored scroll position:', savedState.scrollPosition);
                });
            }
        };

        // Если данные уже загружены (из кеша), восстанавливаем сразу
        if (!this.loading) {
            this.$nextTick(restoreScroll);
        } else {
            // Если идет загрузка, ждем её завершения
            const unwatch = this.$watch('loading', (newVal) => {
                if (!newVal) {
                    this.$nextTick(restoreScroll);
                    unwatch();
                }
            });
        }
    },

    beforeUnmount() {
        if (this.$refs.collectionScreenRef) {
            this.$refs.collectionScreenRef.removeEventListener(
                'scroll',
                this.handleScroll
            );
        }
        // Очищаем таймаут дебаунсинга, если он активен
        if (this.scrollTimeout) {
            clearTimeout(this.scrollTimeout);
            this.scrollTimeout = null;
        }
        // Немедленно сохраняем текущую позицию скролла
        if (this.$refs.collectionScreenRef) {
            const scrollPosition = this.$refs.collectionScreenRef.scrollTop;
            this.$store.dispatch('collections/saveCollectionState', {
                collectionId: 'ps-plus-extra',
                pageState: {
                    currentPage: this.currentPage,
                    scrollPosition: scrollPosition,
                },
            });
            console.log('Saved scroll position in beforeUnmount (PS Plus Extra):', {
                currentPage: this.currentPage,
                scrollPosition: scrollPosition,
            });
        }
    },
};
</script>

<style scoped>
.collection-screen {
    height: 100vh;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
    position: relative;
    padding: 25px 0;
}

.content-container {
    position: relative;
    z-index: 2;
    background-color: #ffffff;
    min-height: calc(100vh - 187px);
    border-radius: 13px 13px 0 0;
    margin-top: -13px;
    padding: 20px 20px 120px;
}

.collection-title {
    font-size: 20px;
    font-weight: bold;
    color: #000;
    margin: 0 0 16px 0;
}

.pagination-container {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
    position: fixed;
    bottom: 90px;
    left: 0;
    right: 0;
    padding: 16px;
    z-index: 10;
}

.pagination-btn,
.page-number {
    min-width: 32px;
    height: 32px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #ffffff;
    color: #000000;
    font-size: 14px;
    cursor: pointer;
    border-radius: 8px;
    transition: background-color 0.2s;
}

.pagination-btn {
    border: 1px solid #000000;
    padding-bottom: 2px;
}

.page-number {
    border: 1px solid #000000;
}

.pagination-btn:disabled {
    opacity: 0.3;
    cursor: not-allowed;
}

.pagination-btn:not(:disabled):hover,
.page-number:not(.active):hover {
    background: #f1f1f1;
}

.page-numbers {
    display: flex;
    gap: 8px;
}

.page-number.active {
    background: #007aff;
    color: #ffffff;
}

.product-section {
    margin-bottom: 60px;
    max-width: 800px;
    margin: 0 auto;
}

.product-list {
    gap: 8px;
    display: flex;
    flex-direction: column;
    width: 100%;
}

.product-list > * {
    background: #ffffff;
    border-radius: 13px;
    margin-bottom: 0;
}

.loading {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    font-size: 18px;
    color: #666;
}

.no-games {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 200px;
    color: #666;
    font-size: 16px;
}
</style>
