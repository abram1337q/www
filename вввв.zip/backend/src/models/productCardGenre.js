import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

export default class ProductCardGenre extends Model {
    static init(sequelize) {
        super.init(
            {
                product_card_id: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'ProductCards',
                        key: 'id'
                    },
                    onDelete: 'CASCADE'
                },
                genre_id: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'Genres',
                        key: 'id'
                    },
                    onDelete: 'CASCADE'
                }
            },
            {
                sequelize,
                modelName: 'ProductCardGenre',
                tableName: 'ProductCardGenres',
                timestamps: false,
                underscored: true
            }
        );
        return this;
    }
}

ProductCardGenre.init(sequelize);
