import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class Localization extends Model {
	static associate(models) {
		Localization.belongsToMany(models.Edition, {
			through: 'edition_localizations',
			foreignKey: 'localization_id',
			otherKey: 'edition_id',
			as: 'editions',
			timestamps: true,
			createdAt: 'createdAt',
			updatedAt: 'updatedAt',
		});
	}

	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				name: {
					type: DataTypes.STRING,
					allowNull: false,
					unique: true,
				},
				image_url: {
					type: DataTypes.STRING,
					allowNull: true,
				},
			},
			{
				sequelize,
				modelName: 'Localization',
				tableName: 'Localizations',
				underscored: true,
			}
		);
		return this;
	}
}

Localization.init(sequelize);
