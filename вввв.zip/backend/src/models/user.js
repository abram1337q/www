import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class User extends Model {
	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				telegramId: {
					type: DataTypes.STRING,
					unique: true,
					allowNull: false,
				},
				telegramUsername: {
					type: DataTypes.STRING,
					allowNull: true,
				},
				psStoreLogin: {
					type: DataTypes.STRING,
					allowNull: true,
				},
				psStorePassword: {
					type: DataTypes.STRING,
					allowNull: true,
				},
				psBackupCodes: {
					type: DataTypes.STRING,
					allowNull: true,
				},
				email: {
					type: DataTypes.STRING,
					allowNull: true,
					validate: {
						isEmail: true,
					},
				},
				currencyId: {
					type: DataTypes.INTEGER,
					allowNull: true,
					defaultValue: 1,
				},
			},
			{
				sequelize,
				modelName: 'User',
				tableName: 'Users',
				timestamps: true,
			}
		);
	}

	static associate(models) {
		User.belongsTo(models.Currency, {
			foreignKey: 'currencyId',
			as: 'Currency'
		});
	}
}

User.init(sequelize);
