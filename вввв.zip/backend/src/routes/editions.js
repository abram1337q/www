import { Router } from 'express';
import { Op } from 'sequelize';
import db from '../models/index.js';

const router = Router();

// Получить все активные коллекции для модалки
router.get('/collections', async (req, res) => {
    try {
        const collections = await db.ProductCollection.findAll({
            where: { is_active: true },
            attributes: ['id', 'name', 'description'],
            order: [['name', 'ASC']],
        });

        res.json(collections);
    } catch (error) {
        console.error('Error fetching collections:', error);
        res.status(500).json({ error: 'Failed to fetch collections' });
    }
});

// Массовое добавление изданий в коллекцию
router.post('/bulk-add-to-collection', async (req, res) => {
    try {
        const { editionIds, collectionId } = req.body;

        if (!editionIds || !Array.isArray(editionIds) || !collectionId) {
            return res.status(400).json({
                error: 'editionIds (array) and collectionId are required'
            });
        }

        // Проверяем существование коллекции
        const collection = await db.ProductCollection.findByPk(collectionId);
        if (!collection) {
            return res.status(404).json({ error: 'Collection not found' });
        }

        // Проверяем существование изданий
        const editions = await db.Edition.findAll({
            where: { id: { [Op.in]: editionIds } },
            attributes: ['id']
        });

        if (editions.length !== editionIds.length) {
            return res.status(400).json({
                error: 'Some editions not found'
            });
        }

        // Получаем уже существующие связи
        const existingRelations = await db.sequelize.query(`
            SELECT edition_id FROM "ProductCollectionEditions"
            WHERE product_collection_id = :collectionId
            AND edition_id = ANY(ARRAY[:editionIds]::int[])
        `, {
            replacements: {
                collectionId,
                editionIds: editionIds
            },
            type: db.sequelize.QueryTypes.SELECT
        });

        const existingEditionIds = existingRelations.map(r => parseInt(r.edition_id));
        const newEditionIds = editionIds.filter(id => !existingEditionIds.includes(parseInt(id)));

        if (newEditionIds.length === 0) {
            return res.json({
                message: 'All editions already in collection',
                addedCount: 0,
                skippedCount: editionIds.length
            });
        }

        // Добавляем новые связи
        const insertData = newEditionIds.map(editionId => ({
            product_collection_id: collectionId,
            edition_id: editionId,
            created_at: new Date(),
            updated_at: new Date()
        }));

        await db.sequelize.getQueryInterface().bulkInsert(
            'ProductCollectionEditions',
            insertData
        );

        res.json({
            message: `Successfully added ${newEditionIds.length} editions to collection`,
            addedCount: newEditionIds.length,
            skippedCount: existingEditionIds.length
        });

    } catch (error) {
        console.error('Error bulk adding to collection:', error);
        res.status(500).json({ error: 'Failed to add editions to collection' });
    }
});

// Предварительный просмотр изданий для добавления
router.post('/preview-for-collection', async (req, res) => {
    try {
        const { editionIds, collectionId } = req.body;

        if (!editionIds || !Array.isArray(editionIds) || !collectionId) {
            return res.status(400).json({
                error: 'editionIds (array) and collectionId are required'
            });
        }

        // Получаем информацию об изданиях
        const editions = await db.Edition.findAll({
            where: { id: { [Op.in]: editionIds } },
            include: [
                {
                    model: db.EditionName,
                    as: 'editionName',
                    attributes: ['name']
                },
                {
                    model: db.ProductCard,
                    as: 'productCard',
                    attributes: ['name']
                }
            ],
            attributes: ['id', 'price', 'discount_amount', 'promotion_end_date']
        });

        // Проверяем, какие издания уже в коллекции
        const existingRelations = await db.sequelize.query(`
            SELECT edition_id FROM "ProductCollectionEditions"
            WHERE product_collection_id = :collectionId
            AND edition_id = ANY(ARRAY[:editionIds]::int[])
        `, {
            replacements: {
                collectionId,
                editionIds: editionIds
            },
            type: db.sequelize.QueryTypes.SELECT
        });

        const existingEditionIds = existingRelations.map(r => r.edition_id);

        // Считаем статистику
        const now = new Date();
        let activeDiscounts = 0;
        let expiringSoon = 0;

        editions.forEach(edition => {
            if (edition.discount_amount && edition.promotion_end_date) {
                const endDate = new Date(edition.promotion_end_date);
                if (endDate > now) {
                    activeDiscounts++;
                    const daysLeft = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));
                    if (daysLeft <= 7) expiringSoon++;
                }
            }
        });

        res.json({
            totalEditions: editions.length,
            newEditions: editions.length - existingEditionIds.length,
            alreadyInCollection: existingEditionIds.length,
            activeDiscounts,
            expiringSoon,
            editions: editions.map(edition => ({
                id: edition.id,
                name: `${edition.productCard?.name} - ${edition.editionName?.name}`,
                price: edition.price,
                discountAmount: edition.discount_amount,
                promotionEndDate: edition.promotion_end_date,
                alreadyInCollection: existingEditionIds.includes(edition.id)
            }))
        });

    } catch (error) {
        console.error('Error previewing editions:', error);
        res.status(500).json({ error: 'Failed to preview editions' });
    }
});

// Получить одно издание по ID для админки (ДОЛЖЕН БЫТЬ В КОНЦЕ, чтобы не перехватывать другие роуты)
router.get('/:id', async (req, res) => {
    try {
        const editionId = parseInt(req.params.id);

        if (isNaN(editionId)) {
            return res.status(400).json({ error: 'Invalid edition ID' });
        }

        const edition = await db.Edition.findByPk(editionId, {
            include: [
                {
                    model: db.EditionName,
                    as: 'editionName',
                    attributes: ['id', 'name']
                },
                {
                    model: db.ProductCard,
                    as: 'productCard',
                    attributes: ['id', 'title', 'image', 'edition_type']
                },
                {
                    model: db.Currency,
                    as: 'currency',
                    attributes: ['id', 'code', 'name', 'symbol']
                },
                {
                    model: db.Currency,
                    as: 'displayCurrency',
                    attributes: ['id', 'code', 'name', 'symbol']
                },
                {
                    model: db.Platform,
                    as: 'platforms',
                    through: { attributes: [] },
                    attributes: ['id', 'name', 'logo_url']
                }
            ],
            attributes: [
                'id',
                'display_currency_id',
                'price',
                'discount_amount',
                'promotion_end_date',
                'ea_play_price',
                'ps_plus_price'
            ]
        });

        if (!edition) {
            return res.status(404).json({ error: 'Edition not found' });
        }

        // Добавляем поле convertedPrice для совместимости с фронтендом
        const response = edition.toJSON();
        response.convertedPrice = response.price;

        res.json(response);
    } catch (error) {
        console.error('Error fetching edition:', error);
        res.status(500).json({ error: 'Failed to fetch edition' });
    }
});

export default router;
