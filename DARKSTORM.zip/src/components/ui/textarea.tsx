import * as React from "react"

import { cn } from "@/lib/utils"

const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.ComponentProps<"textarea">
>(({ className, ...props }, ref) => {
  return (
    <textarea
      className={cn(
        "flex min-h-[120px] w-full rounded-lg border-2 border-zinc-700 bg-zinc-900/50 px-4 py-3 text-base text-zinc-100 shadow-sm transition-all duration-300 placeholder:text-zinc-500 focus-visible:outline-none focus-visible:border-cyan-500 focus-visible:shadow-[0_0_15px_rgba(0,255,255,0.2)] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm resize-none",
        className
      )}
      ref={ref}
      {...props}
    />
  )
})
Textarea.displayName = "Textarea"

export { Textarea }
