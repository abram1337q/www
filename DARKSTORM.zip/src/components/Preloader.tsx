"use client";

import { useEffect, useLayoutEffect, useState } from "react";

// Animated lightning bolt SVG
const LightningBolt = ({
  className,
  delay = 0,
}: { className?: string; delay?: number }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    className={className}
    style={{ animationDelay: `${delay}ms` }}
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth="0.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

// Electric arc SVG path
const ElectricArc = ({
  className,
  delay = 0,
}: { className?: string; delay?: number }) => (
  <svg
    viewBox="0 0 200 100"
    className={className}
    style={{ animationDelay: `${delay}ms` }}
  >
    <path
      d="M0,50 L20,45 L25,55 L40,48 L45,52 L60,46 L70,54 L85,47 L90,53 L105,49 L115,51 L130,48 L140,52 L155,47 L165,53 L180,49 L200,50"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      className="electric-arc-path"
    />
  </svg>
);

interface PreloaderProps {
  onComplete?: () => void;
}

export default function Preloader({ onComplete }: PreloaderProps) {
  const [progress, setProgress] = useState(0);
  const [isFadingOut, setIsFadingOut] = useState(false);

  // Block scroll immediately when preloader mounts
  useLayoutEffect(() => {
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = originalOverflow;
    };
  }, []);

  useEffect(() => {
    // Progress animation over 2 seconds
    const duration = 2000;
    const interval = 20;
    const steps = duration / interval;
    const increment = 100 / steps;

    let currentProgress = 0;
    const timer = setInterval(() => {
      currentProgress += increment;
      if (currentProgress >= 100) {
        currentProgress = 100;
        setProgress(100);
        clearInterval(timer);

        // Start fade out AFTER reaching 100%
        setTimeout(() => {
          setIsFadingOut(true);
          // Call onComplete after fade animation
          setTimeout(() => {
            onComplete?.();
          }, 500);
        }, 300); // Small delay to show 100%
      } else {
        setProgress(Math.min(currentProgress, 100));
      }
    }, interval);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div
      className={`preloader-container ${isFadingOut ? "preloader-fade-out" : ""}`}
    >
      {/* Dark storm background */}
      <div className="preloader-bg" />

      {/* Animated lightning bolts in background */}
      <div className="preloader-bolts">
        {/* Large background bolts */}
        <LightningBolt
          className="preloader-bolt preloader-bolt-1"
          delay={0}
        />
        <LightningBolt
          className="preloader-bolt preloader-bolt-2"
          delay={300}
        />
        <LightningBolt
          className="preloader-bolt preloader-bolt-3"
          delay={600}
        />
        <LightningBolt
          className="preloader-bolt preloader-bolt-4"
          delay={150}
        />
        <LightningBolt
          className="preloader-bolt preloader-bolt-5"
          delay={450}
        />
        <LightningBolt
          className="preloader-bolt preloader-bolt-6"
          delay={750}
        />
      </div>

      {/* Electric arcs */}
      <div className="preloader-arcs">
        <ElectricArc className="preloader-arc preloader-arc-1" delay={0} />
        <ElectricArc className="preloader-arc preloader-arc-2" delay={200} />
        <ElectricArc className="preloader-arc preloader-arc-3" delay={400} />
      </div>

      {/* Main content */}
      <div className="preloader-content">
        {/* Glowing orb behind logo */}
        <div className="preloader-glow-orb" />

        {/* Logo with lightning */}
        <div className="preloader-logo-container">
          <div className="preloader-logo-bolt preloader-logo-bolt-left">
            <LightningBolt className="w-full h-full" />
          </div>

          <div className="preloader-logo">
            <span className="preloader-logo-dark">DARK</span>
            <span className="preloader-logo-storm">STORM</span>
          </div>

          <div className="preloader-logo-bolt preloader-logo-bolt-right">
            <LightningBolt className="w-full h-full" />
          </div>
        </div>

        {/* Subtitle */}
        <div className="preloader-subtitle">
          PUBG MOBILE CLAN
        </div>

        {/* Progress bar */}
        <div className="preloader-progress-container">
          <div className="preloader-progress-track">
            <div
              className="preloader-progress-bar"
              style={{ width: `${progress}%` }}
            />
            <div
              className="preloader-progress-glow"
              style={{ left: `${progress}%` }}
            />
          </div>
          <div className="preloader-progress-text">
            {Math.round(progress)}%
          </div>
        </div>

        {/* Loading text */}
        <div className="preloader-loading-text">
          <span className="preloader-loading-dot">.</span>
          <span className="preloader-loading-dot" style={{ animationDelay: "200ms" }}>.</span>
          <span className="preloader-loading-dot" style={{ animationDelay: "400ms" }}>.</span>
          <span className="preloader-loading-word">ENTERING THE STORM</span>
          <span className="preloader-loading-dot" style={{ animationDelay: "600ms" }}>.</span>
          <span className="preloader-loading-dot" style={{ animationDelay: "800ms" }}>.</span>
          <span className="preloader-loading-dot" style={{ animationDelay: "1000ms" }}>.</span>
        </div>
      </div>

      {/* Screen flash effect */}
      <div className="preloader-flash" />
    </div>
  );
}
