// Mock data for the platform UI

export interface Clan {
  id: string;
  slug: string;
  name: string;
  tag: string;
  logo: string;
  banner: string;
  description: string;
  game: string;
  region: string;
  isRecruiting: boolean;
  rating: number;
  membersCount: number;
  maxMembers: number;
  createdAt: string;
  requirements: string[];
  achievements: string[];
  socialLinks: {
    discord?: string;
    telegram?: string;
    youtube?: string;
    twitch?: string;
  };
  members: ClanMember[];
}

export interface ClanMember {
  id: string;
  nickname: string;
  avatar: string;
  role: "leader" | "officer" | "member";
  joinedAt: string;
  stats: {
    kills: number;
    wins: number;
    kd: number;
  };
}

export interface Tournament {
  id: string;
  name: string;
  banner: string;
  game: string;
  format: string;
  status: "upcoming" | "registration" | "ongoing" | "finished";
  prizePool: string;
  currency: string;
  startDate: string;
  registrationEnd: string;
  description: string;
  rules: string;
  maxTeams: number;
  registeredTeams: number;
  streamUrl?: string;
  brackets?: TournamentBracket[];
  participants: TournamentParticipant[];
}

export interface TournamentBracket {
  round: number;
  matches: {
    id: string;
    team1: string;
    team2: string;
    score1?: number;
    score2?: number;
    winner?: string;
  }[];
}

export interface TournamentParticipant {
  id: string;
  name: string;
  logo: string;
  seed?: number;
}

export interface Notification {
  id: string;
  type: "tournament" | "clan" | "system" | "achievement";
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export interface UserProfile {
  id: string;
  nickname: string;
  avatar: string;
  email: string;
  telegram: string;
  gameId: string;
  clan?: {
    id: string;
    name: string;
    role: string;
    joinedAt: string;
  };
  stats: {
    tournamentsPlayed: number;
    wins: number;
    inClanSince?: string;
  };
  socialLinks: {
    discord?: string;
    telegram?: string;
    youtube?: string;
  };
}

// Mock Clans
export const mockClans: Clan[] = [
  {
    id: "1",
    slug: "darkstorm",
    name: "DARKSTORM",
    tag: "DS",
    logo: "https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=200&h=200&fit=crop",
    banner: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=1200&h=400&fit=crop",
    description: "Элитный клан для настоящих профессионалов PUBG Mobile. Мы не просто играем — мы доминируем на поле боя. Каждый матч — это возможность показать своё мастерство.",
    game: "PUBG Mobile",
    region: "СНГ",
    isRecruiting: true,
    rating: 2450,
    membersCount: 47,
    maxMembers: 50,
    createdAt: "2024-01-15",
    requirements: ["KD 3.0+", "Уровень 40+", "Микрофон", "Активность 3+ дня в неделю"],
    achievements: ["Чемпион сезона 2024", "Топ-3 регионального турнира", "100+ побед в скриммах"],
    socialLinks: {
      discord: "https://discord.gg/darkstorm",
      telegram: "https://t.me/darkstorm",
      youtube: "https://youtube.com/@darkstorm"
    },
    members: [
      { id: "1", nickname: "StormLeader", avatar: "https://i.pravatar.cc/100?img=1", role: "leader", joinedAt: "2024-01-15", stats: { kills: 15420, wins: 312, kd: 5.2 } },
      { id: "2", nickname: "ThunderBolt", avatar: "https://i.pravatar.cc/100?img=2", role: "officer", joinedAt: "2024-01-20", stats: { kills: 12300, wins: 245, kd: 4.8 } },
      { id: "3", nickname: "LightningFury", avatar: "https://i.pravatar.cc/100?img=3", role: "officer", joinedAt: "2024-02-01", stats: { kills: 11500, wins: 230, kd: 4.5 } },
      { id: "4", nickname: "DarkNinja", avatar: "https://i.pravatar.cc/100?img=4", role: "member", joinedAt: "2024-02-15", stats: { kills: 8900, wins: 180, kd: 3.8 } },
      { id: "5", nickname: "ShadowHunter", avatar: "https://i.pravatar.cc/100?img=5", role: "member", joinedAt: "2024-03-01", stats: { kills: 7600, wins: 155, kd: 3.5 } },
    ]
  },
  {
    id: "2",
    slug: "phoenix-rising",
    name: "Phoenix Rising",
    tag: "PHX",
    logo: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=200&h=200&fit=crop",
    banner: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&h=400&fit=crop",
    description: "Возрождаемся после каждого поражения сильнее. Клан для тех, кто не сдаётся и готов расти.",
    game: "PUBG Mobile",
    region: "Европа",
    isRecruiting: true,
    rating: 2280,
    membersCount: 38,
    maxMembers: 50,
    createdAt: "2023-11-20",
    requirements: ["KD 2.5+", "Уровень 35+", "Возраст 16+"],
    achievements: ["Финалисты весеннего кубка", "Топ-10 Европы"],
    socialLinks: {
      discord: "https://discord.gg/phoenix",
      telegram: "https://t.me/phoenix"
    },
    members: []
  },
  {
    id: "3",
    slug: "shadow-wolves",
    name: "Shadow Wolves",
    tag: "SHW",
    logo: "https://images.unsplash.com/photo-1546182990-dffeafbe841d?w=200&h=200&fit=crop",
    banner: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200&h=400&fit=crop",
    description: "Стая, которая охотится вместе. Тактика и координация — наши главные преимущества.",
    game: "PUBG Mobile",
    region: "СНГ",
    isRecruiting: false,
    rating: 2150,
    membersCount: 50,
    maxMembers: 50,
    createdAt: "2023-09-10",
    requirements: ["KD 3.5+", "Опыт турниров", "Conqueror ранг"],
    achievements: ["Чемпионы лиги 2023", "200+ побед"],
    socialLinks: {
      discord: "https://discord.gg/wolves"
    },
    members: []
  },
  {
    id: "4",
    slug: "cyber-dragons",
    name: "Cyber Dragons",
    tag: "CDR",
    logo: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=200&h=200&fit=crop",
    banner: "https://images.unsplash.com/photo-1493711662062-fa541f7f0cd9?w=1200&h=400&fit=crop",
    description: "Технологии + мастерство = победа. Современный подход к киберспорту.",
    game: "PUBG Mobile",
    region: "Азия",
    isRecruiting: true,
    rating: 2380,
    membersCount: 42,
    maxMembers: 50,
    createdAt: "2024-02-01",
    requirements: ["KD 2.8+", "Уровень 40+", "Знание английского"],
    achievements: ["Победители азиатского кубка"],
    socialLinks: {
      discord: "https://discord.gg/dragons",
      twitch: "https://twitch.tv/cyberdragons"
    },
    members: []
  },
  {
    id: "5",
    slug: "ice-titans",
    name: "Ice Titans",
    tag: "ICE",
    logo: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=200&h=200&fit=crop",
    banner: "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?w=1200&h=400&fit=crop",
    description: "Холодный расчёт и ледяная выдержка. Мы не паникуем под огнём.",
    game: "PUBG Mobile",
    region: "Европа",
    isRecruiting: true,
    rating: 2050,
    membersCount: 35,
    maxMembers: 50,
    createdAt: "2024-03-15",
    requirements: ["KD 2.0+", "Микрофон обязателен"],
    achievements: ["Новички сезона"],
    socialLinks: {
      telegram: "https://t.me/icetitans"
    },
    members: []
  },
  {
    id: "6",
    slug: "night-raiders",
    name: "Night Raiders",
    tag: "NTR",
    logo: "https://images.unsplash.com/photo-1507400492013-162706c8c05e?w=200&h=200&fit=crop",
    banner: "https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?w=1200&h=400&fit=crop",
    description: "Ночные рейды — наша стихия. Враги нас не видят, пока не станет слишком поздно.",
    game: "PUBG Mobile",
    region: "СНГ",
    isRecruiting: true,
    rating: 1980,
    membersCount: 28,
    maxMembers: 50,
    createdAt: "2024-04-01",
    requirements: ["KD 2.5+", "Активность вечером"],
    achievements: [],
    socialLinks: {
      discord: "https://discord.gg/raiders"
    },
    members: []
  }
];

// Mock Tournaments
export const mockTournaments: Tournament[] = [
  {
    id: "1",
    name: "DARKSTORM Championship 2024",
    banner: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&h=400&fit=crop",
    game: "PUBG Mobile",
    format: "Squad (4v4)",
    status: "registration",
    prizePool: "100,000",
    currency: "₽",
    startDate: "2024-02-15T18:00:00",
    registrationEnd: "2024-02-14T23:59:00",
    description: "Главный турнир сезона с крупнейшим призовым фондом. Докажите, что вы лучшие!",
    rules: "Стандартные правила PMPL. Матчи проводятся на карте Эрангель. Запрещены эмуляторы и читы.",
    maxTeams: 32,
    registeredTeams: 28,
    streamUrl: "https://twitch.tv/darkstorm",
    participants: [
      { id: "1", name: "DARKSTORM", logo: "https://i.pravatar.cc/50?img=1" },
      { id: "2", name: "Phoenix Rising", logo: "https://i.pravatar.cc/50?img=2" },
      { id: "3", name: "Shadow Wolves", logo: "https://i.pravatar.cc/50?img=3" },
    ],
    brackets: []
  },
  {
    id: "2",
    name: "Weekly Scrims #15",
    banner: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=1200&h=400&fit=crop",
    game: "PUBG Mobile",
    format: "Squad (4v4)",
    status: "upcoming",
    prizePool: "10,000",
    currency: "₽",
    startDate: "2024-02-10T20:00:00",
    registrationEnd: "2024-02-10T19:00:00",
    description: "Еженедельные скриммы для практики и рейтинга.",
    rules: "Карта по жребию. 3 матча.",
    maxTeams: 16,
    registeredTeams: 12,
    participants: [],
    brackets: []
  },
  {
    id: "3",
    name: "Pro League Season 5",
    banner: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200&h=400&fit=crop",
    game: "PUBG Mobile",
    format: "Squad (4v4)",
    status: "ongoing",
    prizePool: "500,000",
    currency: "₽",
    startDate: "2024-01-20T18:00:00",
    registrationEnd: "2024-01-19T23:59:00",
    description: "Профессиональная лига с лучшими командами региона.",
    rules: "Формат лиги. 6 туров по 6 матчей.",
    maxTeams: 20,
    registeredTeams: 20,
    streamUrl: "https://youtube.com/proleague",
    participants: [],
    brackets: []
  },
  {
    id: "4",
    name: "Rookie Cup",
    banner: "https://images.unsplash.com/photo-1493711662062-fa541f7f0cd9?w=1200&h=400&fit=crop",
    game: "PUBG Mobile",
    format: "Duo (2v2)",
    status: "registration",
    prizePool: "5,000",
    currency: "₽",
    startDate: "2024-02-20T19:00:00",
    registrationEnd: "2024-02-19T20:00:00",
    description: "Турнир для новичков. Отличный шанс получить опыт!",
    rules: "Только для игроков без опыта турниров.",
    maxTeams: 24,
    registeredTeams: 15,
    participants: [],
    brackets: []
  },
  {
    id: "5",
    name: "Night Battle Royale",
    banner: "https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?w=1200&h=400&fit=crop",
    game: "PUBG Mobile",
    format: "Squad (4v4)",
    status: "finished",
    prizePool: "25,000",
    currency: "₽",
    startDate: "2024-01-28T22:00:00",
    registrationEnd: "2024-01-27T23:59:00",
    description: "Ночной турнир с особыми правилами.",
    rules: "Только ночные карты.",
    maxTeams: 16,
    registeredTeams: 16,
    participants: [],
    brackets: []
  }
];

// Mock notifications
export const mockNotifications: Notification[] = [
  {
    id: "1",
    type: "tournament",
    title: "Регистрация открыта",
    message: "Регистрация на DARKSTORM Championship 2024 уже открыта!",
    read: false,
    createdAt: "2024-02-05T10:00:00"
  },
  {
    id: "2",
    type: "clan",
    title: "Новый участник",
    message: "ShadowHunter присоединился к вашему клану",
    read: false,
    createdAt: "2024-02-04T15:30:00"
  },
  {
    id: "3",
    type: "achievement",
    title: "Достижение разблокировано",
    message: "Вы получили достижение '10 побед в турнирах'",
    read: true,
    createdAt: "2024-02-03T20:00:00"
  },
  {
    id: "4",
    type: "system",
    title: "Обновление платформы",
    message: "Добавлены новые функции в личном кабинете",
    read: true,
    createdAt: "2024-02-01T12:00:00"
  }
];

// Mock user profile
export const mockUserProfile: UserProfile = {
  id: "1",
  nickname: "StormPlayer",
  avatar: "https://i.pravatar.cc/150?img=8",
  email: "player@darkstorm.gg",
  telegram: "@stormplayer",
  gameId: "5123456789",
  clan: {
    id: "1",
    name: "DARKSTORM",
    role: "member",
    joinedAt: "2024-01-20"
  },
  stats: {
    tournamentsPlayed: 15,
    wins: 4,
    inClanSince: "2024-01-20"
  },
  socialLinks: {
    discord: "StormPlayer#1234",
    telegram: "@stormplayer"
  }
};

// Platform stats
export const platformStats = {
  totalClans: 156,
  totalPlayers: 4782,
  totalTournaments: 89,
  activeTournaments: 5,
  totalPrizePool: "2,500,000 ₽"
};
