import Database from "better-sqlite3";
import path from "path";

const dbPath = path.join(process.cwd(), "clan.db");
const db = new Database(dbPath);

// Initialize database tables
db.exec(`
  CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nickname TEXT NOT NULL,
    game_id TEXT NOT NULL,
    telegram TEXT NOT NULL,
    age TEXT,
    experience TEXT,
    reason TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nickname TEXT NOT NULL,
    game_id TEXT NOT NULL,
    telegram TEXT NOT NULL,
    login TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    application_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES applications(id)
  );
`);

// Generate random login
export function generateLogin(): string {
  const prefix = "DS";
  const randomNum = Math.floor(Math.random() * 900000) + 100000;
  return `${prefix}${randomNum}`;
}

// Generate random password
export function generatePassword(): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let password = "";
  for (let i = 0; i < 10; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
}

// Application types
export interface Application {
  id: number;
  nickname: string;
  game_id: string;
  telegram: string;
  age: string | null;
  experience: string | null;
  reason: string;
  status: "pending" | "approved" | "rejected";
  created_at: string;
}

export interface Member {
  id: number;
  nickname: string;
  game_id: string;
  telegram: string;
  login: string;
  password: string;
  application_id: number | null;
  created_at: string;
}

// Application functions
export function createApplication(data: {
  nickname: string;
  game_id: string;
  telegram: string;
  age?: string;
  experience?: string;
  reason: string;
}): number {
  const stmt = db.prepare(`
    INSERT INTO applications (nickname, game_id, telegram, age, experience, reason)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const result = stmt.run(
    data.nickname,
    data.game_id,
    data.telegram,
    data.age || null,
    data.experience || null,
    data.reason
  );
  return result.lastInsertRowid as number;
}

export function getApplications(): Application[] {
  const stmt = db.prepare("SELECT * FROM applications ORDER BY created_at DESC");
  return stmt.all() as Application[];
}

export function getApplicationById(id: number): Application | undefined {
  const stmt = db.prepare("SELECT * FROM applications WHERE id = ?");
  return stmt.get(id) as Application | undefined;
}

export function updateApplicationStatus(id: number, status: "approved" | "rejected"): void {
  const stmt = db.prepare("UPDATE applications SET status = ? WHERE id = ?");
  stmt.run(status, id);
}

// Member functions
export function createMember(data: {
  nickname: string;
  game_id: string;
  telegram: string;
  login: string;
  password: string;
  application_id: number;
}): number {
  const stmt = db.prepare(`
    INSERT INTO members (nickname, game_id, telegram, login, password, application_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const result = stmt.run(
    data.nickname,
    data.game_id,
    data.telegram,
    data.login,
    data.password,
    data.application_id
  );
  return result.lastInsertRowid as number;
}

export function getMemberByLogin(login: string): Member | undefined {
  const stmt = db.prepare("SELECT * FROM members WHERE login = ?");
  return stmt.get(login) as Member | undefined;
}

export function getMemberByLoginAndPassword(login: string, password: string): Member | undefined {
  const stmt = db.prepare("SELECT * FROM members WHERE login = ? AND password = ?");
  return stmt.get(login, password) as Member | undefined;
}

export function updateMemberCredentials(
  oldLogin: string,
  oldPassword: string,
  newLogin: string,
  newPassword: string
): boolean {
  // First verify old credentials
  const member = getMemberByLoginAndPassword(oldLogin, oldPassword);
  if (!member) {
    return false;
  }

  // Check if new login already exists (if it's different from old)
  if (newLogin !== oldLogin) {
    const existing = getMemberByLogin(newLogin);
    if (existing) {
      return false;
    }
  }

  const stmt = db.prepare("UPDATE members SET login = ?, password = ? WHERE id = ?");
  stmt.run(newLogin, newPassword, member.id);
  return true;
}

export function getAllMembers(): Member[] {
  const stmt = db.prepare("SELECT * FROM members ORDER BY created_at DESC");
  return stmt.all() as Member[];
}

export default db;
