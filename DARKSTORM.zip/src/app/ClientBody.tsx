"use client";

import { useEffect, useState, useCallback } from "react";
import Preloader from "@/components/Preloader";

export default function ClientBody({
  children,
}: {
  children: React.ReactNode;
}) {
  const [showPreloader, setShowPreloader] = useState(true);

  // Remove any extension-added classes during hydration
  useEffect(() => {
    // This runs only on the client after hydration
    document.body.className = "antialiased";
  }, []);



  const handlePreloaderComplete = useCallback(() => {
    setShowPreloader(false);
  }, []);

  return (
    <div className="antialiased">
      {showPreloader && <Preloader onComplete={handlePreloaderComplete} />}
      {children}
    </div>
  );
}
