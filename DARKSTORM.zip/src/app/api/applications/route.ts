import { NextRequest, NextResponse } from "next/server";
import { createApplication, getApplications } from "@/lib/db";

// POST - Create new application
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { nickname, game_id, telegram, age, experience, reason } = body;

    if (!nickname || !game_id || !telegram || !reason) {
      return NextResponse.json(
        { error: "Заполните все обязательные поля" },
        { status: 400 }
      );
    }

    const id = createApplication({
      nickname,
      game_id,
      telegram,
      age,
      experience,
      reason,
    });

    return NextResponse.json({ success: true, id });
  } catch (error) {
    console.error("Error creating application:", error);
    return NextResponse.json(
      { error: "Ошибка при создании заявки" },
      { status: 500 }
    );
  }
}

// GET - Get all applications (for admin)
export async function GET(request: NextRequest) {
  try {
    // Simple admin check via query param (in production use proper auth)
    const { searchParams } = new URL(request.url);
    const adminKey = searchParams.get("key");

    if (adminKey !== "darkstorm2024") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const applications = getApplications();
    return NextResponse.json(applications);
  } catch (error) {
    console.error("Error fetching applications:", error);
    return NextResponse.json(
      { error: "Ошибка при получении заявок" },
      { status: 500 }
    );
  }
}
