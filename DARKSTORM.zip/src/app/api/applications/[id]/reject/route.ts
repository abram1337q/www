import { NextRequest, NextResponse } from "next/server";
import { getApplicationById, updateApplicationStatus } from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { adminKey } = body;

    if (adminKey !== "darkstorm2024") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const applicationId = Number.parseInt(id, 10);
    const application = getApplicationById(applicationId);

    if (!application) {
      return NextResponse.json(
        { error: "Заявка не найдена" },
        { status: 404 }
      );
    }

    if (application.status !== "pending") {
      return NextResponse.json(
        { error: "Заявка уже обработана" },
        { status: 400 }
      );
    }

    // Update application status
    updateApplicationStatus(applicationId, "rejected");

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error rejecting application:", error);
    return NextResponse.json(
      { error: "Ошибка при отклонении заявки" },
      { status: 500 }
    );
  }
}
