import { NextRequest, NextResponse } from "next/server";
import {
  getApplicationById,
  updateApplicationStatus,
  createMember,
  generateLogin,
  generatePassword,
} from "@/lib/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { adminKey } = body;

    if (adminKey !== "darkstorm2024") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const applicationId = Number.parseInt(id, 10);
    const application = getApplicationById(applicationId);

    if (!application) {
      return NextResponse.json(
        { error: "Заявка не найдена" },
        { status: 404 }
      );
    }

    if (application.status !== "pending") {
      return NextResponse.json(
        { error: "Заявка уже обработана" },
        { status: 400 }
      );
    }

    // Generate credentials
    const login = generateLogin();
    const password = generatePassword();

    // Create member
    createMember({
      nickname: application.nickname,
      game_id: application.game_id,
      telegram: application.telegram,
      login,
      password,
      application_id: applicationId,
    });

    // Update application status
    updateApplicationStatus(applicationId, "approved");

    return NextResponse.json({
      success: true,
      credentials: {
        login,
        password,
      },
      telegram: application.telegram,
    });
  } catch (error) {
    console.error("Error approving application:", error);
    return NextResponse.json(
      { error: "Ошибка при подтверждении заявки" },
      { status: 500 }
    );
  }
}
