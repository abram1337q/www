import { NextRequest, NextResponse } from "next/server";
import { updateMemberCredentials, getMemberByLogin } from "@/lib/db";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { oldLogin, oldPassword, newLogin, newPassword } = body;

    if (!oldLogin || !oldPassword || !newLogin || !newPassword) {
      return NextResponse.json(
        { error: "Заполните все поля" },
        { status: 400 }
      );
    }

    // Check if new login is taken (if different)
    if (newLogin !== oldLogin) {
      const existing = getMemberByLogin(newLogin);
      if (existing) {
        return NextResponse.json(
          { error: "Этот логин уже занят" },
          { status: 400 }
        );
      }
    }

    const success = updateMemberCredentials(
      oldLogin,
      oldPassword,
      newLogin,
      newPassword
    );

    if (!success) {
      return NextResponse.json(
        { error: "Неверный старый логин или пароль" },
        { status: 401 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Данные успешно обновлены",
    });
  } catch (error) {
    console.error("Error changing credentials:", error);
    return NextResponse.json(
      { error: "Ошибка при изменении данных" },
      { status: 500 }
    );
  }
}
