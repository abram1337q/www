"use client";

import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { LightningBolt } from "@/components/common/LightningBolt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { mockUserProfile } from "@/lib/mock-data";
import { useState } from "react";

export default function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    nickname: mockUserProfile.nickname,
    email: mockUserProfile.email,
    telegram: mockUserProfile.telegram,
    gameId: mockUserProfile.gameId,
    discord: mockUserProfile.socialLinks.discord || "",
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const handleSave = () => {
    setIsEditing(false);
    // Mock save
  };

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">Мой профиль</h1>
          <p className="text-zinc-400 mt-1">Управление персональными данными и настройками</p>
        </div>

        {/* Profile Card */}
        <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl overflow-hidden">
          {/* Banner */}
          <div className="h-32 bg-gradient-to-r from-cyan-500/20 via-cyan-600/10 to-transparent relative">
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 to-transparent" />
          </div>

          {/* Avatar & Info */}
          <div className="px-6 pb-6 -mt-12 relative">
            <div className="flex flex-col md:flex-row md:items-end gap-4">
              <div className="relative">
                <Avatar className="w-24 h-24 border-4 border-zinc-900 shadow-xl">
                  <AvatarImage src={mockUserProfile.avatar} />
                  <AvatarFallback className="text-2xl">{mockUserProfile.nickname[0]}</AvatarFallback>
                </Avatar>
                <button className="absolute bottom-0 right-0 w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-black hover:bg-cyan-400 transition-colors">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </button>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-white">{mockUserProfile.nickname}</h2>
                <div className="flex flex-wrap items-center gap-2 mt-1">
                  {mockUserProfile.clan && (
                    <Badge className="bg-cyan-500/20 text-cyan-400">{mockUserProfile.clan.name}</Badge>
                  )}
                  <Badge variant="secondary">ID: {mockUserProfile.gameId}</Badge>
                </div>
              </div>
              <Button onClick={() => setIsEditing(!isEditing)} variant={isEditing ? "ghost" : "outline"}>
                {isEditing ? "Отмена" : "Редактировать"}
              </Button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-zinc-900/30 border border-zinc-800 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-cyan-400">{mockUserProfile.stats.tournamentsPlayed}</div>
            <div className="text-sm text-zinc-500">Турниров сыграно</div>
          </div>
          <div className="bg-zinc-900/30 border border-zinc-800 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-green-400">{mockUserProfile.stats.wins}</div>
            <div className="text-sm text-zinc-500">Побед</div>
          </div>
          <div className="bg-zinc-900/30 border border-zinc-800 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-orange-400">
              {mockUserProfile.stats.inClanSince ? new Date(mockUserProfile.stats.inClanSince).toLocaleDateString('ru-RU', { month: 'short', year: 'numeric' }) : '-'}
            </div>
            <div className="text-sm text-zinc-500">В клане с</div>
          </div>
          <div className="bg-zinc-900/30 border border-zinc-800 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-white">
              {Math.round((mockUserProfile.stats.wins / mockUserProfile.stats.tournamentsPlayed) * 100)}%
            </div>
            <div className="text-sm text-zinc-500">Винрейт</div>
          </div>
        </div>

        {/* Profile Form */}
        <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-6">Личная информация</h3>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-2">Никнейм</label>
              <Input
                value={formData.nickname}
                onChange={(e) => setFormData({ ...formData, nickname: e.target.value })}
                disabled={!isEditing}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-2">Game ID</label>
              <Input
                value={formData.gameId}
                onChange={(e) => setFormData({ ...formData, gameId: e.target.value })}
                disabled={!isEditing}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-2">Email</label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                disabled={!isEditing}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-2">Telegram</label>
              <Input
                value={formData.telegram}
                onChange={(e) => setFormData({ ...formData, telegram: e.target.value })}
                disabled={!isEditing}
              />
            </div>
          </div>

          {isEditing && (
            <div className="mt-6">
              <Button onClick={handleSave}>
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Сохранить изменения
              </Button>
            </div>
          )}
        </div>

        {/* Social Links */}
        <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-6">Привязка соц. сетей</h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-zinc-800/30 rounded-xl">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-[#5865F2]/20 flex items-center justify-center">
                  <svg className="w-5 h-5 text-[#5865F2]" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20.317 4.492c-1.53-.69-3.17-1.2-4.885-1.49a.075.075 0 0 0-.079.036c-.21.369-.444.85-.608 1.23a18.566 18.566 0 0 0-5.487 0 12.36 12.36 0 0 0-.617-1.23A.077.077 0 0 0 8.562 3c-1.714.29-3.354.8-4.885 1.491a.07.07 0 0 0-.032.027C.533 9.093-.32 13.555.099 17.961a.08.08 0 0 0 .031.055 20.03 20.03 0 0 0 5.993 2.98.078.078 0 0 0 .084-.026c.462-.62.874-1.275 1.226-1.963.021-.04.001-.088-.041-.104a13.201 13.201 0 0 1-1.872-.878.075.075 0 0 1-.008-.125c.126-.093.252-.19.372-.287a.075.075 0 0 1 .078-.01c3.927 1.764 8.18 1.764 12.061 0a.075.075 0 0 1 .079.009c.12.098.245.195.372.288a.075.075 0 0 1-.006.125c-.598.344-1.22.635-1.873.877a.075.075 0 0 0-.041.105c.36.687.772 1.341 1.225 1.962a.077.077 0 0 0 .084.028 19.963 19.963 0 0 0 6.002-2.981.076.076 0 0 0 .032-.054c.5-5.094-.838-9.52-3.549-13.442a.06.06 0 0 0-.031-.028zM8.02 15.278c-1.182 0-2.157-1.069-2.157-2.38 0-1.312.956-2.38 2.157-2.38 1.21 0 2.176 1.077 2.157 2.38 0 1.312-.956 2.38-2.157 2.38zm7.975 0c-1.183 0-2.157-1.069-2.157-2.38 0-1.312.955-2.38 2.157-2.38 1.21 0 2.176 1.077 2.157 2.38 0 1.312-.946 2.38-2.157 2.38z"/>
                  </svg>
                </div>
                <div>
                  <div className="font-medium text-white">Discord</div>
                  <div className="text-sm text-zinc-500">{formData.discord || "Не привязан"}</div>
                </div>
              </div>
              <Button variant="outline" size="sm">
                {formData.discord ? "Изменить" : "Привязать"}
              </Button>
            </div>

            <div className="flex items-center justify-between p-4 bg-zinc-800/30 rounded-xl">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-[#0088cc]/20 flex items-center justify-center">
                  <svg className="w-5 h-5 text-[#0088cc]" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                  </svg>
                </div>
                <div>
                  <div className="font-medium text-white">Telegram</div>
                  <div className="text-sm text-zinc-500">{formData.telegram}</div>
                </div>
              </div>
              <Badge className="bg-green-500/20 text-green-400">Привязан</Badge>
            </div>

            <div className="flex items-center justify-between p-4 bg-zinc-800/30 rounded-xl">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-[#FF0000]/20 flex items-center justify-center">
                  <svg className="w-5 h-5 text-[#FF0000]" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                  </svg>
                </div>
                <div>
                  <div className="font-medium text-white">YouTube</div>
                  <div className="text-sm text-zinc-500">Не привязан</div>
                </div>
              </div>
              <Button variant="outline" size="sm">Привязать</Button>
            </div>
          </div>
        </div>

        {/* Change Password */}
        <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-6">Изменить пароль</h3>

          <div className="space-y-4 max-w-md">
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-2">Текущий пароль</label>
              <Input
                type="password"
                value={passwordData.currentPassword}
                onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                placeholder="Введите текущий пароль"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-2">Новый пароль</label>
              <Input
                type="password"
                value={passwordData.newPassword}
                onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                placeholder="Введите новый пароль"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-2">Подтвердите пароль</label>
              <Input
                type="password"
                value={passwordData.confirmPassword}
                onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                placeholder="Повторите новый пароль"
              />
            </div>
            <Button variant="outline">Изменить пароль</Button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
