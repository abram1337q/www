"use client";

import { useState } from "react";
import Link from "next/link";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { LightningBolt } from "@/components/common/LightningBolt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { mockUserProfile, mockClans, mockTournaments } from "@/lib/mock-data";

// Get user's clan data
const userClan = mockClans.find(c => c.id === mockUserProfile.clan?.id);

// Mock clan history
const clanHistory = [
  { id: "1", event: "Турнир DARKSTORM Championship", date: "2024-02-01", result: "1 место", points: 100 },
  { id: "2", event: "Weekly Scrims #14", date: "2024-01-28", result: "3 место", points: 50 },
  { id: "3", event: "Pro League Season 5 - Week 3", date: "2024-01-25", result: "Участие", points: 25 },
  { id: "4", event: "Weekly Scrims #13", date: "2024-01-21", result: "2 место", points: 75 },
  { id: "5", event: "Night Battle Royale", date: "2024-01-18", result: "1 место", points: 100 },
];

export default function DashboardClanPage() {
  const [isLeaveModalOpen, setIsLeaveModalOpen] = useState(false);

  // If user has no clan
  if (!userClan || !mockUserProfile.clan) {
    return (
      <DashboardLayout>
        <div className="max-w-4xl mx-auto">
          <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-12 text-center">
            <div className="w-20 h-20 bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-10 h-10 text-zinc-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Вы не состоите в клане</h2>
            <p className="text-zinc-400 mb-6 max-w-md mx-auto">
              Присоединитесь к одному из активных кланов, чтобы участвовать в турнирах и играть в команде
            </p>
            <Link href="/clans">
              <Button size="lg">
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                Найти клан
              </Button>
            </Link>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">Мой клан</h1>
          <p className="text-zinc-400 mt-1">Информация о клане и управление участием</p>
        </div>

        {/* Clan Card */}
        <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl overflow-hidden">
          {/* Banner */}
          <div className="h-40 relative overflow-hidden">
            <img
              src={userClan.banner}
              alt={userClan.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/50 to-transparent" />
          </div>

          {/* Info */}
          <div className="p-6 -mt-16 relative">
            <div className="flex flex-col md:flex-row gap-4 md:items-end">
              <div className="w-24 h-24 rounded-2xl border-4 border-zinc-900 overflow-hidden bg-zinc-800 shadow-xl">
                <img src={userClan.logo} alt={userClan.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <h2 className="text-2xl font-bold text-white">[{userClan.tag}] {userClan.name}</h2>
                  <Badge className="bg-cyan-500/20 text-cyan-400">{mockUserProfile.clan.role}</Badge>
                </div>
                <div className="flex flex-wrap items-center gap-4 text-sm text-zinc-400">
                  <span>{userClan.game}</span>
                  <span className="w-1 h-1 rounded-full bg-zinc-600" />
                  <span>{userClan.region}</span>
                  <span className="w-1 h-1 rounded-full bg-zinc-600" />
                  <span>В клане с {new Date(mockUserProfile.clan.joinedAt).toLocaleDateString('ru-RU')}</span>
                </div>
              </div>
              <div className="flex gap-3">
                <Link href={`/clans/${userClan.slug}`}>
                  <Button variant="outline">
                    <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                    Страница клана
                  </Button>
                </Link>
                <Button variant="outline" className="text-red-400 border-red-500/30 hover:bg-red-500/10" onClick={() => setIsLeaveModalOpen(true)}>
                  <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
                  Покинуть
                </Button>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-zinc-800">
              <div className="text-center p-4 bg-zinc-800/30 rounded-xl">
                <div className="text-2xl font-bold text-cyan-400">{userClan.rating}</div>
                <div className="text-sm text-zinc-500">Рейтинг</div>
              </div>
              <div className="text-center p-4 bg-zinc-800/30 rounded-xl">
                <div className="text-2xl font-bold text-white">{userClan.membersCount}</div>
                <div className="text-sm text-zinc-500">Участников</div>
              </div>
              <div className="text-center p-4 bg-zinc-800/30 rounded-xl">
                <div className="text-2xl font-bold text-green-400">{userClan.achievements.length}</div>
                <div className="text-sm text-zinc-500">Достижений</div>
              </div>
              <div className="text-center p-4 bg-zinc-800/30 rounded-xl">
                <div className="text-2xl font-bold text-orange-400">15</div>
                <div className="text-sm text-zinc-500">Турниров</div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="members" className="space-y-6">
          <TabsList className="bg-zinc-900/50 border border-zinc-800 p-1 w-full md:w-auto">
            <TabsTrigger value="members">Участники</TabsTrigger>
            <TabsTrigger value="history">История участия</TabsTrigger>
            <TabsTrigger value="achievements">Достижения</TabsTrigger>
          </TabsList>

          {/* Members Tab */}
          <TabsContent value="members">
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white">Участники клана</h3>
                <span className="text-sm text-zinc-500">{userClan.members.length} из {userClan.maxMembers}</span>
              </div>

              <div className="space-y-3">
                {userClan.members.map((member) => (
                  <div
                    key={member.id}
                    className={`flex items-center gap-4 p-4 rounded-xl transition-colors ${
                      member.nickname === mockUserProfile.nickname
                        ? 'bg-cyan-500/10 border border-cyan-500/30'
                        : 'bg-zinc-800/30 hover:bg-zinc-800/50'
                    }`}
                  >
                    <Avatar className="w-12 h-12 border-2 border-zinc-700">
                      <AvatarImage src={member.avatar} />
                      <AvatarFallback>{member.nickname[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white">{member.nickname}</span>
                        {member.nickname === mockUserProfile.nickname && (
                          <Badge variant="secondary" className="text-xs">Это вы</Badge>
                        )}
                        <Badge className={
                          member.role === 'leader' ? 'bg-yellow-500/20 text-yellow-400' :
                          member.role === 'officer' ? 'bg-cyan-500/20 text-cyan-400' :
                          'bg-zinc-500/20 text-zinc-400'
                        }>
                          {member.role === 'leader' ? 'Лидер' : member.role === 'officer' ? 'Офицер' : 'Участник'}
                        </Badge>
                      </div>
                      <div className="text-sm text-zinc-500">
                        В клане с {new Date(member.joinedAt).toLocaleDateString('ru-RU')}
                      </div>
                    </div>
                    <div className="hidden md:flex items-center gap-6 text-sm">
                      <div className="text-center">
                        <div className="font-bold text-white">{member.stats.kills.toLocaleString()}</div>
                        <div className="text-zinc-500">киллов</div>
                      </div>
                      <div className="text-center">
                        <div className="font-bold text-green-400">{member.stats.wins}</div>
                        <div className="text-zinc-500">побед</div>
                      </div>
                      <div className="text-center">
                        <div className="font-bold text-cyan-400">{member.stats.kd}</div>
                        <div className="text-zinc-500">K/D</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-6">История участия в турнирах</h3>

              <div className="space-y-4">
                {clanHistory.map((item) => (
                  <div key={item.id} className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      item.result === '1 место' ? 'bg-yellow-500/20' :
                      item.result === '2 место' ? 'bg-zinc-400/20' :
                      item.result === '3 место' ? 'bg-orange-500/20' :
                      'bg-zinc-700/50'
                    }`}>
                      {item.result === '1 место' ? (
                        <svg className="w-6 h-6 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                        </svg>
                      ) : item.result === '2 место' ? (
                        <span className="text-lg font-bold text-zinc-300">2</span>
                      ) : item.result === '3 место' ? (
                        <span className="text-lg font-bold text-orange-400">3</span>
                      ) : (
                        <LightningBolt className="w-5 h-5 text-zinc-500" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-white">{item.event}</div>
                      <div className="text-sm text-zinc-500">
                        {new Date(item.date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })}
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className={
                        item.result === '1 место' ? 'bg-yellow-500/20 text-yellow-400' :
                        item.result === '2 место' ? 'bg-zinc-400/20 text-zinc-300' :
                        item.result === '3 место' ? 'bg-orange-500/20 text-orange-400' :
                        'bg-zinc-500/20 text-zinc-400'
                      }>
                        {item.result}
                      </Badge>
                      <div className="text-sm text-cyan-400 mt-1">+{item.points} очков</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-zinc-800 flex items-center justify-between">
                <div className="text-zinc-400">Всего очков заработано</div>
                <div className="text-2xl font-bold text-cyan-400">
                  {clanHistory.reduce((sum, item) => sum + item.points, 0)}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements">
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-6">Достижения клана</h3>

              {userClan.achievements.length > 0 ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {userClan.achievements.map((achievement, index) => (
                    <div key={index} className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl border border-zinc-700/50">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-500/20 to-orange-500/20 flex items-center justify-center">
                        <svg className="w-6 h-6 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                        </svg>
                      </div>
                      <span className="font-medium text-white">{achievement}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-zinc-500">
                  Пока нет достижений
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Leave Clan Modal */}
      <Dialog open={isLeaveModalOpen} onOpenChange={setIsLeaveModalOpen}>
        <DialogContent className="bg-zinc-900 border-zinc-800 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-white">
              Покинуть клан?
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <p className="text-zinc-400">
              Вы уверены, что хотите покинуть клан <span className="text-white font-semibold">{userClan.name}</span>?
            </p>

            <div className="bg-zinc-800/50 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <svg className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <div className="text-sm text-zinc-400">
                  После выхода из клана вам придётся снова подавать заявку, если захотите вернуться
                </div>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setIsLeaveModalOpen(false)}>
                Отмена
              </Button>
              <Button className="flex-1 bg-red-500 hover:bg-red-600">
                Покинуть клан
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
