"use client";

import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { LightningBolt } from "@/components/common/LightningBolt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { mockUserProfile, mockClans, mockTournaments, mockNotifications, platformStats } from "@/lib/mock-data";
import Link from "next/link";
import { useState, useEffect } from "react";

// Stat card component
const StatCard = ({
  icon,
  value,
  label,
  trend
}: {
  icon: React.ReactNode;
  value: string;
  label: string;
  trend?: { value: string; positive: boolean }
}) => (
  <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 hover:border-cyan-500/30 transition-all group">
    <div className="flex items-start justify-between mb-3">
      <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      {trend && (
        <span className={`text-xs font-medium ${trend.positive ? 'text-green-400' : 'text-red-400'}`}>
          {trend.positive ? '+' : ''}{trend.value}
        </span>
      )}
    </div>
    <div className="text-2xl font-bold text-white mb-1">{value}</div>
    <div className="text-sm text-zinc-500">{label}</div>
  </div>
);

// Top clan card
const TopClanCard = ({ clan, rank }: { clan: typeof mockClans[0]; rank: number }) => (
  <Link
    href={`/clans/${clan.slug}`}
    className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl hover:bg-zinc-800/50 transition-all group"
  >
    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
      rank === 1 ? 'bg-yellow-500/20 text-yellow-400' :
      rank === 2 ? 'bg-zinc-400/20 text-zinc-300' :
      rank === 3 ? 'bg-orange-500/20 text-orange-400' :
      'bg-zinc-700/50 text-zinc-400'
    }`}>
      #{rank}
    </div>
    <div className="w-10 h-10 rounded-full overflow-hidden bg-zinc-700">
      <img src={clan.logo} alt={clan.name} className="w-full h-full object-cover" />
    </div>
    <div className="flex-1 min-w-0">
      <div className="font-semibold text-white group-hover:text-cyan-400 transition-colors truncate">
        [{clan.tag}] {clan.name}
      </div>
      <div className="text-xs text-zinc-500">{clan.membersCount} участников</div>
    </div>
    <div className="text-right">
      <div className="text-cyan-400 font-bold">{clan.rating}</div>
      <div className="text-xs text-zinc-500">рейтинг</div>
    </div>
  </Link>
);

// Tournament carousel card
const TournamentCard = ({ tournament }: { tournament: typeof mockTournaments[0] }) => {
  const statusColors = {
    upcoming: 'bg-blue-500/20 text-blue-400',
    registration: 'bg-green-500/20 text-green-400',
    ongoing: 'bg-orange-500/20 text-orange-400',
    finished: 'bg-zinc-500/20 text-zinc-400',
  };

  const statusLabels = {
    upcoming: 'Скоро',
    registration: 'Регистрация',
    ongoing: 'Идёт',
    finished: 'Завершён',
  };

  return (
    <Link
      href={`/tournaments/${tournament.id}`}
      className="flex-shrink-0 w-72 bg-zinc-900/50 border border-zinc-800 rounded-2xl overflow-hidden hover:border-cyan-500/30 transition-all group"
    >
      <div className="relative h-32 overflow-hidden">
        <img src={tournament.banner} alt={tournament.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 to-transparent" />
        <Badge className={`absolute top-3 right-3 ${statusColors[tournament.status]}`}>
          {statusLabels[tournament.status]}
        </Badge>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-white mb-2 truncate group-hover:text-cyan-400 transition-colors">
          {tournament.name}
        </h3>
        <div className="flex items-center justify-between text-sm">
          <span className="text-zinc-500">{tournament.format}</span>
          <span className="text-cyan-400 font-semibold">{tournament.prizePool} {tournament.currency}</span>
        </div>
        <div className="flex items-center gap-2 mt-3 text-xs text-zinc-500">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          {tournament.registeredTeams}/{tournament.maxTeams} команд
        </div>
      </div>
    </Link>
  );
};

// Notification item
const NotificationItem = ({ notification }: { notification: typeof mockNotifications[0] }) => {
  const typeIcons = {
    tournament: <LightningBolt className="w-4 h-4" />,
    clan: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
    system: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
    achievement: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
      </svg>
    ),
  };

  const typeColors = {
    tournament: 'bg-cyan-500/20 text-cyan-400',
    clan: 'bg-green-500/20 text-green-400',
    system: 'bg-blue-500/20 text-blue-400',
    achievement: 'bg-yellow-500/20 text-yellow-400',
  };

  return (
    <div className={`flex items-start gap-3 p-3 rounded-xl ${!notification.read ? 'bg-zinc-800/50' : ''}`}>
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${typeColors[notification.type]}`}>
        {typeIcons[notification.type]}
      </div>
      <div className="flex-1 min-w-0">
        <div className={`text-sm font-medium ${!notification.read ? 'text-white' : 'text-zinc-400'}`}>
          {notification.title}
        </div>
        <div className="text-xs text-zinc-500 truncate">{notification.message}</div>
      </div>
      {!notification.read && (
        <div className="w-2 h-2 rounded-full bg-cyan-400 mt-2" />
      )}
    </div>
  );
};

export default function DashboardPage() {
  const [currentTournamentIndex, setCurrentTournamentIndex] = useState(0);
  const activeTournaments = mockTournaments.filter(t => t.status !== 'finished');
  const topClans = [...mockClans].sort((a, b) => b.rating - a.rating).slice(0, 5);
  const unreadNotifications = mockNotifications.filter(n => !n.read);

  // Get current hour for greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 6) return "Доброй ночи";
    if (hour < 12) return "Доброе утро";
    if (hour < 18) return "Добрый день";
    return "Добрый вечер";
  };

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Welcome section */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16 border-2 border-cyan-500/50">
              <AvatarImage src={mockUserProfile.avatar} />
              <AvatarFallback className="text-xl">{mockUserProfile.nickname[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-white">
                {getGreeting()}, <span className="text-cyan-400">{mockUserProfile.nickname}</span>!
              </h1>
              <p className="text-zinc-400 mt-1">
                {mockUserProfile.clan ? (
                  <>Участник клана <Link href="/dashboard/clan" className="text-cyan-400 hover:underline">{mockUserProfile.clan.name}</Link></>
                ) : (
                  "Добро пожаловать на платформу"
                )}
              </p>
            </div>
          </div>
          <div className="flex gap-3">
            <Link href="/clans">
              <Button variant="outline">
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                Найти клан
              </Button>
            </Link>
            <Link href="/tournaments">
              <Button>
                <LightningBolt className="w-4 h-4 mr-2" />
                Турниры
              </Button>
            </Link>
          </div>
        </div>

        {/* Platform Statistics */}
        <div>
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            Статистика платформы
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard
              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg>}
              value={platformStats.totalClans.toString()}
              label="Кланов"
              trend={{ value: "12", positive: true }}
            />
            <StatCard
              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>}
              value={platformStats.totalPlayers.toLocaleString()}
              label="Игроков"
              trend={{ value: "156", positive: true }}
            />
            <StatCard
              icon={<LightningBolt className="w-5 h-5" />}
              value={platformStats.totalTournaments.toString()}
              label="Турниров проведено"
            />
            <StatCard
              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
              value={platformStats.totalPrizePool}
              label="Общий призовой фонд"
            />
          </div>
        </div>

        {/* Main content grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left column - Top Clans */}
          <div className="lg:col-span-2 space-y-8">
            {/* Top 5 Clans */}
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <svg className="w-5 h-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                  </svg>
                  Топ-5 кланов
                </h2>
                <Link href="/clans" className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors">
                  Все кланы
                </Link>
              </div>
              <div className="space-y-2">
                {topClans.map((clan, index) => (
                  <TopClanCard key={clan.id} clan={clan} rank={index + 1} />
                ))}
              </div>
            </div>

            {/* Upcoming Tournaments Carousel */}
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <LightningBolt className="w-5 h-5 text-cyan-400" />
                  Ближайшие турниры
                </h2>
                <Link href="/tournaments" className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors">
                  Все турниры
                </Link>
              </div>
              <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
                {activeTournaments.map((tournament) => (
                  <TournamentCard key={tournament.id} tournament={tournament} />
                ))}
              </div>
            </div>
          </div>

          {/* Right column */}
          <div className="space-y-6">
            {/* My Clan Quick View */}
            {mockUserProfile.clan && (
              <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-5">
                <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-4">Мой клан</h3>
                <Link href="/dashboard/clan" className="flex items-center gap-3 hover:bg-zinc-800/30 -mx-2 px-2 py-2 rounded-xl transition-colors">
                  <div className="w-12 h-12 rounded-xl overflow-hidden bg-zinc-700">
                    <img src={mockClans[0].logo} alt={mockUserProfile.clan.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-white">{mockUserProfile.clan.name}</div>
                    <div className="text-xs text-zinc-500">
                      <Badge variant="secondary" className="text-[10px]">{mockUserProfile.clan.role}</Badge>
                    </div>
                  </div>
                  <svg className="w-5 h-5 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
                <div className="grid grid-cols-2 gap-3 mt-4">
                  <div className="bg-zinc-800/50 rounded-xl p-3 text-center">
                    <div className="text-lg font-bold text-cyan-400">{mockClans[0].membersCount}</div>
                    <div className="text-xs text-zinc-500">участников</div>
                  </div>
                  <div className="bg-zinc-800/50 rounded-xl p-3 text-center">
                    <div className="text-lg font-bold text-cyan-400">{mockClans[0].rating}</div>
                    <div className="text-xs text-zinc-500">рейтинг</div>
                  </div>
                </div>
              </div>
            )}

            {/* Active Tournaments */}
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-4">Мои турниры</h3>
              {mockTournaments.filter(t => t.status === 'ongoing' || t.status === 'registration').length > 0 ? (
                <div className="space-y-3">
                  {mockTournaments.filter(t => t.status === 'ongoing' || t.status === 'registration').slice(0, 2).map(tournament => (
                    <Link
                      key={tournament.id}
                      href={`/tournaments/${tournament.id}`}
                      className="block p-3 bg-zinc-800/30 rounded-xl hover:bg-zinc-800/50 transition-colors"
                    >
                      <div className="font-medium text-white text-sm truncate">{tournament.name}</div>
                      <div className="flex items-center justify-between mt-2">
                        <Badge className={tournament.status === 'ongoing' ? 'bg-orange-500/20 text-orange-400' : 'bg-green-500/20 text-green-400'}>
                          {tournament.status === 'ongoing' ? 'Идёт' : 'Регистрация'}
                        </Badge>
                        <span className="text-xs text-zinc-500">{tournament.format}</span>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <div className="text-zinc-500 text-sm mb-3">Вы пока не участвуете в турнирах</div>
                  <Link href="/tournaments">
                    <Button size="sm" variant="outline">Найти турнир</Button>
                  </Link>
                </div>
              )}
            </div>

            {/* Notifications */}
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">Уведомления</h3>
                {unreadNotifications.length > 0 && (
                  <Badge>{unreadNotifications.length} новых</Badge>
                )}
              </div>
              <div className="space-y-2">
                {mockNotifications.slice(0, 3).map(notification => (
                  <NotificationItem key={notification.id} notification={notification} />
                ))}
              </div>
              <Link
                href="/dashboard/notifications"
                className="block text-center text-sm text-cyan-400 hover:text-cyan-300 transition-colors mt-4 pt-4 border-t border-zinc-800"
              >
                Все уведомления
              </Link>
            </div>

            {/* Quick Actions */}
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-4">Быстрые действия</h3>
              <div className="space-y-2">
                <Link href="/dashboard/profile" className="flex items-center gap-3 p-3 bg-zinc-800/30 rounded-xl hover:bg-zinc-800/50 transition-colors">
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                    </svg>
                  </div>
                  <span className="text-sm text-zinc-300">Редактировать профиль</span>
                </Link>
                <Link href="/clans" className="flex items-center gap-3 p-3 bg-zinc-800/30 rounded-xl hover:bg-zinc-800/50 transition-colors">
                  <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center text-green-400">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  </div>
                  <span className="text-sm text-zinc-300">Найти клан</span>
                </Link>
                <Link href="/tournaments" className="flex items-center gap-3 p-3 bg-zinc-800/30 rounded-xl hover:bg-zinc-800/50 transition-colors">
                  <div className="w-8 h-8 rounded-lg bg-orange-500/20 flex items-center justify-center text-orange-400">
                    <LightningBolt className="w-4 h-4" />
                  </div>
                  <span className="text-sm text-zinc-300">Участвовать в турнире</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
