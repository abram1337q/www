"use client";

import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { LightningBolt } from "@/components/common/LightningBolt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

// Extended mock notifications
const initialNotifications = [
  {
    id: "1",
    type: "tournament" as const,
    title: "Регистрация открыта",
    message: "Регистрация на DARKSTORM Championship 2024 уже открыта! Не упустите свой шанс принять участие в главном турнире сезона.",
    read: false,
    createdAt: "2024-02-05T10:00:00",
    link: "/tournaments/1"
  },
  {
    id: "2",
    type: "clan" as const,
    title: "Новый участник",
    message: "ShadowHunter присоединился к вашему клану DARKSTORM. Поприветствуйте нового бойца!",
    read: false,
    createdAt: "2024-02-04T15:30:00",
    link: "/dashboard/clan"
  },
  {
    id: "3",
    type: "achievement" as const,
    title: "Достижение разблокировано",
    message: "Поздравляем! Вы получили достижение '10 побед в турнирах'. Так держать!",
    read: true,
    createdAt: "2024-02-03T20:00:00"
  },
  {
    id: "4",
    type: "system" as const,
    title: "Обновление платформы",
    message: "Мы добавили новые функции в личном кабинете: улучшенная статистика, новые фильтры и многое другое.",
    read: true,
    createdAt: "2024-02-01T12:00:00"
  },
  {
    id: "5",
    type: "tournament" as const,
    title: "Турнир скоро начнётся",
    message: "Weekly Scrims #15 начнётся через 24 часа. Убедитесь, что ваша команда готова!",
    read: false,
    createdAt: "2024-02-09T18:00:00",
    link: "/tournaments/2"
  },
  {
    id: "6",
    type: "clan" as const,
    title: "Заявка в клан",
    message: "Игрок ProSniper подал заявку на вступление в ваш клан. Рассмотрите заявку.",
    read: true,
    createdAt: "2024-02-02T09:15:00",
    link: "/admin"
  },
  {
    id: "7",
    type: "achievement" as const,
    title: "Новое достижение доступно",
    message: "Вы близки к получению достижения 'Серийный победитель'. Осталось выиграть ещё 2 турнира подряд!",
    read: true,
    createdAt: "2024-01-30T14:20:00"
  },
  {
    id: "8",
    type: "system" as const,
    title: "Техническое обслуживание",
    message: "Запланировано техническое обслуживание серверов 15 февраля с 03:00 до 05:00 МСК.",
    read: true,
    createdAt: "2024-01-28T10:00:00"
  },
  {
    id: "9",
    type: "tournament" as const,
    title: "Результаты турнира",
    message: "Night Battle Royale завершён! Ваша команда заняла 1 место. Призовые будут начислены в течение 24 часов.",
    read: true,
    createdAt: "2024-01-28T23:30:00"
  },
  {
    id: "10",
    type: "clan" as const,
    title: "Рейтинг клана обновлён",
    message: "Ваш клан DARKSTORM поднялся на 2 позиции в общем рейтинге! Текущая позиция: #1",
    read: true,
    createdAt: "2024-01-27T16:45:00"
  }
];

const filterOptions = [
  { key: "all", label: "Все", color: "cyan" },
  { key: "tournament", label: "Турниры", color: "cyan" },
  { key: "clan", label: "Клан", color: "green" },
  { key: "achievement", label: "Достижения", color: "yellow" },
  { key: "system", label: "Система", color: "blue" },
];

const NotificationIcon = ({ type }: { type: string }) => {
  switch (type) {
    case "tournament":
      return <LightningBolt className="w-5 h-5" />;
    case "clan":
      return (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      );
    case "achievement":
      return (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
        </svg>
      );
    case "system":
      return (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      );
    default:
      return <LightningBolt className="w-5 h-5" />;
  }
};

const typeColors: Record<string, string> = {
  tournament: 'bg-cyan-500/20 text-cyan-400',
  clan: 'bg-green-500/20 text-green-400',
  achievement: 'bg-yellow-500/20 text-yellow-400',
  system: 'bg-blue-500/20 text-blue-400',
};

const typeLabels: Record<string, string> = {
  tournament: 'Турнир',
  clan: 'Клан',
  achievement: 'Достижение',
  system: 'Система',
};

export default function DashboardNotificationsPage() {
  const [notifications, setNotifications] = useState(initialNotifications);
  const [activeFilter, setActiveFilter] = useState("all");

  const unreadCount = notifications.filter(n => !n.read).length;

  const filteredNotifications = notifications.filter(n =>
    activeFilter === "all" || n.type === activeFilter
  );

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  const markAsRead = (id: string) => {
    setNotifications(notifications.map(n =>
      n.id === id ? { ...n, read: true } : n
    ));
  };

  const deleteNotification = (id: string) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor(diff / (1000 * 60));

    if (minutes < 60) return `${minutes} мин. назад`;
    if (hours < 24) return `${hours} ч. назад`;
    if (days < 7) return `${days} дн. назад`;
    return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
  };

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-white flex items-center gap-3">
              Уведомления
              {unreadCount > 0 && (
                <Badge className="bg-cyan-500 text-black">{unreadCount} новых</Badge>
              )}
            </h1>
            <p className="text-zinc-400 mt-1">Все ваши уведомления в одном месте</p>
          </div>
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllAsRead}>
              <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Прочитать все
            </Button>
          )}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2">
          {filterOptions.map((filter) => (
            <button
              key={filter.key}
              onClick={() => setActiveFilter(filter.key)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                activeFilter === filter.key
                  ? `bg-${filter.color}-500/20 text-${filter.color}-400 border border-${filter.color}-500/30`
                  : 'bg-zinc-800/50 text-zinc-400 border border-zinc-700 hover:border-zinc-600'
              }`}
            >
              {filter.label}
              {filter.key !== "all" && (
                <span className="ml-2 text-xs opacity-60">
                  ({notifications.filter(n => n.type === filter.key).length})
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Notifications List */}
        <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl overflow-hidden">
          {filteredNotifications.length > 0 ? (
            <div className="divide-y divide-zinc-800">
              {filteredNotifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 md:p-5 transition-all hover:bg-zinc-800/30 ${
                    !notification.read ? 'bg-zinc-800/20' : ''
                  }`}
                >
                  <div className="flex gap-4">
                    {/* Icon */}
                    <div className={`flex-shrink-0 w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center ${typeColors[notification.type]}`}>
                      <NotificationIcon type={notification.type} />
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-start gap-2 mb-1">
                        <h3 className={`font-semibold ${!notification.read ? 'text-white' : 'text-zinc-300'}`}>
                          {notification.title}
                        </h3>
                        <Badge variant="secondary" className={`text-xs ${typeColors[notification.type]}`}>
                          {typeLabels[notification.type]}
                        </Badge>
                        {!notification.read && (
                          <span className="w-2 h-2 rounded-full bg-cyan-400 mt-2" />
                        )}
                      </div>
                      <p className={`text-sm mb-2 ${!notification.read ? 'text-zinc-300' : 'text-zinc-500'}`}>
                        {notification.message}
                      </p>
                      <div className="flex flex-wrap items-center gap-4 text-xs text-zinc-500">
                        <span>{formatDate(notification.createdAt)}</span>
                        {notification.link && (
                          <a href={notification.link} className="text-cyan-400 hover:text-cyan-300 transition-colors">
                            Подробнее
                          </a>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex-shrink-0 flex items-start gap-2">
                      {!notification.read && (
                        <button
                          onClick={() => markAsRead(notification.id)}
                          className="p-2 rounded-lg text-zinc-500 hover:text-cyan-400 hover:bg-zinc-800 transition-colors"
                          title="Отметить как прочитанное"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </button>
                      )}
                      <button
                        onClick={() => deleteNotification(notification.id)}
                        className="p-2 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-zinc-800 transition-colors"
                        title="Удалить"
                      >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-12 text-center">
              <div className="w-16 h-16 bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-zinc-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Нет уведомлений</h3>
              <p className="text-zinc-400">
                {activeFilter === "all"
                  ? "У вас пока нет уведомлений"
                  : `Нет уведомлений в категории "${filterOptions.find(f => f.key === activeFilter)?.label}"`}
              </p>
            </div>
          )}
        </div>

        {/* Summary */}
        {notifications.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-4 text-sm text-zinc-500">
            <span>
              Всего уведомлений: {notifications.length}
            </span>
            {notifications.length > 0 && (
              <button
                onClick={() => setNotifications([])}
                className="text-red-400 hover:text-red-300 transition-colors"
              >
                Очистить все
              </button>
            )}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
