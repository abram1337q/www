"use client";

import { useState } from "react";
import Link from "next/link";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { LightningBolt } from "@/components/common/LightningBolt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { mockTournaments } from "@/lib/mock-data";

// Mock user tournament data
const userActiveTournaments = mockTournaments.filter(t => t.status === 'registration' || t.status === 'ongoing').slice(0, 2);
const userTournamentHistory = [
  { id: "1", name: "Night Battle Royale", date: "2024-01-28", placement: 1, prize: "12,500 ₽", kills: 24, points: 156 },
  { id: "2", name: "Weekly Scrims #14", date: "2024-01-21", placement: 3, prize: "2,500 ₽", kills: 18, points: 98 },
  { id: "3", name: "Pro League Season 4 - Week 6", date: "2024-01-14", placement: 5, prize: "-", kills: 15, points: 72 },
  { id: "4", name: "Weekly Scrims #13", date: "2024-01-07", placement: 2, prize: "5,000 ₽", kills: 21, points: 112 },
  { id: "5", name: "New Year Championship", date: "2024-01-01", placement: 8, prize: "-", kills: 12, points: 45 },
];

const userAchievements = [
  { id: "1", name: "Первая кровь", description: "Выиграй свой первый турнир", icon: "trophy", unlocked: true, date: "2024-01-28" },
  { id: "2", name: "Снайпер", description: "Набери 20+ киллов в одном турнире", icon: "target", unlocked: true, date: "2024-01-28" },
  { id: "3", name: "Серийный победитель", description: "Выиграй 3 турнира подряд", icon: "fire", unlocked: false, progress: "1/3" },
  { id: "4", name: "Ветеран", description: "Участвуй в 20 турнирах", icon: "medal", unlocked: true, date: "2024-02-01" },
  { id: "5", name: "Призовой охотник", description: "Заработай 50,000₽ призовых", icon: "coins", unlocked: false, progress: "20,000/50,000" },
  { id: "6", name: "Командный игрок", description: "Сыграй 50 турниров с командой", icon: "users", unlocked: false, progress: "15/50" },
];

// Icon component
const AchievementIcon = ({ icon, unlocked }: { icon: string; unlocked: boolean }) => {
  const baseClasses = `w-8 h-8 ${unlocked ? 'text-cyan-400' : 'text-zinc-600'}`;

  switch (icon) {
    case "trophy":
      return (
        <svg className={baseClasses} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
        </svg>
      );
    case "target":
      return (
        <svg className={baseClasses} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      );
    case "fire":
      return (
        <svg className={baseClasses} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.879 16.121A3 3 0 1012.015 11L11 14H9c0 .768.293 1.536.879 2.121z" />
        </svg>
      );
    case "medal":
      return (
        <svg className={baseClasses} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
        </svg>
      );
    case "coins":
      return (
        <svg className={baseClasses} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      );
    case "users":
      return (
        <svg className={baseClasses} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      );
    default:
      return <LightningBolt className={baseClasses} />;
  }
};

// Tournament Card for active tournaments
const ActiveTournamentCard = ({ tournament }: { tournament: typeof mockTournaments[0] }) => {
  const statusColors: Record<string, string> = {
    registration: 'bg-green-500/20 text-green-400 border-green-500/30',
    ongoing: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  };

  const statusLabels: Record<string, string> = {
    registration: 'Регистрация',
    ongoing: 'Идёт сейчас',
  };

  return (
    <Link
      href={`/tournaments/${tournament.id}`}
      className="group bg-zinc-900/50 border border-zinc-800 rounded-2xl overflow-hidden hover:border-cyan-500/30 transition-all"
    >
      <div className="relative h-32 overflow-hidden">
        <img
          src={tournament.banner}
          alt={tournament.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/50 to-transparent" />
        <Badge className={`absolute top-3 right-3 ${statusColors[tournament.status]}`}>
          {statusLabels[tournament.status]}
        </Badge>
        <div className="absolute bottom-3 left-3">
          <div className="text-xl font-bold text-cyan-400">{tournament.prizePool} {tournament.currency}</div>
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-white group-hover:text-cyan-400 transition-colors mb-2 truncate">
          {tournament.name}
        </h3>
        <div className="flex items-center gap-4 text-sm text-zinc-500">
          <span>{tournament.game}</span>
          <span className="w-1 h-1 rounded-full bg-zinc-600" />
          <span>{tournament.format}</span>
        </div>
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-zinc-800">
          <div className="flex items-center gap-2 text-sm text-zinc-400">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            {new Date(tournament.startDate).toLocaleDateString('ru-RU')}
          </div>
          <div className="flex items-center gap-2 text-sm text-zinc-400">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            {tournament.registeredTeams}/{tournament.maxTeams}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default function DashboardTournamentsPage() {
  const totalPrize = userTournamentHistory
    .filter(t => t.prize !== "-")
    .reduce((sum, t) => sum + parseInt(t.prize.replace(/[^\d]/g, '')), 0);

  const totalKills = userTournamentHistory.reduce((sum, t) => sum + t.kills, 0);
  const totalPoints = userTournamentHistory.reduce((sum, t) => sum + t.points, 0);
  const wins = userTournamentHistory.filter(t => t.placement === 1).length;

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-white">Мои турниры</h1>
            <p className="text-zinc-400 mt-1">Активные турниры, история и достижения</p>
          </div>
          <Link href="/tournaments">
            <Button>
              <LightningBolt className="w-4 h-4 mr-2" />
              Найти турнир
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center">
                <LightningBolt className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div className="text-2xl font-bold text-white">{userTournamentHistory.length + userActiveTournaments.length}</div>
            <div className="text-sm text-zinc-500">Всего турниров</div>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-yellow-500/20 flex items-center justify-center">
                <svg className="w-5 h-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
            </div>
            <div className="text-2xl font-bold text-yellow-400">{wins}</div>
            <div className="text-sm text-zinc-500">Побед</div>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
                <svg className="w-5 h-5 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
            </div>
            <div className="text-2xl font-bold text-red-400">{totalKills}</div>
            <div className="text-sm text-zinc-500">Киллов</div>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center">
                <svg className="w-5 h-5 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
            <div className="text-2xl font-bold text-green-400">{totalPrize.toLocaleString()} ₽</div>
            <div className="text-sm text-zinc-500">Заработано</div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="active" className="space-y-6">
          <TabsList className="bg-zinc-900/50 border border-zinc-800 p-1 w-full md:w-auto">
            <TabsTrigger value="active">
              Активные
              {userActiveTournaments.length > 0 && (
                <Badge className="ml-2 bg-cyan-500/20 text-cyan-400">{userActiveTournaments.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="history">История</TabsTrigger>
            <TabsTrigger value="achievements">Достижения</TabsTrigger>
          </TabsList>

          {/* Active Tournaments Tab */}
          <TabsContent value="active">
            {userActiveTournaments.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-6">
                {userActiveTournaments.map((tournament) => (
                  <ActiveTournamentCard key={tournament.id} tournament={tournament} />
                ))}
              </div>
            ) : (
              <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-12 text-center">
                <div className="w-16 h-16 bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-4">
                  <LightningBolt className="w-8 h-8 text-zinc-600" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Нет активных турниров</h3>
                <p className="text-zinc-400 mb-6">Вы пока не участвуете ни в одном турнире</p>
                <Link href="/tournaments">
                  <Button>
                    <LightningBolt className="w-4 h-4 mr-2" />
                    Найти турнир
                  </Button>
                </Link>
              </div>
            )}
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl overflow-hidden">
              <div className="p-6 border-b border-zinc-800">
                <h3 className="text-lg font-bold text-white">История турниров</h3>
              </div>

              {/* Desktop Table */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-zinc-800 bg-zinc-800/30">
                      <th className="text-left py-4 px-6 text-sm font-semibold text-zinc-400">Турнир</th>
                      <th className="text-center py-4 px-6 text-sm font-semibold text-zinc-400">Дата</th>
                      <th className="text-center py-4 px-6 text-sm font-semibold text-zinc-400">Место</th>
                      <th className="text-center py-4 px-6 text-sm font-semibold text-zinc-400">Киллы</th>
                      <th className="text-center py-4 px-6 text-sm font-semibold text-zinc-400">Очки</th>
                      <th className="text-right py-4 px-6 text-sm font-semibold text-zinc-400">Приз</th>
                    </tr>
                  </thead>
                  <tbody>
                    {userTournamentHistory.map((tournament, index) => (
                      <tr key={tournament.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/20 transition-colors">
                        <td className="py-4 px-6">
                          <div className="font-medium text-white">{tournament.name}</div>
                        </td>
                        <td className="py-4 px-6 text-center text-zinc-400">
                          {new Date(tournament.date).toLocaleDateString('ru-RU')}
                        </td>
                        <td className="py-4 px-6 text-center">
                          <div className={`inline-flex items-center justify-center w-8 h-8 rounded-lg font-bold text-sm ${
                            tournament.placement === 1 ? 'bg-yellow-500/20 text-yellow-400' :
                            tournament.placement === 2 ? 'bg-zinc-400/20 text-zinc-300' :
                            tournament.placement === 3 ? 'bg-orange-500/20 text-orange-400' :
                            'bg-zinc-700/50 text-zinc-500'
                          }`}>
                            {tournament.placement}
                          </div>
                        </td>
                        <td className="py-4 px-6 text-center text-zinc-300">{tournament.kills}</td>
                        <td className="py-4 px-6 text-center text-cyan-400 font-semibold">{tournament.points}</td>
                        <td className="py-4 px-6 text-right">
                          {tournament.prize !== "-" ? (
                            <span className="text-green-400 font-semibold">{tournament.prize}</span>
                          ) : (
                            <span className="text-zinc-600">-</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Cards */}
              <div className="md:hidden divide-y divide-zinc-800">
                {userTournamentHistory.map((tournament) => (
                  <div key={tournament.id} className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="font-medium text-white">{tournament.name}</div>
                        <div className="text-sm text-zinc-500">{new Date(tournament.date).toLocaleDateString('ru-RU')}</div>
                      </div>
                      <div className={`flex items-center justify-center w-8 h-8 rounded-lg font-bold text-sm ${
                        tournament.placement === 1 ? 'bg-yellow-500/20 text-yellow-400' :
                        tournament.placement === 2 ? 'bg-zinc-400/20 text-zinc-300' :
                        tournament.placement === 3 ? 'bg-orange-500/20 text-orange-400' :
                        'bg-zinc-700/50 text-zinc-500'
                      }`}>
                        {tournament.placement}
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-4">
                        <span className="text-zinc-400">Киллы: <span className="text-white">{tournament.kills}</span></span>
                        <span className="text-zinc-400">Очки: <span className="text-cyan-400">{tournament.points}</span></span>
                      </div>
                      {tournament.prize !== "-" && (
                        <span className="text-green-400 font-semibold">{tournament.prize}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Summary */}
              <div className="p-6 bg-zinc-800/30 border-t border-zinc-800">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="text-zinc-400">
                    Всего сыграно: <span className="text-white font-semibold">{userTournamentHistory.length}</span> турниров
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-zinc-400">
                      Очков: <span className="text-cyan-400 font-semibold">{totalPoints}</span>
                    </div>
                    <div className="text-zinc-400">
                      Призовых: <span className="text-green-400 font-semibold">{totalPrize.toLocaleString()} ₽</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements">
            <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white">Достижения</h3>
                <span className="text-sm text-zinc-500">
                  Разблокировано: {userAchievements.filter(a => a.unlocked).length}/{userAchievements.length}
                </span>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {userAchievements.map((achievement) => (
                  <div
                    key={achievement.id}
                    className={`relative p-4 rounded-xl border transition-all ${
                      achievement.unlocked
                        ? 'bg-zinc-800/50 border-cyan-500/30'
                        : 'bg-zinc-800/20 border-zinc-700/30 opacity-60'
                    }`}
                  >
                    {achievement.unlocked && (
                      <div className="absolute top-3 right-3">
                        <svg className="w-5 h-5 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                    )}
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-3 ${
                      achievement.unlocked
                        ? 'bg-gradient-to-br from-cyan-500/20 to-cyan-600/20'
                        : 'bg-zinc-700/30'
                    }`}>
                      <AchievementIcon icon={achievement.icon} unlocked={achievement.unlocked} />
                    </div>
                    <h4 className={`font-semibold mb-1 ${achievement.unlocked ? 'text-white' : 'text-zinc-500'}`}>
                      {achievement.name}
                    </h4>
                    <p className="text-sm text-zinc-500 mb-2">{achievement.description}</p>
                    {achievement.unlocked ? (
                      <div className="text-xs text-cyan-400">
                        Получено {new Date(achievement.date!).toLocaleDateString('ru-RU')}
                      </div>
                    ) : (
                      <div className="text-xs text-zinc-600">
                        Прогресс: {achievement.progress}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
