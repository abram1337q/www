"use client";

import { useState } from "react";
import Link from "next/link";
import { LightningBolt } from "@/components/common/LightningBolt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { mockClans } from "@/lib/mock-data";

// Clan Card Component
const ClanCard = ({ clan }: { clan: typeof mockClans[0] }) => (
  <Link
    href={`/clans/${clan.slug}`}
    className="group bg-zinc-900/50 border border-zinc-800 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-300"
  >
    {/* Banner */}
    <div className="relative h-32 overflow-hidden">
      <img
        src={clan.banner}
        alt={clan.name}
        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/50 to-transparent" />

      {/* Status badges */}
      <div className="absolute top-3 right-3 flex gap-2">
        {clan.isRecruiting ? (
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            Набор открыт
          </Badge>
        ) : (
          <Badge className="bg-zinc-500/20 text-zinc-400 border-zinc-500/30">
            Набор закрыт
          </Badge>
        )}
      </div>

      {/* Logo */}
      <div className="absolute -bottom-6 left-4">
        <div className="w-16 h-16 rounded-xl border-4 border-zinc-900 overflow-hidden bg-zinc-800 shadow-lg">
          <img src={clan.logo} alt={clan.name} className="w-full h-full object-cover" />
        </div>
      </div>
    </div>

    {/* Content */}
    <div className="p-4 pt-8">
      <div className="flex items-start justify-between mb-2">
        <div>
          <h3 className="font-bold text-white group-hover:text-cyan-400 transition-colors">
            [{clan.tag}] {clan.name}
          </h3>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs text-zinc-500">{clan.game}</span>
            <span className="w-1 h-1 rounded-full bg-zinc-600" />
            <span className="text-xs text-zinc-500">{clan.region}</span>
          </div>
        </div>
        <div className="text-right">
          <div className="text-lg font-bold text-cyan-400">{clan.rating}</div>
          <div className="text-xs text-zinc-500">рейтинг</div>
        </div>
      </div>

      <p className="text-sm text-zinc-400 line-clamp-2 mb-4">
        {clan.description}
      </p>

      <div className="flex items-center justify-between pt-3 border-t border-zinc-800">
        <div className="flex items-center gap-1 text-sm text-zinc-400">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          {clan.membersCount}/{clan.maxMembers}
        </div>
        <div className="flex items-center gap-2">
          {clan.achievements.length > 0 && (
            <Badge variant="secondary" className="text-xs">
              {clan.achievements.length} достижений
            </Badge>
          )}
        </div>
      </div>
    </div>
  </Link>
);

export default function ClansPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [gameFilter, setGameFilter] = useState("all");
  const [regionFilter, setRegionFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState<"rating" | "members" | "date">("rating");
  const [currentPage, setCurrentPage] = useState(1);
  const clansPerPage = 6;

  // Filter and sort clans
  let filteredClans = mockClans.filter((clan) => {
    const matchesSearch = clan.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      clan.tag.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGame = gameFilter === "all" || clan.game === gameFilter;
    const matchesRegion = regionFilter === "all" || clan.region === regionFilter;
    const matchesStatus = statusFilter === "all" ||
      (statusFilter === "recruiting" && clan.isRecruiting) ||
      (statusFilter === "closed" && !clan.isRecruiting);
    return matchesSearch && matchesGame && matchesRegion && matchesStatus;
  });

  // Sort
  filteredClans = [...filteredClans].sort((a, b) => {
    if (sortBy === "rating") return b.rating - a.rating;
    if (sortBy === "members") return b.membersCount - a.membersCount;
    if (sortBy === "date") return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    return 0;
  });

  // Pagination
  const totalPages = Math.ceil(filteredClans.length / clansPerPage);
  const paginatedClans = filteredClans.slice(
    (currentPage - 1) * clansPerPage,
    currentPage * clansPerPage
  );

  // Get unique values for filters
  const games = [...new Set(mockClans.map(c => c.game))];
  const regions = [...new Set(mockClans.map(c => c.region))];

  return (
    <div className="min-h-screen storm-gradient">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-zinc-900/80 backdrop-blur-sm border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <LightningBolt className="w-5 h-5 text-cyan-400" />
            <span className="text-lg font-bold text-white">DARKSTORM</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/clans" className="text-cyan-400 text-sm font-medium">
              Все кланы
            </Link>
            <Link href="/tournaments" className="text-zinc-400 hover:text-cyan-400 transition-colors text-sm font-medium">
              Турниры
            </Link>
          </nav>
          <Link href="/login">
            <Button variant="outline" size="sm">
              <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              Личный кабинет
            </Button>
          </Link>
        </div>
      </header>

      <div className="pt-20 pb-12 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Page Header */}
          <div className="text-center mb-12">
            <Badge className="mb-4">
              <svg className="w-3 h-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              КАТАЛОГ КЛАНОВ
            </Badge>
            <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
              Найди свой <span className="text-cyan-400">клан</span>
            </h1>
            <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
              Присоединяйся к одному из {mockClans.length}+ активных кланов на платформе
            </p>
          </div>

          {/* Search and Filters */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-4 md:p-6 mb-8">
            {/* Search */}
            <div className="relative mb-4">
              <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <Input
                placeholder="Поиск по названию или тегу клана..."
                className="pl-12 h-12 bg-zinc-800/50 border-zinc-700"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-3">
              {/* Game Filter */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-zinc-500">Игра:</span>
                <div className="flex gap-1">
                  <button
                    onClick={() => { setGameFilter("all"); setCurrentPage(1); }}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                      gameFilter === "all"
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                    }`}
                  >
                    Все
                  </button>
                  {games.map(game => (
                    <button
                      key={game}
                      onClick={() => { setGameFilter(game); setCurrentPage(1); }}
                      className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                        gameFilter === game
                          ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                          : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                      }`}
                    >
                      {game}
                    </button>
                  ))}
                </div>
              </div>

              {/* Region Filter */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-zinc-500">Регион:</span>
                <div className="flex gap-1">
                  <button
                    onClick={() => { setRegionFilter("all"); setCurrentPage(1); }}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                      regionFilter === "all"
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                    }`}
                  >
                    Все
                  </button>
                  {regions.map(region => (
                    <button
                      key={region}
                      onClick={() => { setRegionFilter(region); setCurrentPage(1); }}
                      className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                        regionFilter === region
                          ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                          : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                      }`}
                    >
                      {region}
                    </button>
                  ))}
                </div>
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-zinc-500">Статус:</span>
                <div className="flex gap-1">
                  <button
                    onClick={() => { setStatusFilter("all"); setCurrentPage(1); }}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                      statusFilter === "all"
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                    }`}
                  >
                    Все
                  </button>
                  <button
                    onClick={() => { setStatusFilter("recruiting"); setCurrentPage(1); }}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                      statusFilter === "recruiting"
                        ? "bg-green-500/20 text-green-400 border border-green-500/30"
                        : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                    }`}
                  >
                    Набор открыт
                  </button>
                </div>
              </div>

              {/* Sort */}
              <div className="flex items-center gap-2 ml-auto">
                <span className="text-sm text-zinc-500">Сортировка:</span>
                <div className="flex gap-1">
                  <button
                    onClick={() => setSortBy("rating")}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                      sortBy === "rating"
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                    }`}
                  >
                    По рейтингу
                  </button>
                  <button
                    onClick={() => setSortBy("members")}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                      sortBy === "members"
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                    }`}
                  >
                    По участникам
                  </button>
                  <button
                    onClick={() => setSortBy("date")}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                      sortBy === "date"
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                    }`}
                  >
                    По дате
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Results Count */}
          <div className="flex items-center justify-between mb-6">
            <p className="text-zinc-400 text-sm">
              Найдено: <span className="text-white font-medium">{filteredClans.length}</span> кланов
            </p>
          </div>

          {/* Clans Grid */}
          {paginatedClans.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {paginatedClans.map((clan) => (
                <ClanCard key={clan.id} clan={clan} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-zinc-900/30 border border-zinc-800 rounded-2xl">
              <svg className="w-16 h-16 mx-auto text-zinc-600 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-xl font-bold text-white mb-2">Кланы не найдены</h3>
              <p className="text-zinc-400">Попробуйте изменить параметры поиска</p>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`w-10 h-10 rounded-lg text-sm font-medium transition-all ${
                    currentPage === page
                      ? "bg-cyan-500 text-black"
                      : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
                  }`}
                >
                  {page}
                </button>
              ))}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-zinc-800">
        <div className="max-w-7xl mx-auto text-center text-zinc-500 text-sm">
          2026 DARKSTORM. Все права защищены.
        </div>
      </footer>
    </div>
  );
}
