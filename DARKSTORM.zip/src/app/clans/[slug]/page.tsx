"use client";

import { useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { LightningBolt } from "@/components/common/LightningBolt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { mockClans, mockTournaments } from "@/lib/mock-data";

export default function ClanPage() {
  const params = useParams();
  const clan = mockClans.find(c => c.slug === params.slug);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!clan) {
    return (
      <div className="min-h-screen storm-gradient flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Клан не найден</h1>
          <Link href="/clans">
            <Button>Вернуться к списку кланов</Button>
          </Link>
        </div>
      </div>
    );
  }

  // Mock clan tournaments
  const clanTournaments = mockTournaments.slice(0, 3);

  return (
    <div className="min-h-screen storm-gradient">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-zinc-900/80 backdrop-blur-sm border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <LightningBolt className="w-5 h-5 text-cyan-400" />
            <span className="text-lg font-bold text-white">DARKSTORM</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/clans" className="text-zinc-400 hover:text-cyan-400 transition-colors text-sm font-medium">
              Все кланы
            </Link>
            <Link href="/tournaments" className="text-zinc-400 hover:text-cyan-400 transition-colors text-sm font-medium">
              Турниры
            </Link>
          </nav>
          <Link href="/login">
            <Button variant="outline" size="sm">Личный кабинет</Button>
          </Link>
        </div>
      </header>

      {/* Banner */}
      <div className="relative h-64 md:h-80 overflow-hidden pt-14">
        <img
          src={clan.banner}
          alt={clan.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/60 to-transparent" />

        {/* Back button */}
        <Link
          href="/clans"
          className="absolute top-20 left-4 flex items-center gap-2 px-3 py-2 bg-zinc-900/80 backdrop-blur-sm rounded-lg text-zinc-400 hover:text-white transition-colors"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Назад
        </Link>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 -mt-24 relative z-10 pb-12">
        {/* Clan Header */}
        <div className="bg-zinc-900/90 backdrop-blur-sm border border-zinc-800 rounded-2xl p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Logo */}
            <div className="flex-shrink-0">
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-2xl border-4 border-zinc-800 overflow-hidden bg-zinc-800 shadow-xl">
                <img src={clan.logo} alt={clan.name} className="w-full h-full object-cover" />
              </div>
            </div>

            {/* Info */}
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-3 mb-2">
                <h1 className="text-3xl md:text-4xl font-black text-white">
                  [{clan.tag}] {clan.name}
                </h1>
                {clan.isRecruiting ? (
                  <Badge className="bg-green-500/20 text-green-400">Набор открыт</Badge>
                ) : (
                  <Badge className="bg-zinc-500/20 text-zinc-400">Набор закрыт</Badge>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-4 text-sm text-zinc-400 mb-4">
                <span className="flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                  {clan.game}
                </span>
                <span className="flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {clan.region}
                </span>
                <span className="flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  Создан {new Date(clan.createdAt).toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}
                </span>
              </div>
              <p className="text-zinc-300">{clan.description}</p>
            </div>

            {/* Actions */}
            <div className="flex flex-col gap-3">
              <Button
                size="lg"
                onClick={() => setIsApplyModalOpen(true)}
                disabled={!clan.isRecruiting}
                className="min-w-[180px]"
              >
                <LightningBolt className="w-4 h-4 mr-2" />
                Подать заявку
              </Button>
              <div className="flex gap-2 justify-center">
                {clan.socialLinks.discord && (
                  <a href={clan.socialLinks.discord} target="_blank" rel="noopener noreferrer"
                    className="w-10 h-10 rounded-lg bg-[#5865F2]/20 flex items-center justify-center text-[#5865F2] hover:bg-[#5865F2]/30 transition-colors">
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20.317 4.492c-1.53-.69-3.17-1.2-4.885-1.49a.075.075 0 0 0-.079.036c-.21.369-.444.85-.608 1.23a18.566 18.566 0 0 0-5.487 0 12.36 12.36 0 0 0-.617-1.23A.077.077 0 0 0 8.562 3c-1.714.29-3.354.8-4.885 1.491a.07.07 0 0 0-.032.027C.533 9.093-.32 13.555.099 17.961a.08.08 0 0 0 .031.055 20.03 20.03 0 0 0 5.993 2.98.078.078 0 0 0 .084-.026c.462-.62.874-1.275 1.226-1.963.021-.04.001-.088-.041-.104a13.201 13.201 0 0 1-1.872-.878.075.075 0 0 1-.008-.125c.126-.093.252-.19.372-.287a.075.075 0 0 1 .078-.01c3.927 1.764 8.18 1.764 12.061 0a.075.075 0 0 1 .079.009c.12.098.245.195.372.288a.075.075 0 0 1-.006.125c-.598.344-1.22.635-1.873.877a.075.075 0 0 0-.041.105c.36.687.772 1.341 1.225 1.962a.077.077 0 0 0 .084.028 19.963 19.963 0 0 0 6.002-2.981.076.076 0 0 0 .032-.054c.5-5.094-.838-9.52-3.549-13.442a.06.06 0 0 0-.031-.028zM8.02 15.278c-1.182 0-2.157-1.069-2.157-2.38 0-1.312.956-2.38 2.157-2.38 1.21 0 2.176 1.077 2.157 2.38 0 1.312-.956 2.38-2.157 2.38zm7.975 0c-1.183 0-2.157-1.069-2.157-2.38 0-1.312.955-2.38 2.157-2.38 1.21 0 2.176 1.077 2.157 2.38 0 1.312-.946 2.38-2.157 2.38z"/>
                    </svg>
                  </a>
                )}
                {clan.socialLinks.telegram && (
                  <a href={clan.socialLinks.telegram} target="_blank" rel="noopener noreferrer"
                    className="w-10 h-10 rounded-lg bg-[#0088cc]/20 flex items-center justify-center text-[#0088cc] hover:bg-[#0088cc]/30 transition-colors">
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                    </svg>
                  </a>
                )}
                {clan.socialLinks.youtube && (
                  <a href={clan.socialLinks.youtube} target="_blank" rel="noopener noreferrer"
                    className="w-10 h-10 rounded-lg bg-[#FF0000]/20 flex items-center justify-center text-[#FF0000] hover:bg-[#FF0000]/30 transition-colors">
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                    </svg>
                  </a>
                )}
                {clan.socialLinks.twitch && (
                  <a href={clan.socialLinks.twitch} target="_blank" rel="noopener noreferrer"
                    className="w-10 h-10 rounded-lg bg-[#9146FF]/20 flex items-center justify-center text-[#9146FF] hover:bg-[#9146FF]/30 transition-colors">
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714z"/>
                    </svg>
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-zinc-800">
            <div className="text-center p-4 bg-zinc-800/30 rounded-xl">
              <div className="text-2xl font-bold text-cyan-400">{clan.rating}</div>
              <div className="text-sm text-zinc-500">Рейтинг</div>
            </div>
            <div className="text-center p-4 bg-zinc-800/30 rounded-xl">
              <div className="text-2xl font-bold text-white">{clan.membersCount}/{clan.maxMembers}</div>
              <div className="text-sm text-zinc-500">Участников</div>
            </div>
            <div className="text-center p-4 bg-zinc-800/30 rounded-xl">
              <div className="text-2xl font-bold text-green-400">{clan.achievements.length}</div>
              <div className="text-sm text-zinc-500">Достижений</div>
            </div>
            <div className="text-center p-4 bg-zinc-800/30 rounded-xl">
              <div className="text-2xl font-bold text-orange-400">15</div>
              <div className="text-sm text-zinc-500">Турниров</div>
            </div>
          </div>
        </div>

        {/* Tabs Content */}
        <Tabs defaultValue="about" className="space-y-6">
          <TabsList className="bg-zinc-900/50 border border-zinc-800 p-1 w-full md:w-auto">
            <TabsTrigger value="about">О клане</TabsTrigger>
            <TabsTrigger value="members">Участники</TabsTrigger>
            <TabsTrigger value="achievements">Достижения</TabsTrigger>
            <TabsTrigger value="tournaments">Турниры</TabsTrigger>
          </TabsList>

          {/* About Tab */}
          <TabsContent value="about" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Requirements */}
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Требования
                </h3>
                <div className="space-y-3">
                  {clan.requirements.map((req, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-zinc-800/30 rounded-xl">
                      <div className="w-2 h-2 rounded-full bg-cyan-400" />
                      <span className="text-zinc-300">{req}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Clan Info */}
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Информация
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between py-2 border-b border-zinc-800">
                    <span className="text-zinc-500">Игра</span>
                    <span className="text-white font-medium">{clan.game}</span>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-zinc-800">
                    <span className="text-zinc-500">Регион</span>
                    <span className="text-white font-medium">{clan.region}</span>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-zinc-800">
                    <span className="text-zinc-500">Дата создания</span>
                    <span className="text-white font-medium">{new Date(clan.createdAt).toLocaleDateString('ru-RU')}</span>
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <span className="text-zinc-500">Статус набора</span>
                    {clan.isRecruiting ? (
                      <Badge className="bg-green-500/20 text-green-400">Открыт</Badge>
                    ) : (
                      <Badge className="bg-zinc-500/20 text-zinc-400">Закрыт</Badge>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Members Tab */}
          <TabsContent value="members">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white">Участники клана</h3>
                <span className="text-sm text-zinc-500">{clan.members.length} из {clan.maxMembers}</span>
              </div>
              <div className="space-y-3">
                {clan.members.map((member) => (
                  <div key={member.id} className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl hover:bg-zinc-800/50 transition-colors">
                    <Avatar className="w-12 h-12 border-2 border-zinc-700">
                      <AvatarImage src={member.avatar} />
                      <AvatarFallback>{member.nickname[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white">{member.nickname}</span>
                        <Badge className={
                          member.role === 'leader' ? 'bg-yellow-500/20 text-yellow-400' :
                          member.role === 'officer' ? 'bg-cyan-500/20 text-cyan-400' :
                          'bg-zinc-500/20 text-zinc-400'
                        }>
                          {member.role === 'leader' ? 'Лидер' : member.role === 'officer' ? 'Офицер' : 'Участник'}
                        </Badge>
                      </div>
                      <div className="text-sm text-zinc-500">
                        В клане с {new Date(member.joinedAt).toLocaleDateString('ru-RU')}
                      </div>
                    </div>
                    <div className="hidden md:flex items-center gap-6 text-sm">
                      <div className="text-center">
                        <div className="font-bold text-white">{member.stats.kills.toLocaleString()}</div>
                        <div className="text-zinc-500">киллов</div>
                      </div>
                      <div className="text-center">
                        <div className="font-bold text-green-400">{member.stats.wins}</div>
                        <div className="text-zinc-500">побед</div>
                      </div>
                      <div className="text-center">
                        <div className="font-bold text-cyan-400">{member.stats.kd}</div>
                        <div className="text-zinc-500">K/D</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-6">Достижения клана</h3>
              {clan.achievements.length > 0 ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {clan.achievements.map((achievement, index) => (
                    <div key={index} className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl border border-zinc-700/50">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-500/20 to-orange-500/20 flex items-center justify-center">
                        <svg className="w-6 h-6 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                        </svg>
                      </div>
                      <span className="font-medium text-white">{achievement}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-zinc-500">
                  Пока нет достижений
                </div>
              )}
            </div>
          </TabsContent>

          {/* Tournaments Tab */}
          <TabsContent value="tournaments">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-6">Турниры клана</h3>
              <div className="space-y-4">
                {clanTournaments.map((tournament) => (
                  <Link
                    key={tournament.id}
                    href={`/tournaments/${tournament.id}`}
                    className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl hover:bg-zinc-800/50 transition-colors group"
                  >
                    <div className="w-20 h-14 rounded-lg overflow-hidden bg-zinc-700 flex-shrink-0">
                      <img src={tournament.banner} alt={tournament.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-white group-hover:text-cyan-400 transition-colors truncate">
                        {tournament.name}
                      </div>
                      <div className="flex items-center gap-3 text-sm text-zinc-500 mt-1">
                        <span>{tournament.format}</span>
                        <span className="w-1 h-1 rounded-full bg-zinc-600" />
                        <span>{tournament.prizePool} {tournament.currency}</span>
                      </div>
                    </div>
                    <Badge className={
                      tournament.status === 'finished' ? 'bg-zinc-500/20 text-zinc-400' :
                      tournament.status === 'ongoing' ? 'bg-orange-500/20 text-orange-400' :
                      'bg-green-500/20 text-green-400'
                    }>
                      {tournament.status === 'finished' ? 'Завершён' :
                       tournament.status === 'ongoing' ? 'Идёт' :
                       tournament.status === 'registration' ? 'Регистрация' : 'Скоро'}
                    </Badge>
                  </Link>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Apply Modal */}
      <Dialog open={isApplyModalOpen} onOpenChange={setIsApplyModalOpen}>
        <DialogContent className="bg-zinc-900 border-zinc-800 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-white flex items-center gap-2">
              <LightningBolt className="w-5 h-5 text-cyan-400" />
              Заявка в клан {clan.name}
            </DialogTitle>
          </DialogHeader>

          {isSubmitted ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Заявка отправлена!</h3>
              <p className="text-zinc-400">Лидер клана рассмотрит её в ближайшее время</p>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setIsSubmitted(true); }} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-2">Никнейм в игре</label>
                <Input placeholder="Твой игровой ник" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-2">Game ID</label>
                <Input placeholder="Твой ID в игре" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-2">Telegram для связи</label>
                <Input placeholder="@username" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-2">Расскажи о себе</label>
                <Textarea
                  placeholder="Опыт, статистика, почему хочешь в этот клан..."
                  className="min-h-[100px]"
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                <LightningBolt className="w-4 h-4 mr-2" />
                Отправить заявку
              </Button>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-zinc-800">
        <div className="max-w-7xl mx-auto text-center text-zinc-500 text-sm">
          2026 DARKSTORM. Все права защищены.
        </div>
      </footer>
    </div>
  );
}
