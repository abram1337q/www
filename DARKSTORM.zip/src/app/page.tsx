"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

// Lightning bolt SVG component
const LightningBolt = ({ className }: { className?: string }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    className={className}
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth="1"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

// Stats counter component
const StatCard = ({ number, label }: { number: string; label: string }) => (
  <div className="text-center p-3 md:p-6">
    <div className="text-3xl md:text-5xl font-black text-cyan-400 animate-pulse-glow">
      {number}
    </div>
    <div className="text-zinc-400 mt-1 md:mt-2 text-[10px] md:text-sm uppercase tracking-wider">
      {label}
    </div>
  </div>
);

// Feature card component
const FeatureCard = ({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) => (
  <div className="card-hover bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 backdrop-blur-sm">
    <div className="text-cyan-400 mb-4">{icon}</div>
    <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
    <p className="text-zinc-400 text-sm leading-relaxed">{description}</p>
  </div>
);

// Requirement item component
const RequirementItem = ({
  text,
  required = true,
}: {
  text: string;
  required?: boolean;
}) => (
  <div className="flex items-center gap-3 py-2">
    <div
      className={`w-2 h-2 rounded-full ${required ? "bg-cyan-400" : "bg-zinc-500"}`}
    />
    <span className={required ? "text-zinc-200" : "text-zinc-400"}>{text}</span>
    {!required && (
      <Badge variant="outline" className="ml-auto text-xs">
        желательно
      </Badge>
    )}
  </div>
);

export default function Home() {
  const [formData, setFormData] = useState({
    nickname: "",
    gameId: "",
    telegram: "",
    age: "",
    experience: "",
    reason: "",
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [submitError, setSubmitError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setSubmitError("");

    try {
      const res = await fetch("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nickname: formData.nickname,
          game_id: formData.gameId,
          telegram: formData.telegram,
          age: formData.age,
          experience: formData.experience,
          reason: formData.reason,
        }),
      });

      if (res.ok) {
        setIsSubmitted(true);
      } else {
        const data = await res.json();
        setSubmitError(data.error || "Ошибка при отправке заявки");
      }
    } catch {
      setSubmitError("Ошибка подключения к серверу");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen storm-gradient overflow-hidden">
      {/* Header with Login Button */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-zinc-900/80 backdrop-blur-sm border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LightningBolt className="w-5 h-5 text-cyan-400" />
            <span className="text-lg font-bold text-white">DARKSTORM</span>
          </div>
          <Link href="/login">
            <Button variant="outline" size="sm">
              <svg
                className="w-4 h-4 mr-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"
                />
              </svg>
              Вход
            </Button>
          </Link>
        </div>
      </header>

      {/* Animated background lightning effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-20 left-10 text-cyan-400/20 bolt-animate">
          <LightningBolt className="w-32 h-32" />
        </div>
        <div className="absolute top-40 right-20 text-cyan-400/20 bolt-animate-delay">
          <LightningBolt className="w-24 h-24" />
        </div>
        <div className="absolute bottom-40 left-1/4 text-cyan-400/10 bolt-animate">
          <LightningBolt className="w-40 h-40" />
        </div>
        <div className="absolute top-1/3 right-1/4 text-cyan-400/10 bolt-animate-delay">
          <LightningBolt className="w-20 h-20" />
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-4 py-20 pt-24">
        {/* Glow effect behind title */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-[150px]" />

        <div className="relative z-10 text-center max-w-5xl mx-auto">
          {/* Badge */}
          <Badge className="mb-6 text-sm px-4 py-1.5">
            <LightningBolt className="w-3 h-3 mr-1" />
            PUBG MOBILE CLAN
          </Badge>

          {/* Main title */}
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-black tracking-tighter mb-6 glitch-hover">
            <span className="text-white">DARK</span>
            <span className="text-cyan-400 animate-pulse-glow">STORM</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-zinc-400 mb-4 max-w-2xl mx-auto">
            Мы не просто играем — мы доминируем
          </p>
          <p className="text-lg text-zinc-500 mb-10 max-w-xl mx-auto">
            Элитный клан для тех, кто готов стать легендой. Никаких рандомов.
            Только лучшие.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="xl" className="group">
              <LightningBolt className="w-5 h-5 group-hover:animate-pulse" />
              Подать заявку
            </Button>
            <Button size="xl" variant="outline">
              Узнать больше
            </Button>
          </div>

          {/* Stats */}
          <div className="mt-20 grid grid-cols-3 gap-4 max-w-lg mx-auto border border-zinc-800 rounded-2xl bg-zinc-900/30 backdrop-blur-sm">
            <StatCard number="50" label="Мест в клане" />
            <StatCard number="47" label="Свободно" />
            <StatCard number="24/7" label="Активность" />
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
          <svg
            className="w-6 h-6 text-zinc-500"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 14l-7 7m0 0l-7-7m7 7V3"
            />
          </svg>
        </div>
      </section>

      {/* About Section */}
      <section className="relative py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">
              О НАС
            </Badge>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
              Кто мы такие?
            </h2>
            <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
              DÄRKSTØRM — это не просто клан. Это братство игроков, объединённых
              одной целью: быть лучшими на поле боя.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <FeatureCard
              icon={<LightningBolt className="w-8 h-8" />}
              title="Молниеносные"
              description="Быстрые решения, мгновенная реакция. Мы атакуем первыми и побеждаем. Враги даже не успевают понять, что произошло."
            />
            <FeatureCard
              icon={
                <svg
                  className="w-8 h-8"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
              }
              title="Командные"
              description="Один за всех, все за одного. Мы играем как единый организм. Каждый знает свою роль и выполняет её идеально."
            />
            <FeatureCard
              icon={
                <svg
                  className="w-8 h-8"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"
                  />
                </svg>
              }
              title="Победители"
              description="Второе место — это первый проигравший. Мы нацелены только на победу. Каждый матч — шанс доказать своё превосходство."
            />
          </div>
        </div>
      </section>

      {/* Why Join Section */}
      <section className="relative py-24 px-4 bg-zinc-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge variant="secondary" className="mb-4">
                ПРЕИМУЩЕСТВА
              </Badge>
              <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
                Почему именно мы?
              </h2>
              <p className="text-zinc-400 text-lg mb-8">
                Вступив в DÄRKSTØRM, ты получаешь не просто тег клана — ты
                становишься частью чего-то большего.
              </p>

              <div className="space-y-4">
                <div className="flex items-start gap-4 p-4 bg-zinc-800/50 rounded-xl border border-zinc-700/50">
                  <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                    <svg
                      className="w-5 h-5 text-cyan-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-white mb-1">
                      Турниры и призы
                    </h4>
                    <p className="text-zinc-400 text-sm">
                      Участвуем в турнирах. Побеждаем. Забираем призы. Всё
                      просто.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-zinc-800/50 rounded-xl border border-zinc-700/50">
                  <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                    <svg
                      className="w-5 h-5 text-cyan-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z"
                      />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-white mb-1">
                      Дружное комьюнити
                    </h4>
                    <p className="text-zinc-400 text-sm">
                      Здесь все свои. Помогаем друг другу расти и становиться
                      сильнее.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Visual element */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-transparent rounded-3xl blur-3xl" />
              <div className="relative bg-zinc-900 border border-zinc-800 rounded-3xl p-8 text-center">
                <div className="text-8xl font-black text-transparent bg-clip-text bg-gradient-to-b from-cyan-400 to-cyan-600 mb-4">
                  DS
                </div>
                <div className="text-2xl font-bold text-white mb-2">
                  DÄRKSTØRM
                </div>
                <div className="text-zinc-500 text-sm mb-6">EST. 2024</div>
                <div className="flex justify-center gap-2">
                  <Badge>ELITE</Badge>
                  <Badge variant="secondary">TOP CLAN</Badge>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Requirements Section */}
      <section className="relative py-24 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">
              ТРЕБОВАНИЯ
            </Badge>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
              Кого мы ищем?
            </h2>
            <p className="text-zinc-400 text-lg">
              Мы не берём всех подряд. Только тех, кто готов играть серьёзно.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
                <svg
                  className="w-5 h-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                Обязательно
              </h3>
              <div className="space-y-1">
                <RequirementItem text="KD не ниже 3.0" />
                <RequirementItem text="Уровень аккаунта 40+" />
                <RequirementItem text="Микрофон для связи" />
                <RequirementItem text="Активность минимум 3 раза в неделю" />
                <RequirementItem text="Адекватность и уважение к тиммейтам" />
              </div>
            </div>

            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-zinc-400 mb-4 flex items-center gap-2">
                <svg
                  className="w-5 h-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                  />
                </svg>
                Плюсом будет
              </h3>
              <div className="space-y-1">
                <RequirementItem text="Опыт в турнирах" required={false} />
                <RequirementItem
                  text="Conqueror / Ace Master ранг"
                  required={false}
                />
                <RequirementItem
                  text="Умение IGL (командовать)"
                  required={false}
                />
                <RequirementItem text="Возраст 16+" required={false} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Application Form Section */}
      <section className="relative py-24 px-4 bg-zinc-900/50" id="apply">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="mb-4">
              <LightningBolt className="w-3 h-3 mr-1" />
              ВСТУПИТЬ В КЛАН
            </Badge>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
              Подай заявку
            </h2>
            <p className="text-zinc-400 text-lg">
              Заполни форму ниже. Мы рассмотрим твою заявку и свяжемся с тобой.
            </p>
          </div>

          {isSubmitted ? (
            <div className="bg-zinc-900 border border-cyan-500/50 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-cyan-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  className="w-8 h-8 text-cyan-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">
                Заявка отправлена!
              </h3>
              <p className="text-zinc-400">
                Мы рассмотрим её в ближайшее время и свяжемся с тобой в игре.
              </p>
            </div>
          ) : (
            <form
              onSubmit={handleSubmit}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8"
            >
              <div className="space-y-6">
                {submitError && (
                  <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 text-red-400 text-sm">
                    {submitError}
                  </div>
                )}
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-zinc-300 mb-2">
                      Никнейм в игре *
                    </label>
                    <Input
                      placeholder="Твой игровой ник"
                      value={formData.nickname}
                      onChange={(e) =>
                        setFormData({ ...formData, nickname: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-300 mb-2">
                      ID игрока *
                    </label>
                    <Input
                      placeholder="Твой ID в PUBG Mobile"
                      value={formData.gameId}
                      onChange={(e) =>
                        setFormData({ ...formData, gameId: e.target.value })
                      }
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-2">
                    Telegram *
                  </label>
                  <Input
                    placeholder="@username"
                    value={formData.telegram}
                    onChange={(e) =>
                      setFormData({ ...formData, telegram: e.target.value })
                    }
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-zinc-300 mb-2">
                      Возраст
                    </label>
                    <Input
                      type="number"
                      placeholder="Сколько тебе лет"
                      value={formData.age}
                      onChange={(e) =>
                        setFormData({ ...formData, age: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-300 mb-2">
                      Опыт игры
                    </label>
                    <Input
                      placeholder="Сколько сезонов играешь"
                      value={formData.experience}
                      onChange={(e) =>
                        setFormData({ ...formData, experience: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-2">
                    Почему хочешь к нам? *
                  </label>
                  <Textarea
                    placeholder="Расскажи о себе, своих достижениях и почему хочешь вступить в DÄRKSTØRM"
                    value={formData.reason}
                    onChange={(e) =>
                      setFormData({ ...formData, reason: e.target.value })
                    }
                    required
                  />
                </div>

                <Button type="submit" size="xl" className="w-full" disabled={isLoading}>
                  <LightningBolt className="w-5 h-5" />
                  {isLoading ? "Отправка..." : "Отправить заявку"}
                </Button>
              </div>
            </form>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-zinc-800">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <LightningBolt className="w-6 h-6 text-cyan-400" />
              <span className="text-xl font-bold text-white">DÄRKSTØRM</span>
            </div>

            <div className="flex items-center gap-6">
              <a
                href="#"
                className="text-zinc-400 hover:text-cyan-400 transition-colors"
              >
                Discord
              </a>
              <a
                href="#"
                className="text-zinc-400 hover:text-cyan-400 transition-colors"
              >
                Telegram
              </a>
              <a
                href="#"
                className="text-zinc-400 hover:text-cyan-400 transition-colors"
              >
                YouTube
              </a>
            </div>

            <div className="text-zinc-500 text-sm">
              2026 DÄRKSTØRM. Все права защищены.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
