"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

interface Application {
  id: number;
  nickname: string;
  game_id: string;
  telegram: string;
  age: string | null;
  experience: string | null;
  reason: string;
  status: "pending" | "approved" | "rejected";
  created_at: string;
}

interface ApprovalResult {
  credentials: {
    login: string;
    password: string;
  };
  telegram: string;
}

const LightningBolt = ({ className }: { className?: string }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    className={className}
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth="1"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminKey, setAdminKey] = useState("");
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [approvalResult, setApprovalResult] = useState<ApprovalResult | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch(`/api/applications?key=${adminKey}`);
      if (res.ok) {
        const data = await res.json();
        setApplications(data);
        setIsAuthenticated(true);
        localStorage.setItem("adminKey", adminKey);
      } else {
        setError("Неверный ключ доступа");
      }
    } catch {
      setError("Ошибка подключения");
    } finally {
      setLoading(false);
    }
  };

  const fetchApplications = async () => {
    const key = localStorage.getItem("adminKey") || adminKey;
    try {
      const res = await fetch(`/api/applications?key=${key}`);
      if (res.ok) {
        const data = await res.json();
        setApplications(data);
      }
    } catch {
      console.error("Error fetching applications");
    }
  };

  const handleApprove = async (id: number) => {
    const key = localStorage.getItem("adminKey") || adminKey;
    setLoading(true);
    setApprovalResult(null);

    try {
      const res = await fetch(`/api/applications/${id}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminKey: key }),
      });

      if (res.ok) {
        const data = await res.json();
        setApprovalResult(data);
        await fetchApplications();
      } else {
        const errorData = await res.json();
        setError(errorData.error || "Ошибка при подтверждении");
      }
    } catch {
      setError("Ошибка подключения");
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async (id: number) => {
    const key = localStorage.getItem("adminKey") || adminKey;
    setLoading(true);

    try {
      const res = await fetch(`/api/applications/${id}/reject`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminKey: key }),
      });

      if (res.ok) {
        await fetchApplications();
      } else {
        const errorData = await res.json();
        setError(errorData.error || "Ошибка при отклонении");
      }
    } catch {
      setError("Ошибка подключения");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const savedKey = localStorage.getItem("adminKey");
    if (savedKey) {
      setAdminKey(savedKey);
      fetch(`/api/applications?key=${savedKey}`)
        .then((res) => {
          if (res.ok) {
            res.json().then((data) => {
              setApplications(data);
              setIsAuthenticated(true);
            });
          }
        })
        .catch(console.error);
    }
  }, []);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary">Ожидает</Badge>;
      case "approved":
        return <Badge className="bg-green-600 hover:bg-green-700">Принят</Badge>;
      case "rejected":
        return <Badge variant="destructive">Отклонён</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen storm-gradient flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-2 mb-4">
              <LightningBolt className="w-8 h-8 text-cyan-400" />
              <span className="text-2xl font-bold text-white">DARKSTORM</span>
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Панель администратора</h1>
            <p className="text-zinc-400">Введите ключ доступа для входа</p>
          </div>

          <form onSubmit={handleLogin} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
            {error && (
              <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 mb-4 text-red-400 text-sm">
                {error}
              </div>
            )}
            <div className="mb-4">
              <label className="block text-sm font-medium text-zinc-300 mb-2">
                Ключ доступа
              </label>
              <Input
                type="password"
                placeholder="Введите ключ"
                value={adminKey}
                onChange={(e) => setAdminKey(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Загрузка..." : "Войти"}
            </Button>
          </form>

          <div className="text-center mt-4">
            <Link href="/" className="text-zinc-400 hover:text-cyan-400 text-sm">
              Вернуться на главную
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen storm-gradient">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LightningBolt className="w-6 h-6 text-cyan-400" />
            <span className="text-xl font-bold text-white">DARKSTORM Admin</span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                На сайт
              </Button>
            </Link>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                localStorage.removeItem("adminKey");
                setIsAuthenticated(false);
              }}
            >
              Выйти
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Approval Result Modal */}
        {approvalResult && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
            <div className="bg-zinc-900 border border-cyan-500/50 rounded-2xl p-6 max-w-md w-full">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg
                    className="w-8 h-8 text-green-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M5 13l4 4L19 7"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Заявка принята!</h3>
                <p className="text-zinc-400 text-sm">
                  Отправьте эти данные игроку в Telegram: <span className="text-cyan-400">{approvalResult.telegram}</span>
                </p>
              </div>

              <div className="bg-zinc-800/50 rounded-xl p-4 mb-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-zinc-400 mb-1">Логин</div>
                    <div className="text-lg font-mono text-cyan-400 select-all">
                      {approvalResult.credentials.login}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-zinc-400 mb-1">Пароль</div>
                    <div className="text-lg font-mono text-cyan-400 select-all">
                      {approvalResult.credentials.password}
                    </div>
                  </div>
                </div>
              </div>

              <Button
                className="w-full"
                onClick={() => {
                  const text = `DARKSTORM - Добро пожаловать в клан!\n\nВаши данные для входа:\nЛогин: ${approvalResult.credentials.login}\nПароль: ${approvalResult.credentials.password}\n\nСайт: ${window.location.origin}/login`;
                  navigator.clipboard.writeText(text);
                }}
              >
                Скопировать сообщение
              </Button>
              <Button
                variant="outline"
                className="w-full mt-2"
                onClick={() => setApprovalResult(null)}
              >
                Закрыть
              </Button>
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="text-3xl font-bold text-white">{applications.length}</div>
            <div className="text-zinc-400 text-sm">Всего заявок</div>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="text-3xl font-bold text-yellow-400">
              {applications.filter((a) => a.status === "pending").length}
            </div>
            <div className="text-zinc-400 text-sm">Ожидают</div>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="text-3xl font-bold text-green-400">
              {applications.filter((a) => a.status === "approved").length}
            </div>
            <div className="text-zinc-400 text-sm">Принято</div>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
            <div className="text-3xl font-bold text-red-400">
              {applications.filter((a) => a.status === "rejected").length}
            </div>
            <div className="text-zinc-400 text-sm">Отклонено</div>
          </div>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 mb-4 text-red-400 text-sm">
            {error}
          </div>
        )}

        {/* Applications List */}
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-zinc-800">
            <h2 className="text-lg font-bold text-white">Заявки</h2>
          </div>

          {applications.length === 0 ? (
            <div className="p-8 text-center text-zinc-400">
              Пока нет заявок
            </div>
          ) : (
            <div className="divide-y divide-zinc-800">
              {applications.map((app) => (
                <div key={app.id} className="p-4 md:p-6">
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <h3 className="text-lg font-bold text-white">{app.nickname}</h3>
                        {getStatusBadge(app.status)}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mb-4">
                        <div>
                          <span className="text-zinc-400">ID игрока:</span>
                          <span className="text-white ml-2">{app.game_id}</span>
                        </div>
                        <div>
                          <span className="text-zinc-400">Telegram:</span>
                          <a
                            href={`https://t.me/${app.telegram.replace("@", "")}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-cyan-400 ml-2 hover:underline"
                          >
                            {app.telegram}
                          </a>
                        </div>
                        {app.age && (
                          <div>
                            <span className="text-zinc-400">Возраст:</span>
                            <span className="text-white ml-2">{app.age}</span>
                          </div>
                        )}
                      </div>

                      {app.experience && (
                        <div className="text-sm mb-2">
                          <span className="text-zinc-400">Опыт:</span>
                          <span className="text-white ml-2">{app.experience}</span>
                        </div>
                      )}

                      <div className="text-sm">
                        <span className="text-zinc-400">Причина:</span>
                        <p className="text-white mt-1">{app.reason}</p>
                      </div>

                      <div className="text-xs text-zinc-500 mt-3">
                        {new Date(app.created_at).toLocaleString("ru-RU")}
                      </div>
                    </div>

                    {app.status === "pending" && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleApprove(app.id)}
                          disabled={loading}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          Принять
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleReject(app.id)}
                          disabled={loading}
                        >
                          Отклонить
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
