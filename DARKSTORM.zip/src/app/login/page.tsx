"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

const LightningBolt = ({ className }: { className?: string }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    className={className}
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth="1"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

interface Member {
  id: number;
  nickname: string;
  game_id: string;
  telegram: string;
  login: string;
}

type View = "login" | "profile" | "changePassword" | "changeAll";

export default function LoginPage() {
  const [view, setView] = useState<View>("login");
  const [member, setMember] = useState<Member | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Login form
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");

  // Change credentials form
  const [oldLogin, setOldLogin] = useState("");
  const [oldPassword, setOldPassword] = useState("");
  const [newLogin, setNewLogin] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login, password }),
      });

      const data = await res.json();

      if (res.ok) {
        setMember(data.member);
        setView("profile");
      } else {
        setError(data.error || "Ошибка входа");
      }
    } catch {
      setError("Ошибка подключения");
    } finally {
      setLoading(false);
    }
  };

  const handleChangeCredentials = async (e: React.FormEvent, changeLogin: boolean) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");

    if (newPassword !== confirmPassword) {
      setError("Пароли не совпадают");
      setLoading(false);
      return;
    }

    try {
      const res = await fetch("/api/auth/change-credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          oldLogin,
          oldPassword,
          newLogin: changeLogin ? newLogin : oldLogin,
          newPassword,
        }),
      });

      const data = await res.json();

      if (res.ok) {
        setSuccess("Данные успешно изменены! Используйте новые данные для входа.");
        // Reset form
        setOldLogin("");
        setOldPassword("");
        setNewLogin("");
        setNewPassword("");
        setConfirmPassword("");
        // Go back to login after 2 seconds
        setTimeout(() => {
          setView("login");
          setSuccess("");
        }, 2000);
      } else {
        setError(data.error || "Ошибка при изменении данных");
      }
    } catch {
      setError("Ошибка подключения");
    } finally {
      setLoading(false);
    }
  };

  const renderLogin = () => (
    <div className="w-full max-w-md">
      <div className="text-center mb-8">
        <Link href="/" className="inline-flex items-center gap-2 mb-4">
          <LightningBolt className="w-8 h-8 text-cyan-400" />
          <span className="text-2xl font-bold text-white">DARKSTORM</span>
        </Link>
        <h1 className="text-2xl font-bold text-white mb-2">Вход в аккаунт</h1>
        <p className="text-zinc-400">Введите данные, которые вам выдали</p>
      </div>

      <form onSubmit={handleLogin} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
        {error && (
          <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 mb-4 text-red-400 text-sm">
            {error}
          </div>
        )}

        <div className="mb-4">
          <label className="block text-sm font-medium text-zinc-300 mb-2">
            Логин
          </label>
          <Input
            placeholder="DS123456"
            value={login}
            onChange={(e) => setLogin(e.target.value)}
            required
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-zinc-300 mb-2">
            Пароль
          </label>
          <Input
            type="password"
            placeholder="Ваш пароль"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <Button type="submit" className="w-full" disabled={loading}>
          <LightningBolt className="w-4 h-4" />
          {loading ? "Загрузка..." : "Войти"}
        </Button>
      </form>

      <div className="mt-6 space-y-2">
        <button
          type="button"
          onClick={() => setView("changePassword")}
          className="w-full text-center text-zinc-400 hover:text-cyan-400 text-sm py-2 transition-colors"
        >
          Изменить пароль
        </button>
        <button
          type="button"
          onClick={() => setView("changeAll")}
          className="w-full text-center text-zinc-400 hover:text-cyan-400 text-sm py-2 transition-colors"
        >
          Изменить логин и пароль
        </button>
      </div>

      <div className="text-center mt-6">
        <Link href="/" className="text-zinc-500 hover:text-zinc-300 text-sm">
          Вернуться на главную
        </Link>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="w-full max-w-md">
      <div className="text-center mb-8">
        <div className="w-20 h-20 bg-cyan-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <LightningBolt className="w-10 h-10 text-cyan-400" />
        </div>
        <Badge className="mb-2">Член клана</Badge>
        <h1 className="text-2xl font-bold text-white">{member?.nickname}</h1>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 mb-6">
        <div className="space-y-4">
          <div className="flex justify-between items-center py-2 border-b border-zinc-800">
            <span className="text-zinc-400">ID игрока</span>
            <span className="text-white font-mono">{member?.game_id}</span>
          </div>
          <div className="flex justify-between items-center py-2 border-b border-zinc-800">
            <span className="text-zinc-400">Telegram</span>
            <span className="text-cyan-400">{member?.telegram}</span>
          </div>
          <div className="flex justify-between items-center py-2">
            <span className="text-zinc-400">Логин</span>
            <span className="text-white font-mono">{member?.login}</span>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Button
          variant="outline"
          className="w-full"
          onClick={() => {
            setOldLogin(member?.login || "");
            setView("changePassword");
          }}
        >
          Изменить пароль
        </Button>
        <Button
          variant="outline"
          className="w-full"
          onClick={() => {
            setOldLogin(member?.login || "");
            setView("changeAll");
          }}
        >
          Изменить логин и пароль
        </Button>
        <Button
          variant="ghost"
          className="w-full"
          onClick={() => {
            setMember(null);
            setView("login");
            setLogin("");
            setPassword("");
          }}
        >
          Выйти
        </Button>
      </div>

      <div className="text-center mt-6">
        <Link href="/" className="text-zinc-500 hover:text-zinc-300 text-sm">
          Вернуться на главную
        </Link>
      </div>
    </div>
  );

  const renderChangeCredentials = (changeLogin: boolean) => (
    <div className="w-full max-w-md">
      <div className="text-center mb-8">
        <Link href="/" className="inline-flex items-center gap-2 mb-4">
          <LightningBolt className="w-8 h-8 text-cyan-400" />
          <span className="text-2xl font-bold text-white">DARKSTORM</span>
        </Link>
        <h1 className="text-2xl font-bold text-white mb-2">
          {changeLogin ? "Изменить логин и пароль" : "Изменить пароль"}
        </h1>
        <p className="text-zinc-400">Введите старые данные для подтверждения</p>
      </div>

      <form
        onSubmit={(e) => handleChangeCredentials(e, changeLogin)}
        className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6"
      >
        {error && (
          <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 mb-4 text-red-400 text-sm">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-green-500/10 border border-green-500/50 rounded-lg p-3 mb-4 text-green-400 text-sm">
            {success}
          </div>
        )}

        <div className="mb-6 pb-6 border-b border-zinc-800">
          <h3 className="text-sm font-medium text-zinc-400 mb-4 uppercase tracking-wider">
            Текущие данные
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-2">
                Текущий логин
              </label>
              <Input
                placeholder="DS123456"
                value={oldLogin}
                onChange={(e) => setOldLogin(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-2">
                Текущий пароль
              </label>
              <Input
                type="password"
                placeholder="Ваш текущий пароль"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                required
              />
            </div>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="text-sm font-medium text-zinc-400 mb-4 uppercase tracking-wider">
            Новые данные
          </h3>
          <div className="space-y-4">
            {changeLogin && (
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">
                  Новый логин
                </label>
                <Input
                  placeholder="Придумайте новый логин"
                  value={newLogin}
                  onChange={(e) => setNewLogin(e.target.value)}
                  required
                />
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-2">
                Новый пароль
              </label>
              <Input
                type="password"
                placeholder="Придумайте новый пароль"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-2">
                Повторите новый пароль
              </label>
              <Input
                type="password"
                placeholder="Повторите новый пароль"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
          </div>
        </div>

        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? "Сохранение..." : "Сохранить изменения"}
        </Button>
      </form>

      <div className="text-center mt-6">
        <button
          type="button"
          onClick={() => {
            setView(member ? "profile" : "login");
            setError("");
            setSuccess("");
            setOldLogin("");
            setOldPassword("");
            setNewLogin("");
            setNewPassword("");
            setConfirmPassword("");
          }}
          className="text-zinc-400 hover:text-cyan-400 text-sm"
        >
          Назад
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen storm-gradient flex items-center justify-center p-4">
      {view === "login" && renderLogin()}
      {view === "profile" && renderProfile()}
      {view === "changePassword" && renderChangeCredentials(false)}
      {view === "changeAll" && renderChangeCredentials(true)}
    </div>
  );
}
