"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { LightningBolt } from "@/components/common/LightningBolt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { mockTournaments } from "@/lib/mock-data";

// Timer component
const CountdownTimer = ({ targetDate }: { targetDate: string }) => {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = new Date(targetDate).getTime() - new Date().getTime();
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(timer);
  }, [targetDate]);

  return (
    <div className="flex items-center gap-1 text-sm">
      <div className="bg-zinc-800/80 px-2 py-1 rounded text-cyan-400 font-mono font-bold">
        {String(timeLeft.days).padStart(2, '0')}д
      </div>
      <span className="text-zinc-600">:</span>
      <div className="bg-zinc-800/80 px-2 py-1 rounded text-cyan-400 font-mono font-bold">
        {String(timeLeft.hours).padStart(2, '0')}ч
      </div>
      <span className="text-zinc-600">:</span>
      <div className="bg-zinc-800/80 px-2 py-1 rounded text-cyan-400 font-mono font-bold">
        {String(timeLeft.minutes).padStart(2, '0')}м
      </div>
      <span className="text-zinc-600">:</span>
      <div className="bg-zinc-800/80 px-2 py-1 rounded text-cyan-400 font-mono font-bold">
        {String(timeLeft.seconds).padStart(2, '0')}с
      </div>
    </div>
  );
};

// Featured Tournament Card (for carousel)
const FeaturedTournamentCard = ({ tournament }: { tournament: typeof mockTournaments[0] }) => {
  const statusColors = {
    upcoming: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    registration: 'bg-green-500/20 text-green-400 border-green-500/30',
    ongoing: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    finished: 'bg-zinc-500/20 text-zinc-400 border-zinc-500/30',
  };

  const statusLabels = {
    upcoming: 'Скоро',
    registration: 'Регистрация',
    ongoing: 'Идёт',
    finished: 'Завершён',
  };

  return (
    <Link
      href={`/tournaments/${tournament.id}`}
      className="flex-shrink-0 w-80 md:w-96 bg-zinc-900/70 border border-zinc-800 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-300 group"
    >
      <div className="relative h-40 overflow-hidden">
        <img
          src={tournament.banner}
          alt={tournament.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/30 to-transparent" />
        <Badge className={`absolute top-3 right-3 ${statusColors[tournament.status]}`}>
          {statusLabels[tournament.status]}
        </Badge>
        <div className="absolute bottom-3 left-3 right-3">
          <div className="text-2xl font-bold text-cyan-400">
            {tournament.prizePool} {tournament.currency}
          </div>
          <div className="text-xs text-zinc-400">Призовой фонд</div>
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors truncate">
          {tournament.name}
        </h3>
        <div className="flex items-center gap-4 text-sm text-zinc-400 mb-3">
          <span>{tournament.game}</span>
          <span className="w-1 h-1 rounded-full bg-zinc-600" />
          <span>{tournament.format}</span>
        </div>
        {(tournament.status === 'registration' || tournament.status === 'upcoming') && (
          <div className="flex items-center justify-between pt-3 border-t border-zinc-800">
            <span className="text-xs text-zinc-500">До начала:</span>
            <CountdownTimer targetDate={tournament.startDate} />
          </div>
        )}
        {tournament.status === 'ongoing' && (
          <div className="flex items-center justify-between pt-3 border-t border-zinc-800">
            <span className="text-xs text-zinc-500">Команд:</span>
            <span className="text-cyan-400 font-semibold">{tournament.registeredTeams}/{tournament.maxTeams}</span>
          </div>
        )}
      </div>
    </Link>
  );
};

// Tournament Card for grid
const TournamentCard = ({ tournament }: { tournament: typeof mockTournaments[0] }) => {
  const statusColors = {
    upcoming: 'bg-blue-500/20 text-blue-400',
    registration: 'bg-green-500/20 text-green-400',
    ongoing: 'bg-orange-500/20 text-orange-400',
    finished: 'bg-zinc-500/20 text-zinc-400',
  };

  const statusLabels = {
    upcoming: 'Скоро',
    registration: 'Регистрация открыта',
    ongoing: 'Идёт сейчас',
    finished: 'Завершён',
  };

  return (
    <Link
      href={`/tournaments/${tournament.id}`}
      className="group bg-zinc-900/50 border border-zinc-800 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-300"
    >
      <div className="relative h-36 overflow-hidden">
        <img
          src={tournament.banner}
          alt={tournament.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/40 to-transparent" />
        <Badge className={`absolute top-3 right-3 ${statusColors[tournament.status]}`}>
          {statusLabels[tournament.status]}
        </Badge>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
          {tournament.name}
        </h3>
        <p className="text-sm text-zinc-400 line-clamp-2 mb-4">
          {tournament.description}
        </p>

        <div className="flex items-center gap-4 text-sm text-zinc-500 mb-4">
          <span className="flex items-center gap-1">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>
            {tournament.game}
          </span>
          <span>{tournament.format}</span>
        </div>

        <div className="flex items-center justify-between pt-3 border-t border-zinc-800">
          <div>
            <div className="text-lg font-bold text-cyan-400">
              {tournament.prizePool} {tournament.currency}
            </div>
            <div className="text-xs text-zinc-500">Призовой фонд</div>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-white">
              {tournament.registeredTeams}/{tournament.maxTeams}
            </div>
            <div className="text-xs text-zinc-500">команд</div>
          </div>
        </div>

        {(tournament.status === 'registration' || tournament.status === 'upcoming') && (
          <div className="mt-4 pt-3 border-t border-zinc-800">
            <div className="flex items-center justify-between">
              <span className="text-xs text-zinc-500">
                {tournament.status === 'registration' ? 'Регистрация до:' : 'Начало:'}
              </span>
              <CountdownTimer targetDate={tournament.status === 'registration' ? tournament.registrationEnd : tournament.startDate} />
            </div>
          </div>
        )}
      </div>
    </Link>
  );
};

export default function TournamentsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [gameFilter, setGameFilter] = useState("all");
  const [formatFilter, setFormatFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [prizeFilter, setPrizeFilter] = useState("all");

  // Active tournaments for carousel
  const activeTournaments = mockTournaments.filter(
    t => t.status === 'registration' || t.status === 'ongoing' || t.status === 'upcoming'
  );

  // Filter tournaments
  const filteredTournaments = mockTournaments.filter((tournament) => {
    const matchesSearch = tournament.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGame = gameFilter === "all" || tournament.game === gameFilter;
    const matchesFormat = formatFilter === "all" || tournament.format === formatFilter;
    const matchesStatus = statusFilter === "all" || tournament.status === statusFilter;
    const matchesPrize = prizeFilter === "all" ||
      (prizeFilter === "high" && parseInt(tournament.prizePool.replace(/[^\d]/g, '')) >= 50000) ||
      (prizeFilter === "medium" && parseInt(tournament.prizePool.replace(/[^\d]/g, '')) >= 10000 && parseInt(tournament.prizePool.replace(/[^\d]/g, '')) < 50000) ||
      (prizeFilter === "low" && parseInt(tournament.prizePool.replace(/[^\d]/g, '')) < 10000);
    return matchesSearch && matchesGame && matchesFormat && matchesStatus && matchesPrize;
  });

  // Get unique values for filters
  const games = [...new Set(mockTournaments.map(t => t.game))];
  const formats = [...new Set(mockTournaments.map(t => t.format))];

  return (
    <div className="min-h-screen storm-gradient">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-zinc-900/80 backdrop-blur-sm border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <LightningBolt className="w-5 h-5 text-cyan-400" />
            <span className="text-lg font-bold text-white">DARKSTORM</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/clans" className="text-zinc-400 hover:text-cyan-400 transition-colors text-sm font-medium">
              Все кланы
            </Link>
            <Link href="/tournaments" className="text-cyan-400 text-sm font-medium">
              Турниры
            </Link>
          </nav>
          <Link href="/login">
            <Button variant="outline" size="sm">Личный кабинет</Button>
          </Link>
        </div>
      </header>

      <div className="pt-20 pb-12 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Page Header */}
          <div className="text-center mb-12">
            <Badge className="mb-4">
              <LightningBolt className="w-3 h-3 mr-1" />
              ТУРНИРЫ
            </Badge>
            <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
              Сражайся за <span className="text-cyan-400">призы</span>
            </h1>
            <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
              Участвуй в турнирах, побеждай и забирай награды
            </p>
          </div>

          {/* Active Tournaments Carousel */}
          {activeTournaments.length > 0 && (
            <div className="mb-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <LightningBolt className="w-5 h-5 text-cyan-400" />
                  Активные турниры
                </h2>
                <Badge variant="secondary">{activeTournaments.length} активных</Badge>
              </div>
              <div className="flex gap-6 overflow-x-auto pb-4 scrollbar-hide">
                {activeTournaments.map((tournament) => (
                  <FeaturedTournamentCard key={tournament.id} tournament={tournament} />
                ))}
              </div>
            </div>
          )}

          {/* Filters */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-4 md:p-6 mb-8">
            {/* Search */}
            <div className="relative mb-4">
              <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <Input
                placeholder="Поиск турнира..."
                className="pl-12 h-12 bg-zinc-800/50 border-zinc-700"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Filter buttons */}
            <div className="flex flex-wrap gap-3">
              {/* Game */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-zinc-500">Игра:</span>
                <div className="flex gap-1">
                  <button
                    onClick={() => setGameFilter("all")}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                      gameFilter === "all"
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                    }`}
                  >
                    Все
                  </button>
                  {games.map(game => (
                    <button
                      key={game}
                      onClick={() => setGameFilter(game)}
                      className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                        gameFilter === game
                          ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                          : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                      }`}
                    >
                      {game}
                    </button>
                  ))}
                </div>
              </div>

              {/* Format */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-zinc-500">Формат:</span>
                <div className="flex gap-1">
                  <button
                    onClick={() => setFormatFilter("all")}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                      formatFilter === "all"
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                    }`}
                  >
                    Все
                  </button>
                  {formats.map(format => (
                    <button
                      key={format}
                      onClick={() => setFormatFilter(format)}
                      className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                        formatFilter === format
                          ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                          : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                      }`}
                    >
                      {format}
                    </button>
                  ))}
                </div>
              </div>

              {/* Status */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-zinc-500">Статус:</span>
                <div className="flex gap-1 flex-wrap">
                  {[
                    { key: "all", label: "Все", color: "cyan" },
                    { key: "registration", label: "Регистрация", color: "green" },
                    { key: "upcoming", label: "Скоро", color: "blue" },
                    { key: "ongoing", label: "Идёт", color: "orange" },
                    { key: "finished", label: "Завершённые", color: "zinc" },
                  ].map(status => (
                    <button
                      key={status.key}
                      onClick={() => setStatusFilter(status.key)}
                      className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                        statusFilter === status.key
                          ? `bg-${status.color}-500/20 text-${status.color}-400 border border-${status.color}-500/30`
                          : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                      }`}
                    >
                      {status.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Prize Pool */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-zinc-500">Приз:</span>
                <div className="flex gap-1">
                  {[
                    { key: "all", label: "Любой" },
                    { key: "high", label: "50K+" },
                    { key: "medium", label: "10-50K" },
                    { key: "low", label: "до 10K" },
                  ].map(prize => (
                    <button
                      key={prize.key}
                      onClick={() => setPrizeFilter(prize.key)}
                      className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                        prizeFilter === prize.key
                          ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                          : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-600"
                      }`}
                    >
                      {prize.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Results Count */}
          <div className="flex items-center justify-between mb-6">
            <p className="text-zinc-400 text-sm">
              Найдено: <span className="text-white font-medium">{filteredTournaments.length}</span> турниров
            </p>
          </div>

          {/* Tournaments Grid */}
          {filteredTournaments.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTournaments.map((tournament) => (
                <TournamentCard key={tournament.id} tournament={tournament} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-zinc-900/30 border border-zinc-800 rounded-2xl">
              <svg className="w-16 h-16 mx-auto text-zinc-600 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-xl font-bold text-white mb-2">Турниры не найдены</h3>
              <p className="text-zinc-400">Попробуйте изменить параметры поиска</p>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-zinc-800">
        <div className="max-w-7xl mx-auto text-center text-zinc-500 text-sm">
          2026 DARKSTORM. Все права защищены.
        </div>
      </footer>
    </div>
  );
}
