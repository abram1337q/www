"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { LightningBolt } from "@/components/common/LightningBolt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { mockTournaments, mockClans } from "@/lib/mock-data";

// Countdown Timer
const CountdownTimer = ({ targetDate, size = "default" }: { targetDate: string; size?: "default" | "large" }) => {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = new Date(targetDate).getTime() - new Date().getTime();
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(timer);
  }, [targetDate]);

  if (size === "large") {
    return (
      <div className="flex items-center gap-2 md:gap-4">
        <div className="text-center">
          <div className="text-2xl md:text-4xl font-bold text-cyan-400 font-mono bg-zinc-800/80 px-3 py-2 rounded-lg">
            {String(timeLeft.days).padStart(2, '0')}
          </div>
          <div className="text-xs text-zinc-500 mt-1">дней</div>
        </div>
        <span className="text-2xl md:text-4xl text-zinc-600 font-bold">:</span>
        <div className="text-center">
          <div className="text-2xl md:text-4xl font-bold text-cyan-400 font-mono bg-zinc-800/80 px-3 py-2 rounded-lg">
            {String(timeLeft.hours).padStart(2, '0')}
          </div>
          <div className="text-xs text-zinc-500 mt-1">часов</div>
        </div>
        <span className="text-2xl md:text-4xl text-zinc-600 font-bold">:</span>
        <div className="text-center">
          <div className="text-2xl md:text-4xl font-bold text-cyan-400 font-mono bg-zinc-800/80 px-3 py-2 rounded-lg">
            {String(timeLeft.minutes).padStart(2, '0')}
          </div>
          <div className="text-xs text-zinc-500 mt-1">минут</div>
        </div>
        <span className="text-2xl md:text-4xl text-zinc-600 font-bold">:</span>
        <div className="text-center">
          <div className="text-2xl md:text-4xl font-bold text-cyan-400 font-mono bg-zinc-800/80 px-3 py-2 rounded-lg">
            {String(timeLeft.seconds).padStart(2, '0')}
          </div>
          <div className="text-xs text-zinc-500 mt-1">секунд</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1 text-sm">
      <div className="bg-zinc-800/80 px-2 py-1 rounded text-cyan-400 font-mono font-bold">
        {String(timeLeft.days).padStart(2, '0')}д
      </div>
      <span className="text-zinc-600">:</span>
      <div className="bg-zinc-800/80 px-2 py-1 rounded text-cyan-400 font-mono font-bold">
        {String(timeLeft.hours).padStart(2, '0')}ч
      </div>
      <span className="text-zinc-600">:</span>
      <div className="bg-zinc-800/80 px-2 py-1 rounded text-cyan-400 font-mono font-bold">
        {String(timeLeft.minutes).padStart(2, '0')}м
      </div>
      <span className="text-zinc-600">:</span>
      <div className="bg-zinc-800/80 px-2 py-1 rounded text-cyan-400 font-mono font-bold">
        {String(timeLeft.seconds).padStart(2, '0')}с
      </div>
    </div>
  );
};

// Mock bracket data
const mockBrackets = [
  {
    round: 1,
    name: "1/4 финала",
    matches: [
      { id: "1", team1: "DARKSTORM", team2: "Phoenix Rising", score1: 3, score2: 1, winner: "DARKSTORM" },
      { id: "2", team1: "Shadow Wolves", team2: "Cyber Dragons", score1: 2, score2: 3, winner: "Cyber Dragons" },
      { id: "3", team1: "Ice Titans", team2: "Night Raiders", score1: 3, score2: 0, winner: "Ice Titans" },
      { id: "4", team1: "Storm Chasers", team2: "Fire Legion", score1: 1, score2: 3, winner: "Fire Legion" },
    ],
  },
  {
    round: 2,
    name: "1/2 финала",
    matches: [
      { id: "5", team1: "DARKSTORM", team2: "Cyber Dragons", score1: 3, score2: 2, winner: "DARKSTORM" },
      { id: "6", team1: "Ice Titans", team2: "Fire Legion", score1: null, score2: null, winner: null },
    ],
  },
  {
    round: 3,
    name: "Финал",
    matches: [
      { id: "7", team1: "TBD", team2: "TBD", score1: null, score2: null, winner: null },
    ],
  },
];

// Mock participants
const mockParticipants = mockClans.slice(0, 8).map((clan, index) => ({
  id: clan.id,
  name: clan.name,
  tag: clan.tag,
  logo: clan.logo,
  seed: index + 1,
  kills: Math.floor(Math.random() * 50) + 10,
  points: Math.floor(Math.random() * 100) + 50,
}));

// Mock comments
const mockComments = [
  {
    id: "1",
    author: { nickname: "StormLeader", avatar: "https://i.pravatar.cc/100?img=1" },
    text: "Отличный турнир! Ждём всех на стриме!",
    createdAt: "2024-02-05T10:30:00",
    likes: 12,
  },
  {
    id: "2",
    author: { nickname: "ProGamer228", avatar: "https://i.pravatar.cc/100?img=10" },
    text: "Наша команда готова показать лучшую игру! GL HF всем участникам",
    createdAt: "2024-02-05T11:15:00",
    likes: 8,
  },
  {
    id: "3",
    author: { nickname: "CyberWarrior", avatar: "https://i.pravatar.cc/100?img=15" },
    text: "Призовой фонд огонь! Это будет легендарно",
    createdAt: "2024-02-05T12:00:00",
    likes: 15,
  },
];

// Bracket Match Component
const BracketMatch = ({ match }: { match: { id: string; team1: string; team2: string; score1?: number | null; score2?: number | null; winner?: string | null } }) => (
  <div className="bg-zinc-800/50 border border-zinc-700 rounded-lg p-3 min-w-[200px]">
    <div className={`flex items-center justify-between p-2 rounded ${match.winner === match.team1 ? 'bg-cyan-500/10' : ''}`}>
      <span className={`text-sm ${match.winner === match.team1 ? 'text-cyan-400 font-semibold' : 'text-zinc-300'}`}>
        {match.team1}
      </span>
      <span className={`text-sm font-bold ${match.winner === match.team1 ? 'text-cyan-400' : 'text-zinc-500'}`}>
        {match.score1 !== null ? match.score1 : '-'}
      </span>
    </div>
    <div className="border-t border-zinc-700 my-1" />
    <div className={`flex items-center justify-between p-2 rounded ${match.winner === match.team2 ? 'bg-cyan-500/10' : ''}`}>
      <span className={`text-sm ${match.winner === match.team2 ? 'text-cyan-400 font-semibold' : 'text-zinc-300'}`}>
        {match.team2}
      </span>
      <span className={`text-sm font-bold ${match.winner === match.team2 ? 'text-cyan-400' : 'text-zinc-500'}`}>
        {match.score2 !== null ? match.score2 : '-'}
      </span>
    </div>
  </div>
);

// Comment Component
const Comment = ({ comment }: { comment: typeof mockComments[0] }) => (
  <div className="flex gap-4 p-4 bg-zinc-800/30 rounded-xl">
    <Avatar className="w-10 h-10">
      <AvatarImage src={comment.author.avatar} />
      <AvatarFallback>{comment.author.nickname[0]}</AvatarFallback>
    </Avatar>
    <div className="flex-1">
      <div className="flex items-center gap-2 mb-1">
        <span className="font-semibold text-white">{comment.author.nickname}</span>
        <span className="text-xs text-zinc-500">
          {new Date(comment.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
      <p className="text-zinc-300 text-sm">{comment.text}</p>
      <div className="flex items-center gap-4 mt-2">
        <button className="flex items-center gap-1 text-xs text-zinc-500 hover:text-cyan-400 transition-colors">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
          {comment.likes}
        </button>
        <button className="text-xs text-zinc-500 hover:text-cyan-400 transition-colors">
          Ответить
        </button>
      </div>
    </div>
  </div>
);

export default function TournamentPage() {
  const params = useParams();
  const tournament = mockTournaments.find(t => t.id === params.id);
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [newComment, setNewComment] = useState("");

  if (!tournament) {
    return (
      <div className="min-h-screen storm-gradient flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Турнир не найден</h1>
          <Link href="/tournaments">
            <Button>Вернуться к списку турниров</Button>
          </Link>
        </div>
      </div>
    );
  }

  const statusColors: Record<string, string> = {
    upcoming: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    registration: 'bg-green-500/20 text-green-400 border-green-500/30',
    ongoing: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    finished: 'bg-zinc-500/20 text-zinc-400 border-zinc-500/30',
  };

  const statusLabels: Record<string, string> = {
    upcoming: 'Скоро',
    registration: 'Регистрация открыта',
    ongoing: 'Идёт сейчас',
    finished: 'Завершён',
  };

  const prizeDistribution = [
    { place: 1, percent: 50, color: 'text-yellow-400' },
    { place: 2, percent: 30, color: 'text-zinc-300' },
    { place: 3, percent: 20, color: 'text-orange-400' },
  ];

  return (
    <div className="min-h-screen storm-gradient">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-zinc-900/80 backdrop-blur-sm border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <LightningBolt className="w-5 h-5 text-cyan-400" />
            <span className="text-lg font-bold text-white">DARKSTORM</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/clans" className="text-zinc-400 hover:text-cyan-400 transition-colors text-sm font-medium">
              Все кланы
            </Link>
            <Link href="/tournaments" className="text-cyan-400 text-sm font-medium">
              Турниры
            </Link>
          </nav>
          <Link href="/login">
            <Button variant="outline" size="sm">Личный кабинет</Button>
          </Link>
        </div>
      </header>

      {/* Banner */}
      <div className="relative h-72 md:h-96 overflow-hidden pt-14">
        <img
          src={tournament.banner}
          alt={tournament.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/70 to-transparent" />

        {/* Back button */}
        <Link
          href="/tournaments"
          className="absolute top-20 left-4 flex items-center gap-2 px-3 py-2 bg-zinc-900/80 backdrop-blur-sm rounded-lg text-zinc-400 hover:text-white transition-colors"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Назад
        </Link>

        {/* Status badge */}
        <Badge className={`absolute top-20 right-4 ${statusColors[tournament.status]}`}>
          {statusLabels[tournament.status]}
        </Badge>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 -mt-32 relative z-10 pb-12">
        {/* Tournament Header */}
        <div className="bg-zinc-900/90 backdrop-blur-sm border border-zinc-800 rounded-2xl p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Info */}
            <div className="flex-1">
              <h1 className="text-3xl md:text-4xl font-black text-white mb-4">
                {tournament.name}
              </h1>
              <div className="flex flex-wrap items-center gap-4 text-sm text-zinc-400 mb-6">
                <span className="flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                  {tournament.game}
                </span>
                <span className="flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  {tournament.format}
                </span>
                <span className="flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  {new Date(tournament.startDate).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })}
                </span>
              </div>
              <p className="text-zinc-300">{tournament.description}</p>

              {/* Actions */}
              <div className="flex flex-wrap gap-3 mt-6">
                {tournament.status === 'registration' && (
                  <Button size="lg" onClick={() => setIsRegisterModalOpen(true)}>
                    <LightningBolt className="w-4 h-4 mr-2" />
                    Зарегистрироваться
                  </Button>
                )}
                {tournament.streamUrl && (
                  <a href={tournament.streamUrl} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="lg">
                      <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714z"/>
                      </svg>
                      Смотреть стрим
                    </Button>
                  </a>
                )}
              </div>
            </div>

            {/* Prize & Timer */}
            <div className="lg:w-80 space-y-4">
              {/* Prize Pool */}
              <div className="bg-zinc-800/50 rounded-xl p-5 text-center border border-zinc-700/50">
                <div className="text-sm text-zinc-500 mb-1">Призовой фонд</div>
                <div className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-cyan-500">
                  {tournament.prizePool} {tournament.currency}
                </div>
              </div>

              {/* Timer */}
              {(tournament.status === 'registration' || tournament.status === 'upcoming') && (
                <div className="bg-zinc-800/50 rounded-xl p-5 border border-zinc-700/50">
                  <div className="text-sm text-zinc-500 mb-3 text-center">
                    {tournament.status === 'registration' ? 'До конца регистрации:' : 'До начала:'}
                  </div>
                  <div className="flex justify-center">
                    <CountdownTimer
                      targetDate={tournament.status === 'registration' ? tournament.registrationEnd : tournament.startDate}
                      size="large"
                    />
                  </div>
                </div>
              )}

              {/* Teams Count */}
              <div className="bg-zinc-800/50 rounded-xl p-5 border border-zinc-700/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-zinc-500">Команд зарегистрировано</span>
                  <span className="font-bold text-white">{tournament.registeredTeams}/{tournament.maxTeams}</span>
                </div>
                <div className="w-full bg-zinc-700 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-cyan-400 h-2 rounded-full transition-all"
                    style={{ width: `${(tournament.registeredTeams / tournament.maxTeams) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs Content */}
        <Tabs defaultValue="info" className="space-y-6">
          <TabsList className="bg-zinc-900/50 border border-zinc-800 p-1 w-full md:w-auto overflow-x-auto flex-nowrap">
            <TabsTrigger value="info">Информация</TabsTrigger>
            <TabsTrigger value="participants">Участники</TabsTrigger>
            <TabsTrigger value="bracket">Турнирная сетка</TabsTrigger>
            <TabsTrigger value="comments">Обсуждение</TabsTrigger>
          </TabsList>

          {/* Info Tab */}
          <TabsContent value="info" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Rules */}
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Правила
                </h3>
                <div className="text-zinc-300 space-y-3">
                  <p>{tournament.rules}</p>
                  <ul className="list-disc list-inside space-y-2 text-zinc-400">
                    <li>Использование читов и макросов запрещено</li>
                    <li>Все участники должны быть онлайн за 15 минут до начала</li>
                    <li>Решение судей окончательно</li>
                    <li>Оскорбления и токсичное поведение наказуемы</li>
                  </ul>
                </div>
              </div>

              {/* Prize Distribution */}
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Распределение призов
                </h3>
                <div className="space-y-4">
                  {prizeDistribution.map((prize) => {
                    const prizeAmount = parseInt(tournament.prizePool.replace(/[^\d]/g, '')) * prize.percent / 100;
                    return (
                      <div key={prize.place} className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg ${
                          prize.place === 1 ? 'bg-yellow-500/20 text-yellow-400' :
                          prize.place === 2 ? 'bg-zinc-400/20 text-zinc-300' :
                          'bg-orange-500/20 text-orange-400'
                        }`}>
                          {prize.place}
                        </div>
                        <div className="flex-1">
                          <div className="font-semibold text-white">
                            {prize.place === 1 ? '1 место' : prize.place === 2 ? '2 место' : '3 место'}
                          </div>
                          <div className="text-sm text-zinc-500">{prize.percent}% от призового фонда</div>
                        </div>
                        <div className={`text-xl font-bold ${prize.color}`}>
                          {prizeAmount.toLocaleString()} {tournament.currency}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Schedule */}
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <svg className="w-5 h-5 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                Расписание
              </h3>
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl">
                  <div className="w-2 h-2 rounded-full bg-green-400" />
                  <div className="flex-1">
                    <div className="font-semibold text-white">Регистрация</div>
                    <div className="text-sm text-zinc-500">до {new Date(tournament.registrationEnd).toLocaleDateString('ru-RU')} 23:59</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl">
                  <div className="w-2 h-2 rounded-full bg-cyan-400" />
                  <div className="flex-1">
                    <div className="font-semibold text-white">Начало турнира</div>
                    <div className="text-sm text-zinc-500">{new Date(tournament.startDate).toLocaleDateString('ru-RU')} в {new Date(tournament.startDate).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 bg-zinc-800/30 rounded-xl">
                  <div className="w-2 h-2 rounded-full bg-orange-400" />
                  <div className="flex-1">
                    <div className="font-semibold text-white">Плей-офф</div>
                    <div className="text-sm text-zinc-500">После завершения группового этапа</div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Participants Tab */}
          <TabsContent value="participants">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white">Участники турнира</h3>
                <span className="text-sm text-zinc-500">{mockParticipants.length} команд</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-zinc-800">
                      <th className="text-left py-3 px-4 text-sm font-semibold text-zinc-400">#</th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-zinc-400">Команда</th>
                      <th className="text-center py-3 px-4 text-sm font-semibold text-zinc-400">Киллы</th>
                      <th className="text-center py-3 px-4 text-sm font-semibold text-zinc-400">Очки</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockParticipants.sort((a, b) => b.points - a.points).map((participant, index) => (
                      <tr key={participant.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                        <td className="py-4 px-4">
                          <div className={`w-6 h-6 rounded flex items-center justify-center text-sm font-bold ${
                            index === 0 ? 'bg-yellow-500/20 text-yellow-400' :
                            index === 1 ? 'bg-zinc-400/20 text-zinc-300' :
                            index === 2 ? 'bg-orange-500/20 text-orange-400' :
                            'bg-zinc-700/50 text-zinc-500'
                          }`}>
                            {index + 1}
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg overflow-hidden bg-zinc-700">
                              <img src={participant.logo} alt={participant.name} className="w-full h-full object-cover" />
                            </div>
                            <div>
                              <div className="font-semibold text-white">[{participant.tag}] {participant.name}</div>
                              <div className="text-xs text-zinc-500">Seed #{participant.seed}</div>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-4 text-center">
                          <span className="text-zinc-300">{participant.kills}</span>
                        </td>
                        <td className="py-4 px-4 text-center">
                          <span className="font-bold text-cyan-400">{participant.points}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>

          {/* Bracket Tab */}
          <TabsContent value="bracket">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-6">Турнирная сетка</h3>

              <div className="overflow-x-auto">
                <div className="flex gap-8 min-w-max pb-4">
                  {mockBrackets.map((round) => (
                    <div key={round.round} className="flex flex-col">
                      <div className="text-sm font-semibold text-cyan-400 mb-4 text-center">
                        {round.name}
                      </div>
                      <div className="flex flex-col gap-4 justify-center" style={{ minHeight: `${round.matches.length * 100}px` }}>
                        {round.matches.map((match) => (
                          <BracketMatch key={match.id} match={match} />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Comments Tab */}
          <TabsContent value="comments">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-6">Обсуждение</h3>

              {/* Add Comment */}
              <div className="mb-6 pb-6 border-b border-zinc-800">
                <div className="flex gap-4">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src="https://i.pravatar.cc/100?img=8" />
                    <AvatarFallback>U</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <Textarea
                      placeholder="Написать комментарий..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      className="min-h-[80px] mb-3"
                    />
                    <Button size="sm" disabled={!newComment.trim()}>
                      Отправить
                    </Button>
                  </div>
                </div>
              </div>

              {/* Comments List */}
              <div className="space-y-4">
                {mockComments.map((comment) => (
                  <Comment key={comment.id} comment={comment} />
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Registration Modal */}
      <Dialog open={isRegisterModalOpen} onOpenChange={setIsRegisterModalOpen}>
        <DialogContent className="bg-zinc-900 border-zinc-800 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-white flex items-center gap-2">
              <LightningBolt className="w-5 h-5 text-cyan-400" />
              Регистрация на турнир
            </DialogTitle>
          </DialogHeader>

          {isRegistered ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Вы зарегистрированы!</h3>
              <p className="text-zinc-400">Следите за уведомлениями о начале турнира</p>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setIsRegistered(true); }} className="space-y-4">
              <div className="bg-zinc-800/50 rounded-xl p-4 mb-4">
                <div className="text-sm text-zinc-400 mb-1">Турнир</div>
                <div className="font-semibold text-white">{tournament.name}</div>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-2">Название команды</label>
                <Input placeholder="Введите название вашей команды" required />
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-2">Капитан команды</label>
                <Input placeholder="Никнейм капитана" required />
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-2">Контакт для связи (Telegram)</label>
                <Input placeholder="@username" required />
              </div>

              <div className="bg-zinc-800/30 rounded-xl p-4 text-sm text-zinc-400">
                <div className="flex items-start gap-2">
                  <svg className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>После регистрации вы получите дальнейшие инструкции в Telegram</span>
                </div>
              </div>

              <Button type="submit" className="w-full">
                <LightningBolt className="w-4 h-4 mr-2" />
                Зарегистрироваться
              </Button>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-zinc-800">
        <div className="max-w-7xl mx-auto text-center text-zinc-500 text-sm">
          2026 DARKSTORM. Все права защищены.
        </div>
      </footer>
    </div>
  );
}
