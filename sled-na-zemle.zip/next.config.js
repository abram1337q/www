/** @type {import('next').NextConfig} */
const path = require('path');
const CopyPlugin = require('copy-webpack-plugin');

const cesiumSource = 'node_modules/cesium/Build/Cesium';
const cesiumBaseUrl = 'cesium';

const nextConfig = {
  allowedDevOrigins: ["*.preview.same-app.com"],
  images: {
    unoptimized: true,
    domains: [
      "source.unsplash.com",
      "images.unsplash.com",
      "ext.same-assets.com",
      "ugc.same-assets.com",
    ],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "source.unsplash.com",
        pathname: "/**",
      },
      {
        protocol: "https",
        hostname: "images.unsplash.com",
        pathname: "/**",
      },
      {
        protocol: "https",
        hostname: "ext.same-assets.com",
        pathname: "/**",
      },
      {
        protocol: "https",
        hostname: "ugc.same-assets.com",
        pathname: "/**",
      },
    ],
  },
  webpack: (config, { isServer }) => {
    if (!isServer) {
      // Cesium static files configuration
      config.plugins.push(
        new CopyPlugin({
          patterns: [
            {
              from: path.join(cesiumSource, 'Workers'),
              to: path.join('../public', cesiumBaseUrl, 'Workers'),
            },
            {
              from: path.join(cesiumSource, 'ThirdParty'),
              to: path.join('../public', cesiumBaseUrl, 'ThirdParty'),
            },
            {
              from: path.join(cesiumSource, 'Assets'),
              to: path.join('../public', cesiumBaseUrl, 'Assets'),
            },
            {
              from: path.join(cesiumSource, 'Widgets'),
              to: path.join('../public', cesiumBaseUrl, 'Widgets'),
            },
          ],
        })
      );

      // Define Cesium base URL
      config.plugins.push(
        new (require('webpack')).DefinePlugin({
          CESIUM_BASE_URL: JSON.stringify(`/${cesiumBaseUrl}`),
        })
      );
    }

    // Resolve cesium correctly
    config.resolve.alias = {
      ...config.resolve.alias,
      cesium: path.resolve(__dirname, 'node_modules/cesium/Build/Cesium/Cesium'),
    };

    return config;
  },
  // Disable turbopack for Cesium compatibility
  experimental: {
    turbo: undefined,
  },
};

module.exports = nextConfig;
