// Клиент базы данных Prisma
// Используем singleton паттерн для избежания множественных подключений

import { PrismaClient } from '@prisma/client';

// Расширяем глобальный объект для хранения клиента
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

// Создаём или используем существующий клиент
export const prisma = globalForPrisma.prisma ?? new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
});

// В режиме разработки сохраняем клиент в глобальном объекте
if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}

export default prisma;
