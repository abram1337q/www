import { NextRequest, NextResponse } from 'next/server';

// GET /api/settlements/{regionId} - получить населённые пункты региона
// Использует Overpass API (OpenStreetMap) для получения данных
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ regionId: string }> }
) {
  try {
    const { regionId } = await params;

    if (!regionId) {
      return NextResponse.json(
        { error: 'Region ID is required' },
        { status: 400 }
      );
    }

    // Используем Overpass API для получения населённых пунктов
    // Формируем запрос по ISO коду региона
    const overpassQuery = `
      [out:json][timeout:25];
      area["ISO3166-2"="${regionId}"]->.searchArea;
      (
        node["place"~"city|town|village"](area.searchArea);
      );
      out body;
    `;

    const response = await fetch('https://overpass-api.de/api/interpreter', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `data=${encodeURIComponent(overpassQuery)}`,
      next: { revalidate: 86400 }, // Кэшируем на 24 часа
    });

    if (!response.ok) {
      throw new Error('Overpass API request failed');
    }

    const data = await response.json();
    const elements = data.elements || [];

    // Преобразуем в нужный формат
    const settlements = elements.map((el: {
      id: number;
      lat: number;
      lon: number;
      tags?: {
        name?: string;
        'name:ru'?: string;
        population?: string;
        place?: string;
      };
    }) => ({
      id: String(el.id),
      name: el.tags?.['name:ru'] || el.tags?.name || 'Без названия',
      coordinates: [el.lon, el.lat] as [number, number],
      population: el.tags?.population ? parseInt(el.tags.population) : null,
      type: el.tags?.place || 'place',
    }));

    // Сортируем по населению (крупные города первыми)
    settlements.sort((a: { population: number | null }, b: { population: number | null }) =>
      (b.population || 0) - (a.population || 0)
    );

    return NextResponse.json({
      success: true,
      regionId,
      settlements: settlements.slice(0, 500), // Ограничиваем 500 населёнными пунктами
      total: settlements.length,
    }, {
      headers: {
        'Cache-Control': 'public, max-age=86400, s-maxage=86400',
      },
    });
  } catch (error) {
    console.error('Error fetching settlements:', error);

    // Возвращаем пустой массив вместо ошибки
    return NextResponse.json({
      success: true,
      regionId: '',
      settlements: [],
      total: 0,
      message: 'Could not load settlements',
    });
  }
}
