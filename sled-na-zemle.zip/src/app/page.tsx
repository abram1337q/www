'use client';

// Главная страница сервиса "След на Земле"
// Интерактивная 3D карта России с историями пользователей

import { useState, useEffect, useCallback } from 'react';
import dynamic from 'next/dynamic';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { CreateStoryModal, type CreateStoryFormData } from '@/components/story/CreateStoryModal';
import { StoryViewModal } from '@/components/story/StoryViewModal';
import type { Story, StoryMapMarker } from '@/types';
import { Loader2 } from 'lucide-react';

// Динамический импорт карты (без SSR, так как MapLibre работает только в браузере)
const InteractiveMap = dynamic(
  () => import('@/components/map/InteractiveMap'),
  {
    ssr: false,
    loading: () => (
      <div className="w-full h-full flex items-center justify-center bg-zinc-100">
        <div className="text-center">
          <Loader2 className="w-10 h-10 text-zinc-400 animate-spin mx-auto mb-4" />
          <p className="text-zinc-500">Загрузка карты...</p>
        </div>
      </div>
    )
  }
);

export default function HomePage() {
  // Состояние для историй на карте
  const [stories, setStories] = useState<StoryMapMarker[]>([]);
  const [isLoadingStories, setIsLoadingStories] = useState(true);

  // Состояние для модального окна создания истории
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [createCoordinates, setCreateCoordinates] = useState<{ lng: number; lat: number } | null>(null);

  // Состояние для модального окна просмотра истории
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedStory, setSelectedStory] = useState<Story | null>(null);
  const [selectedStoryId, setSelectedStoryId] = useState<string | undefined>();

  // Загрузка историй при монтировании
  useEffect(() => {
    loadStories();
  }, []);

  // Функция загрузки историй
  const loadStories = async () => {
    try {
      setIsLoadingStories(true);
      const response = await fetch('/api/stories');
      if (response.ok) {
        const data = await response.json();
        setStories(data.stories || []);
      }
    } catch (error) {
      console.error('Ошибка загрузки историй:', error);
    } finally {
      setIsLoadingStories(false);
    }
  };

  // Обработка клика по карте (открытие формы создания)
  const handleMapClick = useCallback((lngLat: { lng: number; lat: number }) => {
    setCreateCoordinates(lngLat);
    setIsCreateModalOpen(true);
  }, []);

  // Обработка клика по маркеру истории
  const handleStoryClick = useCallback(async (storyId: string) => {
    setSelectedStoryId(storyId);

    try {
      const response = await fetch(`/api/stories/${storyId}`);
      if (response.ok) {
        const data = await response.json();
        setSelectedStory(data.story);
        setIsViewModalOpen(true);
      }
    } catch (error) {
      console.error('Ошибка загрузки истории:', error);
    }
  }, []);

  // Обработка отправки формы создания
  const handleCreateSubmit = async (formData: CreateStoryFormData) => {
    try {
      // Создаём FormData для отправки файлов
      const submitData = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        if (key === 'authorPhoto' && value) {
          submitData.append(key, value as File);
        } else if (key === 'images' && Array.isArray(value)) {
          (value as File[]).forEach((file, index) => {
            submitData.append(`images[${index}]`, file);
          });
        } else if (value !== null && value !== undefined) {
          submitData.append(key, String(value));
        }
      });

      const response = await fetch('/api/stories', {
        method: 'POST',
        body: submitData,
      });

      const data = await response.json();

      if (data.success && data.paymentUrl) {
        // Перенаправляем на страницу оплаты
        window.location.href = data.paymentUrl;
      } else {
        throw new Error(data.error || 'Ошибка создания истории');
      }
    } catch (error) {
      console.error('Ошибка отправки формы:', error);
      alert('Произошла ошибка. Пожалуйста, попробуйте позже.');
    }
  };

  // Обработка сердечка
  const handleHeart = async (storyId: string) => {
    try {
      await fetch(`/api/stories/${storyId}/heart`, {
        method: 'POST',
      });

      // Обновляем счётчик в списке
      setStories(prev => prev.map(s =>
        s.id === storyId ? { ...s, heartsCount: s.heartsCount + 1 } : s
      ));
    } catch (error) {
      console.error('Ошибка отправки сердечка:', error);
    }
  };

  // Закрытие модальных окон
  const handleCloseCreateModal = () => {
    setIsCreateModalOpen(false);
    setCreateCoordinates(null);
  };

  const handleCloseViewModal = () => {
    setIsViewModalOpen(false);
    setSelectedStory(null);
    setSelectedStoryId(undefined);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Шапка */}
      <Header />

      {/* Основной контент - карта */}
      <main className="flex-1 pt-16 relative">
        <div className="absolute inset-0">
          <InteractiveMap
            stories={stories}
            onMapClick={handleMapClick}
            onStoryClick={handleStoryClick}
            selectedStoryId={selectedStoryId}
          />
        </div>

        {/* Индикатор загрузки историй */}
        {isLoadingStories && (
          <div className="absolute top-20 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-sm rounded-full px-4 py-2 shadow-lg flex items-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-zinc-500" />
            <span className="text-sm text-zinc-600">Загрузка историй...</span>
          </div>
        )}

        {/* Статистика (опционально) */}
        {!isLoadingStories && stories.length > 0 && (
          <div className="absolute top-20 right-4 bg-white/90 backdrop-blur-sm rounded-lg px-4 py-3 shadow-lg">
            <div className="text-2xl font-bold text-zinc-900">{stories.length}</div>
            <div className="text-xs text-zinc-500">
              {stories.length === 1 ? 'история' : stories.length < 5 ? 'истории' : 'историй'} на карте
            </div>
          </div>
        )}
      </main>

      {/* Подвал */}
      <Footer />

      {/* Модальное окно создания истории */}
      <CreateStoryModal
        isOpen={isCreateModalOpen}
        onClose={handleCloseCreateModal}
        coordinates={createCoordinates}
        onSubmit={handleCreateSubmit}
      />

      {/* Модальное окно просмотра истории */}
      <StoryViewModal
        isOpen={isViewModalOpen}
        onClose={handleCloseViewModal}
        story={selectedStory}
        onHeart={handleHeart}
      />
    </div>
  );
}
