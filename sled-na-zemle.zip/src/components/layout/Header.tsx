'use client';

// Шапка сайта с логотипом и названием
// Компактная и адаптивная для всех устройств

import Link from 'next/link';

interface HeaderProps {
  transparent?: boolean;
}

export function Header({ transparent = true }: HeaderProps) {
  return (
    <header
      className={`
        fixed top-0 left-0 right-0 z-50
        ${transparent
          ? 'bg-white/90 backdrop-blur-xl border-b border-zinc-200/50 shadow-sm'
          : 'bg-white border-b border-zinc-200 shadow-sm'
        }
      `}
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 sm:h-16">
          {/* Логотип и название */}
          <Link href="/" className="flex items-center gap-2 sm:gap-3 group">
            {/* Иконка-логотип */}
            <div className="relative flex-shrink-0">
              <div className="w-9 h-9 sm:w-11 sm:h-11 bg-gradient-to-br from-amber-400 via-orange-500 to-red-500 rounded-xl sm:rounded-2xl flex items-center justify-center shadow-lg shadow-orange-500/25 group-hover:shadow-xl group-hover:shadow-orange-500/30 transition-all duration-300 group-hover:scale-105">
                <svg className="w-5 h-5 sm:w-6 sm:h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              {/* Декоративный пульсирующий круг */}
              <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 sm:w-3 sm:h-3 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full border-2 border-white animate-pulse" />
            </div>

            {/* Название */}
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold bg-gradient-to-r from-zinc-800 via-zinc-700 to-zinc-800 bg-clip-text text-transparent leading-tight">
                История моей жизни
              </h1>
              <p className="text-[10px] sm:text-xs text-zinc-400 hidden sm:block font-medium">
                Оставь свой след на карте России
              </p>
            </div>
          </Link>

          {/* Навигация */}
          <nav className="flex items-center gap-2 sm:gap-4">
            <Link
              href="/legal/terms"
              className="text-xs sm:text-sm text-zinc-500 hover:text-zinc-700 transition-colors px-2 py-1 rounded-lg hover:bg-zinc-100"
            >
              <span className="hidden sm:inline">О проекте</span>
              <span className="sm:hidden">Инфо</span>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;
