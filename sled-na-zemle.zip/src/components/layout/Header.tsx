'use client';

// Шапка сайта с логотипом и названием
// Фиксированная позиция, прозрачный фон с размытием

import Link from 'next/link';
import { MapPin } from 'lucide-react';

interface HeaderProps {
  transparent?: boolean;
}

export function Header({ transparent = true }: HeaderProps) {
  return (
    <header
      className={`
        fixed top-0 left-0 right-0 z-50
        ${transparent
          ? 'bg-white/80 backdrop-blur-md border-b border-zinc-200/50'
          : 'bg-white border-b border-zinc-200'
        }
      `}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Логотип и название */}
          <Link href="/" className="flex items-center gap-3 group">
            {/* Иконка-логотип */}
            <div className="relative">
              <div className="w-10 h-10 bg-gradient-to-br from-zinc-800 to-zinc-900 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow">
                <MapPin className="w-5 h-5 text-white" />
              </div>
              {/* Декоративная точка */}
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-white" />
            </div>

            {/* Название */}
            <div>
              <h1 className="text-lg font-semibold text-zinc-900 leading-tight">
                История моей жизни
              </h1>
              <p className="text-xs text-zinc-500 hidden sm:block">
                Оставь свой след на карте России
              </p>
            </div>
          </Link>

          {/* Навигация (если понадобится) */}
          <nav className="hidden md:flex items-center gap-6">
            {/* Можно добавить навигацию */}
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;
