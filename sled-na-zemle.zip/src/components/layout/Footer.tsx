'use client';

// Компактный футер сайта
// Стильный дизайн с прозрачностью для наложения на карту

import Link from 'next/link';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const legalLinks = [
    { href: '/legal/terms', label: 'Соглашение' },
    { href: '/legal/privacy', label: 'Конфиденциальность' },
    { href: '/legal/moderation', label: 'Модерация' },
  ];

  return (
    <footer className="bg-zinc-900/95 backdrop-blur-xl text-zinc-400 border-t border-zinc-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 py-4">
          {/* Логотип и копирайт */}
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
              <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              </svg>
            </div>
            <span className="text-sm">
              <span className="text-zinc-300 font-medium">История моей жизни</span>
              <span className="text-zinc-600 mx-2 hidden sm:inline">·</span>
              <span className="hidden sm:inline">© {currentYear}</span>
            </span>
          </div>

          {/* Юридические ссылки */}
          <nav className="flex items-center gap-4 sm:gap-6">
            {legalLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-xs sm:text-sm text-zinc-500 hover:text-amber-400 transition-colors duration-200"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
