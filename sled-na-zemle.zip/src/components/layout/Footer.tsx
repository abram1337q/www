'use client';

// Подвал сайта с юридическими ссылками
// Содержит ссылки на пользовательское соглашение, политику конфиденциальности и правила модерации

import Link from 'next/link';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const legalLinks = [
    { href: '/legal/terms', label: 'Пользовательское соглашение' },
    { href: '/legal/privacy', label: 'Политика конфиденциальности' },
    { href: '/legal/moderation', label: 'Правила модерации' },
  ];

  return (
    <footer className="bg-zinc-900 text-zinc-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Копирайт */}
          <div className="text-sm text-center md:text-left">
            © {currentYear} «История моей жизни». Все права защищены.
          </div>

          {/* Юридические ссылки */}
          <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            {legalLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-sm hover:text-white transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        {/* Дополнительная информация */}
        <div className="mt-6 pt-6 border-t border-zinc-800 text-center">
          <p className="text-xs text-zinc-500">
            Сервис предназначен для создания интерактивной карты России с возможностью
            публикации пользователями личных историй, привязанных к географическим точкам.
          </p>
          <p className="text-xs text-zinc-600 mt-2">
            Данные хранятся на серверах в Российской Федерации в соответствии с 152-ФЗ
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
