'use client';

// Интерактивная 3D карта России на MapLibre GL JS
// Поддерживает три уровня детализации: регионы, населённые пункты, улицы

import { useEffect, useRef, useState, useCallback } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { RUSSIA_CENTER, RUSSIAN_REGIONS } from '@/data/regions';
import { STORY_CATEGORIES, type StoryCategoryId, type StoryMapMarker } from '@/types';

// Уровни зума для разных уровней детализации
const ZOOM_LEVELS = {
  COUNTRY: 3,      // Вся Россия
  REGION: 7,       // Регион
  SETTLEMENT: 14,  // Населённый пункт (улицы)
};

interface InteractiveMapProps {
  stories?: StoryMapMarker[];
  onMapClick?: (lngLat: { lng: number; lat: number }) => void;
  onStoryClick?: (storyId: string) => void;
  onRegionClick?: (regionId: string) => void;
  selectedStoryId?: string;
  initialCenter?: [number, number];
  initialZoom?: number;
}

export function InteractiveMap({
  stories = [],
  onMapClick,
  onStoryClick,
  onRegionClick,
  selectedStoryId,
  initialCenter,
  initialZoom,
}: InteractiveMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<maplibregl.Map | null>(null);
  const markersRef = useRef<maplibregl.Marker[]>([]);
  const [currentZoom, setCurrentZoom] = useState(initialZoom || ZOOM_LEVELS.COUNTRY);
  const [isMapLoaded, setIsMapLoaded] = useState(false);

  // Инициализация карты
  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    const mapTilerKey = process.env.NEXT_PUBLIC_MAPTILER_KEY || 'demo';

    // Создаём карту
    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: `https://api.maptiler.com/maps/streets-v2/style.json?key=${mapTilerKey}`,
      center: initialCenter || RUSSIA_CENTER,
      zoom: initialZoom || ZOOM_LEVELS.COUNTRY,
      pitch: 45, // Наклон для 3D эффекта
      bearing: 0,
      maxBounds: [
        [15, 35],   // Юго-запад
        [190, 85]   // Северо-восток
      ],
      minZoom: 2,
      maxZoom: 18,
    });

    const currentMap = map.current;

    // Добавляем контроллы
    currentMap.addControl(new maplibregl.NavigationControl({
      visualizePitch: true,
    }), 'top-right');

    currentMap.addControl(new maplibregl.ScaleControl({
      maxWidth: 200,
      unit: 'metric',
    }), 'bottom-left');

    // Обработчик загрузки карты
    currentMap.on('load', () => {
      setIsMapLoaded(true);

      // Добавляем 3D здания для детализации
      const layers = currentMap.getStyle().layers;
      const labelLayer = layers?.find(
        layer => layer.type === 'symbol' && layer.layout?.['text-field']
      );

      if (labelLayer) {
        currentMap.addLayer(
          {
            id: '3d-buildings',
            source: 'openmaptiles',
            'source-layer': 'building',
            filter: ['==', 'extrude', 'true'],
            type: 'fill-extrusion',
            minzoom: 14,
            paint: {
              'fill-extrusion-color': '#d4d4d8',
              'fill-extrusion-height': ['get', 'height'],
              'fill-extrusion-base': ['get', 'min_height'],
              'fill-extrusion-opacity': 0.7,
            },
          },
          labelLayer.id
        );
      }
    });

    // Отслеживаем изменение зума
    currentMap.on('zoom', () => {
      setCurrentZoom(currentMap.getZoom());
    });

    // Обработчик клика по карте
    currentMap.on('click', (e) => {
      const zoom = currentMap.getZoom();

      // На уровне улиц - открываем форму создания истории
      if (zoom >= ZOOM_LEVELS.SETTLEMENT && onMapClick) {
        // Проверяем, не кликнули ли по маркеру
        const features = currentMap.queryRenderedFeatures(e.point);
        const isMarkerClick = features.some(f => f.layer.id === 'story-markers');

        if (!isMarkerClick) {
          onMapClick({ lng: e.lngLat.lng, lat: e.lngLat.lat });
        }
      }
    });

    // Очистка при размонтировании
    return () => {
      markersRef.current.forEach(marker => marker.remove());
      currentMap.remove();
      map.current = null;
    };
  }, [initialCenter, initialZoom, onMapClick]);

  // Функция создания HTML маркера с эмодзи
  const createMarkerElement = useCallback((story: StoryMapMarker, isSelected: boolean) => {
    const category = STORY_CATEGORIES[story.category];
    const el = document.createElement('div');
    el.className = 'story-marker';
    el.innerHTML = `
      <div class="marker-container ${isSelected ? 'selected' : ''}">
        <span class="marker-emoji">${category.emoji}</span>
        ${story.heartsCount > 0 ? `<span class="marker-hearts">${story.heartsCount}</span>` : ''}
      </div>
    `;

    // Добавляем обработчик клика
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      onStoryClick?.(story.id);
    });

    return el;
  }, [onStoryClick]);

  // Обновление маркеров на карте
  useEffect(() => {
    if (!map.current || !isMapLoaded) return;

    // Удаляем старые маркеры
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    // Добавляем новые маркеры
    stories.forEach(story => {
      const isSelected = story.id === selectedStoryId;
      const el = createMarkerElement(story, isSelected);

      const marker = new maplibregl.Marker({
        element: el,
        anchor: 'bottom',
      })
        .setLngLat([story.longitude, story.latitude])
        .addTo(map.current!);

      markersRef.current.push(marker);
    });
  }, [stories, selectedStoryId, isMapLoaded, createMarkerElement]);

  // Функция перелёта к точке
  const flyTo = useCallback((center: [number, number], zoom: number) => {
    if (!map.current) return;

    map.current.flyTo({
      center,
      zoom,
      pitch: zoom >= ZOOM_LEVELS.SETTLEMENT ? 60 : 45,
      duration: 1500,
      essential: true,
    });
  }, []);

  // Функция перелёта к региону
  const flyToRegion = useCallback((regionId: string) => {
    const region = RUSSIAN_REGIONS.find(r => r.id === regionId);
    if (region) {
      flyTo(region.center, ZOOM_LEVELS.REGION);
      onRegionClick?.(regionId);
    }
  }, [flyTo, onRegionClick]);

  // Получение текущего уровня детализации
  const getZoomLevel = () => {
    if (currentZoom >= ZOOM_LEVELS.SETTLEMENT) return 'settlement';
    if (currentZoom >= ZOOM_LEVELS.REGION) return 'region';
    return 'country';
  };

  return (
    <div className="relative w-full h-full">
      {/* Контейнер карты */}
      <div ref={mapContainer} className="w-full h-full" />

      {/* Индикатор уровня зума */}
      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 shadow-lg z-10">
        <div className="text-xs text-zinc-500 mb-1">Уровень просмотра</div>
        <div className="text-sm font-medium text-zinc-900">
          {getZoomLevel() === 'country' && 'Вся Россия'}
          {getZoomLevel() === 'region' && 'Регион'}
          {getZoomLevel() === 'settlement' && 'Населённый пункт'}
        </div>
      </div>

      {/* Подсказка для создания истории */}
      {currentZoom >= ZOOM_LEVELS.SETTLEMENT && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 bg-zinc-900/90 text-white px-4 py-2 rounded-full text-sm shadow-lg z-10 pointer-events-none">
          Нажмите на карту, чтобы оставить свою историю
        </div>
      )}

      {/* Стили для маркеров */}
      <style jsx global>{`
        .story-marker {
          cursor: pointer;
          transition: transform 0.2s ease;
        }
        .story-marker:hover {
          transform: scale(1.2);
        }
        .marker-container {
          display: flex;
          flex-direction: column;
          align-items: center;
          filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
        }
        .marker-container.selected {
          transform: scale(1.3);
        }
        .marker-emoji {
          font-size: 28px;
          line-height: 1;
        }
        .marker-hearts {
          background: #ef4444;
          color: white;
          font-size: 10px;
          font-weight: 600;
          padding: 2px 6px;
          border-radius: 10px;
          margin-top: -4px;
          min-width: 18px;
          text-align: center;
        }

        /* Кастомные стили карты */
        .maplibregl-ctrl-group {
          background: rgba(255, 255, 255, 0.95) !important;
          backdrop-filter: blur(8px);
          border-radius: 12px !important;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
        }
        .maplibregl-ctrl-group button {
          border-radius: 8px !important;
        }
        .maplibregl-ctrl-scale {
          background: rgba(255, 255, 255, 0.9) !important;
          backdrop-filter: blur(8px);
          border-radius: 6px !important;
          padding: 2px 8px !important;
          font-size: 11px !important;
        }
      `}</style>
    </div>
  );
}

export default InteractiveMap;
