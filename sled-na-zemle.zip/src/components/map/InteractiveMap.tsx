'use client';

// Интерактивная 3D карта России на MapLibre GL JS
// Показывает ТОЛЬКО Россию с красивой визуализацией регионов

import { useEffect, useRef, useState, useCallback } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { RUSSIA_CENTER, RUSSIAN_REGIONS, type RussianRegion } from '@/data/regions';
import { STORY_CATEGORIES, type StoryMapMarker } from '@/types';

// Уровни зума для разных уровней детализации
const ZOOM_LEVELS = {
  COUNTRY: 3,
  REGION: 6,
  CITY: 10,
  SETTLEMENT: 14,
};

// Границы России
const RUSSIA_BOUNDS: [[number, number], [number, number]] = [
  [19.0, 41.0],
  [180.0, 82.0]
];

interface InteractiveMapProps {
  stories?: StoryMapMarker[];
  onMapClick?: (lngLat: { lng: number; lat: number }) => void;
  onStoryClick?: (storyId: string) => void;
  onRegionClick?: (regionId: string) => void;
  selectedStoryId?: string;
  initialCenter?: [number, number];
  initialZoom?: number;
}

// Цвета для федеральных округов
const DISTRICT_COLORS: Record<string, string> = {
  'Центральный': '#E8D5B7',
  'Северо-Западный': '#C7E0D8',
  'Южный': '#F5E1D0',
  'Северо-Кавказский': '#E5D4C0',
  'Приволжский': '#D4E2D4',
  'Уральский': '#D6DDE8',
  'Сибирский': '#D8E8E8',
  'Дальневосточный': '#E0E5D8',
};

export function InteractiveMap({
  stories = [],
  onMapClick,
  onStoryClick,
  onRegionClick,
  selectedStoryId,
  initialCenter,
  initialZoom,
}: InteractiveMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<maplibregl.Map | null>(null);
  const markersRef = useRef<maplibregl.Marker[]>([]);
  const regionMarkersRef = useRef<maplibregl.Marker[]>([]);
  const [currentZoom, setCurrentZoom] = useState(initialZoom || ZOOM_LEVELS.COUNTRY);
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);
  const [selectedRegion, setSelectedRegion] = useState<RussianRegion | null>(null);
  const [settlements, setSettlements] = useState<Array<{ id: string; name: string; coordinates: [number, number]; population: number | null }>>([]);

  // Подсчёт историй по регионам
  const storiesByRegion = useCallback(() => {
    const counts: Record<string, number> = {};
    stories.forEach(story => {
      if (story.regionId) {
        counts[story.regionId] = (counts[story.regionId] || 0) + 1;
      }
    });
    return counts;
  }, [stories]);

  // Инициализация карты
  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    const mapTilerKey = process.env.NEXT_PUBLIC_MAPTILER_KEY || 'get_your_own_OpIi9ZULNHzrESv6T2vL';

    // Создаём карту с кастомным стилем, ограниченным Россией
    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: {
        version: 8,
        name: 'Russia Map',
        sources: {
          'russia-base': {
            type: 'raster',
            tiles: [
              `https://api.maptiler.com/maps/backdrop/{z}/{x}/{y}.png?key=${mapTilerKey}`
            ],
            tileSize: 256,
            attribution: '&copy; <a href="https://www.maptiler.com/">MapTiler</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
          },
        },
        layers: [
          {
            id: 'background',
            type: 'background',
            paint: {
              'background-color': '#1a365d',
            },
          },
          {
            id: 'russia-base-layer',
            type: 'raster',
            source: 'russia-base',
            minzoom: 0,
            maxzoom: 19,
          },
        ],
        glyphs: `https://api.maptiler.com/fonts/{fontstack}/{range}.pbf?key=${mapTilerKey}`,
      },
      center: initialCenter || [100.0, 65.0],
      zoom: initialZoom || ZOOM_LEVELS.COUNTRY,
      pitch: 30,
      bearing: 0,
      maxBounds: RUSSIA_BOUNDS,
      minZoom: 2.5,
      maxZoom: 18,
    });

    const currentMap = map.current;

    // Добавляем контроллы
    currentMap.addControl(new maplibregl.NavigationControl({
      visualizePitch: true,
    }), 'top-right');

    currentMap.addControl(new maplibregl.ScaleControl({
      maxWidth: 200,
      unit: 'metric',
    }), 'bottom-left');

    // Загрузка карты
    currentMap.on('load', async () => {
      setIsMapLoaded(true);

      // Добавляем GeoJSON источник для регионов России
      try {
        const response = await fetch('https://raw.githubusercontent.com/codeforamerica/click_that_hood/master/public/data/russia.geojson');
        const russiaGeoJSON = await response.json();

        currentMap.addSource('russia-regions', {
          type: 'geojson',
          data: russiaGeoJSON,
        });

        // Слой заливки регионов с 3D-эффектом (fill-extrusion)
        currentMap.addLayer({
          id: 'regions-3d',
          type: 'fill-extrusion',
          source: 'russia-regions',
          paint: {
            'fill-extrusion-color': [
              'case',
              ['boolean', ['feature-state', 'hover'], false],
              '#fbbf24',
              ['boolean', ['feature-state', 'selected'], false],
              '#f59e0b',
              '#e2e8f0'
            ],
            'fill-extrusion-height': [
              'case',
              ['boolean', ['feature-state', 'hover'], false],
              50000,
              25000
            ],
            'fill-extrusion-base': 0,
            'fill-extrusion-opacity': 0.85,
          },
        });

        // Плоский слой для областей без 3D (fallback и для кликов)
        currentMap.addLayer({
          id: 'regions-fill',
          type: 'fill',
          source: 'russia-regions',
          paint: {
            'fill-color': 'transparent',
            'fill-opacity': 0,
          },
        });

        // Границы регионов
        currentMap.addLayer({
          id: 'regions-border',
          type: 'line',
          source: 'russia-regions',
          paint: {
            'line-color': '#475569',
            'line-width': [
              'interpolate',
              ['linear'],
              ['zoom'],
              3, 0.5,
              6, 1,
              10, 2
            ],
            'line-opacity': 0.8,
          },
        });

        // Названия регионов
        currentMap.addLayer({
          id: 'regions-labels',
          type: 'symbol',
          source: 'russia-regions',
          minzoom: 4,
          layout: {
            'text-field': ['get', 'name'],
            'text-font': ['Open Sans Bold'],
            'text-size': [
              'interpolate',
              ['linear'],
              ['zoom'],
              4, 8,
              6, 10,
              8, 12
            ],
            'text-anchor': 'center',
            'text-max-width': 8,
          },
          paint: {
            'text-color': '#1e293b',
            'text-halo-color': '#ffffff',
            'text-halo-width': 1.5,
            'text-opacity': [
              'interpolate',
              ['linear'],
              ['zoom'],
              4, 0.6,
              6, 1
            ],
          },
        });

        // Hover эффект для регионов
        let hoveredId: string | number | null = null;

        currentMap.on('mousemove', 'regions-fill', (e) => {
          if (e.features && e.features.length > 0) {
            if (hoveredId !== null) {
              currentMap.setFeatureState(
                { source: 'russia-regions', id: hoveredId },
                { hover: false }
              );
            }
            hoveredId = e.features[0].id ?? null;
            if (hoveredId !== null) {
              currentMap.setFeatureState(
                { source: 'russia-regions', id: hoveredId },
                { hover: true }
              );
            }
            const regionName = e.features[0].properties?.name;
            setHoveredRegion(regionName);
            currentMap.getCanvas().style.cursor = 'pointer';
          }
        });

        currentMap.on('mouseleave', 'regions-fill', () => {
          if (hoveredId !== null) {
            currentMap.setFeatureState(
              { source: 'russia-regions', id: hoveredId },
              { hover: false }
            );
          }
          hoveredId = null;
          setHoveredRegion(null);
          currentMap.getCanvas().style.cursor = '';
        });

        // Клик по региону
        currentMap.on('click', 'regions-fill', (e) => {
          if (e.features && e.features.length > 0) {
            const feature = e.features[0];
            const regionName = feature.properties?.name;

            // Находим регион в нашем списке
            const region = RUSSIAN_REGIONS.find(r =>
              r.name.toLowerCase().includes(regionName?.toLowerCase() || '') ||
              regionName?.toLowerCase().includes(r.name.toLowerCase())
            );

            if (region) {
              setSelectedRegion(region);
              onRegionClick?.(region.id);

              // Плавный зум к региону
              currentMap.flyTo({
                center: region.center,
                zoom: ZOOM_LEVELS.REGION,
                pitch: 45,
                duration: 1500,
              });

              // Загружаем населённые пункты региона
              loadSettlements(region.id);
            }
          }
        });

      } catch (error) {
        console.error('Ошибка загрузки GeoJSON:', error);
      }
    });

    // Функция загрузки населённых пунктов
    const loadSettlements = async (regionId: string) => {
      try {
        const response = await fetch(`/api/settlements/${regionId}`);
        const data = await response.json();
        if (data.success && data.settlements) {
          setSettlements(data.settlements.slice(0, 100)); // Топ-100 населённых пунктов
        }
      } catch (error) {
        console.error('Ошибка загрузки населённых пунктов:', error);
      }
    };

    // Отслеживаем изменение зума
    currentMap.on('zoom', () => {
      setCurrentZoom(currentMap.getZoom());
    });

    // Обработчик клика по карте (для создания истории)
    currentMap.on('click', (e) => {
      const zoom = currentMap.getZoom();

      // На уровне улиц - открываем форму создания истории
      if (zoom >= ZOOM_LEVELS.SETTLEMENT && onMapClick) {
        const features = currentMap.queryRenderedFeatures(e.point, {
          layers: ['regions-fill']
        });

        if (features.length === 0) {
          onMapClick({ lng: e.lngLat.lng, lat: e.lngLat.lat });
        }
      }
    });

    // Очистка при размонтировании
    return () => {
      markersRef.current.forEach(marker => marker.remove());
      currentMap.remove();
      map.current = null;
    };
  }, [initialCenter, initialZoom, onMapClick, onRegionClick]);

  // Функция создания HTML маркера с эмодзи
  const createMarkerElement = useCallback((story: StoryMapMarker, isSelected: boolean) => {
    const category = STORY_CATEGORIES[story.category];
    const el = document.createElement('div');
    el.className = 'story-marker';
    el.innerHTML = `
      <div class="marker-container ${isSelected ? 'selected' : ''}">
        <div class="marker-pin">
          <span class="marker-emoji">${category.emoji}</span>
        </div>
        ${story.heartsCount > 0 ? `<span class="marker-hearts">${story.heartsCount}</span>` : ''}
      </div>
    `;

    el.addEventListener('click', (e) => {
      e.stopPropagation();
      onStoryClick?.(story.id);
    });

    return el;
  }, [onStoryClick]);

  // Обновление маркеров и кластеров на карте
  useEffect(() => {
    if (!map.current || !isMapLoaded) return;

    const currentMap = map.current;

    // Удаляем старые маркеры
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    // Удаляем старые слои кластеризации если есть
    if (currentMap.getLayer('clusters')) currentMap.removeLayer('clusters');
    if (currentMap.getLayer('cluster-count')) currentMap.removeLayer('cluster-count');
    if (currentMap.getLayer('unclustered-point')) currentMap.removeLayer('unclustered-point');
    if (currentMap.getSource('stories-source')) currentMap.removeSource('stories-source');

    if (stories.length === 0) return;

    // Создаём GeoJSON из историй
    const storiesGeoJSON: GeoJSON.FeatureCollection = {
      type: 'FeatureCollection',
      features: stories.map(story => ({
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: [story.longitude, story.latitude]
        },
        properties: {
          id: story.id,
          category: story.category,
          authorName: story.authorName,
          heartsCount: story.heartsCount,
          emoji: STORY_CATEGORIES[story.category]?.emoji || '📍'
        }
      }))
    };

    // Добавляем источник с кластеризацией
    currentMap.addSource('stories-source', {
      type: 'geojson',
      data: storiesGeoJSON,
      cluster: true,
      clusterMaxZoom: 12,
      clusterRadius: 50
    });

    // Слой кластеров
    currentMap.addLayer({
      id: 'clusters',
      type: 'circle',
      source: 'stories-source',
      filter: ['has', 'point_count'],
      paint: {
        'circle-color': [
          'step',
          ['get', 'point_count'],
          '#fbbf24',
          10, '#f59e0b',
          30, '#ea580c',
          100, '#dc2626'
        ],
        'circle-radius': [
          'step',
          ['get', 'point_count'],
          20,
          10, 25,
          30, 30,
          100, 40
        ],
        'circle-stroke-width': 3,
        'circle-stroke-color': '#ffffff'
      }
    });

    // Текст с количеством в кластере
    currentMap.addLayer({
      id: 'cluster-count',
      type: 'symbol',
      source: 'stories-source',
      filter: ['has', 'point_count'],
      layout: {
        'text-field': '{point_count_abbreviated}',
        'text-font': ['Open Sans Bold'],
        'text-size': 14
      },
      paint: {
        'text-color': '#ffffff'
      }
    });

    // Клик по кластеру - зум
    currentMap.on('click', 'clusters', (e) => {
      const features = currentMap.queryRenderedFeatures(e.point, { layers: ['clusters'] });
      if (!features.length) return;

      const clusterId = features[0].properties?.cluster_id;
      const source = currentMap.getSource('stories-source') as maplibregl.GeoJSONSource;

      source.getClusterExpansionZoom(clusterId, (err, zoom) => {
        if (err) return;
        currentMap.easeTo({
          center: (features[0].geometry as GeoJSON.Point).coordinates as [number, number],
          zoom: zoom || 10
        });
      });
    });

    // Hover на кластерах
    currentMap.on('mouseenter', 'clusters', () => {
      currentMap.getCanvas().style.cursor = 'pointer';
    });
    currentMap.on('mouseleave', 'clusters', () => {
      currentMap.getCanvas().style.cursor = '';
    });

    // Добавляем индивидуальные маркеры для некластеризованных точек
    if (currentZoom >= ZOOM_LEVELS.CITY) {
      stories.forEach(story => {
        const isSelected = story.id === selectedStoryId;
        const el = createMarkerElement(story, isSelected);

        const marker = new maplibregl.Marker({
          element: el,
          anchor: 'bottom',
        })
          .setLngLat([story.longitude, story.latitude])
          .addTo(currentMap);

        markersRef.current.push(marker);
      });
    }
  }, [stories, selectedStoryId, isMapLoaded, createMarkerElement, currentZoom]);

  // Отображение маркеров с количеством историй на регионах
  useEffect(() => {
    if (!map.current || !isMapLoaded) return;

    // Удаляем старые маркеры регионов
    regionMarkersRef.current.forEach(marker => marker.remove());
    regionMarkersRef.current = [];

    // Показываем маркеры только на уровне страны/региона
    if (currentZoom < ZOOM_LEVELS.CITY) {
      const counts = storiesByRegion();

      RUSSIAN_REGIONS.forEach(region => {
        const count = counts[region.id] || 0;
        if (count === 0) return; // Не показываем регионы без историй

        const el = document.createElement('div');
        el.className = 'region-story-count';
        el.innerHTML = `
          <div class="region-badge ${count > 10 ? 'hot' : count > 5 ? 'warm' : ''}">
            <span class="count">${count}</span>
            <span class="icon">📖</span>
          </div>
        `;

        el.addEventListener('click', () => {
          setSelectedRegion(region);
          onRegionClick?.(region.id);
          map.current?.flyTo({
            center: region.center,
            zoom: ZOOM_LEVELS.REGION,
            pitch: 45,
            duration: 1500,
          });
        });

        const marker = new maplibregl.Marker({
          element: el,
          anchor: 'center',
        })
          .setLngLat(region.center)
          .addTo(map.current!);

        regionMarkersRef.current.push(marker);
      });
    }
  }, [currentZoom, isMapLoaded, stories, storiesByRegion, onRegionClick]);

  // Отображение населённых пунктов при зуме на регион
  useEffect(() => {
    if (!map.current || !isMapLoaded) return;

    const currentMap = map.current;

    // Удаляем старый слой населённых пунктов
    if (currentMap.getLayer('settlements-labels')) {
      currentMap.removeLayer('settlements-labels');
    }
    if (currentMap.getLayer('settlements-circles')) {
      currentMap.removeLayer('settlements-circles');
    }
    if (currentMap.getSource('settlements-source')) {
      currentMap.removeSource('settlements-source');
    }

    // Показываем населённые пункты только на уровне региона
    if (currentZoom >= ZOOM_LEVELS.REGION && currentZoom < ZOOM_LEVELS.CITY && settlements.length > 0) {
      const settlementsGeoJSON: GeoJSON.FeatureCollection = {
        type: 'FeatureCollection',
        features: settlements.map(s => ({
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: s.coordinates,
          },
          properties: {
            id: s.id,
            name: s.name,
            population: s.population || 0,
          },
        })),
      };

      currentMap.addSource('settlements-source', {
        type: 'geojson',
        data: settlementsGeoJSON,
      });

      // Круги для населённых пунктов
      currentMap.addLayer({
        id: 'settlements-circles',
        type: 'circle',
        source: 'settlements-source',
        paint: {
          'circle-radius': [
            'interpolate',
            ['linear'],
            ['get', 'population'],
            0, 4,
            10000, 6,
            100000, 10,
            1000000, 14
          ],
          'circle-color': '#f59e0b',
          'circle-stroke-color': '#ffffff',
          'circle-stroke-width': 2,
          'circle-opacity': 0.9,
        },
      });

      // Названия населённых пунктов
      currentMap.addLayer({
        id: 'settlements-labels',
        type: 'symbol',
        source: 'settlements-source',
        layout: {
          'text-field': ['get', 'name'],
          'text-font': ['Open Sans Bold'],
          'text-size': 11,
          'text-anchor': 'top',
          'text-offset': [0, 0.8],
        },
        paint: {
          'text-color': '#1e293b',
          'text-halo-color': '#ffffff',
          'text-halo-width': 1.5,
        },
      });

      // Клик по населённому пункту
      currentMap.on('click', 'settlements-circles', (e) => {
        if (e.features && e.features.length > 0) {
          const coords = (e.features[0].geometry as GeoJSON.Point).coordinates as [number, number];
          currentMap.flyTo({
            center: coords,
            zoom: ZOOM_LEVELS.SETTLEMENT,
            pitch: 60,
            duration: 1500,
          });
        }
      });

      currentMap.on('mouseenter', 'settlements-circles', () => {
        currentMap.getCanvas().style.cursor = 'pointer';
      });
      currentMap.on('mouseleave', 'settlements-circles', () => {
        currentMap.getCanvas().style.cursor = '';
      });
    }
  }, [currentZoom, isMapLoaded, settlements]);

  // Функция перелёта к точке
  const flyTo = useCallback((center: [number, number], zoom: number) => {
    if (!map.current) return;

    map.current.flyTo({
      center,
      zoom,
      pitch: zoom >= ZOOM_LEVELS.SETTLEMENT ? 60 : zoom >= ZOOM_LEVELS.REGION ? 45 : 30,
      duration: 1500,
      essential: true,
    });
  }, []);

  // Сброс к виду всей России
  const resetView = useCallback(() => {
    setSelectedRegion(null);
    flyTo([100.0, 65.0], ZOOM_LEVELS.COUNTRY);
  }, [flyTo]);

  // Получение текущего уровня детализации
  const getZoomLevel = () => {
    if (currentZoom >= ZOOM_LEVELS.SETTLEMENT) return 'settlement';
    if (currentZoom >= ZOOM_LEVELS.CITY) return 'city';
    if (currentZoom >= ZOOM_LEVELS.REGION) return 'region';
    return 'country';
  };

  const regionStoryCounts = storiesByRegion();

  return (
    <div className="relative w-full h-full overflow-hidden">
      {/* Контейнер карты */}
      <div ref={mapContainer} className="w-full h-full" />

      {/* Индикатор уровня зума */}
      <div className="absolute top-4 left-4 z-10">
        <div className="bg-white/95 backdrop-blur-sm rounded-xl px-4 py-2 shadow-lg border border-zinc-100">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-gradient-to-br from-amber-400 to-orange-500" />
            <span className="text-sm font-medium text-zinc-700">
              {getZoomLevel() === 'country' && 'Вся Россия'}
              {getZoomLevel() === 'region' && (selectedRegion?.name || 'Регион')}
              {getZoomLevel() === 'city' && 'Город'}
              {getZoomLevel() === 'settlement' && 'Улицы'}
            </span>
          </div>
        </div>
      </div>

      {/* Кнопка возврата к России */}
      {currentZoom > ZOOM_LEVELS.COUNTRY + 1 && (
        <button
          onClick={resetView}
          className="absolute top-4 right-20 z-10 bg-white/95 backdrop-blur-sm rounded-xl px-4 py-2.5 shadow-lg border border-zinc-100 hover:bg-white transition-all duration-200 flex items-center gap-2"
        >
          <svg className="w-4 h-4 text-zinc-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
          </svg>
          <span className="text-sm font-medium text-zinc-700">Вся Россия</span>
        </button>
      )}

      {/* Информация о наведённом регионе */}
      {hoveredRegion && currentZoom < ZOOM_LEVELS.REGION && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-10 pointer-events-none">
          <div className="bg-zinc-900/90 backdrop-blur-sm text-white px-5 py-2.5 rounded-xl shadow-xl">
            <div className="text-sm font-medium">{hoveredRegion}</div>
            {regionStoryCounts[hoveredRegion] && (
              <div className="text-xs text-zinc-400 mt-0.5">
                {regionStoryCounts[hoveredRegion]} {regionStoryCounts[hoveredRegion] === 1 ? 'история' : 'историй'}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Подсказка для создания истории */}
      {currentZoom >= ZOOM_LEVELS.SETTLEMENT && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-10 pointer-events-none">
          <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-full shadow-xl flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            <span className="text-sm font-medium">Нажмите на карту, чтобы оставить свою историю</span>
          </div>
        </div>
      )}

      {/* Инструкция при загрузке */}
      {currentZoom < ZOOM_LEVELS.REGION && !hoveredRegion && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-10 pointer-events-none">
          <div className="bg-white/90 backdrop-blur-sm text-zinc-700 px-5 py-2.5 rounded-xl shadow-lg border border-zinc-100">
            <span className="text-sm">Нажмите на регион для просмотра</span>
          </div>
        </div>
      )}

      {/* Стили для маркеров */}
      <style jsx global>{`
        .story-marker {
          cursor: pointer;
          transition: transform 0.2s ease;
        }
        .story-marker:hover {
          transform: scale(1.15);
          z-index: 100 !important;
        }
        .marker-container {
          display: flex;
          flex-direction: column;
          align-items: center;
          filter: drop-shadow(0 4px 8px rgba(0,0,0,0.25));
        }
        .marker-container.selected {
          transform: scale(1.2);
          filter: drop-shadow(0 6px 12px rgba(0,0,0,0.35));
        }
        .marker-pin {
          background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
          border: 3px solid #f59e0b;
          border-radius: 50% 50% 50% 0;
          transform: rotate(-45deg);
          width: 44px;
          height: 44px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .marker-emoji {
          font-size: 22px;
          line-height: 1;
          transform: rotate(45deg);
        }
        .marker-hearts {
          background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
          color: white;
          font-size: 11px;
          font-weight: 700;
          padding: 3px 8px;
          border-radius: 12px;
          margin-top: 4px;
          min-width: 20px;
          text-align: center;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        /* Маркеры с количеством историй на регионах */
        .region-story-count {
          cursor: pointer;
          transition: transform 0.2s ease;
        }
        .region-story-count:hover {
          transform: scale(1.15);
          z-index: 100 !important;
        }
        .region-badge {
          display: flex;
          align-items: center;
          gap: 4px;
          background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
          border: 2px solid #f59e0b;
          border-radius: 20px;
          padding: 6px 12px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .region-badge.warm {
          background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
          border-color: #f59e0b;
        }
        .region-badge.hot {
          background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
          border-color: #d97706;
        }
        .region-badge.hot .count {
          color: white;
        }
        .region-badge.hot .icon {
          filter: brightness(0) invert(1);
        }
        .region-badge .count {
          font-size: 14px;
          font-weight: 700;
          color: #92400e;
        }
        .region-badge .icon {
          font-size: 14px;
        }

        /* Кастомные стили карты */
        .maplibregl-ctrl-group {
          background: rgba(255, 255, 255, 0.98) !important;
          backdrop-filter: blur(12px);
          border-radius: 14px !important;
          box-shadow: 0 4px 20px -2px rgba(0, 0, 0, 0.12) !important;
          border: 1px solid rgba(0,0,0,0.05) !important;
          overflow: hidden;
        }
        .maplibregl-ctrl-group button {
          width: 36px !important;
          height: 36px !important;
        }
        .maplibregl-ctrl-group button:hover {
          background-color: #f8fafc !important;
        }
        .maplibregl-ctrl-scale {
          background: rgba(255, 255, 255, 0.95) !important;
          backdrop-filter: blur(8px);
          border-radius: 8px !important;
          padding: 4px 10px !important;
          font-size: 11px !important;
          font-weight: 500;
          border: 1px solid rgba(0,0,0,0.05) !important;
          box-shadow: 0 2px 8px rgba(0,0,0,0.08) !important;
        }
        .maplibregl-ctrl-attrib {
          background: rgba(255,255,255,0.85) !important;
          padding: 2px 8px !important;
          border-radius: 6px !important;
          font-size: 10px !important;
        }
      `}</style>
    </div>
  );
}

export default InteractiveMap;
