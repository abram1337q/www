'use client';

// Интерактивная 3D карта России на Cesium/Resium
// Фотореалистичная визуализация с рельефом, спутником и 3D-зданиями

import { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import {
  Viewer,
  Entity,
  BillboardGraphics,
  LabelGraphics,
  Cesium3DTileset,
  ImageryLayer,
  CameraFlyTo,
  Globe,
} from 'resium';
import {
  Viewer as CesiumViewer,
  Cartesian3,
  Math as CesiumMath,
  Color,
  Cesium3DTileStyle,
  ArcGisMapServerImageryProvider,
  createWorldTerrainAsync,
  IonResource,
  VerticalOrigin,
  HorizontalOrigin,
  LabelStyle,
  Cartographic,
  HeadingPitchRoll,
  Ion,
  ScreenSpaceEventHandler,
  ScreenSpaceEventType,
  defined,
  Ellipsoid,
  sampleTerrainMostDetailed,
  NearFarScalar,
  HeadingPitchRange,
} from 'cesium';
// CSS загружается из public/cesium/Widgets/widgets.css через globals.css
import { RUSSIA_CENTER, RUSSIAN_REGIONS, type RussianRegion } from '@/data/regions';
import { STORY_CATEGORIES, type StoryMapMarker } from '@/types';

// Cesium Ion Token из переменных окружения
// Получите свой на https://cesium.com/ion/tokens
Ion.defaultAccessToken = process.env.NEXT_PUBLIC_CESIUM_ION_TOKEN || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI5ZDAxN2RmOS05MTEwLTRjZTQtOGRkOC04N2NmZTRhYjcxZGUiLCJpZCI6MjU5LCJzY29wZXMiOlsiYXNyIiwiZ2MiXSwiaWF0IjoxNTc1NzUyNzU2fQ.iHLXf8h1hM-xKfF2MvHb9IiU7xnBNOQa1Yjl3NOB0V8';

// Координаты Москвы
const MOSCOW_COORDINATES = {
  longitude: 37.6173,
  latitude: 55.7558,
  height: 300,
};

// Уровни зума для разных уровней детализации
const ZOOM_LEVELS = {
  COUNTRY: 5000000,      // Вся Россия
  REGION: 500000,        // Регион
  CITY: 50000,           // Город
  SETTLEMENT: 3000,      // Улицы
};

interface CesiumMapProps {
  stories?: StoryMapMarker[];
  onMapClick?: (lngLat: { lng: number; lat: number }) => void;
  onStoryClick?: (storyId: string) => void;
  onRegionClick?: (regionId: string) => void;
  selectedStoryId?: string;
  initialCenter?: [number, number];
  initialZoom?: number;
}

// Стиль зданий с бежевым оттенком и процедурными окнами
const buildingStyle = new Cesium3DTileStyle({
  color: {
    conditions: [
      // Здания с этажностью - создаём полосатый эффект для окон
      ['${feature["building:levels"]} !== undefined',
        'mix(color("#f2f0ea"), color("#d4d2cc"), fract(${feature["building:levels"]} * 0.3))'],
      // Дефолтный бежевый цвет
      ['true', 'color("#f2f0ea", 0.9)'],
    ],
  },
});

export function CesiumMap({
  stories = [],
  onMapClick,
  onStoryClick,
  onRegionClick,
  selectedStoryId,
  initialCenter,
  initialZoom,
}: CesiumMapProps) {
  const viewerRef = useRef<CesiumViewer | null>(null);
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const [terrainProvider, setTerrainProvider] = useState<Awaited<ReturnType<typeof createWorldTerrainAsync>> | null>(null);
  const [currentCameraHeight, setCurrentCameraHeight] = useState(ZOOM_LEVELS.COUNTRY);
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);
  const [selectedRegion, setSelectedRegion] = useState<RussianRegion | null>(null);
  const [shouldFlyToMoscow, setShouldFlyToMoscow] = useState(true);

  // Создаём провайдер рельефа
  useEffect(() => {
    const loadTerrain = async () => {
      try {
        const terrain = await createWorldTerrainAsync({
          requestVertexNormals: true,
          requestWaterMask: true,
        });
        setTerrainProvider(terrain);
      } catch (error) {
        console.error('Ошибка загрузки рельефа:', error);
      }
    };
    loadTerrain();
  }, []);

  // Создаём провайдер спутниковых снимков
  const imageryProvider = useMemo(() => {
    return ArcGisMapServerImageryProvider.fromUrl(
      'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer'
    );
  }, []);

  // Подсчёт историй по регионам
  const storiesByRegion = useCallback(() => {
    const counts: Record<string, number> = {};
    for (const story of stories) {
      if (story.regionId) {
        counts[story.regionId] = (counts[story.regionId] || 0) + 1;
      }
    }
    return counts;
  }, [stories]);

  // Обработка загрузки viewer
  const handleViewerReady = useCallback((viewer: CesiumViewer) => {
    viewerRef.current = viewer;
    setIsMapLoaded(true);

    // Настройка глобуса
    viewer.scene.globe.enableLighting = true;
    viewer.scene.globe.depthTestAgainstTerrain = true;
    viewer.shadows = true;

    // Отслеживание высоты камеры
    viewer.camera.changed.addEventListener(() => {
      const height = viewer.camera.positionCartographic.height;
      setCurrentCameraHeight(height);
    });

    // Обработка кликов по карте
    const handler = new ScreenSpaceEventHandler(viewer.scene.canvas);

    handler.setInputAction((movement: { position: { x: number; y: number } }) => {
      const cartesian = viewer.scene.pickPosition(movement.position);

      if (defined(cartesian)) {
        const cartographic = Cartographic.fromCartesian(cartesian);
        const longitude = CesiumMath.toDegrees(cartographic.longitude);
        const latitude = CesiumMath.toDegrees(cartographic.latitude);
        const height = viewer.camera.positionCartographic.height;

        // На уровне улиц - открываем форму создания истории
        if (height <= ZOOM_LEVELS.SETTLEMENT && onMapClick) {
          // Проверяем, не кликнули ли мы на маркер истории
          const pickedObject = viewer.scene.pick(movement.position);
          if (!defined(pickedObject) || !pickedObject.id) {
            onMapClick({ lng: longitude, lat: latitude });
          }
        }
      }
    }, ScreenSpaceEventType.LEFT_CLICK);

    // Fly to initial location (Moscow)
    if (shouldFlyToMoscow) {
      setTimeout(() => {
        viewer.camera.flyTo({
          destination: Cartesian3.fromDegrees(
            initialCenter ? initialCenter[0] : MOSCOW_COORDINATES.longitude,
            initialCenter ? initialCenter[1] : MOSCOW_COORDINATES.latitude,
            initialZoom || ZOOM_LEVELS.CITY
          ),
          orientation: {
            heading: CesiumMath.toRadians(0),
            pitch: CesiumMath.toRadians(-30),
            roll: 0,
          },
          duration: 3,
        });
        setShouldFlyToMoscow(false);
      }, 1000);
    }

    return () => {
      handler.destroy();
    };
  }, [onMapClick, initialCenter, initialZoom, shouldFlyToMoscow]);

  // Функция перелёта к региону
  const flyToRegion = useCallback((region: RussianRegion) => {
    if (!viewerRef.current) return;

    setSelectedRegion(region);
    onRegionClick?.(region.id);

    viewerRef.current.camera.flyTo({
      destination: Cartesian3.fromDegrees(
        region.center[0],
        region.center[1],
        ZOOM_LEVELS.REGION
      ),
      orientation: {
        heading: CesiumMath.toRadians(0),
        pitch: CesiumMath.toRadians(-45),
        roll: 0,
      },
      duration: 1.5,
    });
  }, [onRegionClick]);

  // Функция перелёта к истории
  const flyToStory = useCallback((story: StoryMapMarker) => {
    if (!viewerRef.current) return;

    viewerRef.current.camera.flyTo({
      destination: Cartesian3.fromDegrees(
        story.longitude,
        story.latitude,
        ZOOM_LEVELS.SETTLEMENT
      ),
      orientation: {
        heading: CesiumMath.toRadians(0),
        pitch: CesiumMath.toRadians(-45),
        roll: 0,
      },
      duration: 1.5,
    });
  }, []);

  // Сброс к виду всей России
  const resetView = useCallback(() => {
    if (!viewerRef.current) return;

    setSelectedRegion(null);
    viewerRef.current.camera.flyTo({
      destination: Cartesian3.fromDegrees(100.0, 65.0, ZOOM_LEVELS.COUNTRY),
      orientation: {
        heading: CesiumMath.toRadians(0),
        pitch: CesiumMath.toRadians(-30),
        roll: 0,
      },
      duration: 1.5,
    });
  }, []);

  // Определение уровня детализации
  const getZoomLevel = useCallback(() => {
    if (currentCameraHeight <= ZOOM_LEVELS.SETTLEMENT) return 'settlement';
    if (currentCameraHeight <= ZOOM_LEVELS.CITY) return 'city';
    if (currentCameraHeight <= ZOOM_LEVELS.REGION) return 'region';
    return 'country';
  }, [currentCameraHeight]);

  // Создание иконок для маркеров
  const createMarkerCanvas = useCallback((emoji: string, isSelected: boolean, heartsCount: number) => {
    const canvas = document.createElement('canvas');
    const size = isSelected ? 64 : 52;
    canvas.width = size;
    canvas.height = size + (heartsCount > 0 ? 20 : 0);
    const ctx = canvas.getContext('2d');
    if (!ctx) return canvas;

    // Тень
    ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 4;

    // Фон маркера (каплевидная форма)
    const centerX = size / 2;
    const centerY = size / 2 - 4;
    const radius = size / 2 - 8;

    ctx.beginPath();
    ctx.arc(centerX, centerY - 2, radius, Math.PI, 0, false);
    ctx.lineTo(centerX, size - 8);
    ctx.closePath();

    // Градиент
    const gradient = ctx.createLinearGradient(0, 0, 0, size);
    gradient.addColorStop(0, '#ffffff');
    gradient.addColorStop(1, '#f8fafc');
    ctx.fillStyle = gradient;
    ctx.fill();

    // Обводка
    ctx.shadowBlur = 0;
    ctx.strokeStyle = isSelected ? '#ea580c' : '#f59e0b';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Эмодзи
    ctx.font = `${radius}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(emoji, centerX, centerY);

    // Бейдж с сердечками
    if (heartsCount > 0) {
      const badgeY = size;
      ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
      ctx.shadowBlur = 4;
      ctx.shadowOffsetY = 2;

      const badgeGradient = ctx.createLinearGradient(0, badgeY - 10, 0, badgeY + 10);
      badgeGradient.addColorStop(0, '#ef4444');
      badgeGradient.addColorStop(1, '#dc2626');
      ctx.fillStyle = badgeGradient;

      ctx.beginPath();
      ctx.roundRect(centerX - 15, badgeY - 8, 30, 16, 8);
      ctx.fill();

      ctx.shadowBlur = 0;
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 10px sans-serif';
      ctx.fillText(String(heartsCount), centerX, badgeY);
    }

    return canvas;
  }, []);

  // Создание иконки для региона
  const createRegionMarkerCanvas = useCallback((count: number) => {
    const canvas = document.createElement('canvas');
    canvas.width = 60;
    canvas.height = 36;
    const ctx = canvas.getContext('2d');
    if (!ctx) return canvas;

    // Тень
    ctx.shadowColor = 'rgba(0, 0, 0, 0.15)';
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 4;

    // Фон
    const isHot = count > 10;
    const isWarm = count > 5;

    let gradient;
    if (isHot) {
      gradient = ctx.createLinearGradient(0, 0, 60, 0);
      gradient.addColorStop(0, '#fbbf24');
      gradient.addColorStop(1, '#f59e0b');
    } else if (isWarm) {
      gradient = ctx.createLinearGradient(0, 0, 60, 0);
      gradient.addColorStop(0, '#fef3c7');
      gradient.addColorStop(1, '#fde68a');
    } else {
      gradient = ctx.createLinearGradient(0, 0, 60, 0);
      gradient.addColorStop(0, '#ffffff');
      gradient.addColorStop(1, '#f8fafc');
    }

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.roundRect(0, 0, 60, 32, 16);
    ctx.fill();

    // Обводка
    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Текст
    ctx.fillStyle = isHot ? '#ffffff' : '#92400e';
    ctx.font = 'bold 14px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${count}`, 24, 16);
    ctx.fillText('📖', 46, 16);

    return canvas;
  }, []);

  const regionStoryCounts = storiesByRegion();
  const zoomLevel = getZoomLevel();

  return (
    <div className="relative w-full h-full overflow-hidden">
      <Viewer
        full
        timeline={false}
        animation={false}
        baseLayerPicker={false}
        geocoder={false}
        homeButton={false}
        sceneModePicker={false}
        selectionIndicator={false}
        navigationHelpButton={false}
        infoBox={false}
        fullscreenButton={false}
        vrButton={false}
        shadows={true}
        terrainProvider={terrainProvider || undefined}
        ref={(ref) => {
          if (ref?.cesiumElement && !viewerRef.current) {
            handleViewerReady(ref.cesiumElement);
          }
        }}
      >
        {/* Спутниковый слой ArcGIS */}
        <ImageryLayer imageryProvider={imageryProvider} />

        {/* 3D Здания OSM */}
        <Cesium3DTileset
          url={IonResource.fromAssetId(96188)}
          style={buildingStyle}
          shadows={true}
          maximumScreenSpaceError={16}
        />

        {/* Маркеры историй */}
        {stories.map((story) => {
          const category = STORY_CATEGORIES[story.category];
          const isSelected = story.id === selectedStoryId;
          const markerCanvas = createMarkerCanvas(
            category?.emoji || '📍',
            isSelected,
            story.heartsCount
          );

          return (
            <Entity
              key={story.id}
              position={Cartesian3.fromDegrees(story.longitude, story.latitude, 20)}
              onClick={() => {
                onStoryClick?.(story.id);
                flyToStory(story);
              }}
            >
              <BillboardGraphics
                image={markerCanvas}
                verticalOrigin={VerticalOrigin.BOTTOM}
                horizontalOrigin={HorizontalOrigin.CENTER}
                scale={isSelected ? 1.2 : 1.0}
                scaleByDistance={new NearFarScalar(1000, 1.2, 100000, 0.3)}
                translucencyByDistance={new NearFarScalar(100000, 1.0, 500000, 0.0)}
                disableDepthTestDistance={Number.POSITIVE_INFINITY}
              />
            </Entity>
          );
        })}

        {/* Региональные маркеры с количеством историй (только на уровне страны) */}
        {zoomLevel === 'country' && RUSSIAN_REGIONS.map((region) => {
          const count = regionStoryCounts[region.id] || 0;
          if (count === 0) return null;

          const markerCanvas = createRegionMarkerCanvas(count);

          return (
            <Entity
              key={`region-${region.id}`}
              position={Cartesian3.fromDegrees(region.center[0], region.center[1], 10000)}
              onClick={() => flyToRegion(region)}
            >
              <BillboardGraphics
                image={markerCanvas}
                verticalOrigin={VerticalOrigin.CENTER}
                horizontalOrigin={HorizontalOrigin.CENTER}
                scaleByDistance={new NearFarScalar(500000, 1.0, 5000000, 0.4)}
                disableDepthTestDistance={Number.POSITIVE_INFINITY}
              />
              <LabelGraphics
                text={region.name}
                font="bold 12px sans-serif"
                fillColor={Color.fromCssColorString('#1e293b')}
                outlineColor={Color.WHITE}
                outlineWidth={2}
                style={LabelStyle.FILL_AND_OUTLINE}
                verticalOrigin={VerticalOrigin.TOP}
                pixelOffset={new Cartesian3(0, 25, 0) as any}
                scaleByDistance={new NearFarScalar(500000, 1.0, 5000000, 0.4)}
                disableDepthTestDistance={Number.POSITIVE_INFINITY}
              />
            </Entity>
          );
        })}
      </Viewer>

      {/* Индикатор уровня зума */}
      <div className="absolute top-4 left-4 z-10">
        <div className="bg-white/95 backdrop-blur-sm rounded-xl px-4 py-2 shadow-lg border border-zinc-100">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-gradient-to-br from-amber-400 to-orange-500" />
            <span className="text-sm font-medium text-zinc-700">
              {zoomLevel === 'country' && 'Вся Россия'}
              {zoomLevel === 'region' && (selectedRegion?.name || 'Регион')}
              {zoomLevel === 'city' && 'Город'}
              {zoomLevel === 'settlement' && 'Улицы'}
            </span>
          </div>
        </div>
      </div>

      {/* Кнопка возврата к России */}
      {currentCameraHeight < ZOOM_LEVELS.COUNTRY - 1000000 && (
        <button
          type="button"
          onClick={resetView}
          className="absolute top-4 right-20 z-10 bg-white/95 backdrop-blur-sm rounded-xl px-4 py-2.5 shadow-lg border border-zinc-100 hover:bg-white transition-all duration-200 flex items-center gap-2"
        >
          <svg className="w-4 h-4 text-zinc-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
          </svg>
          <span className="text-sm font-medium text-zinc-700">Вся Россия</span>
        </button>
      )}

      {/* Подсказка для создания истории */}
      {zoomLevel === 'settlement' && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-10 pointer-events-none">
          <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-full shadow-xl flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            <span className="text-sm font-medium">Нажмите на карту, чтобы оставить свою историю</span>
          </div>
        </div>
      )}

      {/* Инструкция при загрузке */}
      {zoomLevel === 'country' && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-10 pointer-events-none">
          <div className="bg-white/90 backdrop-blur-sm text-zinc-700 px-5 py-2.5 rounded-xl shadow-lg border border-zinc-100">
            <span className="text-sm">Нажмите на регион для просмотра</span>
          </div>
        </div>
      )}

      {/* Кастомные стили для Cesium */}
      <style jsx global>{`
        .cesium-widget {
          border-radius: 0 !important;
        }
        .cesium-widget-credits {
          display: none !important;
        }
        .cesium-viewer-toolbar {
          display: none !important;
        }
        .cesium-viewer-bottom {
          display: none !important;
        }
      `}</style>
    </div>
  );
}

export default CesiumMap;
