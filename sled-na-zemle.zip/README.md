# История моей жизни — След на Земле

Интерактивная карта России с личными историями пользователей. Сервис позволяет публиковать истории, привязанные к географическим точкам, создавая цифровой архив памяти граждан РФ.

## Возможности

- 🗺️ **Интерактивная 3D карта России** на MapLibre GL JS
- 📝 **Публикация историй** с привязкой к географическим точкам
- 🏷️ **5 категорий историй**: Любовь и семья, Подвиг, Труд, Жизнь и мудрость, Память
- 💳 **Интеграция с ЮKassa** для приёма платежей
- 📧 **Email-уведомления** о статусе модерации
- 👤 **Личный кабинет автора** по секретной ссылке
- 🛡️ **Административная панель** для модерации
- ❤️ **Система "сердечек"** для отметки понравившихся историй

## Технологический стек

| Компонент | Технология |
|-----------|------------|
| Frontend | Next.js 15, React 19, TypeScript |
| Стилизация | Tailwind CSS, shadcn/ui |
| Карта | MapLibre GL JS + MapTiler |
| База данных | PostgreSQL + Prisma ORM |
| Платежи | ЮKassa API |
| Email | Nodemailer (SMTP) |
| Хранилище | S3-совместимое (Yandex Object Storage) |

## Быстрый старт

### 1. Клонирование и установка

```bash
git clone <repository-url>
cd sled-na-zemle
bun install
```

### 2. Настройка переменных окружения

Скопируйте файл `.env.example` в `.env` и заполните значения:

```bash
cp .env.example .env
```

### 3. Настройка базы данных

```bash
# Генерация клиента Prisma
bunx prisma generate

# Для разработки: создание и применение миграций
bunx prisma migrate dev --name init

# Для продакшена: применение существующих миграций
bunx prisma migrate deploy
```

### 4. Запуск в режиме разработки

```bash
bun run dev
```

Приложение будет доступно по адресу: http://localhost:3000

## Конфигурация

### Переменные окружения

#### База данных
```env
DATABASE_URL="postgresql://user:password@localhost:5432/sled_na_zemle?schema=public"
```

#### ЮKassa
```env
YOOKASSA_SHOP_ID="your_shop_id"
YOOKASSA_SECRET_KEY="your_secret_key"
PAYMENT_AMOUNT="990"
```

#### Email (SMTP)
```env
SMTP_HOST="smtp.yandex.ru"
SMTP_PORT="465"
SMTP_USER="noreply@your-domain.ru"
SMTP_PASS="your_password"
SMTP_FROM="История моей жизни <noreply@your-domain.ru>"
```

#### MapTiler
```env
NEXT_PUBLIC_MAPTILER_KEY="your_maptiler_api_key"
```

#### S3 хранилище
```env
S3_ENDPOINT="https://storage.yandexcloud.net"
S3_REGION="ru-central1"
S3_BUCKET="sled-na-zemle-uploads"
S3_ACCESS_KEY="your_access_key"
S3_SECRET_KEY="your_secret_key"
```

#### Безопасность
```env
JWT_SECRET="your_very_long_secret_key_at_least_64_characters"
CABINET_TOKEN_SALT="your_cabinet_token_salt"
NEXT_PUBLIC_APP_URL="https://your-domain.ru"
```

## Создание администратора

После настройки базы данных создайте первого администратора через Prisma Studio или SQL:

```sql
INSERT INTO admins (id, email, password_hash, name, is_active, created_at, updated_at)
VALUES (
  'cuid_here',
  'admin@example.ru',
  '$2a$12$...', -- bcrypt hash пароля
  'Администратор',
  true,
  NOW(),
  NOW()
);
```

Для генерации bcrypt хеша:
```javascript
const bcrypt = require('bcryptjs');
const hash = bcrypt.hashSync('your_password', 12);
console.log(hash);
```

## Структура проекта

```
sled-na-zemle/
├── prisma/
│   └── schema.prisma      # Схема базы данных
├── src/
│   ├── app/
│   │   ├── api/           # API endpoints
│   │   │   ├── stories/   # CRUD историй
│   │   │   ├── cabinet/   # Личный кабинет
│   │   │   ├── admin/     # Админ-панель
│   │   │   └── payment/   # Webhook ЮKassa
│   │   ├── admin/         # Страницы админки
│   │   ├── cabinet/       # Личный кабинет
│   │   ├── legal/         # Юридические страницы
│   │   └── payment/       # Страницы оплаты
│   ├── components/
│   │   ├── layout/        # Header, Footer
│   │   ├── map/           # Компоненты карты
│   │   ├── story/         # Компоненты историй
│   │   └── ui/            # shadcn/ui компоненты
│   ├── lib/
│   │   ├── auth/          # Токены, авторизация
│   │   ├── db/            # Prisma клиент
│   │   ├── email/         # Nodemailer
│   │   └── payment/       # ЮKassa
│   ├── data/              # Данные регионов
│   └── types/             # TypeScript типы
└── public/                # Статические файлы
```

## API Endpoints

### Публичные

| Метод | URL | Описание |
|-------|-----|----------|
| GET | `/api/stories` | Список опубликованных историй |
| GET | `/api/stories/:id` | Информация об истории |
| POST | `/api/stories` | Создание истории (FormData) |
| POST | `/api/stories/:id/heart` | Добавление "сердечка" |

### Личный кабинет

| Метод | URL | Описание |
|-------|-----|----------|
| GET | `/api/cabinet/:token` | Получение истории |
| PATCH | `/api/cabinet/:token` | Обновление истории |
| DELETE | `/api/cabinet/:token` | Удаление истории |
| POST | `/api/cabinet/:token/resubmit` | Повторная модерация |

### Админ-панель

| Метод | URL | Описание |
|-------|-----|----------|
| POST | `/api/admin/auth` | Авторизация |
| GET | `/api/admin/check` | Проверка авторизации |
| POST | `/api/admin/logout` | Выход |
| GET | `/api/admin/stats` | Статистика |
| GET | `/api/admin/stories` | Список историй |
| POST | `/api/admin/stories/:id/approve` | Одобрение |
| POST | `/api/admin/stories/:id/reject` | Отклонение |

### Платежи

| Метод | URL | Описание |
|-------|-----|----------|
| POST | `/api/payment/webhook` | Webhook от ЮKassa |

## Настройка ЮKassa

1. Зарегистрируйтесь на [yookassa.ru](https://yookassa.ru)
2. Получите `shopId` и `secretKey` в личном кабинете
3. Настройте webhook URL: `https://your-domain.ru/api/payment/webhook`
4. Выберите события: `payment.succeeded`, `payment.canceled`

## Настройка MapTiler

1. Зарегистрируйтесь на [maptiler.com](https://maptiler.com)
2. Создайте API ключ в разделе Account → Keys
3. Добавьте ключ в `NEXT_PUBLIC_MAPTILER_KEY`

## Деплой

### Netlify (рекомендуется)

Проект настроен для деплоя на Netlify:

```bash
# Билд
bun run build

# Деплой
netlify deploy --prod
```

Файл `netlify.toml` уже настроен.

### Docker

```dockerfile
FROM oven/bun:1 as builder
WORKDIR /app
COPY package.json bun.lock ./
RUN bun install
COPY . .
RUN bunx prisma generate
RUN bun run build

FROM oven/bun:1
WORKDIR /app
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package.json ./
EXPOSE 3000
CMD ["bun", "run", "start"]
```

## Требования к хостингу

Согласно 152-ФЗ, персональные данные должны храниться на территории РФ:

- **Серверы**: Yandex Cloud, Selectel, VK Cloud
- **База данных**: PostgreSQL на серверах в РФ
- **Хранилище**: Yandex Object Storage

## Безопасность

- ✅ HTTPS обязателен в продакшене
- ✅ CSRF-защита через Next.js
- ✅ XSS-защита через экранирование
- ✅ SQL-инъекции предотвращены Prisma
- ✅ Rate limiting рекомендуется настроить на уровне nginx/Cloudflare
- ✅ Пароли хешируются bcrypt (12 раундов)
- ✅ JWT токены для админ-сессий (8 часов)
- ✅ Криптографически стойкие токены кабинета (64 символа)

## Лицензия

Проприетарное ПО. Все права защищены.

## Контакты

По вопросам технической поддержки: support@example.ru
