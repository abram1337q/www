<script setup lang="ts">
import { onMounted } from 'vue'
import { usePlayerStore } from './stores/player'
import { useEconomyStore } from './stores/economy'
import { useSocialStore } from './stores/social'
import { useEventsStore } from './stores/events'
import Dashboard from './components/Dashboard.vue'

const playerStore = usePlayerStore()
const economyStore = useEconomyStore()
const socialStore = useSocialStore()
const eventsStore = useEventsStore()

onMounted(() => {
  // Initialize economy
  economyStore.updateMarketPrices()

  // Generate some NPCs
  socialStore.generateRandomProfiles(20)
})
</script>

<template>
  <div id="app">
    <header class="app-header">
      <div class="header-content">
        <h1 class="logo">Life Simulator</h1>
        <p class="tagline">Живи. Работай. Развивайся.</p>
      </div>
    </header>

    <main class="main-content">
      <Dashboard />
    </main>
  </div>
</template>

<style scoped>
.app-header {
  background: rgba(255, 255, 255, 0.02);
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(10px);
  position: sticky;
  top: 0;
  z-index: 100;
}

.header-content {
  max-width: 1400px;
  margin: 0 auto;
  padding: 1.5rem 2rem;
}

.logo {
  margin: 0;
  font-size: 1.5rem;
  font-weight: 700;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.tagline {
  margin: 0.25rem 0 0 0;
  font-size: 0.875rem;
  opacity: 0.6;
}

.main-content {
  min-height: calc(100vh - 100px);
}

@media (max-width: 768px) {
  .header-content {
    padding: 1rem;
  }

  .logo {
    font-size: 1.25rem;
  }
}
</style>
