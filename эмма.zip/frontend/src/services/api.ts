import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

export interface ChatMessage {
  message: string
  session_id: string
  mode: 'story' | 'free'
  scene_id?: string
  stream: boolean
}

export interface StoryArc {
  id: string
  title: string
  description: string
  locked: boolean
  progress: number
  completed: boolean
  current_scene?: string
}

export interface Scene {
  id: string
  title: string
  context: string
  objectives: string[]
  next_scenes?: string[]
  is_ending?: boolean
  ending_type?: string
}

export interface SessionResponse {
  session_id: string
}

export interface ArcsResponse {
  arcs: StoryArc[]
}

export interface ProgressUpdate {
  session_id: string
  arc_id: string
  scene_id: string
  completed: boolean
}

// NEW: Dating interfaces
export interface DatingChatPayload {
  character_id: string
  message: string
  session_id: string
  context?: string
  relationship_data?: any
}

export interface AIInitiatedMessagePayload {
  character_id: string
  session_id: string
  relationship_data?: any
  last_conversation_summary?: string
}

export interface AIInitiatedMessageResponse {
  message: string
  character: AICharacter
  timestamp: string
}

export interface ContextualAction {
  id: string
  label: string
  cost: number
  effect: string
}

export interface GenerateActionsPayload {
  character_id: string
  relationship_data?: any
  conversation_context?: string
  player_money: number
}

export interface GenerateActionsResponse {
  actions: ContextualAction[]
  locked_actions: ContextualAction[]
  character: AICharacter
}

export interface PerformActionPayload {
  character_id: string
  action_id: string
  session_id: string
  relationship_data?: any
}

export interface PerformActionResponse {
  response: string
  action_description: string
  character: AICharacter
}

export interface DatingChatResponse {
  response: string
  character: AICharacter
  session_id: string
}

export interface AICharacter {
  id: string
  name: string
  age: number
  occupation: string
  personality: string
  description: string
  interests: string[]
  speaking_style: string
}

// NEW: Job Interview interfaces
export interface JobInterviewPayload {
  job_title: string
  company: string
  requirements: {
    intelligence?: number
    charisma?: number
    experience?: number
  }
  message: string
  session_id: string
}

export interface JobInterviewResponse {
  response: string
  is_hired: boolean
  session_id: string
}

// NEW: Advisor interfaces
export interface AdvisorPayload {
  player_stats: {
    age?: number
    money?: number
    intelligence?: number
    charisma?: number
    happiness?: number
  }
  economic_situation: {
    health?: number
    inflation?: number
  }
  question: string
}

export interface AdvisorResponse {
  advice: string
}

// NEW: Game save/load interfaces
export interface GameSavePayload {
  session_id: string
  game_state: any
}

export interface GameSaveResponse {
  success: boolean
  saved_at: string
}

export interface GameLoadResponse {
  state: any
  saved_at: string
}

export interface CharactersResponse {
  characters: AICharacter[]
}

export interface HealthCheckResponse {
  status: string
  api_key_configured: boolean
  active_sessions: number
  game_states: number
}

export const apiService = {
  // Session management
  async createSession(): Promise<SessionResponse> {
    const { data } = await api.post<SessionResponse>('/session/create')
    return data
  },

  // Chat
  async sendMessage(payload: ChatMessage): Promise<Response> {
    const response = await fetch(`${API_BASE_URL}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    })
    return response
  },

  // Story arcs (if backend implements these)
  async getStoryArcs(sessionId: string): Promise<ArcsResponse> {
    const { data } = await api.get<ArcsResponse>(`/story/arcs?session_id=${sessionId}`)
    return data
  },

  async getScene(sceneId: string): Promise<Scene> {
    const { data } = await api.get<Scene>(`/story/scene/${sceneId}`)
    return data
  },

  async updateProgress(payload: ProgressUpdate) {
    const { data } = await api.post('/story/progress', payload)
    return data
  },

  // NEW: Dating AI endpoints
  async datingChat(payload: DatingChatPayload): Promise<DatingChatResponse> {
    const { data } = await api.post<DatingChatResponse>('/dating/chat', payload)
    return data
  },

  async getAIInitiatedMessage(payload: AIInitiatedMessagePayload): Promise<AIInitiatedMessageResponse> {
    const { data } = await api.post<AIInitiatedMessageResponse>('/dating/ai-message', payload)
    return data
  },

  async generateActions(payload: GenerateActionsPayload): Promise<GenerateActionsResponse> {
    const { data } = await api.post<GenerateActionsResponse>('/dating/generate-actions', payload)
    return data
  },

  async performAction(payload: PerformActionPayload): Promise<PerformActionResponse> {
    const { data } = await api.post<PerformActionResponse>('/dating/perform-action', payload)
    return data
  },

  async getCharacters(): Promise<CharactersResponse> {
    const { data } = await api.get<CharactersResponse>('/characters')
    return data
  },

  // NEW: Job Interview AI endpoint
  async jobInterview(payload: JobInterviewPayload): Promise<JobInterviewResponse> {
    const { data } = await api.post<JobInterviewResponse>('/job/interview', payload)
    return data
  },

  // NEW: Advisor AI endpoint
  async getAdvice(payload: AdvisorPayload): Promise<AdvisorResponse> {
    const { data } = await api.post<AdvisorResponse>('/advisor/advice', payload)
    return data
  },

  // NEW: Game state management
  async saveGame(payload: GameSavePayload): Promise<GameSaveResponse> {
    const { data } = await api.post<GameSaveResponse>('/game/save', payload)
    return data
  },

  async loadGame(sessionId: string): Promise<GameLoadResponse> {
    const { data } = await api.get<GameLoadResponse>(`/game/load?session_id=${sessionId}`)
    return data
  },

  // Health check
  async healthCheck(): Promise<HealthCheckResponse> {
    const { data } = await api.get<HealthCheckResponse>('/health')
    return data
  },
}
