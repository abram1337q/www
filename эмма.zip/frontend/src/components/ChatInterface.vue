<template>
  <div class="chat-interface">
    <!-- Chat Header -->
    <div class="chat-header">
      <button class="btn-back" @click="$emit('back')">
        <span class="back-icon">←</span>
        <span>Назад</span>
      </button>

      <div class="chat-info">
        <h3 class="chat-title">{{ chatTitle }}</h3>
        <p v-if="chatSubtitle" class="chat-subtitle">{{ chatSubtitle }}</p>
      </div>

      <div class="mode-badge" :class="chatStore.currentMode">
        {{ modeBadgeText }}
      </div>
    </div>

    <!-- Messages Container -->
    <div ref="messagesContainer" class="messages-container">
      <TransitionGroup name="message">
        <ChatMessage
          v-for="message in chatStore.messages"
          :key="message.id"
          :message="message"
        />
      </TransitionGroup>

      <!-- Typing Indicator -->
      <div v-if="chatStore.isTyping" class="typing-indicator">
        <div class="typing-avatar">💕</div>
        <div class="typing-dots">
          <span />
          <span />
          <span />
        </div>
        <span class="typing-text">Эмма печатает...</span>
      </div>
    </div>

    <!-- Objectives Panel (Story Mode) -->
    <div v-if="chatStore.currentMode === 'story' && currentObjectives.length" class="objectives-panel">
      <h4 class="objectives-title">🎯 Цели сцены</h4>
      <ul class="objectives-list">
        <li v-for="(objective, index) in currentObjectives" :key="index">
          {{ objective }}
        </li>
      </ul>
    </div>

    <!-- Input Area -->
    <div class="input-area">
      <div class="input-container">
        <textarea
          ref="messageInput"
          v-model="messageText"
          class="message-input"
          placeholder="Напишите сообщение..."
          rows="1"
          @keydown.enter.exact.prevent="handleSend"
          @input="adjustTextareaHeight"
        />
        <button
          class="btn-send"
          :disabled="!messageText.trim() || chatStore.isTyping"
          @click="handleSend"
        >
          <span class="send-icon">➤</span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick, watch } from 'vue'
import { useChatStore } from '@/stores/chat'
import { useStoryStore } from '@/stores/story'
import { useSessionStore } from '@/stores/session'
import { apiService } from '@/services/api'
import ChatMessage from './ChatMessage.vue'

const emit = defineEmits<{
  back: []
}>()

const chatStore = useChatStore()
const storyStore = useStoryStore()
const sessionStore = useSessionStore()

const messageText = ref('')
const messagesContainer = ref<HTMLElement>()
const messageInput = ref<HTMLTextAreaElement>()

const chatTitle = computed(() => {
  if (chatStore.currentMode === 'story') {
    return `📖 ${storyStore.currentSceneData?.title || 'История с Эммой'}`
  }

  const locationEmojis: Record<string, string> = {
    cafe: '☕',
    park: '🌳',
    home: '🏠',
    video: '💻',
  }

  const locationNames: Record<string, string> = {
    cafe: 'В кофейне',
    park: 'В парке',
    home: 'У неё дома',
    video: 'На видеозвонке',
  }

  const emoji = chatStore.selectedLocation ? locationEmojis[chatStore.selectedLocation] : '💬'
  const name = chatStore.selectedLocation ? locationNames[chatStore.selectedLocation] : 'Общение с Эммой'

  return `${emoji} ${name}`
})

const chatSubtitle = computed(() => {
  if (chatStore.currentMode === 'story') {
    return storyStore.currentSceneData?.context || ''
  }
  return 'Свободное общение'
})

const modeBadgeText = computed(() => {
  return chatStore.currentMode === 'story' ? 'Сюжетный режим' : 'Свободный режим'
})

const currentObjectives = computed(() => {
  return storyStore.currentSceneData?.objectives || []
})

onMounted(() => {
  initializeChat()
  messageInput.value?.focus()
})

watch(() => chatStore.messages.length, () => {
  nextTick(() => scrollToBottom())
})

function initializeChat() {
  if (chatStore.currentMode === 'story' && storyStore.currentSceneData) {
    chatStore.addMessage('system', storyStore.currentSceneData.context)
  } else if (chatStore.currentMode === 'free') {
    const locationNames: Record<string, string> = {
      cafe: 'кофейне',
      park: 'парке',
      home: 'её дома',
      video: 'видеозвонке',
    }
    const location = chatStore.selectedLocation ? locationNames[chatStore.selectedLocation] : 'неизвестном месте'
    chatStore.addMessage('system', `Вы встретились с Эммой в ${location}. Она улыбается вам и выглядит рада встрече.`)
  }
}

async function handleSend() {
  if (!messageText.value.trim() || chatStore.isTyping) return
  if (!sessionStore.sessionId) return

  const message = messageText.value.trim()
  messageText.value = ''
  adjustTextareaHeight()

  chatStore.addMessage('user', message)
  chatStore.isTyping = true

  try {
    const response = await apiService.sendMessage({
      message,
      session_id: sessionStore.sessionId,
      mode: chatStore.currentMode!,
      scene_id: chatStore.currentScene || undefined,
      stream: true,
    })

    await handleStreamingResponse(response)
  } catch (error) {
    console.error('Error sending message:', error)
    chatStore.addMessage('system', 'Произошла ошибка при отправке сообщения. Проверьте подключение к серверу.')
  } finally {
    chatStore.isTyping = false
    messageInput.value?.focus()
  }
}

async function handleStreamingResponse(response: Response) {
  if (!response.body) return

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let assistantMessage = ''
  let messageId = ''

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      const chunk = decoder.decode(value, { stream: true })
      const lines = chunk.split('\n')

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const data = JSON.parse(line.slice(6))

            if (data.content) {
              assistantMessage += data.content

              // Update or create message
              if (!messageId) {
                messageId = `${Date.now()}-assistant`
                chatStore.addMessage('assistant', assistantMessage, messageId)
                chatStore.isTyping = false
              } else {
                // Update existing message
                chatStore.updateMessageContent(messageId, assistantMessage)
              }

              scrollToBottom()
            }

            if (data.done) {
              // Increase relationship
              sessionStore.updateRelationship(Math.random() * 5)
            }
          } catch (e) {
            // Ignore parse errors
          }
        }
      }
    }
  } finally {
    reader.releaseLock()
  }
}

function adjustTextareaHeight() {
  if (!messageInput.value) return
  messageInput.value.style.height = 'auto'
  messageInput.value.style.height = `${Math.min(messageInput.value.scrollHeight, 120)}px`
}

function scrollToBottom() {
  if (!messagesContainer.value) return
  messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
}
</script>

<style scoped>
.chat-interface {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 180px);
  max-width: 1200px;
  margin: 0 auto;
  background: var(--bg-secondary);
  border-radius: var(--radius-lg);
  border: 1px solid var(--border-color);
  box-shadow: var(--shadow-lg);
  overflow: hidden;
  animation: scaleIn 0.3s ease;
}

.chat-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1.25rem 1.5rem;
  background: var(--bg-tertiary);
  border-bottom: 1px solid var(--border-color);
  flex-shrink: 0;
}

.btn-back {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-sm);
  color: var(--text-primary);
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-back:hover {
  background: var(--bg-primary);
  border-color: var(--accent-purple);
}

.back-icon {
  font-size: 1.25rem;
}

.chat-info {
  flex: 1;
  min-width: 0;
}

.chat-title {
  font-size: 1.125rem;
  font-weight: 600;
  margin-bottom: 0.25rem;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.chat-subtitle {
  font-size: 0.875rem;
  color: var(--text-secondary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.mode-badge {
  padding: 0.5rem 1rem;
  border-radius: var(--radius-xl);
  font-size: 0.75rem;
  font-weight: 500;
  white-space: nowrap;
}

.mode-badge.story {
  background: linear-gradient(135deg, rgba(255, 107, 157, 0.2), rgba(168, 85, 247, 0.2));
  border: 1px solid var(--accent-purple);
  color: var(--accent-pink);
}

.mode-badge.free {
  background: linear-gradient(135deg, rgba(96, 165, 250, 0.2), rgba(139, 92, 246, 0.2));
  border: 1px solid var(--accent-blue);
  color: var(--accent-blue);
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.message-enter-active {
  transition: all 0.3s ease;
}

.message-enter-from {
  opacity: 0;
  transform: translateY(10px);
}

.typing-indicator {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem 1rem;
  animation: fadeIn 0.3s ease;
}

.typing-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: var(--gradient-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
  flex-shrink: 0;
}

.typing-dots {
  display: flex;
  gap: 0.4rem;
}

.typing-dots span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--accent-purple);
  animation: typing 1.4s infinite;
}

.typing-dots span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-dots span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 60%, 100% {
    transform: translateY(0);
    opacity: 0.5;
  }
  30% {
    transform: translateY(-8px);
    opacity: 1;
  }
}

.typing-text {
  color: var(--text-secondary);
  font-size: 0.875rem;
}

.objectives-panel {
  position: fixed;
  top: 140px;
  right: 2rem;
  width: 280px;
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  padding: 1.25rem;
  box-shadow: var(--shadow-lg);
  animation: slideIn 0.3s ease;
  z-index: 10;
}

.objectives-title {
  font-size: 1rem;
  font-weight: 600;
  color: var(--accent-pink);
  margin-bottom: 1rem;
}

.objectives-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.objectives-list li {
  padding: 0.75rem 1rem;
  padding-left: 2.5rem;
  background: var(--bg-tertiary);
  border-radius: var(--radius-sm);
  color: var(--text-secondary);
  font-size: 0.875rem;
  position: relative;
  line-height: 1.4;
}

.objectives-list li::before {
  content: '○';
  position: absolute;
  left: 1rem;
  color: var(--text-muted);
  font-size: 1rem;
}

.input-area {
  padding: 1.25rem 1.5rem;
  background: var(--bg-tertiary);
  border-top: 1px solid var(--border-color);
  flex-shrink: 0;
}

.input-container {
  display: flex;
  gap: 0.75rem;
  align-items: flex-end;
}

.message-input {
  flex: 1;
  padding: 0.875rem 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  color: var(--text-primary);
  font-family: inherit;
  font-size: 0.95rem;
  resize: none;
  max-height: 120px;
  transition: all 0.3s ease;
  line-height: 1.5;
}

.message-input:focus {
  outline: none;
  border-color: var(--accent-purple);
  box-shadow: 0 0 0 3px rgba(168, 85, 247, 0.1);
}

.message-input::placeholder {
  color: var(--text-muted);
}

.btn-send {
  width: 48px;
  height: 48px;
  background: var(--gradient-primary);
  border: none;
  border-radius: var(--radius-md);
  color: var(--text-primary);
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
}

.btn-send:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(255, 107, 157, 0.4);
}

.btn-send:active:not(:disabled) {
  transform: translateY(0);
}

.btn-send:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.send-icon {
  font-size: 1.25rem;
}

@media (max-width: 1024px) {
  .objectives-panel {
    display: none;
  }
}

@media (max-width: 768px) {
  .chat-interface {
    height: calc(100vh - 140px);
    border-radius: var(--radius-md);
  }

  .chat-header {
    padding: 1rem;
    flex-wrap: wrap;
  }

  .chat-info {
    order: -1;
    flex-basis: 100%;
    margin-bottom: 0.5rem;
  }

  .messages-container {
    padding: 1rem;
  }

  .input-area {
    padding: 1rem;
  }
}

@media (max-width: 480px) {
  .chat-header {
    padding: 0.875rem;
  }

  .btn-back span:not(.back-icon) {
    display: none;
  }

  .mode-badge {
    font-size: 0.7rem;
    padding: 0.4rem 0.75rem;
  }

  .messages-container {
    padding: 0.75rem;
    gap: 0.75rem;
  }

  .input-area {
    padding: 0.75rem;
  }

  .btn-send {
    width: 44px;
    height: 44px;
  }
}
</style>
