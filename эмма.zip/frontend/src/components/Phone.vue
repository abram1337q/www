<template>
  <div v-if="phoneStore.isPhoneOpen || phoneStore.hasIncomingCall" class="phone-overlay" @click.self="handleOverlayClick">
    <div class="phone-container" :class="{ 'minimized': !phoneStore.isPhoneOpen && phoneStore.hasIncomingCall }">
      <!-- Входящий звонок -->
      <div v-if="phoneStore.callState === 'ringing_incoming'" class="incoming-call">
        <div class="call-animation">
          <div class="call-avatar">📞</div>
          <div class="call-info">
            <div class="caller-name">{{ currentCallContact?.name }}</div>
            <div class="caller-number">{{ currentCallContact?.phoneNumber }}</div>
            <div class="call-status">Входящий звонок...</div>
          </div>
          <div class="call-actions">
            <button class="call-btn answer" @click="phoneStore.answerCall()">
              <span class="icon">✅</span>
              <span>Ответить</span>
            </button>
            <button class="call-btn decline" @click="phoneStore.declineCall()">
              <span class="icon">❌</span>
              <span>Отклонить</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Исходящий звонок -->
      <div v-else-if="phoneStore.callState === 'ringing_outgoing'" class="outgoing-call">
        <div class="call-animation">
          <div class="call-avatar">📞</div>
          <div class="call-info">
            <div class="caller-name">{{ currentCallContact?.name }}</div>
            <div class="caller-number">{{ currentCallContact?.phoneNumber }}</div>
            <div class="call-status">Вызов...</div>
          </div>
          <div class="call-actions">
            <button class="call-btn decline" @click="phoneStore.declineCall()">
              <span class="icon">❌</span>
              <span>Отменить</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Активный звонок -->
      <div v-else-if="phoneStore.callState === 'active'" class="active-call">
        <div class="call-header">
          <div class="call-contact-info">
            <div class="contact-avatar">{{ currentCallContact?.avatar || '📞' }}</div>
            <div>
              <div class="contact-name">{{ currentCallContact?.name }}</div>
              <div class="call-duration">{{ formattedCallDuration }}</div>
            </div>
          </div>
          <button class="btn-minimize" @click="phoneStore.isPhoneOpen = false" v-if="phoneStore.isPhoneOpen">_</button>
        </div>

        <div class="call-messages" ref="callMessagesContainer">
          <div v-for="msg in phoneStore.currentCall?.messages" :key="msg.id" class="call-message" :class="msg.sender">
            <div class="message-bubble">{{ msg.content }}</div>
            <div class="message-time">{{ formatTime(msg.timestamp) }}</div>
          </div>
        </div>

        <div class="call-input">
          <textarea
            v-model="callMessageText"
            placeholder="Написать сообщение..."
            @keydown.enter.exact.prevent="sendCallMessage"
            rows="2"
          />
          <button class="btn-send" @click="sendCallMessage" :disabled="!callMessageText.trim() || isTyping">
            ➤
          </button>
        </div>

        <div class="call-controls">
          <button class="call-btn end" @click="handleEndCall">
            <span class="icon">📞</span>
            <span>Завершить</span>
          </button>
        </div>
      </div>

      <!-- Обычный интерфейс телефона -->
      <div v-else class="phone-main">
        <div class="phone-header">
          <h2>📱 Телефон</h2>
          <button class="btn-close" @click="phoneStore.closePhone()">✕</button>
        </div>

        <div class="phone-tabs">
          <button
            class="tab-btn"
            :class="{ active: phoneStore.currentTab === 'contacts' }"
            @click="phoneStore.setTab('contacts')"
          >
            👥 Контакты
          </button>
          <button
            class="tab-btn"
            :class="{ active: phoneStore.currentTab === 'history' }"
            @click="phoneStore.setTab('history')"
          >
            📋 История
            <span v-if="phoneStore.missedCallsCount > 0" class="badge">{{ phoneStore.missedCallsCount }}</span>
          </button>
          <button
            class="tab-btn"
            :class="{ active: phoneStore.currentTab === 'dial' }"
            @click="phoneStore.setTab('dial')"
          >
            🔢 Набор
          </button>
        </div>

        <div class="phone-content">
          <!-- Контакты -->
          <div v-if="phoneStore.currentTab === 'contacts'" class="contacts-list">
            <div v-if="phoneStore.contacts.length === 0" class="empty-state">
              Нет контактов
            </div>
            <div
              v-for="contact in phoneStore.contacts"
              :key="contact.id"
              class="contact-item"
              @click="initiateCall(contact.id)"
            >
              <div class="contact-avatar">{{ contact.avatar }}</div>
              <div class="contact-info">
                <div class="contact-name">{{ contact.name }}</div>
                <div class="contact-number">{{ contact.phoneNumber }}</div>
                <div class="contact-stats">
                  Отношения: {{ contact.relationshipLevel }}% · Звонков: {{ contact.totalCalls }}
                </div>
              </div>
              <div class="contact-action">📞</div>
            </div>
          </div>

          <!-- История -->
          <div v-if="phoneStore.currentTab === 'history'" class="call-history">
            <div v-if="phoneStore.callHistory.length === 0" class="empty-state">
              Нет истории звонков
            </div>
            <div
              v-for="record in phoneStore.callHistory"
              :key="record.id"
              class="history-item"
              :class="record.status"
            >
              <div class="history-icon">
                <span v-if="record.type === 'incoming'">📥</span>
                <span v-else>📤</span>
              </div>
              <div class="history-info">
                <div class="history-name">{{ record.contactName }}</div>
                <div class="history-time">{{ formatDate(record.startTime) }}</div>
                <div class="history-status">
                  {{ getCallStatusText(record) }}
                </div>
              </div>
              <button class="btn-call-back" @click="callBack(record.contactId)">📞</button>
            </div>
          </div>

          <!-- Набор номера -->
          <div v-if="phoneStore.currentTab === 'dial'" class="dial-pad">
            <div class="dial-number-display">{{ dialNumber || 'Введите номер' }}</div>
            <div class="dial-grid">
              <button v-for="num in dialPadNumbers" :key="num" class="dial-btn" @click="addDigit(num)">
                {{ num }}
              </button>
              <button class="dial-btn" @click="addDigit('*')">*</button>
              <button class="dial-btn" @click="addDigit('0')">0</button>
              <button class="dial-btn" @click="addDigit('#')">#</button>
            </div>
            <div class="dial-actions">
              <button class="dial-action-btn delete" @click="deleteDigit">⌫</button>
              <button class="dial-action-btn call" @click="dialCall" :disabled="!dialNumber">📞</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, nextTick, onMounted } from 'vue'
import { usePhoneStore } from '@/stores/phone'
import { useSocialStore } from '@/stores/social'
import { useSessionStore } from '@/stores/session'
import { apiService } from '@/services/api'

const phoneStore = usePhoneStore()
const socialStore = useSocialStore()
const sessionStore = useSessionStore()

const callMessageText = ref('')
const isTyping = ref(false)
const callMessagesContainer = ref<HTMLElement>()
const dialNumber = ref('')
const dialPadNumbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]
const callStartTime = ref<Date | null>(null)
const callDuration = ref(0)
let callTimer: number | null = null

const currentCallContact = computed(() => {
  if (!phoneStore.currentCall) return null
  return phoneStore.getContact(phoneStore.currentCall.contactId)
})

const formattedCallDuration = computed(() => {
  const minutes = Math.floor(callDuration.value / 60)
  const seconds = callDuration.value % 60
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
})

// Запускаем таймер звонка
watch(() => phoneStore.callState, (newState) => {
  if (newState === 'active') {
    callStartTime.value = new Date()
    callDuration.value = 0
    startCallTimer()
  } else {
    stopCallTimer()
  }
})

function startCallTimer() {
  if (callTimer) return
  callTimer = window.setInterval(() => {
    if (callStartTime.value) {
      callDuration.value = Math.floor((Date.now() - callStartTime.value.getTime()) / 1000)
    }
  }, 1000)
}

function stopCallTimer() {
  if (callTimer) {
    clearInterval(callTimer)
    callTimer = null
  }
}

function handleOverlayClick() {
  if (phoneStore.callState === 'idle') {
    phoneStore.closePhone()
  }
}

function initiateCall(contactId: string) {
  phoneStore.initiateOutgoingCall(contactId)
}

function callBack(contactId: string) {
  phoneStore.initiateOutgoingCall(contactId)
}

async function sendCallMessage() {
  if (!callMessageText.value.trim() || isTyping.value || !phoneStore.currentCall) return

  const message = callMessageText.value.trim()
  callMessageText.value = ''

  // Добавляем сообщение пользователя
  phoneStore.addCallMessage('user', message)
  scrollToBottom()

  isTyping.value = true

  try {
    // Получаем ответ от AI
    const dateProfile = socialStore.dateProfiles.find(d => d.id === phoneStore.currentCall?.contactId)
    const relationshipData = dateProfile ? {
      stage: dateProfile.relationshipStage,
      level: dateProfile.relationshipLevel,
      trust: dateProfile.trust,
      tension: dateProfile.tension,
      married: dateProfile.relationshipStage === 'married',
      children: []
    } : undefined

    const response = await apiService.datingChat({
      character_id: phoneStore.currentCall.contactId,
      message: message,
      session_id: sessionStore.sessionId || '',
      context: 'Вы разговариваете по телефону.',
      relationship_data: relationshipData
    })

    // Добавляем ответ AI
    phoneStore.addCallMessage('ai', response.response)
    scrollToBottom()

    // Обновляем отношения
    socialStore.interactWithPartner(phoneStore.currentCall.contactId, 'talk')
  } catch (error) {
    console.error('Error sending call message:', error)
  } finally {
    isTyping.value = false
  }
}

function handleEndCall() {
  phoneStore.endCall()
  callMessageText.value = ''
}

function addDigit(digit: string | number) {
  dialNumber.value += String(digit)
}

function deleteDigit() {
  dialNumber.value = dialNumber.value.slice(0, -1)
}

function dialCall() {
  if (!dialNumber.value) return
  // Здесь можно добавить логику набора номера
  // Пока просто очищаем
  dialNumber.value = ''
}

function scrollToBottom() {
  nextTick(() => {
    if (callMessagesContainer.value) {
      callMessagesContainer.value.scrollTop = callMessagesContainer.value.scrollHeight
    }
  })
}

function formatTime(date: Date): string {
  return new Date(date).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })
}

function formatDate(date: Date): string {
  return new Date(date).toLocaleString('ru-RU', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit'
  })
}

function getCallStatusText(record: any): string {
  if (record.status === 'missed') return 'Пропущенный'
  if (record.status === 'declined') return 'Отклонен'
  if (record.duration) {
    const minutes = Math.floor(record.duration / 60)
    const seconds = record.duration % 60
    return `${minutes}м ${seconds}с`
  }
  return 'Завершен'
}
</script>

<style scoped>
.phone-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(5px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  animation: fadeIn 0.2s ease;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.phone-container {
  background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
  border-radius: 24px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
  width: 90%;
  max-width: 450px;
  max-height: 90vh;
  overflow: hidden;
  animation: slideUp 0.3s ease;
}

@keyframes slideUp {
  from {
    transform: translateY(50px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.phone-container.minimized {
  max-width: 320px;
  max-height: 400px;
}

/* Входящий/исходящий звонок */
.incoming-call,
.outgoing-call {
  padding: 3rem 2rem;
  text-align: center;
}

.call-animation {
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.05); }
}

.call-avatar {
  font-size: 5rem;
  margin-bottom: 1.5rem;
  animation: ring 1s infinite;
}

@keyframes ring {
  0%, 100% { transform: rotate(0deg); }
  10%, 30% { transform: rotate(-15deg); }
  20%, 40% { transform: rotate(15deg); }
}

.call-info {
  margin-bottom: 2rem;
}

.caller-name {
  font-size: 1.8rem;
  font-weight: 700;
  color: white;
  margin-bottom: 0.5rem;
}

.caller-number {
  font-size: 1rem;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 0.5rem;
}

.call-status {
  font-size: 0.9rem;
  color: rgba(255, 255, 255, 0.8);
  animation: blink 1.5s infinite;
}

@keyframes blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.call-actions {
  display: flex;
  gap: 1rem;
  justify-content: center;
}

.call-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  padding: 1rem 2rem;
  border: none;
  border-radius: 50px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}

.call-btn .icon {
  font-size: 1.5rem;
}

.call-btn.answer {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  color: white;
}

.call-btn.answer:hover {
  transform: scale(1.05);
  box-shadow: 0 8px 20px rgba(16, 185, 129, 0.4);
}

.call-btn.decline {
  background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
  color: white;
}

.call-btn.decline:hover {
  transform: scale(1.05);
  box-shadow: 0 8px 20px rgba(239, 68, 68, 0.4);
}

.call-btn.end {
  background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
  color: white;
  width: 100%;
  padding: 1rem;
}

/* Активный звонок */
.active-call {
  display: flex;
  flex-direction: column;
  height: 600px;
}

.call-header {
  padding: 1.5rem;
  background: rgba(255, 255, 255, 0.05);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.call-contact-info {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.contact-avatar {
  font-size: 2.5rem;
}

.contact-name {
  font-size: 1.2rem;
  font-weight: 600;
  color: white;
}

.call-duration {
  font-size: 0.9rem;
  color: rgba(255, 255, 255, 0.6);
}

.btn-minimize {
  background: rgba(255, 255, 255, 0.1);
  border: none;
  color: white;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  cursor: pointer;
  font-size: 1.2rem;
}

.call-messages {
  flex: 1;
  overflow-y: auto;
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.call-message {
  display: flex;
  flex-direction: column;
  max-width: 80%;
}

.call-message.user {
  align-self: flex-end;
  align-items: flex-end;
}

.call-message.ai {
  align-self: flex-start;
  align-items: flex-start;
}

.message-bubble {
  padding: 0.75rem 1rem;
  border-radius: 16px;
  margin-bottom: 0.25rem;
}

.call-message.user .message-bubble {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.call-message.ai .message-bubble {
  background: rgba(255, 255, 255, 0.1);
  color: white;
}

.message-time {
  font-size: 0.7rem;
  color: rgba(255, 255, 255, 0.5);
  padding: 0 0.5rem;
}

.call-input {
  padding: 1rem;
  background: rgba(255, 255, 255, 0.05);
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  display: flex;
  gap: 0.5rem;
}

.call-input textarea {
  flex: 1;
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  padding: 0.75rem;
  color: white;
  font-family: inherit;
  resize: none;
}

.call-input textarea::placeholder {
  color: rgba(255, 255, 255, 0.4);
}

.btn-send {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  color: white;
  width: 40px;
  border-radius: 12px;
  cursor: pointer;
  font-size: 1.2rem;
}

.btn-send:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.call-controls {
  padding: 1rem;
  background: rgba(255, 255, 255, 0.05);
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

/* Основной интерфейс */
.phone-main {
  display: flex;
  flex-direction: column;
  height: 600px;
}

.phone-header {
  padding: 1.5rem;
  background: rgba(255, 255, 255, 0.05);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.phone-header h2 {
  margin: 0;
  color: white;
  font-size: 1.3rem;
}

.btn-close {
  background: rgba(255, 255, 255, 0.1);
  border: none;
  color: white;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  cursor: pointer;
  font-size: 1.2rem;
}

.phone-tabs {
  display: flex;
  background: rgba(255, 255, 255, 0.03);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.tab-btn {
  flex: 1;
  padding: 1rem;
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.6);
  cursor: pointer;
  position: relative;
  transition: all 0.2s;
  font-size: 0.9rem;
}

.tab-btn.active {
  color: white;
  background: rgba(102, 126, 234, 0.2);
}

.tab-btn .badge {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  background: #ef4444;
  color: white;
  border-radius: 10px;
  padding: 0.1rem 0.4rem;
  font-size: 0.7rem;
}

.phone-content {
  flex: 1;
  overflow-y: auto;
  padding: 1rem;
}

.empty-state {
  text-align: center;
  padding: 3rem 1rem;
  color: rgba(255, 255, 255, 0.5);
}

/* Контакты */
.contacts-list {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.contact-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.contact-item:hover {
  background: rgba(255, 255, 255, 0.1);
  transform: translateX(5px);
}

.contact-item .contact-avatar {
  font-size: 2.5rem;
}

.contact-info {
  flex: 1;
}

.contact-name {
  font-weight: 600;
  color: white;
  margin-bottom: 0.25rem;
}

.contact-number {
  font-size: 0.85rem;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 0.25rem;
}

.contact-stats {
  font-size: 0.75rem;
  color: rgba(255, 255, 255, 0.5);
}

.contact-action {
  font-size: 1.5rem;
  opacity: 0.6;
}

/* История */
.call-history {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.history-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
}

.history-item.missed {
  border-left: 3px solid #ef4444;
}

.history-icon {
  font-size: 1.5rem;
}

.history-info {
  flex: 1;
}

.history-name {
  font-weight: 600;
  color: white;
  margin-bottom: 0.25rem;
}

.history-time {
  font-size: 0.8rem;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 0.25rem;
}

.history-status {
  font-size: 0.75rem;
  color: rgba(255, 255, 255, 0.5);
}

.btn-call-back {
  background: rgba(102, 126, 234, 0.2);
  border: none;
  color: white;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  cursor: pointer;
  font-size: 1.2rem;
}

/* Набор номера */
.dial-pad {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.dial-number-display {
  text-align: center;
  padding: 1.5rem;
  font-size: 1.5rem;
  color: white;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  min-height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.dial-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
}

.dial-btn {
  aspect-ratio: 1;
  background: rgba(255, 255, 255, 0.1);
  border: none;
  border-radius: 50%;
  color: white;
  font-size: 1.5rem;
  cursor: pointer;
  transition: all 0.2s;
}

.dial-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: scale(1.05);
}

.dial-actions {
  display: flex;
  gap: 1rem;
}

.dial-action-btn {
  flex: 1;
  padding: 1rem;
  border: none;
  border-radius: 12px;
  font-size: 1.2rem;
  cursor: pointer;
  transition: all 0.2s;
}

.dial-action-btn.delete {
  background: rgba(255, 255, 255, 0.1);
  color: white;
}

.dial-action-btn.call {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  color: white;
}

.dial-action-btn.call:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
