<template>
  <div class="dating-chat">
    <div class="character-header">
      <button class="btn-back" @click="$emit('back')">
        <span>← Назад</span>
      </button>
      <div v-if="character" class="character-info">
        <div class="character-avatar">{{ character.avatar || '💕' }}</div>
        <div>
          <h3>{{ character.name }}, {{ character.age }}</h3>
          <p class="character-occupation">{{ character.occupation }}</p>
        </div>
      </div>
    </div>

    <div ref="messagesContainer" class="messages-container">
      <div v-for="msg in messages" :key="msg.id" class="message" :class="msg.role">
        <div class="message-content">{{ msg.content }}</div>
      </div>

      <div v-if="isTyping" class="typing-indicator">
        <span></span><span></span><span></span>
      </div>
    </div>

    <div class="input-area">
      <textarea
        v-model="messageText"
        class="message-input"
        placeholder="Напишите сообщение..."
        @keydown.enter.exact.prevent="sendMessage"
      />
      <button class="btn-send" :disabled="!messageText.trim() || isTyping" @click="sendMessage">
        Отправить
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import { apiService, type AICharacter } from '@/services/api'
import { useSessionStore } from '@/stores/session'
import { useGameStore } from '@/stores/game'

const props = defineProps<{
  characterId: string
}>()

const emit = defineEmits<{
  back: []
}>()

const sessionStore = useSessionStore()
const gameStore = useGameStore()
const character = ref<AICharacter | null>(null)
const messages = ref<Array<{ id: string; role: string; content: string }>>([])
const messageText = ref('')
const isTyping = ref(false)
const messagesContainer = ref<HTMLElement>()

onMounted(async () => {
  await loadCharacter()
  addSystemMessage()
})

async function loadCharacter() {
  try {
    const response = await apiService.getCharacters()
    character.value = response.characters.find(c => c.id === props.characterId) || null
  } catch (error) {
    console.error('Error loading character:', error)
  }
}

function addSystemMessage() {
  if (character.value) {
    messages.value.push({
      id: Date.now().toString(),
      role: 'system',
      content: `Вы на свидании с ${character.value.name}. ${character.value.description}`
    })
  }
}

async function sendMessage() {
  if (!messageText.value.trim() || isTyping.value || !sessionStore.sessionId) return

  const userMessage = messageText.value.trim()
  messageText.value = ''

  messages.value.push({
    id: Date.now().toString(),
    role: 'user',
    content: userMessage
  })

  isTyping.value = true
  scrollToBottom()

  try {
    const response = await apiService.datingChat({
      character_id: props.characterId,
      message: userMessage,
      session_id: sessionStore.sessionId,
      context: 'Вы на свидании в уютном кафе.'
    })

    messages.value.push({
      id: Date.now().toString(),
      role: 'assistant',
      content: response.response
    })

    scrollToBottom()

    // Auto-save after dating conversation
    gameStore.saveGame()
  } catch (error) {
    console.error('Error sending message:', error)
    messages.value.push({
      id: Date.now().toString(),
      role: 'system',
      content: 'Ошибка при отправке сообщения'
    })
  } finally {
    isTyping.value = false
  }
}

function scrollToBottom() {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}
</script>

<style scoped>
.dating-chat {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 180px);
  background: var(--bg-secondary);
  border-radius: var(--radius-lg);
  border: 1px solid var(--border-color);
}

.character-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1.25rem 1.5rem;
  background: var(--bg-tertiary);
  border-bottom: 1px solid var(--border-color);
}

.btn-back {
  padding: 0.5rem 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-sm);
  cursor: pointer;
  color: var(--text-primary);
}

.character-info {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.character-avatar {
  font-size: 3rem;
}

.character-occupation {
  color: var(--text-secondary);
  font-size: 0.9rem;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.message {
  max-width: 70%;
  padding: 0.875rem 1.125rem;
  border-radius: var(--radius-md);
}

.message.user {
  align-self: flex-end;
  background: var(--gradient-primary);
  color: white;
}

.message.assistant {
  align-self: flex-start;
  background: var(--bg-tertiary);
  color: var(--text-primary);
}

.message.system {
  align-self: center;
  background: rgba(168, 85, 247, 0.1);
  color: var(--text-secondary);
  font-size: 0.875rem;
  text-align: center;
}

.typing-indicator {
  display: flex;
  gap: 0.4rem;
  padding: 0.75rem;
}

.typing-indicator span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--accent-purple);
  animation: typing 1.4s infinite;
}

.typing-indicator span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-indicator span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 60%, 100% {
    transform: translateY(0);
    opacity: 0.5;
  }
  30% {
    transform: translateY(-8px);
    opacity: 1;
  }
}

.input-area {
  padding: 1.25rem 1.5rem;
  background: var(--bg-tertiary);
  border-top: 1px solid var(--border-color);
  display: flex;
  gap: 0.75rem;
}

.message-input {
  flex: 1;
  padding: 0.875rem 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  color: var(--text-primary);
  font-family: inherit;
  resize: none;
  max-height: 120px;
}

.btn-send {
  padding: 0.875rem 1.5rem;
  background: var(--gradient-primary);
  border: none;
  border-radius: var(--radius-md);
  color: white;
  cursor: pointer;
  font-weight: 600;
}

.btn-send:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
