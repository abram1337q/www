<template>
  <div class="dating-chat">
    <div class="character-header">
      <button class="btn-back" @click="$emit('back')">
        <span>← Назад</span>
      </button>
      <div v-if="character" class="character-info">
        <div class="character-avatar">{{ character.avatar || '💕' }}</div>
        <div class="character-details">
          <h3>{{ character.name }}, {{ character.age }}</h3>
          <p class="character-occupation">{{ character.occupation }}</p>
          <div class="relationship-progress">
            <div class="relationship-stage">{{ relationshipStageLabel }}</div>
            <div class="progress-bar">
              <div class="progress-fill" :style="{ width: relationshipLevel + '%' }"></div>
            </div>
            <div class="progress-text">{{ relationshipLevel }}% · {{ totalInteractions }} взаимодействий</div>
          </div>
        </div>
      </div>
    </div>

    <div ref="messagesContainer" class="messages-container">
      <div v-for="msg in messages" :key="msg.id" class="message" :class="msg.role">
        <div class="message-content">{{ msg.content }}</div>
      </div>

      <div v-if="isTyping" class="typing-indicator">
        <span></span><span></span><span></span>
      </div>
    </div>

    <div v-if="availableActions.length > 0" class="actions-panel">
      <div class="actions-title">💡 Быстрые действия</div>
      <div class="actions-grid">
        <button
          v-for="action in availableActions"
          :key="action.id"
          class="action-btn"
          :disabled="isTyping || action.cost > playerMoney"
          @click="performAction(action)"
        >
          <span class="action-label">{{ action.label }}</span>
          <span class="action-cost" v-if="action.cost > 0">{{ formatMoney(action.cost) }}</span>
          <span class="action-effect">{{ action.effect }}</span>
        </button>
      </div>
    </div>

    <div class="input-area">
      <textarea
        v-model="messageText"
        class="message-input"
        placeholder="Напишите сообщение..."
        @keydown.enter.exact.prevent="sendMessage"
      />
      <button class="btn-send" :disabled="!messageText.trim() || isTyping" @click="sendMessage">
        Отправить
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, computed, watch } from 'vue'
import { apiService, type AICharacter, type ContextualAction } from '@/services/api'
import { useSessionStore } from '@/stores/session'
import { useGameStore } from '@/stores/game'
import { useSocialStore } from '@/stores/social'
import { usePlayerStore } from '@/stores/player'

const props = defineProps<{
  characterId: string
}>()

const emit = defineEmits<{
  back: []
}>()

const sessionStore = useSessionStore()
const gameStore = useGameStore()
const socialStore = useSocialStore()
const playerStore = usePlayerStore()

const character = ref<AICharacter | null>(null)
const messages = ref<Array<{ id: string; role: string; content: string }>>([])
const messageText = ref('')
const isTyping = ref(false)
const messagesContainer = ref<HTMLElement>()
const relationshipLevel = ref(0)
const totalInteractions = ref(0)
const availableActions = ref<ContextualAction[]>([])
const playerMoney = computed(() => playerStore.money)

const relationshipStageLabel = computed(() => {
  const level = relationshipLevel.value
  if (level < 10) return '😐 Незнакомцы'
  if (level < 30) return '👋 Знакомые'
  if (level < 50) return '🙂 Друзья'
  if (level < 70) return '😊 Близкие друзья'
  if (level < 85) return '😍 Влюблены'
  if (level < 92) return '💑 Встречаетесь'
  if (level < 95) return '💍 Помолвлены'
  return '💒 Женаты'
})

onMounted(async () => {
  await loadCharacter()
  loadRelationshipData()
  loadSavedMessages()
  if (messages.value.length === 0) {
    addSystemMessage()
  }
  await loadActions()
})

async function loadCharacter() {
  try {
    const response = await apiService.getCharacters()
    character.value = response.characters.find(c => c.id === props.characterId) || null
  } catch (error) {
    console.error('Error loading character:', error)
  }
}

function loadRelationshipData() {
  const dateProfile = socialStore.dateProfiles.find(d => d.id === props.characterId)
  if (dateProfile) {
    relationshipLevel.value = dateProfile.relationshipLevel
    totalInteractions.value = dateProfile.totalInteractions
  }
}

function loadSavedMessages() {
  const chatKey = `dating_chat_${sessionStore.sessionId}_${props.characterId}`
  const savedMessages = localStorage.getItem(chatKey)

  if (savedMessages) {
    try {
      messages.value = JSON.parse(savedMessages)
      scrollToBottom()
    } catch (error) {
      console.error('Error loading saved messages:', error)
      messages.value = []
    }
  }
}

function saveMessages() {
  const chatKey = `dating_chat_${sessionStore.sessionId}_${props.characterId}`
  try {
    localStorage.setItem(chatKey, JSON.stringify(messages.value))
  } catch (error) {
    console.error('Error saving messages:', error)
  }
}

function addSystemMessage() {
  if (character.value) {
    const stage = relationshipStageLabel.value
    const level = relationshipLevel.value
    let intro = ''

    if (level < 10) {
      intro = `Вы увидели профиль ${character.value.name} в приложении для знакомств и решили написать. ${character.value.description}`
    } else if (level < 30) {
      intro = `Вы уже познакомились с ${character.value.name} и общаетесь. ${character.value.description}`
    } else if (level < 70) {
      intro = `${character.value.name} - ваша знакомая. ${character.value.description}`
    } else {
      intro = `${character.value.name} - ваша девушка. ${character.value.description}`
    }

    messages.value.push({
      id: Date.now().toString(),
      role: 'system',
      content: `${intro}\n\n📊 Статус отношений: ${stage}`
    })
  }
}

async function loadActions() {
  if (!sessionStore.sessionId) return

  try {
    const dateProfile = socialStore.dateProfiles.find(d => d.id === props.characterId)
    const relationshipData = dateProfile ? {
      stage: dateProfile.relationshipStage,
      level: dateProfile.relationshipLevel,
      trust: dateProfile.trust,
      tension: dateProfile.tension,
      hasPhoneNumber: dateProfile.hasPhoneNumber || false
    } : undefined

    const response = await apiService.generateActions({
      character_id: props.characterId,
      relationship_data: relationshipData,
      player_money: playerMoney.value
    })

    availableActions.value = response.actions
  } catch (error) {
    console.error('Error loading actions:', error)
  }
}

async function performAction(action: ContextualAction) {
  if (isTyping.value || !sessionStore.sessionId) return

  // Проверяем деньги
  if (action.cost > playerMoney.value) {
    messages.value.push({
      id: Date.now().toString(),
      role: 'system',
      content: `❌ Недостаточно средств! Нужно: ${formatMoney(action.cost)}`
    })
    saveMessages()
    return
  }

  isTyping.value = true

  try {
    // Списываем деньги если нужно
    if (action.cost > 0) {
      playerStore.spendMoney(action.cost)
    }

    // Добавляем сообщение о действии
    messages.value.push({
      id: Date.now().toString(),
      role: 'user',
      content: `[Вы: ${action.label}]`
    })
    saveMessages()
    scrollToBottom()

    const dateProfile = socialStore.dateProfiles.find(d => d.id === props.characterId)
    const relationshipData = dateProfile ? {
      stage: dateProfile.relationshipStage,
      level: dateProfile.relationshipLevel,
      trust: dateProfile.trust,
      tension: dateProfile.tension,
      hasPhoneNumber: dateProfile.hasPhoneNumber || false
    } : undefined

    const response = await apiService.performAction({
      character_id: props.characterId,
      action_id: action.id,
      session_id: sessionStore.sessionId,
      relationship_data: relationshipData
    })

    // Добавляем ответ ИИ
    messages.value.push({
      id: Date.now().toString(),
      role: 'assistant',
      content: response.response
    })
    saveMessages()
    scrollToBottom()

    // Обновляем отношения
    const oldStage = relationshipStageLabel.value
    socialStore.interactWithPartner(props.characterId, getInteractionType(action.id))
    loadRelationshipData()

    const newStage = relationshipStageLabel.value
    if (oldStage !== newStage) {
      messages.value.push({
        id: Date.now().toString(),
        role: 'system',
        content: `🎉 Ваши отношения перешли на новый уровень: ${newStage}!`
      })
      saveMessages()
      scrollToBottom()
    }

    // Обновляем доступные действия
    await loadActions()

    gameStore.saveGame()
  } catch (error) {
    console.error('Error performing action:', error)
    messages.value.push({
      id: Date.now().toString(),
      role: 'system',
      content: '❌ Ошибка при выполнении действия'
    })
    saveMessages()
  } finally {
    isTyping.value = false
  }
}

function getInteractionType(actionId: string): 'talk' | 'date' | 'gift' | 'vacation' {
  if (['compliment', 'ask_about_day', 'share_hobby', 'send_meme'].includes(actionId)) {
    return 'talk'
  } else if (['invite_coffee', 'cinema', 'romantic_date', 'romantic_evening'].includes(actionId)) {
    return 'date'
  } else if (['small_gift', 'expensive_gift', 'jewelry', 'cook_dinner', 'surprise'].includes(actionId)) {
    return 'gift'
  } else if (['weekend_trip', 'voice_call'].includes(actionId)) {
    return 'vacation'
  }
  return 'talk'
}

function formatMoney(amount: number): string {
  return new Intl.NumberFormat('ru-RU', { style: 'currency', currency: 'RUB' }).format(amount)
}

async function sendMessage() {
  if (!messageText.value.trim() || isTyping.value || !sessionStore.sessionId) return

  const userMessage = messageText.value.trim()
  messageText.value = ''

  messages.value.push({
    id: Date.now().toString(),
    role: 'user',
    content: userMessage
  })

  saveMessages()

  isTyping.value = true
  scrollToBottom()

  try {
    // Получить данные о текущих отношениях
    const dateProfile = socialStore.dateProfiles.find(d => d.id === props.characterId)
    const relationshipData = dateProfile ? {
      stage: dateProfile.relationshipStage,
      level: dateProfile.relationshipLevel,
      trust: dateProfile.trust,
      tension: dateProfile.tension,
      married: dateProfile.relationshipStage === 'married',
      children: []
    } : undefined

    const response = await apiService.datingChat({
      character_id: props.characterId,
      message: userMessage,
      session_id: sessionStore.sessionId,
      context: getDateContext(),
      relationship_data: relationshipData
    })

    messages.value.push({
      id: Date.now().toString(),
      role: 'assistant',
      content: response.response
    })

    saveMessages()

    scrollToBottom()

    // ВАЖНО: Повысить уровень отношений после взаимодействия
    const oldLevel = relationshipLevel.value
    const oldStage = relationshipStageLabel.value

    socialStore.interactWithPartner(props.characterId, 'talk')

    // Обновить локальные данные
    loadRelationshipData()

    const newStage = relationshipStageLabel.value

    // Показать уведомление о переходе на новую стадию
    if (oldStage !== newStage) {
      messages.value.push({
        id: Date.now().toString(),
        role: 'system',
        content: `🎉 Ваши отношения перешли на новый уровень: ${newStage}!`
      })
      saveMessages()
      scrollToBottom()
    }

    // Auto-save after dating conversation
    gameStore.saveGame()
  } catch (error) {
    console.error('Error sending message:', error)
    messages.value.push({
      id: Date.now().toString(),
      role: 'system',
      content: 'Ошибка при отправке сообщения'
    })
    saveMessages()
  } finally {
    isTyping.value = false
  }
}

function getDateContext(): string {
  const level = relationshipLevel.value
  const locations = {
    stranger: ['онлайн в приложении для знакомств', 'в социальной сети', 'переписываетесь в мессенджере'],
    acquaintance: ['в уютном кафе', 'на прогулке в парке', 'в книжном магазине'],
    friend: ['в кино', 'в ресторане', 'на выставке'],
    close_friend: ['у неё дома', 'у вас дома', 'на пикнике'],
    dating: ['на романтическом ужине', 'на берегу озера', 'в романтическом месте']
  }

  let stage = 'stranger'
  let contextPrefix = 'Вы познакомились онлайн и'

  if (level < 10) {
    stage = 'stranger'
    contextPrefix = 'Вы только что познакомились онлайн и'
  } else if (level < 30) {
    stage = 'acquaintance'
    contextPrefix = 'Вы уже знакомы и встречаетесь'
  } else if (level < 50) {
    stage = 'friend'
    contextPrefix = 'Вы друзья и проводите время'
  } else if (level < 70) {
    stage = 'close_friend'
    contextPrefix = 'Вы близкие друзья и находитесь'
  } else {
    stage = 'dating'
    contextPrefix = 'Вы влюблены друг в друга и сейчас'
  }

  const locationArray = locations[stage as keyof typeof locations]
  const randomLocation = locationArray[Math.floor(Math.random() * locationArray.length)]

  return `${contextPrefix} ${randomLocation}.`
}

function scrollToBottom() {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

// НОВОЕ: Перезагружаем действия при изменении уровня отношений
watch(relationshipLevel, async () => {
  await loadActions()
})
</script>

<style scoped>
.dating-chat {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 180px);
  background: var(--bg-secondary);
  border-radius: var(--radius-lg);
  border: 1px solid var(--border-color);
}

.character-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1.25rem 1.5rem;
  background: var(--bg-tertiary);
  border-bottom: 1px solid var(--border-color);
}

.btn-back {
  padding: 0.5rem 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-sm);
  cursor: pointer;
  color: var(--text-primary);
}

.character-info {
  display: flex;
  align-items: center;
  gap: 1rem;
  flex: 1;
}

.character-avatar {
  font-size: 3rem;
}

.character-details {
  flex: 1;
}

.character-occupation {
  color: var(--text-secondary);
  font-size: 0.9rem;
  margin: 0.25rem 0;
}

.relationship-progress {
  margin-top: 0.75rem;
}

.relationship-stage {
  font-size: 0.85rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #667eea;
}

.progress-bar {
  height: 8px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 0.25rem;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  transition: width 0.5s ease;
}

.progress-text {
  font-size: 0.75rem;
  color: var(--text-secondary);
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.message {
  max-width: 70%;
  padding: 0.875rem 1.125rem;
  border-radius: var(--radius-md);
}

.message.user {
  align-self: flex-end;
  background: var(--gradient-primary);
  color: white;
}

.message.assistant {
  align-self: flex-start;
  background: var(--bg-tertiary);
  color: var(--text-primary);
}

.message.system {
  align-self: center;
  background: rgba(168, 85, 247, 0.1);
  color: var(--text-secondary);
  font-size: 0.875rem;
  text-align: center;
}

.typing-indicator {
  display: flex;
  gap: 0.4rem;
  padding: 0.75rem;
}

.typing-indicator span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--accent-purple);
  animation: typing 1.4s infinite;
}

.typing-indicator span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-indicator span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 60%, 100% {
    transform: translateY(0);
    opacity: 0.5;
  }
  30% {
    transform: translateY(-8px);
    opacity: 1;
  }
}

.input-area {
  padding: 1.25rem 1.5rem;
  background: var(--bg-tertiary);
  border-top: 1px solid var(--border-color);
  display: flex;
  gap: 0.75rem;
}

.message-input {
  flex: 1;
  padding: 0.875rem 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  color: var(--text-primary);
  font-family: inherit;
  resize: none;
  max-height: 120px;
}

.btn-send {
  padding: 0.875rem 1.5rem;
  background: var(--gradient-primary);
  border: none;
  border-radius: var(--radius-md);
  color: white;
  cursor: pointer;
  font-weight: 600;
}

.btn-send:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.actions-panel {
  padding: 1rem 1.5rem;
  background: var(--bg-tertiary);
  border-top: 1px solid var(--border-color);
  border-bottom: 1px solid var(--border-color);
}

.actions-title {
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--text-secondary);
  margin-bottom: 0.75rem;
}

.actions-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 0.75rem;
}

.action-btn {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 0.75rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  cursor: pointer;
  transition: all 0.2s;
  text-align: left;
}

.action-btn:hover:not(:disabled) {
  background: var(--bg-primary);
  border-color: var(--accent-purple);
  transform: translateY(-2px);
}

.action-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.action-label {
  font-size: 0.9rem;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 0.25rem;
}

.action-cost {
  font-size: 0.8rem;
  color: #f59e0b;
  margin-bottom: 0.25rem;
}

.action-effect {
  font-size: 0.75rem;
  color: var(--text-secondary);
}
</style>
