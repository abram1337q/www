<template>
  <div class="dashboard">
    <!-- Global Events Banner -->
    <div v-if="eventsStore.hasActiveEvent" class="events-banner">
      <div v-for="event in eventsStore.activeEvents" :key="event.id" class="event-alert" :class="`event-${event.type}`">
        <div class="event-icon">{{ getEventIcon(event.type) }}</div>
        <div class="event-content">
          <h4>{{ event.title }}</h4>
          <p>{{ event.description }}</p>
        </div>
      </div>
    </div>

    <!-- Player Stats Header -->
    <div class="stats-header">
      <div class="player-info">
        <div class="player-avatar">{{ playerStore.name[0].toUpperCase() }}</div>
        <div class="player-details">
          <h2>{{ playerStore.name }}</h2>
          <p class="player-age">{{ Math.floor(playerStore.stats.age) }} лет</p>
          <p v-if="playerStore.job" class="player-job">{{ playerStore.job.title }}</p>
        </div>
      </div>

      <div class="quick-stats">
        <div class="stat-card">
          <div class="stat-icon">💰</div>
          <div class="stat-info">
            <span class="stat-label">Деньги</span>
            <span class="stat-value">{{ formatMoney(playerStore.money) }}</span>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">📈</div>
          <div class="stat-info">
            <span class="stat-label">Капитал</span>
            <span class="stat-value">{{ formatMoney(playerStore.netWorth) }}</span>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">😊</div>
          <div class="stat-info">
            <span class="stat-label">Счастье</span>
            <span class="stat-value">{{ playerStore.stats.happiness }}%</span>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">❤️</div>
          <div class="stat-info">
            <span class="stat-label">Здоровье</span>
            <span class="stat-value">{{ playerStore.stats.health }}%</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Navigation Tabs -->
    <div class="nav-tabs">
      <button
        v-for="tab in tabs"
        :key="tab.id"
        :class="['tab', { active: activeTab === tab.id }]"
        @click="activeTab = tab.id"
      >
        <span class="tab-icon">{{ tab.icon }}</span>
        <span class="tab-label">{{ tab.label }}</span>
      </button>
    </div>

    <!-- Tab Content -->
    <div class="tab-content">
      <!-- Profile Tab -->
      <div v-if="activeTab === 'profile'" class="profile-view">
        <div class="content-grid">
          <div class="card">
            <h3>Характеристики</h3>
            <div class="stats-list">
              <div class="stat-row">
                <span>Интеллект</span>
                <div class="stat-bar">
                  <div class="stat-fill" :style="{ width: playerStore.stats.intelligence + '%' }"></div>
                  <span class="stat-number">{{ playerStore.stats.intelligence }}</span>
                </div>
              </div>
              <div class="stat-row">
                <span>Харизма</span>
                <div class="stat-bar">
                  <div class="stat-fill" :style="{ width: playerStore.stats.charisma + '%' }"></div>
                  <span class="stat-number">{{ playerStore.stats.charisma }}</span>
                </div>
              </div>
              <div class="stat-row">
                <span>Сила</span>
                <div class="stat-bar">
                  <div class="stat-fill" :style="{ width: playerStore.stats.strength + '%' }"></div>
                  <span class="stat-number">{{ playerStore.stats.strength }}</span>
                </div>
              </div>
              <div class="stat-row">
                <span>Энергия</span>
                <div class="stat-bar">
                  <div class="stat-fill energy" :style="{ width: playerStore.stats.energy + '%' }"></div>
                  <span class="stat-number">{{ playerStore.stats.energy }}</span>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <h3>Финансы</h3>
            <div class="finance-info">
              <div class="finance-row">
                <span>Доход/месяц:</span>
                <span class="positive">+{{ formatMoney(playerStore.monthlyIncome) }}</span>
              </div>
              <div class="finance-row">
                <span>Расходы/месяц:</span>
                <span class="negative">-{{ formatMoney(playerStore.monthlyExpenses) }}</span>
              </div>
              <div class="finance-row total">
                <span>Чистый доход:</span>
                <span :class="playerStore.monthlyIncome - playerStore.monthlyExpenses >= 0 ? 'positive' : 'negative'">
                  {{ formatMoney(playerStore.monthlyIncome - playerStore.monthlyExpenses) }}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Jobs Tab -->
      <div v-if="activeTab === 'jobs'" class="jobs-view">
        <JobInterview
          v-if="showJobInterview && selectedJob"
          :job-title="selectedJob.title"
          :company="selectedJob.company"
          :salary="selectedJob.currentSalary"
          @back="handleBackFromInterview"
          @hired="handleJobHired"
        />
        <div v-else>
          <div class="section-header">
            <h3>Рынок труда</h3>
            <div class="market-info">
              <span>Состояние экономики: {{ economyStore.economicHealth }}%</span>
              <span>Безработица: {{ economyStore.unemploymentRate }}%</span>
            </div>
          </div>

          <div class="jobs-grid">
            <div v-for="job in economyStore.jobListings" :key="job.id" class="job-card">
              <div class="job-header">
                <h4>{{ job.title }}</h4>
                <span class="company">{{ job.company }}</span>
              </div>
              <div class="job-salary">{{ formatMoney(job.currentSalary) }}/мес</div>
              <div class="job-applicants">
                <div class="applicants-bar">
                  <div class="applicants-fill" :style="{ width: (job.applicants / job.maxApplicants * 100) + '%' }"></div>
                </div>
                <span>{{ job.applicants }}/{{ job.maxApplicants }} кандидатов</span>
              </div>
              <div class="job-requirements">
                <span>Интеллект: {{ job.requirements.intelligence }}+</span>
                <span>Харизма: {{ job.requirements.charisma }}+</span>
                <span>Опыт: {{ job.requirements.experience }}+ лет</span>
              </div>
              <button
                class="apply-btn"
                :disabled="job.isApplied || !canApplyForJob(job)"
                @click="applyForJob(job)"
              >
                {{ job.isApplied ? 'Пройти собеседование' : 'Откликнуться' }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Real Estate Tab -->
      <div v-if="activeTab === 'realestate'" class="realestate-view">
        <h3>Рынок недвижимости</h3>
        <div class="realestate-grid">
          <div v-for="property in economyStore.realEstateListings" :key="property.id" class="property-card">
            <div class="property-type">{{ getPropertyTypeLabel(property.type) }}</div>
            <h4>{{ property.name }}</h4>
            <div class="property-price">{{ formatMoney(property.currentPrice) }}</div>
            <div class="property-expense">{{ formatMoney(property.monthlyExpense) }}/мес</div>
            <div class="property-demand">
              <span>Спрос:</span>
              <div class="demand-bar">
                <div class="demand-fill" :style="{ width: property.demand + '%' }"></div>
              </div>
            </div>
            <button
              class="buy-btn"
              :disabled="playerStore.money < property.currentPrice"
              @click="buyProperty(property)"
            >
              Купить
            </button>
          </div>
        </div>
      </div>

      <!-- Marketplace Tab -->
      <div v-if="activeTab === 'marketplace'" class="marketplace-view">
        <h3>Магазин товаров</h3>
        <p class="section-desc">Покупайте товары для повышения характеристик</p>

        <div class="marketplace-grid">
          <div v-for="item in economyStore.marketItems" :key="item.id" class="market-item-card">
            <div class="item-category">{{ getCategoryLabel(item.category) }}</div>
            <h4>{{ item.name }}</h4>
            <div class="item-price">{{ formatMoney(item.currentPrice) }}</div>
            <div class="item-stock">
              <span>В наличии:</span>
              <span class="stock-count">{{ item.stock }}</span>
            </div>
            <div class="item-effect">{{ getItemEffect(item.category) }}</div>
            <button
              class="buy-item-btn"
              :disabled="playerStore.money < item.currentPrice || item.stock === 0"
              @click="buyMarketItem(item)"
            >
              {{ item.stock === 0 ? 'Нет в наличии' : 'Купить' }}
            </button>
          </div>
        </div>
      </div>

      <!-- Social Tab -->
      <div v-if="activeTab === 'social'" class="social-view">
        <h3>Социальная сеть</h3>
        <div class="profiles-grid">
          <div v-for="profile in socialStore.profiles.slice(0, 12)" :key="profile.id" class="profile-card">
            <div class="profile-avatar">{{ profile.avatar }}</div>
            <h4>{{ profile.name }}</h4>
            <p class="profile-age">{{ profile.age }} лет</p>
            <p class="profile-job">{{ profile.occupation }}</p>
            <div class="profile-stats-mini">
              <span>💰 {{ formatMoney(profile.netWorth) }}</span>
              <span>😊 {{ profile.happiness }}%</span>
            </div>
            <span class="profile-status">{{ getStatusLabel(profile.relationshipStatus) }}</span>
          </div>
        </div>
      </div>

      <!-- Dating Tab -->
      <div v-if="activeTab === 'dating'" class="dating-view">
        <DatingChat
          v-if="showDatingChat && selectedCharacterId"
          :character-id="selectedCharacterId"
          @back="handleBackFromDating"
        />
        <div v-else>
          <h3>AI Знакомства</h3>
          <p class="section-desc">Познакомьтесь с AI персонажами и пообщайтесь с ними</p>

          <div class="dates-grid">
            <div v-for="date in socialStore.dateProfiles" :key="date.id" class="date-card">
              <div class="date-avatar">{{ date.avatar }}</div>
              <h4>{{ date.name }}</h4>
              <p class="date-age">{{ date.age }} лет</p>
              <p class="date-job">{{ date.occupation }}</p>
              <div class="date-personality">{{ getPersonalityLabel(date.personality) }}</div>

              <div class="relationship-status">
                <div class="relationship-stage">
                  {{ getRelationshipStageLabel(date.relationshipLevel) }}
                </div>
                <div class="relationship-bar">
                  <div class="relationship-fill" :style="{ width: date.relationshipLevel + '%' }"></div>
                </div>
                <div class="relationship-level">{{ date.relationshipLevel }}% · {{ date.totalInteractions }} встреч</div>
              </div>

              <div class="compatibility">
                <span>Совместимость:</span>
                <div class="compatibility-bar">
                  <div class="compatibility-fill" :style="{ width: date.compatibility + '%' }"></div>
                  <span>{{ date.compatibility }}%</span>
                </div>
              </div>
              <div class="date-interests">
                <span v-for="interest in date.interests.slice(0, 3)" :key="interest" class="interest-tag">
                  {{ interest }}
                </span>
              </div>

              <div class="date-actions">
                <button class="date-btn primary" @click="startDating(date.id)">
                  💬 Пообщаться
                </button>

                <button
                  v-if="date.relationshipLevel >= 50"
                  class="date-btn secondary"
                  :disabled="playerStore.money < 5000"
                  @click="takeOnDate(date.id)"
                >
                  🍽️ Свидание (5,000₽)
                </button>

                <button
                  v-if="date.relationshipLevel >= 70"
                  class="date-btn secondary"
                  :disabled="playerStore.money < 15000"
                  @click="giveGift(date.id)"
                >
                  🎁 Подарок (15,000₽)
                </button>

                <button
                  v-if="date.relationshipLevel >= 85 && date.relationshipStage !== 'engaged' && date.relationshipStage !== 'married'"
                  class="date-btn special"
                  @click="proposeMarriage(date.id)"
                >
                  💍 Предложение
                </button>

                <button
                  v-if="date.relationshipStage === 'engaged'"
                  class="date-btn special"
                  :disabled="playerStore.money < 300000"
                  @click="marryPartner(date.id)"
                >
                  💒 Свадьба (300,000₽)
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Family Tab -->
      <div v-if="activeTab === 'family'" class="family-view">
        <h3>👨‍👩‍👧‍👦 Моя семья</h3>

        <div v-if="socialStore.currentPartner" class="partner-section">
          <h4>💑 Партнер</h4>
          <div class="partner-card">
            <div class="partner-avatar">{{ socialStore.currentPartner.avatar }}</div>
            <div class="partner-info">
              <h3>{{ socialStore.currentPartner.name }}</h3>
              <p>{{ socialStore.currentPartner.age }} лет · {{ socialStore.currentPartner.occupation }}</p>
              <div class="partner-status">
                {{ getRelationshipStageLabel(socialStore.currentPartner.relationshipLevel) }}
              </div>
              <div class="partner-stats">
                <div class="stat-item">
                  <span>Отношения:</span>
                  <div class="mini-bar">
                    <div class="mini-fill" :style="{ width: socialStore.currentPartner.relationshipLevel + '%' }"></div>
                  </div>
                  <span>{{ socialStore.currentPartner.relationshipLevel }}%</span>
                </div>
                <div class="stat-item">
                  <span>Доверие:</span>
                  <div class="mini-bar">
                    <div class="mini-fill" :style="{ width: socialStore.currentPartner.trust + '%' }"></div>
                  </div>
                  <span>{{ socialStore.currentPartner.trust }}%</span>
                </div>
                <div class="stat-item">
                  <span>Напряжение:</span>
                  <div class="mini-bar tension">
                    <div class="mini-fill tension" :style="{ width: socialStore.currentPartner.tension + '%' }"></div>
                  </div>
                  <span>{{ socialStore.currentPartner.tension }}%</span>
                </div>
              </div>
              <button class="date-btn primary" @click="startDating(socialStore.currentPartner.id)">
                💬 Пообщаться
              </button>
            </div>
          </div>
        </div>

        <div v-else class="no-partner">
          <p>💔 У вас пока нет партнера</p>
          <button class="date-btn primary" @click="activeTab = 'dating'">
            Перейти к знакомствам
          </button>
        </div>
      </div>

      <!-- AI Advisor Tab -->
      <div v-if="activeTab === 'advisor'" class="advisor-view">
        <AIAdvisor />
      </div>

      <!-- Leaderboards Tab -->
      <div v-if="activeTab === 'leaderboards'" class="leaderboards-view">
        <div class="leaderboards-grid">
          <div class="leaderboard-section">
            <h3>🏆 Богатейшие</h3>
            <div class="leaderboard-list">
              <div v-for="entry in socialStore.wealthLeaderboard" :key="entry.profile.id" class="leaderboard-entry">
                <span class="rank">{{ entry.rank }}</span>
                <span class="profile-avatar-mini">{{ entry.profile.avatar }}</span>
                <span class="profile-name">{{ entry.profile.name }}</span>
                <span class="score">{{ formatMoney(entry.score) }}</span>
              </div>
            </div>
          </div>

          <div class="leaderboard-section">
            <h3>😊 Самые счастливые</h3>
            <div class="leaderboard-list">
              <div v-for="entry in socialStore.happinessLeaderboard" :key="entry.profile.id" class="leaderboard-entry">
                <span class="rank">{{ entry.rank }}</span>
                <span class="profile-avatar-mini">{{ entry.profile.avatar }}</span>
                <span class="profile-name">{{ entry.profile.name }}</span>
                <span class="score">{{ entry.score }}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Time Control -->
    <div class="time-control">
      <button class="time-btn" @click="passTime">⏩ Пропустить месяц</button>
    </div>

    <!-- Save/Load Controls -->
    <div class="save-controls">
      <button class="save-btn" :disabled="gameStore.isSaving" @click="gameStore.saveGame()">
        {{ gameStore.isSaving ? '💾 Сохранение...' : '💾 Сохранить' }}
      </button>
      <button class="load-btn" @click="gameStore.loadGame()">
        📂 Загрузить
      </button>
      <button class="reset-btn" @click="handleReset">
        🔄 Новая игра
      </button>
      <div v-if="gameStore.lastSaveTime" class="last-save">
        Последнее сохранение: {{ formatSaveTime(gameStore.lastSaveTime) }}
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { usePlayerStore } from '@/stores/player'
import { useEconomyStore } from '@/stores/economy'
import { useSocialStore } from '@/stores/social'
import { useEventsStore } from '@/stores/events'
import { useSessionStore } from '@/stores/session'
import { useGameStore } from '@/stores/game'
import type { JobListing, RealEstateListing } from '@/stores/economy'
import DatingChat from './DatingChat.vue'
import JobInterview from './JobInterview.vue'
import AIAdvisor from './AIAdvisor.vue'

const playerStore = usePlayerStore()
const economyStore = useEconomyStore()
const socialStore = useSocialStore()
const eventsStore = useEventsStore()
const sessionStore = useSessionStore()
const gameStore = useGameStore()

const activeTab = ref('profile')
const showDatingChat = ref(false)
const selectedCharacterId = ref<string | null>(null)
const showJobInterview = ref(false)
const selectedJob = ref<JobListing | null>(null)

const tabs = [
  { id: 'profile', label: 'Профиль', icon: '👤' },
  { id: 'jobs', label: 'Работа', icon: '💼' },
  { id: 'realestate', label: 'Недвижимость', icon: '🏠' },
  { id: 'marketplace', label: 'Магазин', icon: '🛒' },
  { id: 'social', label: 'Люди', icon: '👥' },
  { id: 'dating', label: 'AI Знакомства', icon: '💕' },
  { id: 'family', label: 'Семья', icon: '👨‍👩‍👧‍👦' },
  { id: 'advisor', label: 'AI Советник', icon: '🧠' },
  { id: 'leaderboards', label: 'Рейтинги', icon: '🏆' }
]

function formatMoney(amount: number): string {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount)
}

function getEventIcon(type: string): string {
  const icons = {
    crisis: '📉',
    epidemic: '🦠',
    boom: '📈',
    disaster: '🌪️',
    celebration: '🎉'
  }
  return icons[type as keyof typeof icons] || '📢'
}

function getPropertyTypeLabel(type: string): string {
  const labels = {
    apartment: 'Квартира',
    house: 'Дом',
    mansion: 'Особняк'
  }
  return labels[type as keyof typeof labels] || type
}

function getStatusLabel(status: string): string {
  const labels = {
    single: 'Свободен',
    dating: 'Встречается',
    married: 'Женат/Замужем'
  }
  return labels[status as keyof typeof labels] || status
}

function getPersonalityLabel(personality: string): string {
  const labels = {
    outgoing: 'Общительная',
    shy: 'Застенчивая',
    confident: 'Уверенная',
    creative: 'Творческая',
    intellectual: 'Интеллектуальная'
  }
  return labels[personality as keyof typeof labels] || personality
}

function canApplyForJob(job: JobListing): boolean {
  return (
    playerStore.stats.intelligence >= job.requirements.intelligence &&
    playerStore.stats.charisma >= job.requirements.charisma &&
    (playerStore.job?.experience || 0) >= job.requirements.experience
  )
}

function applyForJob(job: JobListing) {
  if (canApplyForJob(job)) {
    economyStore.applyForJob(job.id)
    selectedJob.value = job
    showJobInterview.value = true
  }
}

function handleJobHired(jobData: { jobTitle: string; company: string; salary: number }) {
  playerStore.setJob({
    id: selectedJob.value!.id,
    title: jobData.jobTitle,
    company: jobData.company,
    salary: jobData.salary,
    experience: selectedJob.value!.requirements.experience,
    level: 1
  })
  showJobInterview.value = false
  selectedJob.value = null

  // Auto-save after getting hired
  gameStore.saveGame()
}

function handleBackFromInterview() {
  showJobInterview.value = false
  selectedJob.value = null
}

function startDating(dateId: string) {
  selectedCharacterId.value = dateId
  showDatingChat.value = true
}

function handleBackFromDating() {
  showDatingChat.value = false
  selectedCharacterId.value = null
}

function getRelationshipStageLabel(level: number): string {
  if (level < 10) return '😐 Незнакомцы'
  if (level < 30) return '👋 Знакомые'
  if (level < 50) return '🙂 Друзья'
  if (level < 70) return '😊 Близкие друзья'
  if (level < 85) return '😍 Влюблены'
  if (level < 92) return '💑 Встречаетесь'
  if (level < 95) return '💍 Помолвлены'
  return '💒 Женаты'
}

function takeOnDate(dateId: string) {
  if (playerStore.money >= 5000) {
    playerStore.addMoney(-5000)
    socialStore.interactWithPartner(dateId, 'date')
    alert('Отличное свидание! Ваши отношения улучшились.')
    gameStore.saveGame()
  }
}

function giveGift(dateId: string) {
  if (playerStore.money >= 15000) {
    playerStore.addMoney(-15000)
    socialStore.interactWithPartner(dateId, 'gift')
    alert('Подарок очень понравился! Отношения значительно улучшились.')
    gameStore.saveGame()
  }
}

function proposeMarriage(dateId: string) {
  const success = socialStore.proposeMarriage(dateId)
  if (success) {
    alert('🎉 Она сказала ДА! Поздравляем с помолвкой!')
    gameStore.saveGame()
  } else {
    alert('😔 К сожалению, она отказала. Нужно улучшить отношения.')
  }
}

function marryPartner(dateId: string) {
  if (playerStore.money >= 300000) {
    playerStore.addMoney(-300000)
    const success = socialStore.marry(dateId, 300000)
    if (success) {
      alert('💒 Поздравляем с свадьбой! Теперь вы женаты!')
      gameStore.saveGame()
    }
  }
}

function buyProperty(listing: RealEstateListing) {
  const property = {
    id: listing.id,
    type: listing.type,
    name: listing.name,
    value: listing.currentPrice,
    monthlyExpense: listing.monthlyExpense
  }

  const success = playerStore.buyProperty(property)
  if (success) {
    // Auto-save after purchase
    gameStore.saveGame()
  }
}

function getCategoryLabel(category: string): string {
  const labels = {
    food: 'Еда',
    clothes: 'Одежда',
    electronics: 'Электроника',
    transport: 'Транспорт'
  }
  return labels[category as keyof typeof labels] || category
}

function getItemEffect(category: string): string {
  const effects = {
    food: '+5 Энергия, +2 Здоровье',
    clothes: '+3 Харизма, +5 Счастье',
    electronics: '+5 Интеллект, +3 Счастье',
    transport: '+10 Счастье, +5 Харизма'
  }
  return effects[category as keyof typeof effects] || ''
}

function buyMarketItem(item: any) {
  if (playerStore.money >= item.currentPrice && item.stock > 0) {
    const success = economyStore.buyItem(item.id)
    if (success) {
      playerStore.addMoney(-item.currentPrice)

      // Apply item effects
      switch (item.category) {
        case 'food':
          playerStore.updateStat('energy', playerStore.stats.energy + 5)
          playerStore.updateStat('health', playerStore.stats.health + 2)
          break
        case 'clothes':
          playerStore.updateStat('charisma', playerStore.stats.charisma + 3)
          playerStore.updateStat('happiness', playerStore.stats.happiness + 5)
          break
        case 'electronics':
          playerStore.updateStat('intelligence', playerStore.stats.intelligence + 5)
          playerStore.updateStat('happiness', playerStore.stats.happiness + 3)
          break
        case 'transport':
          playerStore.updateStat('happiness', playerStore.stats.happiness + 10)
          playerStore.updateStat('charisma', playerStore.stats.charisma + 5)
          break
      }

      // Auto-save after purchase
      gameStore.saveGame()
    }
  }
}

function marry() {
  socialStore.marry()
  // Auto-save after marriage
  gameStore.saveGame()
}

function breakUp() {
  socialStore.breakUp()
  // Auto-save after breakup
  gameStore.saveGame()
}

function passTime() {
  // Используем новую функцию прогресса месяца из gameStore
  gameStore.progressMonth()

  // Симулируем экономику и события
  economyStore.simulateEconomicChange()
  eventsStore.simulateMonth()

  // Apply event effects
  const effects = eventsStore.getActiveEffects()
  if (effects.health) {
    playerStore.updateStat('health', playerStore.stats.health + effects.health)
  }
  if (effects.happiness) {
    playerStore.updateStat('happiness', playerStore.stats.happiness + effects.happiness)
  }

  // Показать уведомление о прошедшем месяце
  const income = playerStore.monthlyIncome
  const expenses = playerStore.monthlyExpenses
  const netIncome = income - expenses

  alert(`📅 Прошел месяц!\n\n💰 Доход: +${formatMoney(income)}\n💸 Расходы: -${formatMoney(expenses)}\n📊 Чистая прибыль: ${formatMoney(netIncome)}\n\n🎂 Возраст: ${Math.floor(playerStore.stats.age)} лет`)
}

async function handleReset() {
  if (confirm('Вы уверены, что хотите начать новую игру? Все несохраненные данные будут потеряны.')) {
    await gameStore.resetGame()
    location.reload()
  }
}

function formatSaveTime(date: Date): string {
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffMins = Math.floor(diffMs / 60000)

  if (diffMins < 1) return 'только что'
  if (diffMins < 60) return `${diffMins} мин. назад`

  const diffHours = Math.floor(diffMins / 60)
  if (diffHours < 24) return `${diffHours} ч. назад`

  return date.toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}
</script>

<style scoped>
.dashboard {
  max-width: 1400px;
  margin: 0 auto;
  padding: 2rem;
}

.events-banner {
  margin-bottom: 2rem;
}

.event-alert {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem 1.5rem;
  border-radius: 12px;
  margin-bottom: 1rem;
  border-left: 4px solid;
}

.event-crisis {
  background: rgba(239, 68, 68, 0.1);
  border-left-color: #ef4444;
}

.event-epidemic {
  background: rgba(245, 158, 11, 0.1);
  border-left-color: #f59e0b;
}

.event-boom {
  background: rgba(16, 185, 129, 0.1);
  border-left-color: #10b981;
}

.event-disaster {
  background: rgba(168, 85, 247, 0.1);
  border-left-color: #a855f7;
}

.event-celebration {
  background: rgba(59, 130, 246, 0.1);
  border-left-color: #3b82f6;
}

.event-icon {
  font-size: 2rem;
}

.event-content h4 {
  margin: 0 0 0.25rem 0;
  font-size: 1rem;
  font-weight: 600;
}

.event-content p {
  margin: 0;
  font-size: 0.875rem;
  opacity: 0.8;
}

.stats-header {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
}

.player-info {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.player-avatar {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2rem;
  font-weight: 600;
  color: white;
}

.player-details h2 {
  margin: 0 0 0.25rem 0;
  font-size: 1.75rem;
}

.player-age,
.player-job {
  margin: 0.25rem 0;
  opacity: 0.7;
  font-size: 0.95rem;
}

.quick-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.02);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  transition: all 0.3s;
}

.stat-card:hover {
  background: rgba(255, 255, 255, 0.04);
  transform: translateY(-2px);
}

.stat-icon {
  font-size: 2rem;
}

.stat-info {
  display: flex;
  flex-direction: column;
}

.stat-label {
  font-size: 0.75rem;
  opacity: 0.6;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.stat-value {
  font-size: 1.25rem;
  font-weight: 600;
  margin-top: 0.25rem;
}

.nav-tabs {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 2rem;
  overflow-x: auto;
  padding-bottom: 0.5rem;
}

.tab {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  color: rgba(255, 255, 255, 0.6);
  cursor: pointer;
  transition: all 0.3s;
  white-space: nowrap;
}

.tab:hover {
  background: rgba(255, 255, 255, 0.05);
  color: rgba(255, 255, 255, 0.9);
}

.tab.active {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-color: transparent;
}

.tab-icon {
  font-size: 1.25rem;
}

.tab-label {
  font-size: 0.95rem;
  font-weight: 500;
}

.tab-content {
  min-height: 500px;
}

.content-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 1.5rem;
}

.card {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 16px;
  padding: 2rem;
}

.card h3 {
  margin: 0 0 1.5rem 0;
  font-size: 1.25rem;
}

.stats-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.stat-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}

.stat-bar {
  position: relative;
  flex: 1;
  height: 32px;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  overflow: hidden;
}

.stat-fill {
  height: 100%;
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  transition: width 0.5s;
}

.stat-fill.energy {
  background: linear-gradient(90deg, #10b981 0%, #059669 100%);
}

.stat-number {
  position: absolute;
  right: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  font-size: 0.875rem;
  font-weight: 600;
}

.finance-info {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.finance-row {
  display: flex;
  justify-content: space-between;
  padding: 0.75rem 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.finance-row.total {
  border-bottom: none;
  font-weight: 600;
  font-size: 1.1rem;
}

.positive {
  color: #10b981;
}

.negative {
  color: #ef4444;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}

.section-header h3 {
  margin: 0;
  font-size: 1.5rem;
}

.market-info {
  display: flex;
  gap: 2rem;
  font-size: 0.875rem;
  opacity: 0.7;
}

.jobs-grid,
.realestate-grid,
.marketplace-grid,
.profiles-grid,
.dates-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1.5rem;
}

.job-card,
.property-card,
.market-item-card,
.profile-card,
.date-card {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 16px;
  padding: 1.5rem;
  transition: all 0.3s;
}

.job-card:hover,
.property-card:hover,
.market-item-card:hover,
.profile-card:hover,
.date-card:hover {
  background: rgba(255, 255, 255, 0.05);
  transform: translateY(-4px);
}

.job-header h4,
.property-card h4,
.market-item-card h4,
.profile-card h4,
.date-card h4 {
  margin: 0 0 0.5rem 0;
  font-size: 1.1rem;
}

.company,
.property-type,
.item-category {
  font-size: 0.875rem;
  opacity: 0.6;
}

.job-salary,
.property-price,
.item-price {
  font-size: 1.5rem;
  font-weight: 600;
  margin: 1rem 0;
  color: #10b981;
}

.property-expense {
  font-size: 0.875rem;
  opacity: 0.7;
  margin-bottom: 1rem;
}

.item-stock {
  display: flex;
  justify-content: space-between;
  font-size: 0.875rem;
  margin: 0.5rem 0;
  opacity: 0.8;
}

.stock-count {
  font-weight: 600;
  color: #10b981;
}

.item-effect {
  font-size: 0.875rem;
  padding: 0.5rem;
  background: rgba(102, 126, 234, 0.1);
  border-radius: 6px;
  margin: 1rem 0;
  opacity: 0.9;
}

.buy-item-btn {
  width: 100%;
  padding: 0.75rem;
  border: none;
  border-radius: 8px;
  font-size: 0.95rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
  margin-top: 1rem;
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  color: white;
}

.buy-item-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 8px 16px rgba(16, 185, 129, 0.3);
}

.buy-item-btn:disabled {
  background: rgba(255, 255, 255, 0.1);
  cursor: not-allowed;
  opacity: 0.5;
}

.job-applicants,
.property-demand {
  margin: 1rem 0;
}

.applicants-bar,
.demand-bar,
.compatibility-bar {
  position: relative;
  height: 8px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 4px;
  margin: 0.5rem 0;
  overflow: hidden;
}

.applicants-fill,
.demand-fill,
.compatibility-fill {
  height: 100%;
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  transition: width 0.5s;
}

.job-requirements {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin: 1rem 0;
  font-size: 0.875rem;
  opacity: 0.7;
}

.apply-btn,
.buy-btn,
.date-btn,
.marry-btn,
.breakup-btn {
  width: 100%;
  padding: 0.75rem;
  border: none;
  border-radius: 8px;
  font-size: 0.95rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
  margin-top: 1rem;
}

.apply-btn,
.buy-btn,
.date-btn,
.marry-btn {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.apply-btn:hover:not(:disabled),
.buy-btn:hover:not(:disabled),
.date-btn:hover:not(:disabled),
.marry-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 16px rgba(102, 126, 234, 0.3);
}

.apply-btn:disabled,
.buy-btn:disabled,
.date-btn:disabled {
  background: rgba(255, 255, 255, 0.1);
  cursor: not-allowed;
  opacity: 0.5;
}

.breakup-btn {
  background: rgba(239, 68, 68, 0.2);
  color: #ef4444;
}

.breakup-btn:hover {
  background: rgba(239, 68, 68, 0.3);
}

.profile-avatar,
.date-avatar {
  font-size: 3rem;
  text-align: center;
  margin-bottom: 1rem;
}

.profile-age,
.profile-job,
.date-age,
.date-job {
  text-align: center;
  margin: 0.25rem 0;
  opacity: 0.7;
  font-size: 0.875rem;
}

.profile-stats-mini {
  display: flex;
  justify-content: center;
  gap: 1rem;
  margin: 1rem 0;
  font-size: 0.875rem;
}

.profile-status,
.date-personality {
  display: block;
  text-align: center;
  padding: 0.5rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
  font-size: 0.875rem;
  margin-top: 0.5rem;
}

.compatibility {
  margin: 1rem 0;
}

.compatibility span {
  font-size: 0.875rem;
  opacity: 0.7;
}

.compatibility-bar {
  position: relative;
}

.compatibility-bar span {
  position: absolute;
  right: 0.5rem;
  top: -1.5rem;
  font-size: 0.75rem;
  font-weight: 600;
}

.date-interests {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin: 1rem 0;
}

.interest-tag {
  padding: 0.25rem 0.75rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  font-size: 0.75rem;
}

.relationship-status {
  margin: 1rem 0;
  padding: 0.75rem;
  background: rgba(102, 126, 234, 0.1);
  border-radius: 8px;
}

.relationship-stage {
  font-size: 0.85rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #667eea;
  text-align: center;
}

.relationship-bar {
  height: 6px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 3px;
  overflow: hidden;
  margin-bottom: 0.25rem;
}

.relationship-fill {
  height: 100%;
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  transition: width 0.5s ease;
}

.relationship-level {
  font-size: 0.7rem;
  text-align: center;
  opacity: 0.7;
}

.date-actions {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-top: 1rem;
}

.date-btn.primary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.date-btn.secondary {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
}

.date-btn.special {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  font-weight: 700;
}

.current-partner {
  margin-bottom: 2rem;
}

.partner-card {
  background: rgba(255, 255, 255, 0.05);
  border: 2px solid rgba(102, 126, 234, 0.3);
  border-radius: 16px;
  padding: 2rem;
  text-align: center;
  max-width: 400px;
  margin: 0 auto;
}

.partner-avatar {
  font-size: 4rem;
  margin-bottom: 1rem;
}

.relationship-status {
  font-size: 1.25rem;
  margin: 1rem 0;
  padding: 0.75rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
}

.partner-actions {
  display: flex;
  gap: 1rem;
  margin-top: 1.5rem;
}

.leaderboards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 2rem;
}

.leaderboard-section {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 16px;
  padding: 2rem;
}

.leaderboard-section h3 {
  margin: 0 0 1.5rem 0;
  font-size: 1.25rem;
}

.leaderboard-list {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.leaderboard-entry {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0.75rem 1rem;
  background: rgba(255, 255, 255, 0.02);
  border-radius: 12px;
  transition: all 0.3s;
}

.leaderboard-entry:hover {
  background: rgba(255, 255, 255, 0.05);
}

.leaderboard-entry:nth-child(1) {
  background: linear-gradient(90deg, rgba(255, 215, 0, 0.1), transparent);
  border-left: 3px solid #ffd700;
}

.leaderboard-entry:nth-child(2) {
  background: linear-gradient(90deg, rgba(192, 192, 192, 0.1), transparent);
  border-left: 3px solid #c0c0c0;
}

.leaderboard-entry:nth-child(3) {
  background: linear-gradient(90deg, rgba(205, 127, 50, 0.1), transparent);
  border-left: 3px solid #cd7f32;
}

.rank {
  font-weight: 600;
  min-width: 2rem;
  text-align: center;
}

.profile-avatar-mini {
  font-size: 1.5rem;
}

.profile-name {
  flex: 1;
  font-weight: 500;
}

.score {
  font-weight: 600;
  color: #10b981;
}

.time-control {
  position: fixed;
  bottom: 2rem;
  right: 2rem;
}

.time-btn {
  padding: 1rem 2rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 12px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 8px 24px rgba(102, 126, 234, 0.3);
  transition: all 0.3s;
}

.time-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 12px 32px rgba(102, 126, 234, 0.4);
}

.section-desc {
  text-align: center;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 2rem;
}

.advisor-view {
  max-width: 800px;
  margin: 0 auto;
}

.family-view h3 {
  margin-bottom: 2rem;
  font-size: 1.5rem;
}

.partner-section {
  margin-bottom: 2rem;
}

.partner-section h4 {
  margin-bottom: 1rem;
  font-size: 1.25rem;
}

.partner-card {
  display: flex;
  gap: 2rem;
  padding: 2rem;
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 16px;
}

.partner-avatar {
  font-size: 5rem;
  text-align: center;
}

.partner-info {
  flex: 1;
}

.partner-info h3 {
  margin: 0 0 0.5rem 0;
  font-size: 1.5rem;
}

.partner-info p {
  margin: 0 0 1rem 0;
  opacity: 0.7;
}

.partner-status {
  display: inline-block;
  padding: 0.5rem 1rem;
  background: rgba(102, 126, 234, 0.2);
  border-radius: 8px;
  font-weight: 600;
  margin-bottom: 1rem;
}

.partner-stats {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  margin-bottom: 1.5rem;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.stat-item > span:first-child {
  min-width: 100px;
  font-size: 0.875rem;
  opacity: 0.7;
}

.mini-bar {
  flex: 1;
  height: 8px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 4px;
  overflow: hidden;
}

.mini-fill {
  height: 100%;
  background: linear-gradient(90deg, #10b981 0%, #059669 100%);
  transition: width 0.5s ease;
}

.mini-fill.tension {
  background: linear-gradient(90deg, #ef4444 0%, #dc2626 100%);
}

.stat-item > span:last-child {
  min-width: 40px;
  text-align: right;
  font-weight: 600;
  font-size: 0.875rem;
}

.no-partner {
  text-align: center;
  padding: 4rem 2rem;
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 16px;
}

.no-partner p {
  font-size: 1.25rem;
  margin-bottom: 1.5rem;
  opacity: 0.7;
}

@media (max-width: 768px) {
  .dashboard {
    padding: 1rem;
  }

  .stats-header {
    padding: 1.5rem;
  }

  .quick-stats {
    grid-template-columns: repeat(2, 1fr);
  }

  .nav-tabs {
    flex-wrap: nowrap;
    overflow-x: auto;
  }

  .content-grid,
  .jobs-grid,
  .realestate-grid,
  .profiles-grid,
  .dates-grid,
  .leaderboards-grid {
    grid-template-columns: 1fr;
  }

  .time-control {
    bottom: 1rem;
    right: 1rem;
  }
}
</style>
