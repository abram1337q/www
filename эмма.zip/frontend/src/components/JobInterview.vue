<template>
  <div class="job-interview">
    <div class="interview-header">
      <button class="btn-back" @click="$emit('back')">← Назад</button>
      <div class="job-info">
        <h3>{{ jobTitle }} в {{ company }}</h3>
        <p class="job-requirements">
          Требования: Интеллект {{ requirements.intelligence }}+,
          Харизма {{ requirements.charisma }}+
        </p>
      </div>
    </div>

    <div ref="messagesContainer" class="messages-container">
      <div v-for="msg in messages" :key="msg.id" class="message" :class="msg.role">
        <div class="message-content">{{ msg.content }}</div>
      </div>

      <div v-if="isTyping" class="typing-indicator">
        <span></span><span></span><span></span>
      </div>

      <div v-if="isHired !== null" class="interview-result" :class="{ hired: isHired }">
        {{ isHired ? '🎉 Поздравляем! Вы приняты на работу!' : '😔 К сожалению, вы не прошли собеседование' }}
      </div>
    </div>

    <div class="input-area">
      <textarea
        v-model="messageText"
        class="message-input"
        placeholder="Ваш ответ..."
        :disabled="isHired !== null"
        @keydown.enter.exact.prevent="sendMessage"
      />
      <button
        class="btn-send"
        :disabled="!messageText.trim() || isTyping || isHired !== null"
        @click="sendMessage"
      >
        Ответить
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import { apiService } from '@/services/api'
import { useSessionStore } from '@/stores/session'
import { usePlayerStore } from '@/stores/player'

const props = defineProps<{
  jobTitle: string
  company: string
  salary: number
}>()

const emit = defineEmits<{
  back: []
  hired: [{ jobTitle: string; company: string; salary: number }]
}>()

const sessionStore = useSessionStore()
const playerStore = usePlayerStore()

const messages = ref<Array<{ id: string; role: string; content: string }>>([])
const messageText = ref('')
const isTyping = ref(false)
const isHired = ref<boolean | null>(null)
const messagesContainer = ref<HTMLElement>()

const requirements = ref({
  intelligence: 50,
  charisma: 50,
  experience: 0
})

onMounted(() => {
  addSystemMessage()
})

function addSystemMessage() {
  messages.value.push({
    id: Date.now().toString(),
    role: 'assistant',
    content: `Добрый день! Я HR менеджер компании ${props.company}. Спасибо, что пришли на собеседование на позицию ${props.jobTitle}. Расскажите, пожалуйста, о себе и почему вы хотите работать у нас?`
  })
}

async function sendMessage() {
  if (!messageText.value.trim() || isTyping.value || !sessionStore.sessionId) return

  const userMessage = messageText.value.trim()
  messageText.value = ''

  messages.value.push({
    id: Date.now().toString(),
    role: 'user',
    content: userMessage
  })

  isTyping.value = true
  scrollToBottom()

  try {
    const response = await apiService.jobInterview({
      job_title: props.jobTitle,
      company: props.company,
      requirements: {
        intelligence: playerStore.stats.intelligence,
        charisma: playerStore.stats.charisma,
        experience: 0
      },
      message: userMessage,
      session_id: sessionStore.sessionId
    })

    messages.value.push({
      id: Date.now().toString(),
      role: 'assistant',
      content: response.response
    })

    if (response.is_hired) {
      isHired.value = true
      setTimeout(() => {
        emit('hired', {
          jobTitle: props.jobTitle,
          company: props.company,
          salary: props.salary
        })
      }, 3000)
    }

    scrollToBottom()
  } catch (error) {
    console.error('Error in interview:', error)
    messages.value.push({
      id: Date.now().toString(),
      role: 'system',
      content: 'Ошибка при отправке ответа'
    })
  } finally {
    isTyping.value = false
  }
}

function scrollToBottom() {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}
</script>

<style scoped>
.job-interview {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 180px);
  background: var(--bg-secondary);
  border-radius: var(--radius-lg);
  border: 1px solid var(--border-color);
}

.interview-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1.25rem 1.5rem;
  background: var(--bg-tertiary);
  border-bottom: 1px solid var(--border-color);
}

.btn-back {
  padding: 0.5rem 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-sm);
  cursor: pointer;
  color: var(--text-primary);
}

.job-info h3 {
  font-size: 1.125rem;
  margin-bottom: 0.25rem;
}

.job-requirements {
  color: var(--text-secondary);
  font-size: 0.875rem;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.message {
  max-width: 70%;
  padding: 0.875rem 1.125rem;
  border-radius: var(--radius-md);
}

.message.user {
  align-self: flex-end;
  background: var(--gradient-primary);
  color: white;
}

.message.assistant {
  align-self: flex-start;
  background: var(--bg-tertiary);
  color: var(--text-primary);
}

.typing-indicator {
  display: flex;
  gap: 0.4rem;
  padding: 0.75rem;
}

.typing-indicator span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--accent-purple);
  animation: typing 1.4s infinite;
}

.typing-indicator span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-indicator span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 60%, 100% {
    transform: translateY(0);
    opacity: 0.5;
  }
  30% {
    transform: translateY(-8px);
    opacity: 1;
  }
}

.interview-result {
  padding: 1.5rem;
  border-radius: var(--radius-md);
  text-align: center;
  font-weight: 600;
  font-size: 1.125rem;
  animation: fadeIn 0.5s ease;
}

.interview-result.hired {
  background: linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(16, 185, 129, 0.2));
  border: 1px solid #22c55e;
  color: #22c55e;
}

.interview-result:not(.hired) {
  background: linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(220, 38, 38, 0.2));
  border: 1px solid #ef4444;
  color: #ef4444;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.input-area {
  padding: 1.25rem 1.5rem;
  background: var(--bg-tertiary);
  border-top: 1px solid var(--border-color);
  display: flex;
  gap: 0.75rem;
}

.message-input {
  flex: 1;
  padding: 0.875rem 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  color: var(--text-primary);
  font-family: inherit;
  resize: none;
  max-height: 120px;
}

.message-input:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-send {
  padding: 0.875rem 1.5rem;
  background: var(--gradient-primary);
  border: none;
  border-radius: var(--radius-md);
  color: white;
  cursor: pointer;
  font-weight: 600;
}

.btn-send:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
