<template>
  <div class="ai-advisor">
    <div class="advisor-header">
      <h3>🧠 AI Карьерный советник</h3>
      <p class="advisor-subtitle">Получите персональные советы по карьере и жизни</p>
    </div>

    <div class="advisor-content">
      <div v-if="advice" class="advice-display">
        <div class="advice-icon">💡</div>
        <div class="advice-text">{{ advice }}</div>
      </div>

      <div v-if="isLoading" class="loading-indicator">
        <div class="spinner"></div>
        <p>Советник анализирует вашу ситуацию...</p>
      </div>

      <div class="quick-questions">
        <h4>Быстрые вопросы:</h4>
        <button
          v-for="question in quickQuestions"
          :key="question"
          class="question-btn"
          :disabled="isLoading"
          @click="askQuestion(question)"
        >
          {{ question }}
        </button>
      </div>

      <div class="custom-question">
        <textarea
          v-model="customQuestion"
          class="question-input"
          placeholder="Или задайте свой вопрос..."
          rows="3"
          :disabled="isLoading"
        />
        <button
          class="btn-ask"
          :disabled="!customQuestion.trim() || isLoading"
          @click="askQuestion(customQuestion)"
        >
          Спросить советника
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { apiService } from '@/services/api'
import { usePlayerStore } from '@/stores/player'
import { useEconomyStore } from '@/stores/economy'

const playerStore = usePlayerStore()
const economyStore = useEconomyStore()

const advice = ref('')
const customQuestion = ref('')
const isLoading = ref(false)

const quickQuestions = [
  'Как мне увеличить свой доход?',
  'Стоит ли менять работу?',
  'Какие инвестиции мне подойдут?',
  'Как развить свои навыки?',
  'Как улучшить баланс работы и жизни?'
]

async function askQuestion(question: string) {
  if (!question.trim() || isLoading.value) return

  isLoading.value = true
  advice.value = ''

  try {
    const response = await apiService.getAdvice({
      player_stats: {
        age: playerStore.stats.age,
        money: playerStore.money,
        intelligence: playerStore.stats.intelligence,
        charisma: playerStore.stats.charisma,
        happiness: playerStore.stats.happiness
      },
      economic_situation: {
        health: economyStore.economicHealth,
        inflation: economyStore.inflation
      },
      question
    })

    advice.value = response.advice

    if (question === customQuestion.value) {
      customQuestion.value = ''
    }
  } catch (error) {
    console.error('Error getting advice:', error)
    advice.value = 'Извините, произошла ошибка при получении совета. Проверьте подключение к серверу.'
  } finally {
    isLoading.value = false
  }
}
</script>

<style scoped>
.ai-advisor {
  background: var(--bg-secondary);
  border-radius: var(--radius-lg);
  border: 1px solid var(--border-color);
  overflow: hidden;
}

.advisor-header {
  padding: 1.5rem;
  background: var(--bg-tertiary);
  border-bottom: 1px solid var(--border-color);
  text-align: center;
}

.advisor-header h3 {
  font-size: 1.5rem;
  margin-bottom: 0.5rem;
}

.advisor-subtitle {
  color: var(--text-secondary);
  font-size: 0.9rem;
}

.advisor-content {
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.advice-display {
  display: flex;
  gap: 1rem;
  padding: 1.5rem;
  background: linear-gradient(135deg, rgba(168, 85, 247, 0.1), rgba(139, 92, 246, 0.1));
  border: 1px solid var(--accent-purple);
  border-radius: var(--radius-md);
  animation: fadeIn 0.5s ease;
}

.advice-icon {
  font-size: 2rem;
  flex-shrink: 0;
}

.advice-text {
  flex: 1;
  line-height: 1.6;
  color: var(--text-primary);
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.loading-indicator {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
  padding: 2rem;
}

.spinner {
  width: 48px;
  height: 48px;
  border: 4px solid var(--border-color);
  border-top-color: var(--accent-purple);
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.loading-indicator p {
  color: var(--text-secondary);
  font-size: 0.875rem;
}

.quick-questions {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.quick-questions h4 {
  font-size: 1rem;
  margin-bottom: 0.5rem;
  color: var(--text-secondary);
}

.question-btn {
  padding: 1rem;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  color: var(--text-primary);
  cursor: pointer;
  text-align: left;
  transition: all 0.3s ease;
}

.question-btn:hover:not(:disabled) {
  background: var(--bg-card);
  border-color: var(--accent-purple);
  transform: translateX(4px);
}

.question-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.custom-question {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.question-input {
  padding: 1rem;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  color: var(--text-primary);
  font-family: inherit;
  font-size: 0.95rem;
  resize: vertical;
}

.question-input:focus {
  outline: none;
  border-color: var(--accent-purple);
}

.question-input:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-ask {
  padding: 1rem 1.5rem;
  background: var(--gradient-primary);
  border: none;
  border-radius: var(--radius-md);
  color: white;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s ease;
}

.btn-ask:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(255, 107, 157, 0.4);
}

.btn-ask:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
