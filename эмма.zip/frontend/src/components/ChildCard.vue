<template>
  <div class="child-card">
    <div class="child-header">
      <div class="child-avatar">
        {{ child.gender === 'male' ? '👦' : '👧' }}
      </div>
      <div class="child-basic-info">
        <h4 v-if="child.name">{{ child.name }}</h4>
        <input
          v-else
          type="text"
          placeholder="Введите имя ребенка"
          @keyup.enter="saveName"
          ref="nameInput"
          class="name-input"
        />
        <p class="child-age">{{ child.age }} {{ getAgeText(child.age) }} ({{ getStageText(child.stage) }})</p>
        <p class="child-personality">{{ getPersonalityText(child.personality) }}</p>
      </div>
    </div>

    <!-- Характеристики ребенка -->
    <div class="child-stats">
      <div class="stat-item">
        <span class="stat-icon">❤️</span>
        <span class="stat-name">Здоровье</span>
        <div class="stat-bar">
          <div class="stat-fill health" :style="{ width: child.stats.health + '%' }"></div>
        </div>
        <span class="stat-value">{{ child.stats.health }}</span>
      </div>

      <div class="stat-item">
        <span class="stat-icon">🧠</span>
        <span class="stat-name">Интеллект</span>
        <div class="stat-bar">
          <div class="stat-fill intelligence" :style="{ width: child.stats.intelligence + '%' }"></div>
        </div>
        <span class="stat-value">{{ child.stats.intelligence }}</span>
      </div>

      <div class="stat-item">
        <span class="stat-icon">✨</span>
        <span class="stat-name">Харизма</span>
        <div class="stat-bar">
          <div class="stat-fill charisma" :style="{ width: child.stats.charisma + '%' }"></div>
        </div>
        <span class="stat-value">{{ child.stats.charisma }}</span>
      </div>

      <div class="stat-item">
        <span class="stat-icon">💪</span>
        <span class="stat-name">Сила</span>
        <div class="stat-bar">
          <div class="stat-fill strength" :style="{ width: child.stats.strength + '%' }"></div>
        </div>
        <span class="stat-value">{{ child.stats.strength }}</span>
      </div>

      <div class="stat-item">
        <span class="stat-icon">😊</span>
        <span class="stat-name">Счастье</span>
        <div class="stat-bar">
          <div class="stat-fill happiness" :style="{ width: child.stats.happiness + '%' }"></div>
        </div>
        <span class="stat-value">{{ child.stats.happiness }}</span>
      </div>
    </div>

    <!-- Отношения с родителем -->
    <div class="child-relationship">
      <p class="relationship-label">💞 Отношения с вами:</p>
      <div class="relationship-bar">
        <div class="relationship-fill" :style="{ width: child.relationshipWithPlayer + '%' }"></div>
      </div>
      <span class="relationship-value">{{ child.relationshipWithPlayer }}%</span>
    </div>

    <!-- Таланты -->
    <div v-if="child.talents.length > 0" class="child-talents">
      <p class="talents-label">🌟 Таланты:</p>
      <div class="talents-list">
        <span v-for="talent in child.talents" :key="talent" class="talent-badge">
          {{ talent }}
        </span>
      </div>
    </div>

    <!-- Образование -->
    <div v-if="child.education.currentLevel !== 'none'" class="child-education">
      <h5>📚 Образование</h5>
      <p>Уровень: {{ getEducationText(child.education.currentLevel) }}</p>
      <p v-if="child.education.performance > 0">
        Успеваемость:
        <span :class="getPerformanceClass(child.education.performance)">
          {{ child.education.performance }}%
        </span>
      </p>

      <!-- Секции и кружки -->
      <div v-if="child.stage !== 'infant'" class="activities">
        <p class="activities-label">⚽ Секции и кружки:</p>
        <div v-if="child.education.activities.length === 0" class="no-activities">
          Не записан ни в одну секцию
        </div>
        <div v-else class="activities-list">
          <div v-for="activity in child.education.activities" :key="activity" class="activity-item">
            <span>{{ activity }}</span>
            <button @click="removeActivityClick(activity)" class="btn-remove">✕</button>
          </div>
        </div>

        <!-- Добавить секцию -->
        <div class="add-activity">
          <select v-model="selectedActivity" class="activity-select">
            <option value="">Выбрать секцию...</option>
            <option
              v-for="activity in availableActivities"
              :key="activity.name"
              :value="activity.name"
              :disabled="child.education.activities.includes(activity.name)">
              {{ activity.name }} ({{ activity.cost.toLocaleString() }}₽/мес)
            </option>
          </select>
          <button
            @click="enrollActivityClick"
            :disabled="!selectedActivity"
            class="btn-enroll">
            ➕ Записать
          </button>
        </div>
      </div>

      <!-- Университет -->
      <div v-if="child.age >= 18 && child.education.currentLevel === 'school'" class="university">
        <button @click="enrollUniversity" class="btn-university">
          🎓 Отправить в университет (50,000₽/мес)
        </button>
      </div>
    </div>

    <!-- Финансы -->
    <div class="child-finance">
      <p>💰 Расходы: {{ formatMoney(child.monthlyExpense) }}/мес</p>
      <p class="total-spent">Всего потрачено: {{ formatMoney(child.totalSpent) }}</p>
    </div>

    <!-- Действия с ребенком -->
    <div class="child-actions">
      <button
        @click="interact('play')"
        :disabled="child.stage === 'adult'"
        class="action-btn play">
        🎮 Играть (-10 энергии)
      </button>
      <button
        @click="interact('talk')"
        class="action-btn talk">
        💬 Поговорить
      </button>
      <button
        @click="interact('help')"
        :disabled="child.education.currentLevel === 'none'"
        class="action-btn help">
        📖 Помочь с уроками (-15 энергии)
      </button>
      <button
        @click="interact('punish')"
        class="action-btn punish">
        😠 Наказать
      </button>
    </div>

    <!-- Воспоминания -->
    <div v-if="showMemories" class="child-memories">
      <h5>📝 Важные события</h5>
      <ul class="memories-list">
        <li v-for="(memory, index) in child.memories.slice().reverse()" :key="index">
          {{ memory }}
        </li>
      </ul>
    </div>
    <button @click="showMemories = !showMemories" class="btn-toggle-memories">
      {{ showMemories ? '▲ Скрыть' : '▼ Показать воспоминания' }}
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import type { Child, ChildStage } from '../stores/family'

const props = defineProps<{
  child: Child
}>()

const emit = defineEmits<{
  (e: 'interact', childId: string, type: 'play' | 'talk' | 'help' | 'punish'): void
  (e: 'enroll-activity', childId: string, activity: string, cost: number): void
  (e: 'remove-activity', childId: string, activity: string, cost: number): void
  (e: 'name-child', childId: string, name: string): void
}>()

const nameInput = ref<HTMLInputElement>()
const selectedActivity = ref('')
const showMemories = ref(false)

const availableActivities = [
  { name: '⚽ Футбол', cost: 8000 },
  { name: '🎵 Музыка', cost: 10000 },
  { name: '🎨 Рисование', cost: 7000 },
  { name: '🥋 Карате', cost: 12000 },
  { name: '💃 Танцы', cost: 9000 },
  { name: '♟️ Шахматы', cost: 6000 },
  { name: '💻 Программирование', cost: 15000 },
  { name: '🎭 Театр', cost: 8000 },
  { name: '🏊 Плавание', cost: 10000 },
  { name: '📚 Английский', cost: 12000 }
]

function saveName(event: Event) {
  const input = event.target as HTMLInputElement
  const name = input.value.trim()
  if (name) {
    emit('name-child', props.child.id, name)
  }
}

function interact(type: 'play' | 'talk' | 'help' | 'punish') {
  emit('interact', props.child.id, type)
}

function enrollActivityClick() {
  if (!selectedActivity.value) return

  const activity = availableActivities.find(a => a.name === selectedActivity.value)
  if (activity) {
    emit('enroll-activity', props.child.id, activity.name, activity.cost)
    selectedActivity.value = ''
  }
}

function removeActivityClick(activityName: string) {
  const activity = availableActivities.find(a => a.name === activityName)
  if (activity) {
    emit('remove-activity', props.child.id, activity.name, activity.cost)
  }
}

function enrollUniversity() {
  // TODO: implement university enrollment
  alert('Функция в разработке')
}

function getAgeText(age: number): string {
  if (age === 1) return 'год'
  if (age >= 2 && age <= 4) return 'года'
  return 'лет'
}

function getStageText(stage: ChildStage): string {
  const stages = {
    infant: 'Младенец',
    toddler: 'Дошкольник',
    school: 'Школьник',
    teen: 'Подросток',
    adult: 'Взрослый'
  }
  return stages[stage]
}

function getPersonalityText(personality: string): string {
  const personalities = {
    calm: '😌 Спокойный',
    energetic: '⚡ Энергичный',
    shy: '😳 Стеснительный',
    rebellious: '😎 Бунтарь'
  }
  return personalities[personality as keyof typeof personalities] || personality
}

function getEducationText(level: string): string {
  const levels = {
    none: 'Нет',
    kindergarten: 'Детский сад',
    school: 'Школа',
    university: 'Университет',
    graduated: 'Выпускник'
  }
  return levels[level as keyof typeof levels] || level
}

function getPerformanceClass(performance: number): string {
  if (performance >= 80) return 'excellent'
  if (performance >= 60) return 'good'
  if (performance >= 40) return 'average'
  return 'poor'
}

function formatMoney(amount: number): string {
  return amount.toLocaleString('ru-RU') + '₽'
}
</script>

<style scoped>
.child-card {
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.child-header {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
  align-items: center;
}

.child-avatar {
  font-size: 60px;
  line-height: 1;
}

.child-basic-info h4 {
  margin: 0 0 5px 0;
  font-size: 22px;
}

.name-input {
  padding: 8px 12px;
  font-size: 18px;
  border: 2px solid #2196f3;
  border-radius: 6px;
  width: 250px;
}

.child-age {
  color: #666;
  margin: 0 0 5px 0;
}

.child-personality {
  color: #888;
  font-size: 14px;
  margin: 0;
}

.child-stats {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 15px;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 10px;
}

.stat-icon {
  font-size: 18px;
  width: 24px;
}

.stat-name {
  min-width: 90px;
  font-size: 14px;
}

.stat-bar {
  flex: 1;
  height: 6px;
  background: #e0e0e0;
  border-radius: 3px;
  overflow: hidden;
}

.stat-fill {
  height: 100%;
  transition: width 0.3s;
}

.stat-fill.health { background: #f44336; }
.stat-fill.intelligence { background: #2196f3; }
.stat-fill.charisma { background: #9c27b0; }
.stat-fill.strength { background: #ff9800; }
.stat-fill.happiness { background: #4caf50; }

.stat-value {
  min-width: 30px;
  text-align: right;
  font-size: 14px;
  font-weight: 600;
}

.child-relationship {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 15px;
  padding: 10px;
  background: #f8f9fa;
  border-radius: 8px;
}

.relationship-label {
  margin: 0;
  font-size: 14px;
}

.relationship-bar {
  flex: 1;
  height: 8px;
  background: #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
}

.relationship-fill {
  height: 100%;
  background: linear-gradient(90deg, #f48fb1, #ce93d8);
  transition: width 0.3s;
}

.relationship-value {
  font-weight: 600;
  font-size: 14px;
}

.child-talents {
  margin-bottom: 15px;
}

.talents-label {
  font-size: 14px;
  margin-bottom: 5px;
}

.talents-list {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}

.talent-badge {
  padding: 4px 10px;
  background: #e3f2fd;
  color: #1976d2;
  border-radius: 12px;
  font-size: 12px;
}

.child-education {
  margin-bottom: 15px;
  padding: 15px;
  background: #f8f9fa;
  border-radius: 8px;
}

.child-education h5 {
  margin-top: 0;
}

.child-education p {
  margin: 5px 0;
}

.excellent { color: #4caf50; font-weight: 600; }
.good { color: #8bc34a; font-weight: 600; }
.average { color: #ff9800; font-weight: 600; }
.poor { color: #f44336; font-weight: 600; }

.activities {
  margin-top: 10px;
}

.activities-label {
  font-weight: 600;
  margin-bottom: 5px;
}

.no-activities {
  color: #999;
  font-size: 14px;
  padding: 10px;
  text-align: center;
}

.activities-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 10px;
}

.activity-item {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 6px 10px;
  background: #e8f5e9;
  border-radius: 6px;
  font-size: 14px;
}

.btn-remove {
  background: none;
  border: none;
  color: #f44336;
  cursor: pointer;
  font-size: 16px;
  padding: 0;
  margin-left: 5px;
}

.add-activity {
  display: flex;
  gap: 10px;
  margin-top: 10px;
}

.activity-select {
  flex: 1;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
}

.btn-enroll {
  padding: 8px 16px;
  background: #4caf50;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
}

.btn-enroll:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.university {
  margin-top: 10px;
}

.btn-university {
  width: 100%;
  padding: 12px;
  background: #2196f3;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.child-finance {
  margin-bottom: 15px;
  padding: 10px;
  background: #fff3e0;
  border-radius: 6px;
}

.child-finance p {
  margin: 5px 0;
}

.total-spent {
  font-size: 12px;
  color: #666;
}

.child-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 15px;
}

.action-btn {
  padding: 8px 12px;
  border: none;
  border-radius: 6px;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.2s;
}

.action-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.action-btn.play {
  background: #e3f2fd;
  color: #1976d2;
}

.action-btn.talk {
  background: #f3e5f5;
  color: #7b1fa2;
}

.action-btn.help {
  background: #e8f5e9;
  color: #388e3c;
}

.action-btn.punish {
  background: #ffebee;
  color: #d32f2f;
}

.action-btn:hover:not(:disabled) {
  transform: translateY(-1px);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.child-memories {
  margin-top: 15px;
  padding: 15px;
  background: #fafafa;
  border-radius: 8px;
}

.child-memories h5 {
  margin-top: 0;
}

.memories-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.memories-list li {
  padding: 8px;
  margin: 5px 0;
  background: white;
  border-radius: 4px;
  font-size: 13px;
}

.btn-toggle-memories {
  width: 100%;
  padding: 8px;
  background: #f5f5f5;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 12px;
  color: #666;
}

.btn-toggle-memories:hover {
  background: #e0e0e0;
}
</style>
