<template>
  <div v-if="eventsStore.isEventSceneOpen && eventsStore.currentEvent" class="scene-overlay">
    <div class="scene-container">
      <!-- Заголовок сцены -->
      <div class="scene-header">
        <div class="scene-title">
          <h2>{{ eventsStore.currentEvent.title }}</h2>
          <p class="scene-location">📍 {{ eventsStore.currentEvent.location }}</p>
        </div>
        <div class="scene-progress">
          <div class="progress-bar">
            <div class="progress-fill" :style="{ width: eventsStore.currentEvent.progress + '%' }"></div>
          </div>
          <div class="progress-text">{{ Math.round(eventsStore.currentEvent.progress) }}%</div>
        </div>
      </div>

      <!-- Визуальная сцена -->
      <div class="scene-visual" :class="getSceneClass()">
        <div class="scene-backdrop"></div>
        <div class="scene-content">
          <!-- Специфичный контент для каждого типа события -->
          <div v-if="eventsStore.currentEvent.type === 'bar_performance'" class="bar-scene">
            <div class="stage">
              <div class="stage-lights"></div>
              <div class="performer">
                <div class="performer-avatar">🎤</div>
                <div class="performer-name">{{ eventsStore.currentEvent.partnerName }}</div>
                <div class="musical-notes">♪ ♫ ♪</div>
              </div>
            </div>
            <div class="audience">
              <div class="audience-member">👥</div>
              <div class="audience-member">👥</div>
              <div class="audience-member you">🧍 (Вы)</div>
              <div class="audience-member">👥</div>
            </div>
          </div>

          <div v-else-if="eventsStore.currentEvent.type === 'restaurant_dinner'" class="restaurant-scene">
            <div class="table">
              <div class="table-decoration">🕯️ 🌹 🕯️</div>
              <div class="dinner-participants">
                <div class="participant you">🧍 (Вы)</div>
                <div class="table-center">🍽️</div>
                <div class="participant partner">{{ getPartnerAvatar() }} {{ eventsStore.currentEvent.partnerName }}</div>
              </div>
            </div>
          </div>

          <div v-else-if="eventsStore.currentEvent.type === 'cinema'" class="cinema-scene">
            <div class="screen">🎬 Фильм</div>
            <div class="cinema-seats">
              <div class="seat">💺</div>
              <div class="seat you">🧍</div>
              <div class="seat partner">{{ getPartnerAvatar() }}</div>
              <div class="seat">💺</div>
            </div>
          </div>

          <div v-else-if="eventsStore.currentEvent.type === 'pickup'" class="pickup-scene">
            <div class="house">🏠</div>
            <div class="pickup-participants">
              <div class="participant you">🧍 (Вы)</div>
              <div class="participant partner">{{ getPartnerAvatar() }} {{ eventsStore.currentEvent.partnerName }}</div>
            </div>
            <div class="car">🚗</div>
          </div>

          <div v-else class="generic-scene">
            <div class="scene-icon">{{ getSceneIcon() }}</div>
            <div class="scene-participants">
              <div class="participant you">🧍 (Вы)</div>
              <div class="participant partner">{{ getPartnerAvatar() }} {{ eventsStore.currentEvent.partnerName }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Лог событий / чат -->
      <div class="scene-log" ref="sceneLogContainer">
        <div v-for="msg in eventsStore.currentEvent.messages" :key="msg.id" class="log-message" :class="msg.sender">
          <div class="message-sender" v-if="msg.sender !== 'system'">
            {{ msg.sender === 'user' ? 'Вы' : eventsStore.currentEvent.partnerName }}
          </div>
          <div class="message-content">{{ msg.content }}</div>
        </div>

        <div v-if="isWaitingForAI" class="typing-indicator">
          <span></span><span></span><span></span>
        </div>
      </div>

      <!-- Действия -->
      <div class="scene-actions">
        <div class="actions-title">Что вы хотите сделать?</div>
        <div class="actions-grid">
          <button
            v-for="action in eventsStore.currentEvent.availableActions"
            :key="action.id"
            class="action-btn"
            :class="{ completed: eventsStore.currentEvent.completedActions.includes(action.id) }"
            :disabled="eventsStore.currentEvent.completedActions.includes(action.id) || isWaitingForAI"
            @click="performAction(action)"
          >
            <span class="action-icon">{{ action.icon }}</span>
            <span class="action-label">{{ action.label }}</span>
            <span v-if="eventsStore.currentEvent.completedActions.includes(action.id)" class="action-check">✓</span>
          </button>
        </div>

        <div class="scene-controls">
          <button class="btn-complete" @click="completeEvent" :disabled="eventsStore.currentEvent.progress < 50">
            {{ eventsStore.currentEvent.progress >= 100 ? '✓ Завершить событие' : '→ Уйти' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, nextTick } from 'vue'
import { useInteractiveEventsStore } from '@/stores/interactiveEvents'
import { useSocialStore } from '@/stores/social'
import { useSessionStore } from '@/stores/session'
import { usePlayerStore } from '@/stores/player'
import { apiService } from '@/services/api'
import type { EventAction } from '@/stores/interactiveEvents'

const eventsStore = useInteractiveEventsStore()
const socialStore = useSocialStore()
const sessionStore = useSessionStore()
const playerStore = usePlayerStore()

const sceneLogContainer = ref<HTMLElement>()
const isWaitingForAI = ref(false)

function getSceneClass() {
  return eventsStore.currentEvent?.type.replace('_', '-') || ''
}

function getSceneIcon() {
  const icons: Record<string, string> = {
    park_walk: '🌳',
    concert: '🎵',
    museum: '🖼️',
    beach: '🏖️',
    party: '🎉',
    shopping: '🛍️'
  }
  return icons[eventsStore.currentEvent?.type || ''] || '📍'
}

function getPartnerAvatar() {
  if (!eventsStore.currentEvent?.partnerId) return '👤'
  const partner = socialStore.dateProfiles.find(p => p.id === eventsStore.currentEvent?.partnerId)
  return partner?.avatar || '👤'
}

async function performAction(action: EventAction) {
  if (!eventsStore.currentEvent || isWaitingForAI.value) return

  const success = eventsStore.performEventAction(action.id)
  if (!success) return

  scrollToBottom()

  // Ждем немного перед ответом AI
  await new Promise(resolve => setTimeout(resolve, 500))

  // Получаем реакцию партнера через AI
  if (eventsStore.currentEvent.partnerId) {
    isWaitingForAI.value = true

    try {
      const dateProfile = socialStore.dateProfiles.find(p => p.id === eventsStore.currentEvent?.partnerId)
      const relationshipData = dateProfile ? {
        stage: dateProfile.relationshipStage,
        level: dateProfile.relationshipLevel,
        trust: dateProfile.trust,
        tension: dateProfile.tension,
        married: dateProfile.relationshipStage === 'married',
        children: []
      } : undefined

      const context = `Вы находитесь на событии: "${eventsStore.currentEvent.title}" в локации "${eventsStore.currentEvent.location}". Игрок только что сделал действие: "${action.label}". Отреагируй на это действие естественно и эмоционально.`

      const response = await apiService.datingChat({
        character_id: eventsStore.currentEvent.partnerId,
        message: `[Действие: ${action.label}]`,
        session_id: sessionStore.sessionId || '',
        context,
        relationship_data: relationshipData
      })

      eventsStore.addEventMessage('partner', response.response)
      scrollToBottom()

      // Обновляем отношения
      if (action.relationshipBonus) {
        socialStore.interactWithPartner(eventsStore.currentEvent.partnerId, 'date')
      }
    } catch (error) {
      console.error('Error getting AI response:', error)
    } finally {
      isWaitingForAI.value = false
    }
  }
}

function completeEvent() {
  if (!eventsStore.currentEvent) return

  const impact = eventsStore.completeEvent()

  // Показываем уведомление
  if (impact > 0 && eventsStore.currentEvent.partnerId) {
    // Обновить счастье игрока
    playerStore.updateStats({ happiness: 5 })
  }
}

function scrollToBottom() {
  nextTick(() => {
    if (sceneLogContainer.value) {
      sceneLogContainer.value.scrollTop = sceneLogContainer.value.scrollHeight
    }
  })
}

// Автоскролл при новых сообщениях
watch(() => eventsStore.currentEvent?.messages.length, () => {
  scrollToBottom()
})
</script>

<style scoped>
.scene-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.95);
  z-index: 9998;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.scene-container {
  width: 95%;
  max-width: 1200px;
  height: 90vh;
  background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
  border-radius: 20px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  animation: slideUp 0.4s ease;
}

@keyframes slideUp {
  from {
    transform: translateY(50px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.scene-header {
  padding: 1.5rem 2rem;
  background: rgba(255, 255, 255, 0.05);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.scene-title h2 {
  margin: 0 0 0.5rem 0;
  color: white;
  font-size: 1.5rem;
}

.scene-location {
  margin: 0;
  color: rgba(255, 255, 255, 0.6);
  font-size: 0.9rem;
}

.scene-progress {
  min-width: 200px;
}

.progress-bar {
  height: 8px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 0.5rem;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  transition: width 0.5s ease;
}

.progress-text {
  text-align: right;
  font-size: 0.85rem;
  color: rgba(255, 255, 255, 0.6);
}

.scene-visual {
  height: 300px;
  position: relative;
  overflow: hidden;
  background: linear-gradient(180deg, #2d1b4e 0%, #1a1a2e 100%);
}

.scene-backdrop {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  opacity: 0.3;
}

.scene-content {
  position: relative;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
}

/* Бар сцена */
.bar-scene {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2rem;
}

.stage {
  position: relative;
  background: linear-gradient(135deg, #4a1d96 0%, #6b2fb5 100%);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 10px 30px rgba(106, 47, 181, 0.4);
  animation: stagePulse 3s infinite;
}

@keyframes stagePulse {
  0%, 100% { box-shadow: 0 10px 30px rgba(106, 47, 181, 0.4); }
  50% { box-shadow: 0 15px 40px rgba(106, 47, 181, 0.6); }
}

.stage-lights {
  position: absolute;
  top: -20px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 2rem;
  animation: lightsBlink 2s infinite;
}

@keyframes lightsBlink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.performer {
  text-align: center;
}

.performer-avatar {
  font-size: 4rem;
  margin-bottom: 1rem;
  animation: performerSway 2s infinite;
}

@keyframes performerSway {
  0%, 100% { transform: rotate(-5deg); }
  50% { transform: rotate(5deg); }
}

.performer-name {
  font-size: 1.2rem;
  font-weight: 600;
  color: white;
  margin-bottom: 0.5rem;
}

.musical-notes {
  font-size: 1.5rem;
  color: rgba(255, 255, 255, 0.7);
  animation: notesFloat 3s infinite;
}

@keyframes notesFloat {
  0%, 100% { transform: translateY(0); opacity: 1; }
  50% { transform: translateY(-10px); opacity: 0.5; }
}

.audience {
  display: flex;
  gap: 2rem;
  align-items: flex-end;
}

.audience-member {
  font-size: 2rem;
  opacity: 0.6;
}

.audience-member.you {
  font-size: 2.5rem;
  opacity: 1;
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
}

/* Ресторан */
.restaurant-scene {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
}

.table {
  background: rgba(139, 69, 19, 0.3);
  border-radius: 50%;
  padding: 3rem;
  position: relative;
}

.table-decoration {
  text-align: center;
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

.dinner-participants {
  display: flex;
  align-items: center;
  gap: 3rem;
}

.table-center {
  font-size: 2rem;
}

.participant {
  font-size: 2rem;
  text-align: center;
}

/* Кино */
.cinema-scene {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2rem;
}

.screen {
  background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
  padding: 2rem 4rem;
  border-radius: 10px;
  font-size: 1.5rem;
  color: white;
  box-shadow: 0 10px 40px rgba(59, 130, 246, 0.5);
}

.cinema-seats {
  display: flex;
  gap: 1rem;
}

.seat {
  font-size: 2rem;
}

/* Забрать девушку */
.pickup-scene {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2rem;
}

.house {
  font-size: 4rem;
}

.pickup-participants {
  display: flex;
  gap: 2rem;
}

.car {
  font-size: 3rem;
  animation: carShake 2s infinite;
}

@keyframes carShake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-2px); }
  75% { transform: translateX(2px); }
}

/* Общая сцена */
.generic-scene {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2rem;
}

.scene-icon {
  font-size: 5rem;
}

.scene-participants {
  display: flex;
  gap: 3rem;
}

/* Лог событий */
.scene-log {
  flex: 1;
  overflow-y: auto;
  padding: 1.5rem 2rem;
  background: rgba(0, 0, 0, 0.3);
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.log-message {
  margin-bottom: 1rem;
  padding: 0.75rem 1rem;
  border-radius: 12px;
  max-width: 80%;
}

.log-message.system {
  background: rgba(168, 85, 247, 0.2);
  color: rgba(255, 255, 255, 0.8);
  margin: 0 auto 1rem;
  text-align: center;
  max-width: 90%;
}

.log-message.user {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  margin-left: auto;
}

.log-message.partner {
  background: rgba(255, 255, 255, 0.1);
}

.message-sender {
  font-size: 0.8rem;
  font-weight: 600;
  margin-bottom: 0.25rem;
  opacity: 0.8;
}

.message-content {
  color: white;
  line-height: 1.5;
}

.typing-indicator {
  display: flex;
  gap: 0.4rem;
  padding: 0.75rem;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  width: fit-content;
}

.typing-indicator span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.6);
  animation: typing 1.4s infinite;
}

.typing-indicator span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-indicator span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 60%, 100% {
    transform: translateY(0);
    opacity: 0.5;
  }
  30% {
    transform: translateY(-8px);
    opacity: 1;
  }
}

/* Действия */
.scene-actions {
  padding: 1.5rem 2rem;
  background: rgba(255, 255, 255, 0.03);
}

.actions-title {
  font-size: 0.9rem;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 1rem;
}

.actions-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 0.75rem;
  margin-bottom: 1rem;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.875rem 1rem;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  color: white;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
}

.action-btn:hover:not(:disabled) {
  background: rgba(102, 126, 234, 0.3);
  border-color: rgba(102, 126, 234, 0.5);
  transform: translateY(-2px);
}

.action-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.action-btn.completed {
  background: rgba(16, 185, 129, 0.2);
  border-color: rgba(16, 185, 129, 0.4);
}

.action-icon {
  font-size: 1.5rem;
}

.action-label {
  flex: 1;
  font-size: 0.875rem;
  text-align: left;
}

.action-check {
  color: #10b981;
  font-size: 1.2rem;
}

.scene-controls {
  margin-top: 1rem;
}

.btn-complete {
  width: 100%;
  padding: 1rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  border-radius: 12px;
  color: white;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-complete:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
}

.btn-complete:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
