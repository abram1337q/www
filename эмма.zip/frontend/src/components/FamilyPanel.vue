<template>
  <div class="family-panel">
    <div class="panel-header">
      <h2>👨‍👩‍👧‍👦 Семья</h2>
    </div>

    <!-- Текущий партнер -->
    <div v-if="currentPartner" class="partner-section">
      <h3>💕 Партнер</h3>
      <div class="partner-card">
        <div class="partner-avatar">{{ currentPartner.avatar }}</div>
        <div class="partner-info">
          <h4>{{ currentPartner.name }}</h4>
          <p class="occupation">{{ currentPartner.occupation }}, {{ currentPartner.age }} лет</p>

          <!-- Статус отношений -->
          <div class="relationship-status">
            <div class="status-badge" :class="currentPartner.relationshipStage">
              {{ getStageText(currentPartner.relationshipStage) }}
            </div>
            <div class="relationship-level">
              <div class="level-bar">
                <div class="level-fill" :style="{ width: currentPartner.relationshipLevel + '%' }"></div>
              </div>
              <span class="level-text">{{ currentPartner.relationshipLevel }}%</span>
            </div>
          </div>

          <!-- Доверие и напряжение -->
          <div class="relationship-stats">
            <div class="stat">
              <span class="stat-label">🤝 Доверие:</span>
              <div class="stat-bar">
                <div class="stat-fill trust" :style="{ width: currentPartner.trust + '%' }"></div>
              </div>
              <span class="stat-value">{{ currentPartner.trust }}%</span>
            </div>
            <div class="stat">
              <span class="stat-label">⚡ Напряжение:</span>
              <div class="stat-bar">
                <div class="stat-fill tension" :style="{ width: currentPartner.tension + '%' }"></div>
              </div>
              <span class="stat-value">{{ currentPartner.tension }}%</span>
            </div>
          </div>

          <!-- Финансы партнера -->
          <div class="partner-finance">
            <p>💰 Доход: {{ formatMoney(currentPartner.income) }}/мес</p>
            <p v-if="currentPartner.sharedBudget">🏦 Общий бюджет</p>
          </div>

          <!-- Действия с партнером -->
          <div class="partner-actions">
            <button @click="interact('talk')" class="action-btn talk">💬 Поговорить</button>
            <button @click="interact('date')" class="action-btn date">🍽️ Свидание (5,000₽)</button>
            <button @click="interact('gift')" class="action-btn gift">🎁 Подарок (15,000₽)</button>

            <button
              v-if="currentPartner.relationshipStage === 'dating' || currentPartner.relationshipStage === 'crush'"
              @click="proposeMarriage"
              class="action-btn propose">
              💍 Сделать предложение
            </button>

            <button
              v-if="currentPartner.relationshipStage === 'engaged'"
              @click="marry"
              class="action-btn marry">
              💒 Пожениться (300,000₽)
            </button>

            <button
              v-if="currentPartner.relationshipStage === 'married' && !familyStore.currentPregnancy?.isActive"
              @click="planChild"
              class="action-btn plan-child">
              👶 Планировать ребенка
            </button>
          </div>

          <!-- Конфликты -->
          <div v-if="currentPartner.conflictHistory.filter(c => !c.resolved).length > 0" class="conflicts">
            <h4>⚠️ Активные конфликты</h4>
            <div
              v-for="conflict in currentPartner.conflictHistory.filter(c => !c.resolved)"
              :key="conflict.id"
              class="conflict-item">
              <p>{{ getConflictText(conflict.reason) }}</p>
              <p class="conflict-severity">Серьезность: {{ conflict.severity }}%</p>
              <button @click="resolveConflict(conflict.id)" class="btn-resolve">🤝 Помириться</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Беременность -->
    <div v-if="familyStore.currentPregnancy?.isActive" class="pregnancy-section">
      <h3>🤰 Беременность</h3>
      <div class="pregnancy-card">
        <p class="months-remaining">Осталось месяцев: {{ familyStore.currentPregnancy.monthsRemaining }}</p>
        <div class="pregnancy-progress">
          <div
            class="pregnancy-bar"
            :style="{ width: ((9 - familyStore.currentPregnancy.monthsRemaining) / 9 * 100) + '%' }">
          </div>
        </div>
        <p v-if="familyStore.currentPregnancy.complications" class="warning">⚠️ Есть осложнения</p>
      </div>
    </div>

    <!-- Дети -->
    <div class="children-section">
      <h3>👶 Дети ({{ familyStore.totalChildren }})</h3>

      <div v-if="familyStore.children.length === 0" class="no-children">
        <p>У вас пока нет детей</p>
      </div>

      <div v-else class="children-list">
        <ChildCard
          v-for="child in familyStore.children"
          :key="child.id"
          :child="child"
          @interact="interactWithChild"
          @enroll-activity="enrollActivity"
          @remove-activity="removeActivity"
          @name-child="nameChild"
        />
      </div>
    </div>

    <!-- Воспитание -->
    <div v-if="familyStore.children.length > 0" class="parenting-section">
      <h3>🎓 Стиль воспитания</h3>
      <div class="parenting-styles">
        <button
          @click="setParentingStyle('strict')"
          :class="{ active: familyStore.parentingStyle === 'strict' }"
          class="style-btn">
          👮 Строгое
        </button>
        <button
          @click="setParentingStyle('balanced')"
          :class="{ active: familyStore.parentingStyle === 'balanced' }"
          class="style-btn">
          ⚖️ Сбалансированное
        </button>
        <button
          @click="setParentingStyle('soft')"
          :class="{ active: familyStore.parentingStyle === 'soft' }"
          class="style-btn">
          🤗 Мягкое
        </button>
      </div>
    </div>

    <!-- Ближайшие события -->
    <div v-if="familyStore.upcomingEvents.length > 0" class="events-section">
      <h3>📅 Ближайшие события</h3>
      <div class="events-list">
        <div v-for="event in familyStore.upcomingEvents" :key="event.id" class="event-item">
          <p class="event-title">{{ event.title }}</p>
          <p class="event-date">{{ formatDate(event.date) }}</p>
        </div>
      </div>
    </div>

    <!-- Статистика -->
    <div class="family-stats">
      <h3>📊 Семейная статистика</h3>
      <div class="stats-grid">
        <div class="stat-card">
          <p class="stat-label">Детей:</p>
          <p class="stat-value">{{ familyStore.totalChildren }}</p>
        </div>
        <div class="stat-card">
          <p class="stat-label">Месячные расходы на детей:</p>
          <p class="stat-value">{{ formatMoney(familyStore.totalMonthlyChildExpenses) }}</p>
        </div>
        <div v-if="currentPartner?.marriageDate" class="stat-card">
          <p class="stat-label">В браке:</p>
          <p class="stat-value">{{ getMarriageDuration() }} мес</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useSocialStore } from '../stores/social'
import { useFamilyStore } from '../stores/family'
import { usePlayerStore } from '../stores/player'
import ChildCard from './ChildCard.vue'
import type { RelationshipStage } from '../stores/social'

const socialStore = useSocialStore()
const familyStore = useFamilyStore()
const playerStore = usePlayerStore()

const currentPartner = computed(() => socialStore.currentPartner)

function interact(type: 'talk' | 'date' | 'gift' | 'vacation') {
  if (!currentPartner.value) return

  const costs = { talk: 0, date: 5000, gift: 15000, vacation: 200000 }
  const cost = costs[type]

  if (cost > 0 && playerStore.money < cost) {
    alert('Недостаточно денег!')
    return
  }

  if (cost > 0) {
    playerStore.addMoney(-cost)
  }

  socialStore.interactWithPartner(currentPartner.value.id, type)

  // Снизить энергию
  const energyCost = type === 'vacation' ? 30 : type === 'date' ? 15 : 5
  playerStore.updateStat('energy', playerStore.stats.energy - energyCost)
}

function proposeMarriage() {
  if (!currentPartner.value) return

  const success = socialStore.proposeMarriage(currentPartner.value.id)

  if (success) {
    alert(`${currentPartner.value.name} приняла предложение! 💍`)
  } else {
    alert(`${currentPartner.value.name} не готова... 😔`)
  }
}

function marry() {
  if (!currentPartner.value) return

  const cost = 300000
  if (playerStore.money < cost) {
    alert('Недостаточно денег на свадьбу!')
    return
  }

  playerStore.addMoney(-cost)
  const success = socialStore.marry(currentPartner.value.id, cost)

  if (success) {
    alert(`Поздравляем с браком! 💒`)
  }
}

function planChild() {
  if (!currentPartner.value) return

  const success = familyStore.startPregnancy(currentPartner.value.id)

  if (success) {
    alert('Вы ожидаете ребенка! 🤰')
  }
}

function interactWithChild(childId: string, type: 'play' | 'talk' | 'help' | 'punish') {
  familyStore.interactWithChild(childId, type)
}

function enrollActivity(childId: string, activity: string, cost: number) {
  if (playerStore.money < cost * 3) {
    alert('Недостаточно денег на секцию!')
    return
  }

  familyStore.enrollActivity(childId, activity, cost)
}

function removeActivity(childId: string, activity: string, cost: number) {
  familyStore.removeActivity(childId, activity, cost)
}

function nameChild(childId: string, name: string) {
  familyStore.nameChild(childId, name)
}

function resolveConflict(conflictId: string) {
  if (!currentPartner.value) return
  socialStore.resolveConflict(currentPartner.value.id, conflictId, 'Помирились')
}

function setParentingStyle(style: 'strict' | 'soft' | 'balanced') {
  familyStore.setParentingStyle(style)
}

function getStageText(stage: RelationshipStage): string {
  const stages = {
    stranger: 'Незнакомец',
    acquaintance: 'Знакомый',
    friend: 'Друг',
    close_friend: 'Близкий друг',
    crush: 'Влюблены',
    dating: 'Встречаетесь',
    engaged: 'Помолвка',
    married: 'В браке',
    divorced: 'Разведены'
  }
  return stages[stage] || stage
}

function getConflictText(reason: string): string {
  const reasons = {
    neglect: 'Мало времени вместе',
    money: 'Финансовые проблемы',
    values: 'Разные взгляды',
    infidelity: 'Измена',
    children: 'Воспитание детей',
    other: 'Другое'
  }
  return reasons[reason as keyof typeof reasons] || reason
}

function formatMoney(amount: number): string {
  return amount.toLocaleString('ru-RU') + '₽'
}

function formatDate(date: Date): string {
  return new Date(date).toLocaleDateString('ru-RU')
}

function getMarriageDuration(): number {
  if (!currentPartner.value?.marriageDate) return 0
  const months = (Date.now() - new Date(currentPartner.value.marriageDate).getTime()) / (1000 * 60 * 60 * 24 * 30)
  return Math.floor(months)
}
</script>

<style scoped>
.family-panel {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.panel-header h2 {
  font-size: 28px;
  margin-bottom: 20px;
}

.partner-section,
.pregnancy-section,
.children-section,
.parenting-section,
.events-section,
.family-stats {
  background: #f8f9fa;
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 20px;
}

.partner-card {
  display: flex;
  gap: 20px;
  align-items: flex-start;
}

.partner-avatar {
  font-size: 80px;
  line-height: 1;
}

.partner-info {
  flex: 1;
}

.partner-info h4 {
  font-size: 24px;
  margin: 0 0 5px 0;
}

.occupation {
  color: #666;
  margin: 0 0 15px 0;
}

.relationship-status {
  margin-bottom: 15px;
}

.status-badge {
  display: inline-block;
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 10px;
}

.status-badge.stranger { background: #e0e0e0; color: #666; }
.status-badge.acquaintance { background: #b3e5fc; color: #01579b; }
.status-badge.friend { background: #c8e6c9; color: #2e7d32; }
.status-badge.close_friend { background: #a5d6a7; color: #1b5e20; }
.status-badge.crush { background: #f8bbd0; color: #880e4f; }
.status-badge.dating { background: #f48fb1; color: #c2185b; }
.status-badge.engaged { background: #ce93d8; color: #6a1b9a; }
.status-badge.married { background: #ffb74d; color: #e65100; }

.relationship-level {
  display: flex;
  align-items: center;
  gap: 10px;
}

.level-bar {
  flex: 1;
  height: 10px;
  background: #e0e0e0;
  border-radius: 5px;
  overflow: hidden;
}

.level-fill {
  height: 100%;
  background: linear-gradient(90deg, #f48fb1, #ce93d8);
  transition: width 0.3s;
}

.level-text {
  font-weight: 600;
  min-width: 40px;
}

.relationship-stats {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin: 15px 0;
}

.stat {
  display: flex;
  align-items: center;
  gap: 10px;
}

.stat-label {
  min-width: 100px;
  font-size: 14px;
}

.stat-bar {
  flex: 1;
  height: 8px;
  background: #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
}

.stat-fill {
  height: 100%;
  transition: width 0.3s;
}

.stat-fill.trust {
  background: #4caf50;
}

.stat-fill.tension {
  background: #f44336;
}

.stat-value {
  min-width: 40px;
  font-size: 14px;
  font-weight: 600;
}

.partner-finance {
  margin: 15px 0;
  padding: 10px;
  background: #fff;
  border-radius: 8px;
}

.partner-finance p {
  margin: 5px 0;
}

.partner-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 15px;
}

.action-btn {
  padding: 10px 16px;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}

.action-btn.talk {
  background: #e3f2fd;
  color: #1976d2;
}

.action-btn.date {
  background: #fce4ec;
  color: #c2185b;
}

.action-btn.gift {
  background: #f3e5f5;
  color: #7b1fa2;
}

.action-btn.propose {
  background: #fff3e0;
  color: #e65100;
}

.action-btn.marry {
  background: #ffebee;
  color: #c62828;
}

.action-btn.plan-child {
  background: #e8f5e9;
  color: #2e7d32;
}

.action-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.conflicts {
  margin-top: 20px;
  padding: 15px;
  background: #ffebee;
  border-radius: 8px;
}

.conflicts h4 {
  margin-top: 0;
  color: #c62828;
}

.conflict-item {
  padding: 10px;
  background: #fff;
  border-radius: 6px;
  margin-bottom: 10px;
}

.conflict-severity {
  color: #f44336;
  font-size: 12px;
}

.btn-resolve {
  margin-top: 8px;
  padding: 6px 12px;
  background: #4caf50;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

.pregnancy-card {
  padding: 15px;
  background: #fff;
  border-radius: 8px;
}

.months-remaining {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 10px;
}

.pregnancy-progress {
  height: 12px;
  background: #e0e0e0;
  border-radius: 6px;
  overflow: hidden;
}

.pregnancy-bar {
  height: 100%;
  background: linear-gradient(90deg, #f48fb1, #ce93d8);
  transition: width 0.3s;
}

.warning {
  color: #f44336;
  margin-top: 10px;
}

.no-children {
  text-align: center;
  padding: 40px;
  color: #999;
}

.children-list {
  display: grid;
  gap: 15px;
}

.parenting-styles {
  display: flex;
  gap: 10px;
}

.style-btn {
  flex: 1;
  padding: 12px;
  border: 2px solid #e0e0e0;
  background: #fff;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
}

.style-btn.active {
  border-color: #4caf50;
  background: #e8f5e9;
}

.events-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.event-item {
  padding: 12px;
  background: #fff;
  border-radius: 8px;
  border-left: 4px solid #2196f3;
}

.event-title {
  font-weight: 600;
  margin: 0 0 5px 0;
}

.event-date {
  color: #666;
  font-size: 14px;
  margin: 0;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
}

.stat-card {
  padding: 15px;
  background: #fff;
  border-radius: 8px;
  text-align: center;
}

.stat-card .stat-label {
  color: #666;
  margin-bottom: 5px;
}

.stat-card .stat-value {
  font-size: 24px;
  font-weight: 700;
  color: #333;
}
</style>
