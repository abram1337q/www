<template>
  <div class="chat-message" :class="[message.role]">
    <div v-if="message.role !== 'system'" class="message-avatar">
      {{ avatarEmoji }}
    </div>

    <div class="message-content">
      <div class="message-text" v-html="formattedContent" />
      <div v-if="message.role !== 'system'" class="message-time">
        {{ formattedTime }}
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { ChatMessage } from '@/stores/chat'

const props = defineProps<{
  message: ChatMessage
}>()

const avatarEmoji = computed(() => {
  return props.message.role === 'user' ? '👤' : '💕'
})

const formattedContent = computed(() => {
  let content = props.message.content

  // Replace *text* with <em>text</em> for italic
  content = content.replace(/\*(.*?)\*/g, '<em>$1</em>')

  // Replace **text** with <strong>text</strong> for bold
  content = content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')

  // Preserve line breaks
  content = content.replace(/\n/g, '<br>')

  return content
})

const formattedTime = computed(() => {
  const date = new Date(props.message.timestamp)
  return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })
})
</script>

<style scoped>
.chat-message {
  display: flex;
  gap: 0.75rem;
  animation: messageSlide 0.3s ease;
  align-items: flex-start;
}

@keyframes messageSlide {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.chat-message.user {
  flex-direction: row-reverse;
}

.chat-message.system {
  justify-content: center;
}

.message-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
  flex-shrink: 0;
  background: var(--gradient-primary);
  box-shadow: 0 2px 8px rgba(255, 107, 157, 0.3);
}

.chat-message.user .message-avatar {
  background: var(--gradient-secondary);
  box-shadow: 0 2px 8px rgba(96, 165, 250, 0.3);
}

.message-content {
  max-width: 70%;
  min-width: 100px;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.chat-message.system .message-content {
  max-width: 85%;
  text-align: center;
  background: rgba(96, 165, 250, 0.1);
  border: 1px solid rgba(96, 165, 250, 0.3);
  padding: 1rem 1.5rem;
  border-radius: var(--radius-md);
}

.message-text {
  padding: 0.875rem 1.125rem;
  border-radius: var(--radius-md);
  background: var(--bg-tertiary);
  color: var(--text-primary);
  line-height: 1.6;
  font-size: 0.95rem;
  word-wrap: break-word;
  overflow-wrap: break-word;
}

.chat-message.user .message-text {
  background: linear-gradient(135deg, rgba(255, 107, 157, 0.2), rgba(168, 85, 247, 0.2));
  border: 1px solid rgba(168, 85, 247, 0.3);
}

.chat-message.system .message-text {
  background: transparent;
  border: none;
  padding: 0;
  color: var(--accent-blue);
  font-size: 0.9rem;
}

.message-text :deep(em) {
  font-style: italic;
  color: var(--accent-pink);
}

.message-text :deep(strong) {
  font-weight: 600;
  color: var(--text-primary);
}

.message-time {
  font-size: 0.75rem;
  color: var(--text-muted);
  padding: 0 0.5rem;
  font-variant-numeric: tabular-nums;
}

.chat-message.user .message-time {
  text-align: right;
}

@media (max-width: 768px) {
  .message-content {
    max-width: 80%;
  }

  .message-avatar {
    width: 36px;
    height: 36px;
    font-size: 1.125rem;
  }

  .message-text {
    padding: 0.75rem 1rem;
    font-size: 0.9rem;
  }
}

@media (max-width: 480px) {
  .message-content {
    max-width: 85%;
  }

  .chat-message.system .message-content {
    max-width: 95%;
  }

  .message-avatar {
    width: 32px;
    height: 32px;
    font-size: 1rem;
  }

  .message-text {
    padding: 0.625rem 0.875rem;
    font-size: 0.875rem;
  }
}
</style>
