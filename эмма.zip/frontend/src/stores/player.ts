import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export interface PlayerStats {
  age: number
  health: number
  happiness: number
  energy: number
  intelligence: number
  charisma: number
  strength: number
}

export interface Job {
  id: string
  title: string
  company: string
  salary: number
  experience: number
  level: number
}

export interface Relationship {
  id: string
  name: string
  avatar: string
  type: 'friend' | 'romantic' | 'spouse'
  level: number // 0-100
  lastInteraction: Date
}

export interface Property {
  id: string
  type: 'apartment' | 'house' | 'mansion'
  name: string
  value: number
  monthlyExpense: number
}

export const usePlayerStore = defineStore('player', () => {
  const name = ref('Игрок')
  const money = ref(1000)
  const stats = ref<PlayerStats>({
    age: 18,
    health: 100,
    happiness: 70,
    energy: 100,
    intelligence: 50,
    charisma: 50,
    strength: 50
  })

  const job = ref<Job | null>(null)
  const relationships = ref<Relationship[]>([])
  const properties = ref<Property[]>([])
  const achievements = ref<string[]>([])

  const netWorth = computed(() => {
    const propertyValue = properties.value.reduce((sum, p) => sum + p.value, 0)
    return money.value + propertyValue
  })

  const monthlyIncome = computed(() => job.value?.salary || 0)
  const monthlyExpenses = computed(() => {
    return properties.value.reduce((sum, p) => sum + p.monthlyExpense, 0)
  })

  function updateStat(stat: keyof PlayerStats, value: number) {
    stats.value[stat] = Math.max(0, Math.min(100, value))
  }

  function addMoney(amount: number) {
    money.value += amount
  }

  function spendMoney(amount: number): boolean {
    if (money.value >= amount) {
      money.value -= amount
      return true
    }
    return false
  }

  function setJob(newJob: Job) {
    job.value = newJob
  }

  function addRelationship(relationship: Relationship) {
    relationships.value.push(relationship)
  }

  function updateRelationship(id: string, level: number) {
    const rel = relationships.value.find(r => r.id === id)
    if (rel) {
      rel.level = Math.max(0, Math.min(100, level))
      rel.lastInteraction = new Date()
    }
  }

  function addProperty(property: Property) {
    properties.value.push(property)
  }

  function buyProperty(property: Property): boolean {
    if (money.value >= property.value) {
      money.value -= property.value
      properties.value.push(property)
      return true
    }
    return false
  }

  function passMonth() {
    // Monthly income/expenses
    money.value += monthlyIncome.value
    money.value -= monthlyExpenses.value

    // Age increment (every 12 months)
    stats.value.age += 1/12

    // Decay relationships that haven't been interacted with
    relationships.value.forEach(rel => {
      const daysSince = (Date.now() - rel.lastInteraction.getTime()) / (1000 * 60 * 60 * 24)
      if (daysSince > 30) {
        rel.level = Math.max(0, rel.level - 5)
      }
    })
  }

  return {
    name,
    money,
    stats,
    job,
    relationships,
    properties,
    achievements,
    netWorth,
    monthlyIncome,
    monthlyExpenses,
    updateStat,
    addMoney,
    spendMoney,
    setJob,
    addRelationship,
    updateRelationship,
    addProperty,
    buyProperty,
    passMonth
  }
})
