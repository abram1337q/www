import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export interface JobListing {
  id: string
  title: string
  company: string
  baseSalary: number
  currentSalary: number
  requirements: {
    intelligence: number
    charisma: number
    experience: number
  }
  applicants: number
  maxApplicants: number
  isApplied: boolean
}

export interface RealEstateListing {
  id: string
  type: 'apartment' | 'house' | 'mansion'
  name: string
  basePrice: number
  currentPrice: number
  monthlyExpense: number
  demand: number
}

export interface MarketItem {
  id: string
  name: string
  category: 'food' | 'clothes' | 'electronics' | 'transport'
  basePrice: number
  currentPrice: number
  stock: number
}

export const useEconomyStore = defineStore('economy', () => {
  const economicHealth = ref(100) // 0-100, affects everything
  const inflationRate = ref(2) // percentage per year
  const unemploymentRate = ref(5) // percentage

  const jobListings = ref<JobListing[]>([
    {
      id: 'job1',
      title: 'Стажёр',
      company: 'TechCorp',
      baseSalary: 30000,
      currentSalary: 30000,
      requirements: { intelligence: 30, charisma: 20, experience: 0 },
      applicants: 5,
      maxApplicants: 10,
      isApplied: false
    },
    {
      id: 'job2',
      title: 'Младший разработчик',
      company: 'DevStudio',
      baseSalary: 60000,
      currentSalary: 60000,
      requirements: { intelligence: 50, charisma: 30, experience: 1 },
      applicants: 8,
      maxApplicants: 10,
      isApplied: false
    },
    {
      id: 'job3',
      title: 'Менеджер продаж',
      company: 'SalesHub',
      baseSalary: 50000,
      currentSalary: 50000,
      requirements: { intelligence: 40, charisma: 60, experience: 0 },
      applicants: 3,
      maxApplicants: 8,
      isApplied: false
    },
    {
      id: 'job4',
      title: 'Старший разработчик',
      company: 'TechGiants',
      baseSalary: 120000,
      currentSalary: 120000,
      requirements: { intelligence: 70, charisma: 50, experience: 3 },
      applicants: 12,
      maxApplicants: 15,
      isApplied: false
    }
  ])

  const realEstateListings = ref<RealEstateListing[]>([
    {
      id: 're1',
      type: 'apartment',
      name: 'Уютная студия',
      basePrice: 500000,
      currentPrice: 500000,
      monthlyExpense: 5000,
      demand: 50
    },
    {
      id: 're2',
      type: 'apartment',
      name: 'Двухкомнатная квартира',
      basePrice: 1200000,
      currentPrice: 1200000,
      monthlyExpense: 8000,
      demand: 60
    },
    {
      id: 're3',
      type: 'house',
      name: 'Загородный дом',
      basePrice: 3000000,
      currentPrice: 3000000,
      monthlyExpense: 15000,
      demand: 40
    },
    {
      id: 're4',
      type: 'mansion',
      name: 'Особняк класса люкс',
      basePrice: 10000000,
      currentPrice: 10000000,
      monthlyExpense: 50000,
      demand: 20
    }
  ])

  const marketItems = ref<MarketItem[]>([
    { id: 'food1', name: 'Продукты', category: 'food', basePrice: 5000, currentPrice: 5000, stock: 100 },
    { id: 'clothes1', name: 'Одежда', category: 'clothes', basePrice: 10000, currentPrice: 10000, stock: 50 },
    { id: 'electronics1', name: 'Смартфон', category: 'electronics', basePrice: 30000, currentPrice: 30000, stock: 30 },
    { id: 'transport1', name: 'Автомобиль', category: 'transport', basePrice: 800000, currentPrice: 800000, stock: 10 }
  ])

  function applyForJob(jobId: string) {
    const job = jobListings.value.find(j => j.id === jobId)
    if (job && !job.isApplied && job.applicants < job.maxApplicants) {
      job.isApplied = true
      job.applicants++
      // Decrease salary slightly due to increased competition
      job.currentSalary = Math.floor(job.baseSalary * (1 - (job.applicants / job.maxApplicants) * 0.2))
    }
  }

  function updateMarketPrices() {
    // Update real estate prices based on demand
    realEstateListings.value.forEach(listing => {
      const demandFactor = listing.demand / 50 // normalize to ~1
      const economicFactor = economicHealth.value / 100
      listing.currentPrice = Math.floor(listing.basePrice * demandFactor * economicFactor)
    })

    // Update job salaries based on applicants and economy
    jobListings.value.forEach(job => {
      const competitionFactor = 1 - (job.applicants / job.maxApplicants) * 0.3
      const economicFactor = economicHealth.value / 100
      job.currentSalary = Math.floor(job.baseSalary * competitionFactor * economicFactor)
    })

    // Update market items
    marketItems.value.forEach(item => {
      const stockFactor = Math.max(0.5, Math.min(2, 100 / item.stock))
      const economicFactor = economicHealth.value / 100
      item.currentPrice = Math.floor(item.basePrice * stockFactor * economicFactor)
    })
  }

  function simulateEconomicChange() {
    // Random economic fluctuations
    const change = (Math.random() - 0.5) * 10
    economicHealth.value = Math.max(0, Math.min(100, economicHealth.value + change))

    // Update all prices
    updateMarketPrices()
  }

  function buyItem(itemId: string): boolean {
    const item = marketItems.value.find(i => i.id === itemId)
    if (item && item.stock > 0) {
      item.stock--
      updateMarketPrices()
      return true
    }
    return false
  }

  return {
    economicHealth,
    inflationRate,
    inflation: inflationRate, // Alias for API compatibility
    unemploymentRate,
    jobListings,
    realEstateListings,
    marketItems,
    applyForJob,
    updateMarketPrices,
    simulateEconomicChange,
    buyItem
  }
})
