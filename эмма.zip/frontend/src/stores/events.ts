import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export interface GlobalEvent {
  id: string
  type: 'crisis' | 'epidemic' | 'boom' | 'disaster' | 'celebration'
  title: string
  description: string
  effects: {
    economicHealth?: number
    jobSalaries?: number
    realEstatePrices?: number
    happiness?: number
    health?: number
  }
  duration: number // in months
  startedAt: Date
  isActive: boolean
}

export const useEventsStore = defineStore('events', () => {
  const activeEvents = ref<GlobalEvent[]>([])
  const eventHistory = ref<GlobalEvent[]>([])
  const monthsSinceLastEvent = ref(0)

  const eventTemplates: Omit<GlobalEvent, 'id' | 'startedAt' | 'isActive'>[] = [
    {
      type: 'crisis',
      title: 'Экономический кризис',
      description: 'Мировая экономика переживает тяжёлые времена. Зарплаты падают, недвижимость дешевеет.',
      effects: {
        economicHealth: -30,
        jobSalaries: -25,
        realEstatePrices: -20,
        happiness: -15
      },
      duration: 6
    },
    {
      type: 'epidemic',
      title: 'Эпидемия гриппа',
      description: 'По городу распространяется опасный вирус. Люди болеют, настроение подавленное.',
      effects: {
        health: -20,
        happiness: -10,
        economicHealth: -15
      },
      duration: 3
    },
    {
      type: 'boom',
      title: 'Экономический бум',
      description: 'Экономика процветает! Растут зарплаты, появляются новые возможности.',
      effects: {
        economicHealth: 25,
        jobSalaries: 30,
        realEstatePrices: 15,
        happiness: 20
      },
      duration: 8
    },
    {
      type: 'disaster',
      title: 'Стихийное бедствие',
      description: 'Природная катастрофа нанесла серьёзный ущерб городу и его жителям.',
      effects: {
        economicHealth: -20,
        realEstatePrices: -30,
        happiness: -25,
        health: -15
      },
      duration: 4
    },
    {
      type: 'celebration',
      title: 'Национальный праздник',
      description: 'Город празднует! Все в хорошем настроении, бизнес процветает.',
      effects: {
        happiness: 30,
        economicHealth: 10,
        jobSalaries: 5
      },
      duration: 1
    },
    {
      type: 'crisis',
      title: 'Банковский кризис',
      description: 'Несколько крупных банков обанкротились. Финансовая система под угрозой.',
      effects: {
        economicHealth: -35,
        jobSalaries: -20,
        happiness: -20
      },
      duration: 5
    },
    {
      type: 'boom',
      title: 'Технологический прорыв',
      description: 'Новые технологии открывают огромные возможности для бизнеса и карьеры.',
      effects: {
        economicHealth: 30,
        jobSalaries: 25,
        happiness: 15
      },
      duration: 12
    }
  ]

  const hasActiveEvent = computed(() => activeEvents.value.length > 0)

  function triggerRandomEvent() {
    // Only trigger if no active events and random chance
    if (hasActiveEvent.value) return

    // 5% chance per month to trigger an event
    if (Math.random() > 0.05) {
      monthsSinceLastEvent.value++
      return
    }

    // Increase chance if it's been a while
    const chanceFactor = Math.min(monthsSinceLastEvent.value / 12, 0.5)
    if (Math.random() > chanceFactor) {
      monthsSinceLastEvent.value++
      return
    }

    const template = eventTemplates[Math.floor(Math.random() * eventTemplates.length)]
    const event: GlobalEvent = {
      ...template,
      id: `event${Date.now()}`,
      startedAt: new Date(),
      isActive: true
    }

    activeEvents.value.push(event)
    eventHistory.value.push(event)
    monthsSinceLastEvent.value = 0
  }

  function updateEvents() {
    activeEvents.value = activeEvents.value.filter(event => {
      const monthsActive = Math.floor(
        (Date.now() - event.startedAt.getTime()) / (1000 * 60 * 60 * 24 * 30)
      )

      if (monthsActive >= event.duration) {
        event.isActive = false
        return false
      }
      return true
    })
  }

  function getActiveEffects() {
    const totalEffects = {
      economicHealth: 0,
      jobSalaries: 0,
      realEstatePrices: 0,
      happiness: 0,
      health: 0
    }

    activeEvents.value.forEach(event => {
      if (event.effects.economicHealth) totalEffects.economicHealth += event.effects.economicHealth
      if (event.effects.jobSalaries) totalEffects.jobSalaries += event.effects.jobSalaries
      if (event.effects.realEstatePrices) totalEffects.realEstatePrices += event.effects.realEstatePrices
      if (event.effects.happiness) totalEffects.happiness += event.effects.happiness
      if (event.effects.health) totalEffects.health += event.effects.health
    })

    return totalEffects
  }

  function simulateMonth() {
    updateEvents()
    triggerRandomEvent()
  }

  return {
    activeEvents,
    eventHistory,
    monthsSinceLastEvent,
    hasActiveEvent,
    triggerRandomEvent,
    updateEvents,
    getActiveEffects,
    simulateMonth
  }
})
