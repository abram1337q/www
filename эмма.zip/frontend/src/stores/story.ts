import { defineStore } from 'pinia'
import { ref } from 'vue'
import { apiService, type StoryArc, type Scene } from '@/services/api'
import { useSessionStore } from './session'

export const useStoryStore = defineStore('story', () => {
  const arcs = ref<StoryArc[]>([])
  const currentSceneData = ref<Scene | null>(null)
  const loading = ref(false)

  async function loadArcs() {
    const sessionStore = useSessionStore()
    if (!sessionStore.sessionId) return

    loading.value = true
    try {
      const data = await apiService.getStoryArcs(sessionStore.sessionId)
      arcs.value = data.arcs
    } catch (error) {
      console.error('Failed to load arcs:', error)
    } finally {
      loading.value = false
    }
  }

  async function loadScene(sceneId: string) {
    loading.value = true
    try {
      const data = await apiService.getScene(sceneId)
      currentSceneData.value = data
      return data
    } catch (error) {
      console.error('Failed to load scene:', error)
      return null
    } finally {
      loading.value = false
    }
  }

  async function updateProgress(arcId: string, sceneId: string, completed = false) {
    const sessionStore = useSessionStore()
    if (!sessionStore.sessionId) return

    try {
      await apiService.updateProgress({
        session_id: sessionStore.sessionId,
        arc_id: arcId,
        scene_id: sceneId,
        completed,
      })
      await loadArcs()
    } catch (error) {
      console.error('Failed to update progress:', error)
    }
  }

  return {
    arcs,
    currentSceneData,
    loading,
    loadArcs,
    loadScene,
    updateProgress,
  }
})
