import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { DateProfile } from './social'

export interface PhoneContact {
  id: string
  name: string
  phoneNumber: string
  avatar: string
  relationshipLevel: number
  lastCallTime?: Date
  totalCalls: number
}

export interface CallRecord {
  id: string
  contactId: string
  contactName: string
  type: 'incoming' | 'outgoing'
  status: 'answered' | 'missed' | 'declined'
  startTime: Date
  duration?: number // в секундах
  messages: CallMessage[]
}

export interface CallMessage {
  id: string
  sender: 'user' | 'ai'
  content: string
  timestamp: Date
}

export type CallState = 'idle' | 'ringing_incoming' | 'ringing_outgoing' | 'active' | 'ended'

export const usePhoneStore = defineStore('phone', () => {
  // Состояние телефона
  const isPhoneOpen = ref(false)
  const currentTab = ref<'contacts' | 'history' | 'dial'>('contacts')

  // Звонки
  const callState = ref<CallState>('idle')
  const currentCall = ref<CallRecord | null>(null)
  const callHistory = ref<CallRecord[]>([])

  // Контакты
  const contacts = ref<PhoneContact[]>([])

  // Вычисляемые свойства
  const hasIncomingCall = computed(() => callState.value === 'ringing_incoming')
  const isInCall = computed(() => callState.value === 'active')
  const missedCallsCount = computed(() =>
    callHistory.value.filter(c => c.status === 'missed').length
  )

  // Методы управления телефоном
  function openPhone() {
    isPhoneOpen.value = true
  }

  function closePhone() {
    if (callState.value === 'active' || callState.value === 'ringing_incoming') {
      // Не закрываем телефон во время активного звонка
      return
    }
    isPhoneOpen.value = false
  }

  function setTab(tab: 'contacts' | 'history' | 'dial') {
    currentTab.value = tab
  }

  // Методы управления контактами
  function addContact(contact: Omit<PhoneContact, 'totalCalls' | 'phoneNumber'> & { phoneNumber?: string }) {
    const existingContact = contacts.value.find(c => c.id === contact.id)
    if (existingContact) {
      // Обновляем существующий контакт
      existingContact.name = contact.name
      existingContact.avatar = contact.avatar
      existingContact.relationshipLevel = contact.relationshipLevel
      if (contact.phoneNumber) {
        existingContact.phoneNumber = contact.phoneNumber
      }
      return
    }

    // Генерируем случайный номер если не указан
    const phoneNumber = contact.phoneNumber || generatePhoneNumber()

    contacts.value.push({
      ...contact,
      phoneNumber,
      totalCalls: 0
    })
  }

  function removeContact(contactId: string) {
    const index = contacts.value.findIndex(c => c.id === contactId)
    if (index !== -1) {
      contacts.value.splice(index, 1)
    }
  }

  function getContact(contactId: string): PhoneContact | undefined {
    return contacts.value.find(c => c.id === contactId)
  }

  function generatePhoneNumber(): string {
    const prefix = '+7'
    const code = Math.floor(Math.random() * 900) + 100 // 100-999
    const part1 = Math.floor(Math.random() * 900) + 100
    const part2 = Math.floor(Math.random() * 90) + 10
    const part3 = Math.floor(Math.random() * 90) + 10
    return `${prefix} (${code}) ${part1}-${part2}-${part3}`
  }

  // Методы управления звонками
  function initiateOutgoingCall(contactId: string) {
    const contact = getContact(contactId)
    if (!contact || callState.value !== 'idle') return

    const call: CallRecord = {
      id: `call_${Date.now()}`,
      contactId,
      contactName: contact.name,
      type: 'outgoing',
      status: 'answered',
      startTime: new Date(),
      messages: []
    }

    currentCall.value = call
    callState.value = 'ringing_outgoing'
    openPhone()

    // Симуляция ответа через 2-4 секунды
    const answerDelay = 2000 + Math.random() * 2000
    setTimeout(() => {
      if (callState.value === 'ringing_outgoing') {
        answerCall()
      }
    }, answerDelay)
  }

  function receiveIncomingCall(contactId: string) {
    const contact = getContact(contactId)
    if (!contact || callState.value !== 'idle') return

    const call: CallRecord = {
      id: `call_${Date.now()}`,
      contactId,
      contactName: contact.name,
      type: 'incoming',
      status: 'answered',
      startTime: new Date(),
      messages: []
    }

    currentCall.value = call
    callState.value = 'ringing_incoming'
    // Телефон автоматически показывается при входящем звонке
    openPhone()
  }

  function answerCall() {
    if (!currentCall.value || callState.value === 'idle') return

    callState.value = 'active'
    currentCall.value.status = 'answered'

    // Обновляем контакт
    const contact = getContact(currentCall.value.contactId)
    if (contact) {
      contact.lastCallTime = new Date()
      contact.totalCalls++
    }
  }

  function declineCall() {
    if (!currentCall.value || callState.value === 'idle') return

    currentCall.value.status = 'declined'

    // Добавляем в историю
    callHistory.value.unshift(currentCall.value)

    currentCall.value = null
    callState.value = 'idle'
  }

  function endCall() {
    if (!currentCall.value || callState.value !== 'active') return

    // Вычисляем длительность звонка
    const duration = Math.floor((Date.now() - currentCall.value.startTime.getTime()) / 1000)
    currentCall.value.duration = duration

    // Добавляем в историю
    callHistory.value.unshift(currentCall.value)

    currentCall.value = null
    callState.value = 'idle'
  }

  function addCallMessage(sender: 'user' | 'ai', content: string) {
    if (!currentCall.value || callState.value !== 'active') return

    const message: CallMessage = {
      id: `msg_${Date.now()}`,
      sender,
      content,
      timestamp: new Date()
    }

    currentCall.value.messages.push(message)
  }

  // Очистка истории звонков
  function clearCallHistory() {
    callHistory.value = []
  }

  function deleteCallRecord(callId: string) {
    const index = callHistory.value.findIndex(c => c.id === callId)
    if (index !== -1) {
      callHistory.value.splice(index, 1)
    }
  }

  // Синхронизация с социальным store
  function syncContactFromPartner(partner: DateProfile) {
    addContact({
      id: partner.id,
      name: partner.name,
      avatar: partner.avatar,
      relationshipLevel: partner.relationshipLevel,
      phoneNumber: (partner as any).phoneNumber
    })
  }

  return {
    // State
    isPhoneOpen,
    currentTab,
    callState,
    currentCall,
    callHistory,
    contacts,

    // Computed
    hasIncomingCall,
    isInCall,
    missedCallsCount,

    // Methods - Phone UI
    openPhone,
    closePhone,
    setTab,

    // Methods - Contacts
    addContact,
    removeContact,
    getContact,
    syncContactFromPartner,

    // Methods - Calls
    initiateOutgoingCall,
    receiveIncomingCall,
    answerCall,
    declineCall,
    endCall,
    addCallMessage,
    clearCallHistory,
    deleteCallRecord
  }
})
