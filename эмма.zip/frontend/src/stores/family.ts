import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { usePlayerStore } from './player'

// Типы детей по возрасту
export type ChildStage = 'infant' | 'toddler' | 'school' | 'teen' | 'adult'
export type ParentingStyle = 'strict' | 'soft' | 'balanced'
export type ChildPersonality = 'calm' | 'energetic' | 'shy' | 'rebellious'

// Этапы беременности
export interface Pregnancy {
  motherId: string
  fatherId: string
  monthsRemaining: number
  isActive: boolean
  complications: boolean
  startDate: Date
}

// Характеристики ребенка
export interface ChildStats {
  health: number // 0-100
  intelligence: number // 0-100
  charisma: number // 0-100
  strength: number // 0-100
  happiness: number // 0-100
}

// Образование ребенка
export interface ChildEducation {
  currentLevel: 'none' | 'kindergarten' | 'school' | 'university' | 'graduated'
  performance: number // успеваемость 0-100
  activities: string[] // секции и кружки
  monthlyActivityCost: number
}

// Основной интерфейс ребенка
export interface Child {
  id: string
  name: string
  gender: 'male' | 'female'
  birthDate: Date
  age: number // в годах
  months: number // месяцев с рождения

  stats: ChildStats
  personality: ChildPersonality
  talents: string[] // музыка, спорт, наука, искусство

  education: ChildEducation

  // Отношения с родителем
  relationshipWithPlayer: number // 0-100
  relationshipWithPartner: number // 0-100
  lastInteraction: Date

  // Финансы
  monthlyExpense: number
  totalSpent: number

  // Жизненный этап
  stage: ChildStage

  // История
  memories: string[] // важные события
  achievements: string[]
}

// Семейное событие
export interface FamilyEvent {
  id: string
  type: 'birthday' | 'anniversary' | 'pregnancy' | 'birth' | 'graduation' | 'marriage' | 'death'
  title: string
  description: string
  date: Date
  participants: string[]
  cost?: number
  happinessBonus?: number
}

// Семейная цель
export interface FamilyGoal {
  id: string
  title: string
  description: string
  targetAmount?: number
  currentAmount?: number
  deadline?: Date
  completed: boolean
  reward: {
    money?: number
    happiness?: number
  }
}

export const useFamilyStore = defineStore('family', () => {
  const playerStore = usePlayerStore()

  // Состояние
  const children = ref<Child[]>([])
  const currentPregnancy = ref<Pregnancy | null>(null)
  const familyEvents = ref<FamilyEvent[]>([])
  const familyGoals = ref<FamilyGoal[]>([])
  const parentingStyle = ref<ParentingStyle>('balanced')
  const sharedBudget = ref(false)
  const partnerIncome = ref(0)

  // Материнский капитал
  const maternalCapitalReceived = ref(false)
  const maternalCapitalAmount = 600000

  // Вычисляемые значения
  const totalChildren = computed(() => children.value.length)
  const livingChildren = computed(() => children.value.filter(c => c.stats.health > 0))
  const totalMonthlyChildExpenses = computed(() => {
    return children.value.reduce((sum, child) => sum + child.monthlyExpense, 0)
  })

  const upcomingEvents = computed(() => {
    const now = new Date()
    return familyEvents.value
      .filter(e => e.date > now)
      .sort((a, b) => a.date.getTime() - b.date.getTime())
      .slice(0, 5)
  })

  // Функция: Начать беременность
  function startPregnancy(partnerId: string): boolean {
    if (currentPregnancy.value?.isActive) {
      return false // уже беременны
    }

    currentPregnancy.value = {
      motherId: 'player',
      fatherId: partnerId,
      monthsRemaining: 9,
      isActive: true,
      complications: Math.random() < 0.05, // 5% шанс осложнений
      startDate: new Date()
    }

    // Добавить событие
    addFamilyEvent({
      type: 'pregnancy',
      title: '🤰 Беременность!',
      description: 'Вы ожидаете ребенка! Осталось 9 месяцев.',
      participants: ['player', partnerId],
      happinessBonus: 15
    })

    playerStore.updateStat('happiness', playerStore.stats.happiness + 15)

    return true
  }

  // Функция: Прогресс беременности (вызывается каждый месяц)
  function progressPregnancy() {
    if (!currentPregnancy.value?.isActive) return

    currentPregnancy.value.monthsRemaining--

    if (currentPregnancy.value.monthsRemaining <= 0) {
      giveBirth()
    }
  }

  // Функция: Роды
  function giveBirth() {
    if (!currentPregnancy.value) return

    const pregnancy = currentPregnancy.value
    const birthCost = 50000

    // Проверка денег
    if (playerStore.money < birthCost) {
      playerStore.addMoney(-playerStore.money * 0.5) // берем долг
    } else {
      playerStore.addMoney(-birthCost)
    }

    // Создать ребенка
    const gender: 'male' | 'female' = Math.random() > 0.5 ? 'male' : 'female'
    const baseStats = 50 + Math.random() * 30 // генетика

    const newChild: Child = {
      id: `child_${Date.now()}`,
      name: '', // будет задано игроком
      gender,
      birthDate: new Date(),
      age: 0,
      months: 0,
      stats: {
        health: 80 + Math.random() * 20,
        intelligence: baseStats,
        charisma: baseStats,
        strength: baseStats,
        happiness: 100
      },
      personality: getRandomPersonality(),
      talents: generateRandomTalents(),
      education: {
        currentLevel: 'none',
        performance: 0,
        activities: [],
        monthlyActivityCost: 0
      },
      relationshipWithPlayer: 100,
      relationshipWithPartner: 100,
      lastInteraction: new Date(),
      monthlyExpense: 20000, // младенец
      totalSpent: birthCost,
      stage: 'infant',
      memories: [`Родился ${new Date().toLocaleDateString()}`],
      achievements: []
    }

    children.value.push(newChild)

    // Материнский капитал за 2-го ребенка
    if (children.value.length >= 2 && !maternalCapitalReceived.value) {
      playerStore.addMoney(maternalCapitalAmount)
      maternalCapitalReceived.value = true

      addFamilyEvent({
        type: 'birth',
        title: '💰 Материнский капитал',
        description: `Получен материнский капитал: ${maternalCapitalAmount.toLocaleString()} ₽`,
        participants: ['player']
      })
    }

    // Событие рождения
    addFamilyEvent({
      type: 'birth',
      title: `👶 Рождение ${gender === 'male' ? 'мальчика' : 'девочки'}!`,
      description: 'Поздравляем! В семье пополнение.',
      participants: ['player', pregnancy.fatherId],
      cost: birthCost,
      happinessBonus: 30
    })

    playerStore.updateStat('happiness', playerStore.stats.happiness + 30)
    playerStore.updateStat('energy', playerStore.stats.energy - 20) // роды утомляют

    // Закончить беременность
    currentPregnancy.value.isActive = false
    currentPregnancy.value = null
  }

  // Функция: Назвать ребенка
  function nameChild(childId: string, name: string) {
    const child = children.value.find(c => c.id === childId)
    if (child) {
      child.name = name
      child.memories.push(`Получил имя: ${name}`)
    }
  }

  // Функция: Прогресс развития ребенка (каждый месяц)
  function progressChildren() {
    children.value.forEach(child => {
      child.months++
      child.age = Math.floor(child.months / 12)

      // Обновить стадию
      updateChildStage(child)

      // Обновить расходы в зависимости от возраста
      updateChildExpenses(child)

      // Развитие характеристик
      developChildStats(child)

      // Снижение отношений если нет взаимодействия
      const daysSinceInteraction = (Date.now() - child.lastInteraction.getTime()) / (1000 * 60 * 60 * 24)
      if (daysSinceInteraction > 30) {
        child.relationshipWithPlayer = Math.max(0, child.relationshipWithPlayer - 5)
      }

      // Дни рождения
      if (child.months % 12 === 0 && child.months > 0) {
        celebrateBirthday(child)
      }

      // Накопить общие траты
      child.totalSpent += child.monthlyExpense
      playerStore.addMoney(-child.monthlyExpense)
    })
  }

  // Функция: Обновить стадию ребенка
  function updateChildStage(child: Child) {
    if (child.age < 3) {
      child.stage = 'infant'
    } else if (child.age < 7) {
      child.stage = 'toddler'
      if (child.education.currentLevel === 'none') {
        child.education.currentLevel = 'kindergarten'
        child.memories.push(`${child.age} лет: Пошел в садик`)
      }
    } else if (child.age < 14) {
      child.stage = 'school'
      if (child.education.currentLevel === 'kindergarten') {
        child.education.currentLevel = 'school'
        child.memories.push(`${child.age} лет: Пошел в школу`)
      }
    } else if (child.age < 18) {
      child.stage = 'teen'
    } else {
      child.stage = 'adult'
      if (child.education.currentLevel === 'school') {
        child.memories.push(`${child.age} лет: Закончил школу`)
      }
    }
  }

  // Функция: Обновить расходы на ребенка
  function updateChildExpenses(child: Child) {
    switch (child.stage) {
      case 'infant':
        child.monthlyExpense = 20000 + child.education.monthlyActivityCost
        break
      case 'toddler':
        child.monthlyExpense = 15000 + child.education.monthlyActivityCost
        break
      case 'school':
        child.monthlyExpense = 25000 + child.education.monthlyActivityCost
        break
      case 'teen':
        child.monthlyExpense = 30000 + child.education.monthlyActivityCost
        break
      case 'adult':
        // Если в университете
        if (child.education.currentLevel === 'university') {
          child.monthlyExpense = 50000
        } else {
          child.monthlyExpense = 0 // уже самостоятельный
        }
        break
    }
  }

  // Функция: Развитие характеристик ребенка
  function developChildStats(child: Child) {
    // Базовое развитие
    const baseGrowth = 0.5

    // Бонус от воспитания
    const parentingBonus = parentingStyle.value === 'balanced' ? 1.2 :
                          parentingStyle.value === 'strict' ? 1.0 : 0.8

    // Бонус от секций
    const activityBonus = child.education.activities.length * 0.3

    // Развитие интеллекта
    if (child.education.currentLevel !== 'none') {
      child.stats.intelligence = Math.min(100, child.stats.intelligence + baseGrowth * parentingBonus)
    }

    // Развитие через секции
    child.education.activities.forEach(activity => {
      if (activity.includes('спорт') || activity.includes('танцы')) {
        child.stats.strength = Math.min(100, child.stats.strength + activityBonus)
      }
      if (activity.includes('музыка') || activity.includes('искусство')) {
        child.stats.charisma = Math.min(100, child.stats.charisma + activityBonus)
      }
      if (activity.includes('шахматы') || activity.includes('программирование')) {
        child.stats.intelligence = Math.min(100, child.stats.intelligence + activityBonus)
      }
    })

    // Счастье зависит от отношений
    child.stats.happiness = Math.min(100, 50 + child.relationshipWithPlayer * 0.5)
  }

  // Функция: Отпраздновать день рождения
  function celebrateBirthday(child: Child) {
    const cost = 15000

    if (playerStore.money >= cost) {
      playerStore.addMoney(-cost)
      child.relationshipWithPlayer = Math.min(100, child.relationshipWithPlayer + 10)
      child.stats.happiness = Math.min(100, child.stats.happiness + 15)

      addFamilyEvent({
        type: 'birthday',
        title: `🎂 День рождения ${child.name}`,
        description: `${child.name} исполнилось ${child.age} лет!`,
        participants: ['player', child.id],
        cost,
        happinessBonus: 5
      })
    }
  }

  // Функция: Взаимодействовать с ребенком
  function interactWithChild(childId: string, interactionType: 'play' | 'talk' | 'help' | 'punish') {
    const child = children.value.find(c => c.id === childId)
    if (!child) return

    child.lastInteraction = new Date()

    switch (interactionType) {
      case 'play':
        child.relationshipWithPlayer = Math.min(100, child.relationshipWithPlayer + 5)
        child.stats.happiness = Math.min(100, child.stats.happiness + 10)
        playerStore.updateStat('energy', playerStore.stats.energy - 10)
        break
      case 'talk':
        child.relationshipWithPlayer = Math.min(100, child.relationshipWithPlayer + 3)
        child.stats.charisma = Math.min(100, child.stats.charisma + 1)
        break
      case 'help':
        if (child.education.currentLevel !== 'none') {
          child.stats.intelligence = Math.min(100, child.stats.intelligence + 2)
          child.education.performance = Math.min(100, child.education.performance + 5)
          playerStore.updateStat('energy', playerStore.stats.energy - 15)
        }
        break
      case 'punish':
        child.stats.happiness = Math.max(0, child.stats.happiness - 10)
        child.relationshipWithPlayer = Math.max(0, child.relationshipWithPlayer - 5)
        break
    }
  }

  // Функция: Добавить секцию
  function enrollActivity(childId: string, activity: string, monthlyCost: number): boolean {
    const child = children.value.find(c => c.id === childId)
    if (!child) return false

    if (child.education.activities.includes(activity)) {
      return false
    }

    child.education.activities.push(activity)
    child.education.monthlyActivityCost += monthlyCost

    child.memories.push(`${child.age} лет: Начал заниматься ${activity}`)

    return true
  }

  // Функция: Убрать секцию
  function removeActivity(childId: string, activity: string, monthlyCost: number) {
    const child = children.value.find(c => c.id === childId)
    if (!child) return

    child.education.activities = child.education.activities.filter(a => a !== activity)
    child.education.monthlyActivityCost -= monthlyCost
  }

  // Функция: Отправить в университет
  function enrollUniversity(childId: string): boolean {
    const child = children.value.find(c => c.id === childId)
    if (!child || child.age < 18 || child.education.currentLevel === 'university') {
      return false
    }

    child.education.currentLevel = 'university'
    child.memories.push(`${child.age} лет: Поступил в университет`)

    addFamilyEvent({
      type: 'graduation',
      title: `🎓 ${child.name} в университете!`,
      description: `${child.name} поступил в университет.`,
      participants: ['player', child.id],
      happinessBonus: 10
    })

    return true
  }

  // Функция: Добавить семейное событие
  function addFamilyEvent(eventData: Partial<FamilyEvent>) {
    const event: FamilyEvent = {
      id: `event_${Date.now()}`,
      type: eventData.type || 'birthday',
      title: eventData.title || '',
      description: eventData.description || '',
      date: eventData.date || new Date(),
      participants: eventData.participants || [],
      cost: eventData.cost,
      happinessBonus: eventData.happinessBonus
    }

    familyEvents.value.push(event)

    if (event.happinessBonus) {
      playerStore.updateStat('happiness', playerStore.stats.happiness + event.happinessBonus)
    }
  }

  // Функция: Установить стиль воспитания
  function setParentingStyle(style: ParentingStyle) {
    parentingStyle.value = style
  }

  // Вспомогательные функции
  function getRandomPersonality(): ChildPersonality {
    const personalities: ChildPersonality[] = ['calm', 'energetic', 'shy', 'rebellious']
    return personalities[Math.floor(Math.random() * personalities.length)]
  }

  function generateRandomTalents(): string[] {
    const allTalents = ['музыка', 'спорт', 'наука', 'искусство', 'актерство', 'математика', 'языки']
    const count = Math.floor(Math.random() * 3) + 1
    const talents: string[] = []

    for (let i = 0; i < count; i++) {
      const talent = allTalents[Math.floor(Math.random() * allTalents.length)]
      if (!talents.includes(talent)) {
        talents.push(talent)
      }
    }

    return talents
  }

  return {
    // State
    children,
    currentPregnancy,
    familyEvents,
    familyGoals,
    parentingStyle,
    sharedBudget,
    partnerIncome,
    maternalCapitalReceived,

    // Computed
    totalChildren,
    livingChildren,
    totalMonthlyChildExpenses,
    upcomingEvents,

    // Actions
    startPregnancy,
    progressPregnancy,
    giveBirth,
    nameChild,
    progressChildren,
    interactWithChild,
    enrollActivity,
    removeActivity,
    enrollUniversity,
    addFamilyEvent,
    setParentingStyle
  }
})
