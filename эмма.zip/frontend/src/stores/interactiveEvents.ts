import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export type EventType =
  | 'bar_performance'      // Выступление в баре
  | 'restaurant_dinner'    // Ужин в ресторане
  | 'cinema'              // Кино
  | 'park_walk'           // Прогулка в парке
  | 'concert'             // Концерт
  | 'museum'              // Музей
  | 'beach'               // Пляж
  | 'party'               // Вечеринка
  | 'shopping'            // Шопинг
  | 'pickup'              // Забрать партнера

export interface EventAction {
  id: string
  label: string
  icon: string
  description?: string
  cooldown?: number // секунды до следующего действия
  relationshipBonus?: number
}

export interface InteractiveEvent {
  id: string
  type: EventType
  title: string
  description: string
  location: string
  partnerId?: string
  partnerName?: string

  // Состояние события
  status: 'pending' | 'notified' | 'ongoing' | 'completed' | 'cancelled'

  // Время
  scheduledTime?: Date
  startTime?: Date
  endTime?: Date

  // Действия доступные в событии
  availableActions: EventAction[]
  completedActions: string[]

  // Прогресс события (0-100)
  progress: number

  // Сообщения и диалоги во время события
  messages: EventMessage[]

  // Стоимость и влияние
  cost: number
  relationshipImpact: number
  happinessImpact: number
}

export interface EventMessage {
  id: string
  sender: 'system' | 'partner' | 'user'
  content: string
  timestamp: Date
}

export interface EventInvitation {
  id: string
  eventType: EventType
  partnerId: string
  partnerName: string
  title: string
  description: string
  proposedTime: Date
  location: string
  expiresAt: Date
  accepted: boolean
}

export const useInteractiveEventsStore = defineStore('interactiveEvents', () => {
  const currentEvent = ref<InteractiveEvent | null>(null)
  const eventHistory = ref<InteractiveEvent[]>([])
  const activeInvitations = ref<EventInvitation[]>([])
  const isEventSceneOpen = ref(false)

  // Computed
  const hasActiveEvent = computed(() => currentEvent.value?.status === 'ongoing')
  const hasPendingInvitations = computed(() => activeInvitations.value.length > 0)

  // Создание события
  function createEvent(
    type: EventType,
    partnerId?: string,
    partnerName?: string,
    scheduledTime?: Date
  ): InteractiveEvent {
    const eventConfig = getEventConfig(type)

    const event: InteractiveEvent = {
      id: `event_${Date.now()}`,
      type,
      title: eventConfig.title,
      description: eventConfig.description,
      location: eventConfig.location,
      partnerId,
      partnerName,
      status: 'pending',
      scheduledTime,
      availableActions: eventConfig.actions,
      completedActions: [],
      progress: 0,
      messages: [],
      cost: eventConfig.cost,
      relationshipImpact: 0,
      happinessImpact: 0
    }

    return event
  }

  // Конфигурация для разных типов событий
  function getEventConfig(type: EventType) {
    const configs: Record<EventType, {
      title: string
      description: string
      location: string
      cost: number
      actions: EventAction[]
    }> = {
      bar_performance: {
        title: 'Выступление в баре',
        description: 'Твоя девушка выступает на сцене, исполняя песни',
        location: 'Бар "Лунная соната"',
        cost: 2000,
        actions: [
          { id: 'take_seat', label: 'Занять место у сцены', icon: '🪑', relationshipBonus: 2 },
          { id: 'order_drink', label: 'Заказать напиток', icon: '🍷', relationshipBonus: 1 },
          { id: 'applaud', label: 'Аплодировать', icon: '👏', relationshipBonus: 3 },
          { id: 'send_flower', label: 'Отправить цветы на сцену', icon: '🌹', relationshipBonus: 5 },
          { id: 'cheer', label: 'Подбодрить возгласами', icon: '🎉', relationshipBonus: 2 },
          { id: 'record_video', label: 'Снять на видео', icon: '📹', relationshipBonus: 3 },
          { id: 'wait_backstage', label: 'Подождать за кулисами', icon: '🚪', relationshipBonus: 4 }
        ]
      },
      restaurant_dinner: {
        title: 'Романтический ужин',
        description: 'Ужин в роскошном ресторане',
        location: 'Ресторан "Звездная ночь"',
        cost: 5000,
        actions: [
          { id: 'hold_hand', label: 'Взять за руку', icon: '🤝', relationshipBonus: 3 },
          { id: 'compliment', label: 'Сделать комплимент', icon: '💬', relationshipBonus: 2 },
          { id: 'toast', label: 'Произнести тост', icon: '🥂', relationshipBonus: 4 },
          { id: 'order_wine', label: 'Заказать вино', icon: '🍷', relationshipBonus: 2 },
          { id: 'share_story', label: 'Рассказать историю', icon: '📖', relationshipBonus: 3 },
          { id: 'dance', label: 'Пригласить на танец', icon: '💃', relationshipBonus: 5 }
        ]
      },
      cinema: {
        title: 'Поход в кино',
        description: 'Просмотр фильма в кинотеатре',
        location: 'Кинотеатр "Премьер"',
        cost: 1500,
        actions: [
          { id: 'buy_popcorn', label: 'Купить попкорн', icon: '🍿', relationshipBonus: 1 },
          { id: 'hold_hand', label: 'Взять за руку', icon: '🤝', relationshipBonus: 3 },
          { id: 'whisper', label: 'Шепнуть что-то на ухо', icon: '💭', relationshipBonus: 2 },
          { id: 'discuss_movie', label: 'Обсудить фильм', icon: '💬', relationshipBonus: 2 }
        ]
      },
      park_walk: {
        title: 'Прогулка в парке',
        description: 'Романтическая прогулка',
        location: 'Центральный парк',
        cost: 500,
        actions: [
          { id: 'hold_hand', label: 'Взять за руку', icon: '🤝', relationshipBonus: 2 },
          { id: 'sit_bench', label: 'Сесть на скамейку', icon: '🪑', relationshipBonus: 1 },
          { id: 'buy_icecream', label: 'Купить мороженое', icon: '🍦', relationshipBonus: 2 },
          { id: 'take_photo', label: 'Сделать фото', icon: '📸', relationshipBonus: 3 },
          { id: 'feed_ducks', label: 'Покормить уток', icon: '🦆', relationshipBonus: 1 }
        ]
      },
      concert: {
        title: 'Концерт',
        description: 'Поход на концерт',
        location: 'Концертный зал',
        cost: 3000,
        actions: [
          { id: 'sing_along', label: 'Подпевать', icon: '🎤', relationshipBonus: 2 },
          { id: 'dance', label: 'Танцевать', icon: '💃', relationshipBonus: 3 },
          { id: 'hug', label: 'Обнять', icon: '🤗', relationshipBonus: 4 }
        ]
      },
      museum: {
        title: 'Поход в музей',
        description: 'Культурное времяпрепровождение',
        location: 'Художественный музей',
        cost: 1000,
        actions: [
          { id: 'discuss_art', label: 'Обсудить картину', icon: '🖼️', relationshipBonus: 3 },
          { id: 'take_photo', label: 'Сделать фото', icon: '📸', relationshipBonus: 2 },
          { id: 'hold_hand', label: 'Взять за руку', icon: '🤝', relationshipBonus: 2 }
        ]
      },
      beach: {
        title: 'День на пляже',
        description: 'Отдых у моря',
        location: 'Городской пляж',
        cost: 2000,
        actions: [
          { id: 'swim', label: 'Искупаться', icon: '🏊', relationshipBonus: 2 },
          { id: 'sunbathe', label: 'Загорать', icon: '☀️', relationshipBonus: 1 },
          { id: 'play_volleyball', label: 'Поиграть в волейбол', icon: '🏐', relationshipBonus: 3 },
          { id: 'build_sandcastle', label: 'Построить замок из песка', icon: '🏰', relationshipBonus: 2 }
        ]
      },
      party: {
        title: 'Вечеринка',
        description: 'Веселая вечеринка с друзьями',
        location: 'Клуб "Неон"',
        cost: 3000,
        actions: [
          { id: 'dance', label: 'Танцевать', icon: '💃', relationshipBonus: 3 },
          { id: 'drink', label: 'Выпить коктейль', icon: '🍹', relationshipBonus: 1 },
          { id: 'socialize', label: 'Общаться с друзьями', icon: '👥', relationshipBonus: 2 }
        ]
      },
      shopping: {
        title: 'Шопинг',
        description: 'Поход по магазинам',
        location: 'Торговый центр "Галерея"',
        cost: 5000,
        actions: [
          { id: 'help_choose', label: 'Помочь выбрать одежду', icon: '👗', relationshipBonus: 3 },
          { id: 'buy_gift', label: 'Купить подарок', icon: '🎁', relationshipBonus: 4 },
          { id: 'have_coffee', label: 'Выпить кофе', icon: '☕', relationshipBonus: 2 }
        ]
      },
      pickup: {
        title: 'Забрать девушку',
        description: 'Вы приехали, чтобы забрать свою девушку',
        location: 'У её дома',
        cost: 0,
        actions: [
          { id: 'greet', label: 'Поприветствовать', icon: '👋', relationshipBonus: 1 },
          { id: 'help_with_coat', label: 'Помочь с пальто', icon: '🧥', relationshipBonus: 2 },
          { id: 'compliment', label: 'Сделать комплимент', icon: '💬', relationshipBonus: 2 },
          { id: 'open_door', label: 'Открыть дверь машины', icon: '🚗', relationshipBonus: 1 }
        ]
      }
    }

    return configs[type]
  }

  // Начать событие
  function startEvent(event: InteractiveEvent) {
    currentEvent.value = event
    currentEvent.value.status = 'ongoing'
    currentEvent.value.startTime = new Date()
    isEventSceneOpen.value = true

    // Добавить приветственное сообщение
    addEventMessage('system', event.description)
  }

  // Выполнить действие в событии
  function performEventAction(actionId: string): boolean {
    if (!currentEvent.value || currentEvent.value.status !== 'ongoing') return false

    const action = currentEvent.value.availableActions.find(a => a.id === actionId)
    if (!action) return false

    // Проверяем, не было ли уже выполнено
    if (currentEvent.value.completedActions.includes(actionId)) {
      return false
    }

    // Добавляем в выполненные
    currentEvent.value.completedActions.push(actionId)

    // Увеличиваем прогресс
    const progressIncrease = 100 / currentEvent.value.availableActions.length
    currentEvent.value.progress = Math.min(100, currentEvent.value.progress + progressIncrease)

    // Добавляем влияние на отношения
    if (action.relationshipBonus) {
      currentEvent.value.relationshipImpact += action.relationshipBonus
    }

    // Добавляем сообщение о действии
    addEventMessage('user', `Вы: ${action.label}`)

    return true
  }

  // Добавить сообщение в событие
  function addEventMessage(sender: 'system' | 'partner' | 'user', content: string) {
    if (!currentEvent.value) return

    const message: EventMessage = {
      id: `msg_${Date.now()}`,
      sender,
      content,
      timestamp: new Date()
    }

    currentEvent.value.messages.push(message)
  }

  // Завершить событие
  function completeEvent() {
    if (!currentEvent.value) return

    currentEvent.value.status = 'completed'
    currentEvent.value.endTime = new Date()

    // Сохраняем в историю
    eventHistory.value.unshift(currentEvent.value)

    // Возвращаем влияние на отношения
    const impact = currentEvent.value.relationshipImpact

    // Закрываем сцену
    isEventSceneOpen.value = false

    // Очищаем текущее событие через небольшую задержку
    setTimeout(() => {
      currentEvent.value = null
    }, 500)

    return impact
  }

  // Отменить событие
  function cancelEvent() {
    if (!currentEvent.value) return

    currentEvent.value.status = 'cancelled'
    currentEvent.value.endTime = new Date()

    isEventSceneOpen.value = false
    currentEvent.value = null
  }

  // Создать приглашение от партнера
  function createInvitation(
    eventType: EventType,
    partnerId: string,
    partnerName: string,
    proposedTime: Date
  ): EventInvitation {
    const eventConfig = getEventConfig(eventType)

    const invitation: EventInvitation = {
      id: `invite_${Date.now()}`,
      eventType,
      partnerId,
      partnerName,
      title: eventConfig.title,
      description: eventConfig.description,
      proposedTime,
      location: eventConfig.location,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 часа
      accepted: false
    }

    activeInvitations.value.push(invitation)
    return invitation
  }

  // Принять приглашение
  function acceptInvitation(invitationId: string) {
    const invitation = activeInvitations.value.find(i => i.id === invitationId)
    if (!invitation) return null

    invitation.accepted = true

    // Создаем событие
    const event = createEvent(
      invitation.eventType,
      invitation.partnerId,
      invitation.partnerName,
      invitation.proposedTime
    )

    // Удаляем приглашение
    removeInvitation(invitationId)

    // Если событие должно начаться сейчас, начинаем его
    const now = new Date()
    if (!event.scheduledTime || event.scheduledTime <= now) {
      startEvent(event)
    } else {
      // Иначе помечаем как ожидающее
      event.status = 'notified'
    }

    return event
  }

  // Отклонить приглашение
  function declineInvitation(invitationId: string) {
    removeInvitation(invitationId)
  }

  // Удалить приглашение
  function removeInvitation(invitationId: string) {
    const index = activeInvitations.value.findIndex(i => i.id === invitationId)
    if (index !== -1) {
      activeInvitations.value.splice(index, 1)
    }
  }

  // Очистить просроченные приглашения
  function cleanupExpiredInvitations() {
    const now = new Date()
    activeInvitations.value = activeInvitations.value.filter(
      i => i.expiresAt > now
    )
  }

  return {
    // State
    currentEvent,
    eventHistory,
    activeInvitations,
    isEventSceneOpen,

    // Computed
    hasActiveEvent,
    hasPendingInvitations,

    // Methods
    createEvent,
    startEvent,
    performEventAction,
    addEventMessage,
    completeEvent,
    cancelEvent,
    createInvitation,
    acceptInvitation,
    declineInvitation,
    removeInvitation,
    cleanupExpiredInvitations
  }
})
