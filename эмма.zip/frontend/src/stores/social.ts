import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export interface SocialProfile {
  id: string
  name: string
  avatar: string
  age: number
  occupation: string
  netWorth: number
  happiness: number
  relationshipStatus: 'single' | 'dating' | 'married'
  interests: string[]
  isPlayer: boolean
}

// Расширенная личность для партнеров
export interface PersonalityTraits {
  openness: number // открытость 0-100
  conscientiousness: number // добросовестность 0-100
  extraversion: number // экстраверсия 0-100
  agreeableness: number // доброжелательность 0-100
  neuroticism: number // невротизм 0-100
}

// Желания партнера
export interface PartnerDesires {
  wantsKids: boolean
  wantsMarriage: boolean
  careerOriented: boolean
  financiallyAmbitious: boolean
}

// Конфликт
export interface Conflict {
  id: string
  reason: 'neglect' | 'money' | 'values' | 'infidelity' | 'children' | 'other'
  severity: number // 0-100
  date: Date
  resolved: boolean
  resolution?: string
}

// Стадии отношений
export type RelationshipStage =
  | 'stranger'        // 0-10%
  | 'acquaintance'    // 10-30%
  | 'friend'          // 30-50%
  | 'close_friend'    // 50-70%
  | 'crush'           // 70-85%
  | 'dating'          // 85-92%
  | 'engaged'         // 92-95%
  | 'married'         // 95-100%
  | 'divorced'        // после развода

// Расширенный профиль для свиданий и партнеров
export interface DateProfile extends SocialProfile {
  compatibility: number // 0-100
  attractiveness: number
  personality: 'outgoing' | 'shy' | 'confident' | 'creative' | 'intellectual'
  isAI: boolean

  // НОВОЕ: Расширенные отношения
  relationshipLevel: number // 0-100 (точный уровень отношений)
  relationshipStage: RelationshipStage
  trust: number // доверие 0-100
  tension: number // напряжение 0-100

  personalityTraits: PersonalityTraits
  desires: PartnerDesires

  // Финансы
  income: number
  sharedBudget: boolean

  // История
  firstMetDate: Date
  lastInteractionDate: Date
  totalInteractions: number
  conflictHistory: Conflict[]

  // Брак
  marriageDate?: Date
  anniversaries: Date[]

  // Измены
  infidelitySuspicion: number // подозрение в измене 0-100
  caughtCheating: boolean

  // Телефон
  hasPhoneNumber: boolean
  phoneNumber?: string
}

// Друг (не романтический партнер)
export interface Friend {
  id: string
  name: string
  avatar: string
  age: number
  occupation: string
  friendshipLevel: number // 0-100
  lastInteraction: Date
  interests: string[]
  personality: string
  helpfulness: number // насколько помогает в трудные времена
}

export interface LeaderboardEntry {
  rank: number
  profile: SocialProfile
  score: number
}

// Событие отношений
export interface RelationshipEvent {
  id: string
  partnerId: string
  type: 'date' | 'gift' | 'anniversary' | 'conflict' | 'proposal' | 'marriage' | 'divorce'
  description: string
  date: Date
  impactOnRelationship: number
  cost?: number
}

export const useSocialStore = defineStore('social', () => {
  const profiles = ref<SocialProfile[]>([
    {
      id: 'npc1',
      name: 'Александр Петров',
      avatar: '👨‍💼',
      age: 28,
      occupation: 'Менеджер',
      netWorth: 2500000,
      happiness: 75,
      relationshipStatus: 'single',
      interests: ['спорт', 'путешествия', 'бизнес'],
      isPlayer: false
    },
    {
      id: 'npc2',
      name: 'Мария Иванова',
      avatar: '👩‍💻',
      age: 25,
      occupation: 'Разработчик',
      netWorth: 1800000,
      happiness: 82,
      relationshipStatus: 'dating',
      interests: ['программирование', 'музыка', 'кино'],
      isPlayer: false
    },
    {
      id: 'npc3',
      name: 'Дмитрий Соколов',
      avatar: '👨‍🎨',
      age: 30,
      occupation: 'Дизайнер',
      netWorth: 3200000,
      happiness: 88,
      relationshipStatus: 'married',
      interests: ['искусство', 'фотография', 'архитектура'],
      isPlayer: false
    },
    {
      id: 'npc4',
      name: 'Елена Смирнова',
      avatar: '👩‍⚕️',
      age: 27,
      occupation: 'Врач',
      netWorth: 2100000,
      happiness: 79,
      relationshipStatus: 'single',
      interests: ['медицина', 'фитнес', 'чтение'],
      isPlayer: false
    }
  ])

  const dateProfiles = ref<DateProfile[]>([
    {
      id: 'date1',
      name: 'София',
      avatar: '👩‍🦰',
      age: 24,
      occupation: 'Художница',
      netWorth: 800000,
      happiness: 85,
      relationshipStatus: 'single',
      interests: ['искусство', 'музыка', 'природа'],
      isPlayer: false,
      compatibility: 78,
      attractiveness: 85,
      personality: 'creative',
      isAI: true,
      relationshipLevel: 0,
      relationshipStage: 'stranger',
      trust: 50,
      tension: 0,
      personalityTraits: {
        openness: 90,
        conscientiousness: 60,
        extraversion: 55,
        agreeableness: 80,
        neuroticism: 45
      },
      desires: {
        wantsKids: true,
        wantsMarriage: true,
        careerOriented: false,
        financiallyAmbitious: false
      },
      income: 40000,
      sharedBudget: false,
      firstMetDate: new Date(),
      lastInteractionDate: new Date(),
      totalInteractions: 0,
      conflictHistory: [],
      anniversaries: [],
      infidelitySuspicion: 0,
      caughtCheating: false,
      hasPhoneNumber: false
    },
    {
      id: 'date2',
      name: 'Анна',
      avatar: '👩‍🔬',
      age: 26,
      occupation: 'Учёная',
      netWorth: 1500000,
      happiness: 72,
      relationshipStatus: 'single',
      interests: ['наука', 'книги', 'шахматы'],
      isPlayer: false,
      compatibility: 82,
      attractiveness: 80,
      personality: 'intellectual',
      isAI: true,
      relationshipLevel: 0,
      relationshipStage: 'stranger',
      trust: 50,
      tension: 0,
      personalityTraits: {
        openness: 85,
        conscientiousness: 90,
        extraversion: 40,
        agreeableness: 70,
        neuroticism: 30
      },
      desires: {
        wantsKids: false,
        wantsMarriage: false,
        careerOriented: true,
        financiallyAmbitious: true
      },
      income: 80000,
      sharedBudget: false,
      firstMetDate: new Date(),
      lastInteractionDate: new Date(),
      totalInteractions: 0,
      conflictHistory: [],
      anniversaries: [],
      infidelitySuspicion: 0,
      caughtCheating: false,
      hasPhoneNumber: false
    },
    {
      id: 'date3',
      name: 'Виктория',
      avatar: '👩‍💼',
      age: 29,
      occupation: 'Предприниматель',
      netWorth: 5000000,
      happiness: 90,
      relationshipStatus: 'single',
      interests: ['бизнес', 'путешествия', 'спорт'],
      isPlayer: false,
      compatibility: 70,
      attractiveness: 88,
      personality: 'confident',
      isAI: true,
      relationshipLevel: 0,
      relationshipStage: 'stranger',
      trust: 50,
      tension: 0,
      personalityTraits: {
        openness: 75,
        conscientiousness: 85,
        extraversion: 90,
        agreeableness: 60,
        neuroticism: 25
      },
      desires: {
        wantsKids: true,
        wantsMarriage: true,
        careerOriented: true,
        financiallyAmbitious: true
      },
      income: 150000,
      sharedBudget: false,
      firstMetDate: new Date(),
      lastInteractionDate: new Date(),
      totalInteractions: 0,
      conflictHistory: [],
      anniversaries: [],
      infidelitySuspicion: 0,
      caughtCheating: false,
      hasPhoneNumber: false
    },
    {
      id: 'date4',
      name: 'Ксения',
      avatar: '👩‍🎤',
      age: 23,
      occupation: 'Музыкант',
      netWorth: 600000,
      happiness: 95,
      relationshipStatus: 'single',
      interests: ['музыка', 'вечеринки', 'танцы'],
      isPlayer: false,
      compatibility: 65,
      attractiveness: 90,
      personality: 'outgoing',
      isAI: true,
      relationshipLevel: 0,
      relationshipStage: 'stranger',
      trust: 50,
      tension: 0,
      personalityTraits: {
        openness: 95,
        conscientiousness: 50,
        extraversion: 95,
        agreeableness: 85,
        neuroticism: 60
      },
      desires: {
        wantsKids: false,
        wantsMarriage: false,
        careerOriented: true,
        financiallyAmbitious: false
      },
      income: 35000,
      sharedBudget: false,
      firstMetDate: new Date(),
      lastInteractionDate: new Date(),
      totalInteractions: 0,
      conflictHistory: [],
      anniversaries: [],
      infidelitySuspicion: 0,
      caughtCheating: false
    }
  ])

  const friends = ref<Friend[]>([])
  const currentPartner = ref<DateProfile | null>(null)
  const datingHistory = ref<string[]>([])
  const relationshipEvents = ref<RelationshipEvent[]>([])

  const wealthLeaderboard = computed(() => {
    return profiles.value
      .map((profile, index) => ({
        rank: index + 1,
        profile,
        score: profile.netWorth
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
  })

  const happinessLeaderboard = computed(() => {
    return profiles.value
      .map((profile, index) => ({
        rank: index + 1,
        profile,
        score: profile.happiness
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
  })

  // Функция: Определить стадию отношений по уровню
  function getRelationshipStage(level: number): RelationshipStage {
    if (level < 10) return 'stranger'
    if (level < 30) return 'acquaintance'
    if (level < 50) return 'friend'
    if (level < 70) return 'close_friend'
    if (level < 85) return 'crush'
    if (level < 92) return 'dating'
    if (level < 95) return 'engaged'
    return 'married'
  }

  // Функция: Взаимодействовать с партнером (повышает уровень)
  function interactWithPartner(partnerId: string, interactionType: 'talk' | 'date' | 'gift' | 'vacation') {
    const partner = dateProfiles.value.find(p => p.id === partnerId)
    if (!partner) return

    partner.lastInteractionDate = new Date()
    partner.totalInteractions++

    let relationshipBonus = 0
    let trustBonus = 0
    let tensionReduction = 0
    let cost = 0

    switch (interactionType) {
      case 'talk':
        relationshipBonus = 2 + (partner.compatibility / 50)
        trustBonus = 1
        tensionReduction = 5
        break
      case 'date':
        relationshipBonus = 5 + (partner.compatibility / 30)
        trustBonus = 2
        tensionReduction = 10
        cost = 5000
        break
      case 'gift':
        relationshipBonus = 8
        trustBonus = 3
        tensionReduction = 15
        cost = 15000
        break
      case 'vacation':
        relationshipBonus = 15
        trustBonus = 10
        tensionReduction = 30
        cost = 200000
        break
    }

    // Обновить уровень
    partner.relationshipLevel = Math.min(100, partner.relationshipLevel + relationshipBonus)
    partner.trust = Math.min(100, partner.trust + trustBonus)
    partner.tension = Math.max(0, partner.tension - tensionReduction)

    // Обновить стадию
    const oldStage = partner.relationshipStage
    partner.relationshipStage = getRelationshipStage(partner.relationshipLevel)

    // Добавить событие
    addRelationshipEvent({
      partnerId,
      type: interactionType === 'date' ? 'date' : 'gift',
      description: `${getInteractionDescription(interactionType)} с ${partner.name}`,
      impactOnRelationship: relationshipBonus,
      cost
    })

    // Если стадия изменилась
    if (oldStage !== partner.relationshipStage && partner.relationshipStage === 'dating') {
      currentPartner.value = partner
    }
  }

  function getInteractionDescription(type: string): string {
    switch (type) {
      case 'talk': return 'Разговор'
      case 'date': return 'Свидание'
      case 'gift': return 'Подарок'
      case 'vacation': return 'Совместный отпуск'
      default: return 'Взаимодействие'
    }
  }

  // Функция: Сделать предложение
  function proposeMarriage(partnerId: string): boolean {
    const partner = dateProfiles.value.find(p => p.id === partnerId)
    if (!partner) return false

    if (partner.relationshipLevel < 85 || partner.relationshipStage === 'married') {
      return false
    }

    // Шанс принятия зависит от уровня отношений и доверия
    const acceptanceChance = (partner.relationshipLevel + partner.trust) / 2
    const accepted = Math.random() * 100 < acceptanceChance

    if (accepted) {
      partner.relationshipLevel = 92
      partner.relationshipStage = 'engaged'

      addRelationshipEvent({
        partnerId,
        type: 'proposal',
        description: `💍 ${partner.name} приняла предложение!`,
        impactOnRelationship: 10
      })

      return true
    } else {
      partner.tension += 20
      partner.relationshipLevel -= 10
      return false
    }
  }

  // Функция: Пожениться
  function marry(partnerId: string, weddingCost: number = 300000): boolean {
    const partner = dateProfiles.value.find(p => p.id === partnerId)
    if (!partner || partner.relationshipStage !== 'engaged') {
      return false
    }

    partner.relationshipStage = 'married'
    partner.relationshipLevel = 100
    partner.marriageDate = new Date()
    partner.relationshipStatus = 'married'
    currentPartner.value = partner

    addRelationshipEvent({
      partnerId,
      type: 'marriage',
      description: `💒 Свадьба с ${partner.name}!`,
      impactOnRelationship: 20,
      cost: weddingCost
    })

    return true
  }

  // Функция: Создать конфликт
  function createConflict(partnerId: string, reason: Conflict['reason'], severity: number) {
    const partner = dateProfiles.value.find(p => p.id === partnerId)
    if (!partner) return

    const conflict: Conflict = {
      id: `conflict_${Date.now()}`,
      reason,
      severity,
      date: new Date(),
      resolved: false
    }

    partner.conflictHistory.push(conflict)
    partner.tension += severity
    partner.relationshipLevel = Math.max(0, partner.relationshipLevel - severity / 5)
    partner.trust = Math.max(0, partner.trust - severity / 3)

    addRelationshipEvent({
      partnerId,
      type: 'conflict',
      description: `😢 Конфликт: ${getConflictReasonText(reason)}`,
      impactOnRelationship: -severity / 5
    })
  }

  function getConflictReasonText(reason: Conflict['reason']): string {
    switch (reason) {
      case 'neglect': return 'Мало времени вместе'
      case 'money': return 'Финансовые проблемы'
      case 'values': return 'Разные взгляды на жизнь'
      case 'infidelity': return 'Измена'
      case 'children': return 'Вопросы воспитания детей'
      default: return 'Другое'
    }
  }

  // Функция: Разрешить конфликт
  function resolveConflict(partnerId: string, conflictId: string, resolution: string) {
    const partner = dateProfiles.value.find(p => p.id === partnerId)
    if (!partner) return

    const conflict = partner.conflictHistory.find(c => c.id === conflictId)
    if (!conflict || conflict.resolved) return

    conflict.resolved = true
    conflict.resolution = resolution

    partner.tension = Math.max(0, partner.tension - conflict.severity)
    partner.relationshipLevel = Math.min(100, partner.relationshipLevel + conflict.severity / 10)
    partner.trust = Math.min(100, partner.trust + 5)
  }

  // Функция: Развестись
  function divorce(partnerId: string, playerMoney: number): { alimony: number; propertyLoss: number } {
    const partner = dateProfiles.value.find(p => p.id === partnerId)
    if (!partner || partner.relationshipStage !== 'married') {
      return { alimony: 0, propertyLoss: 0 }
    }

    partner.relationshipStage = 'divorced'
    partner.relationshipStatus = 'single'
    partner.relationshipLevel = 20
    currentPartner.value = null

    // Раздел имущества (50/50)
    const propertyLoss = playerMoney * 0.5

    // Алименты (20% дохода)
    const alimony = 0 // будет вычисляться каждый месяц

    addRelationshipEvent({
      partnerId,
      type: 'divorce',
      description: `💔 Развод с ${partner.name}`,
      impactOnRelationship: -50
    })

    return { alimony, propertyLoss }
  }

  // Функция: Добавить друга
  function addFriend(friend: Friend) {
    friends.value.push(friend)
  }

  // Функция: Взаимодействовать с другом
  function interactWithFriend(friendId: string) {
    const friend = friends.value.find(f => f.id === friendId)
    if (!friend) return

    friend.lastInteraction = new Date()
    friend.friendshipLevel = Math.min(100, friend.friendshipLevel + 5)
  }

  // Функция: Автоматические проверки отношений (вызывается каждый месяц)
  function monthlyRelationshipCheck() {
    if (!currentPartner.value) return

    const partner = currentPartner.value
    const daysSinceInteraction = (Date.now() - partner.lastInteractionDate.getTime()) / (1000 * 60 * 60 * 24)

    // Если давно не взаимодействовали
    if (daysSinceInteraction > 30) {
      partner.tension += 10
      partner.relationshipLevel = Math.max(0, partner.relationshipLevel - 5)
      createConflict(partner.id, 'neglect', 20)
    }

    // Автоматический конфликт при высоком напряжении
    if (partner.tension >= 80 && Math.random() < 0.5) {
      createConflict(partner.id, 'other', 30)
    }

    // Проверка годовщины
    if (partner.marriageDate) {
      const yearsSinceMarriage = (Date.now() - partner.marriageDate.getTime()) / (1000 * 60 * 60 * 24 * 365)
      if (Math.floor(yearsSinceMarriage) > partner.anniversaries.length) {
        partner.anniversaries.push(new Date())
        partner.relationshipLevel = Math.min(100, partner.relationshipLevel + 5)

        addRelationshipEvent({
          partnerId: partner.id,
          type: 'anniversary',
          description: `🎉 ${partner.anniversaries.length}-я годовщина брака!`,
          impactOnRelationship: 5,
          cost: 20000
        })
      }
    }
  }

  // Функция: Добавить событие отношений
  function addRelationshipEvent(eventData: Partial<RelationshipEvent>) {
    const event: RelationshipEvent = {
      id: `rel_event_${Date.now()}`,
      partnerId: eventData.partnerId || '',
      type: eventData.type || 'date',
      description: eventData.description || '',
      date: eventData.date || new Date(),
      impactOnRelationship: eventData.impactOnRelationship || 0,
      cost: eventData.cost
    }

    relationshipEvents.value.push(event)
  }

  function addProfile(profile: SocialProfile) {
    profiles.value.push(profile)
  }

  function meetPerson(profileId: string) {
    const profile = profiles.value.find(p => p.id === profileId)
    return profile
  }

  function startDating(dateId: string) {
    const date = dateProfiles.value.find(d => d.id === dateId)
    if (date && date.relationshipStatus === 'single' && date.relationshipLevel >= 85) {
      currentPartner.value = date
      date.relationshipStatus = 'dating'
      date.relationshipStage = 'dating'
      datingHistory.value.push(dateId)
      return true
    }
    return false
  }

  function breakUp() {
    if (currentPartner.value) {
      currentPartner.value.relationshipStatus = 'single'
      currentPartner.value.relationshipStage = 'friend'
      currentPartner.value.relationshipLevel = Math.max(30, currentPartner.value.relationshipLevel - 30)
      currentPartner.value = null
      return true
    }
    return false
  }

  function generateRandomProfiles(count: number) {
    const names = ['Иван', 'Максим', 'Артём', 'Олег', 'Сергей', 'Анастасия', 'Дарья', 'Екатерина', 'Ольга']
    const surnames = ['Кузнецов', 'Попов', 'Васильев', 'Новиков', 'Морозов']
    const jobs = ['Программист', 'Дизайнер', 'Менеджер', 'Предприниматель', 'Учитель', 'Врач']
    const avatars = ['👨', '👩', '👨‍💼', '👩‍💼', '👨‍💻', '👩‍💻', '👨‍🎨', '👩‍🎨']

    for (let i = 0; i < count; i++) {
      const name = `${names[Math.floor(Math.random() * names.length)]} ${surnames[Math.floor(Math.random() * surnames.length)]}`
      addProfile({
        id: `gen${Date.now()}${i}`,
        name,
        avatar: avatars[Math.floor(Math.random() * avatars.length)],
        age: 20 + Math.floor(Math.random() * 25),
        occupation: jobs[Math.floor(Math.random() * jobs.length)],
        netWorth: Math.floor(Math.random() * 5000000),
        happiness: 50 + Math.floor(Math.random() * 50),
        relationshipStatus: Math.random() > 0.6 ? 'single' : 'dating',
        interests: ['хобби', 'спорт', 'развлечения'],
        isPlayer: false
      })
    }
  }

  return {
    profiles,
    dateProfiles,
    friends,
    currentPartner,
    datingHistory,
    relationshipEvents,
    wealthLeaderboard,
    happinessLeaderboard,
    addProfile,
    meetPerson,
    startDating,
    breakUp,
    generateRandomProfiles,
    // Новые функции
    interactWithPartner,
    proposeMarriage,
    marry,
    createConflict,
    resolveConflict,
    divorce,
    addFriend,
    interactWithFriend,
    monthlyRelationshipCheck,
    addRelationshipEvent,
    getRelationshipStage
  }
})
