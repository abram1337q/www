import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export interface SocialProfile {
  id: string
  name: string
  avatar: string
  age: number
  occupation: string
  netWorth: number
  happiness: number
  relationshipStatus: 'single' | 'dating' | 'married'
  interests: string[]
  isPlayer: boolean
}

export interface DateProfile extends SocialProfile {
  compatibility: number // 0-100
  attractiveness: number
  personality: 'outgoing' | 'shy' | 'confident' | 'creative' | 'intellectual'
  isAI: boolean
}

export interface LeaderboardEntry {
  rank: number
  profile: SocialProfile
  score: number
}

export const useSocialStore = defineStore('social', () => {
  const profiles = ref<SocialProfile[]>([
    {
      id: 'npc1',
      name: 'Александр Петров',
      avatar: '👨‍💼',
      age: 28,
      occupation: 'Менеджер',
      netWorth: 2500000,
      happiness: 75,
      relationshipStatus: 'single',
      interests: ['спорт', 'путешествия', 'бизнес'],
      isPlayer: false
    },
    {
      id: 'npc2',
      name: 'Мария Иванова',
      avatar: '👩‍💻',
      age: 25,
      occupation: 'Разработчик',
      netWorth: 1800000,
      happiness: 82,
      relationshipStatus: 'dating',
      interests: ['программирование', 'музыка', 'кино'],
      isPlayer: false
    },
    {
      id: 'npc3',
      name: 'Дмитрий Соколов',
      avatar: '👨‍🎨',
      age: 30,
      occupation: 'Дизайнер',
      netWorth: 3200000,
      happiness: 88,
      relationshipStatus: 'married',
      interests: ['искусство', 'фотография', 'архитектура'],
      isPlayer: false
    },
    {
      id: 'npc4',
      name: 'Елена Смирнова',
      avatar: '👩‍⚕️',
      age: 27,
      occupation: 'Врач',
      netWorth: 2100000,
      happiness: 79,
      relationshipStatus: 'single',
      interests: ['медицина', 'фитнес', 'чтение'],
      isPlayer: false
    }
  ])

  const dateProfiles = ref<DateProfile[]>([
    {
      id: 'date1',
      name: 'София',
      avatar: '👩‍🦰',
      age: 24,
      occupation: 'Художница',
      netWorth: 800000,
      happiness: 85,
      relationshipStatus: 'single',
      interests: ['искусство', 'музыка', 'природа'],
      isPlayer: false,
      compatibility: 78,
      attractiveness: 85,
      personality: 'creative',
      isAI: true
    },
    {
      id: 'date2',
      name: 'Анна',
      avatar: '👩‍🔬',
      age: 26,
      occupation: 'Учёная',
      netWorth: 1500000,
      happiness: 72,
      relationshipStatus: 'single',
      interests: ['наука', 'книги', 'шахматы'],
      isPlayer: false,
      compatibility: 82,
      attractiveness: 80,
      personality: 'intellectual',
      isAI: true
    },
    {
      id: 'date3',
      name: 'Виктория',
      avatar: '👩‍💼',
      age: 29,
      occupation: 'Предприниматель',
      netWorth: 5000000,
      happiness: 90,
      relationshipStatus: 'single',
      interests: ['бизнес', 'путешествия', 'спорт'],
      isPlayer: false,
      compatibility: 70,
      attractiveness: 88,
      personality: 'confident',
      isAI: true
    },
    {
      id: 'date4',
      name: 'Ксения',
      avatar: '👩‍🎤',
      age: 23,
      occupation: 'Музыкант',
      netWorth: 600000,
      happiness: 95,
      relationshipStatus: 'single',
      interests: ['музыка', 'вечеринки', 'танцы'],
      isPlayer: false,
      compatibility: 65,
      attractiveness: 90,
      personality: 'outgoing',
      isAI: true
    }
  ])

  const currentPartner = ref<DateProfile | null>(null)
  const datingHistory = ref<string[]>([])

  const wealthLeaderboard = computed(() => {
    return profiles.value
      .map((profile, index) => ({
        rank: index + 1,
        profile,
        score: profile.netWorth
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
  })

  const happinessLeaderboard = computed(() => {
    return profiles.value
      .map((profile, index) => ({
        rank: index + 1,
        profile,
        score: profile.happiness
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
  })

  function addProfile(profile: SocialProfile) {
    profiles.value.push(profile)
  }

  function meetPerson(profileId: string) {
    const profile = profiles.value.find(p => p.id === profileId)
    return profile
  }

  function startDating(dateId: string) {
    const date = dateProfiles.value.find(d => d.id === dateId)
    if (date && date.relationshipStatus === 'single') {
      currentPartner.value = date
      date.relationshipStatus = 'dating'
      datingHistory.value.push(dateId)
      return true
    }
    return false
  }

  function marry() {
    if (currentPartner.value) {
      currentPartner.value.relationshipStatus = 'married'
      return true
    }
    return false
  }

  function breakUp() {
    if (currentPartner.value) {
      currentPartner.value.relationshipStatus = 'single'
      currentPartner.value = null
      return true
    }
    return false
  }

  function generateRandomProfiles(count: number) {
    const names = ['Иван', 'Максим', 'Артём', 'Олег', 'Сергей', 'Анастасия', 'Дарья', 'Екатерина', 'Ольга']
    const surnames = ['Кузнецов', 'Попов', 'Васильев', 'Новиков', 'Морозов']
    const jobs = ['Программист', 'Дизайнер', 'Менеджер', 'Предприниматель', 'Учитель', 'Врач']
    const avatars = ['👨', '👩', '👨‍💼', '👩‍💼', '👨‍💻', '👩‍💻', '👨‍🎨', '👩‍🎨']

    for (let i = 0; i < count; i++) {
      const name = `${names[Math.floor(Math.random() * names.length)]} ${surnames[Math.floor(Math.random() * surnames.length)]}`
      addProfile({
        id: `gen${Date.now()}${i}`,
        name,
        avatar: avatars[Math.floor(Math.random() * avatars.length)],
        age: 20 + Math.floor(Math.random() * 25),
        occupation: jobs[Math.floor(Math.random() * jobs.length)],
        netWorth: Math.floor(Math.random() * 5000000),
        happiness: 50 + Math.floor(Math.random() * 50),
        relationshipStatus: Math.random() > 0.6 ? 'single' : 'dating',
        interests: ['хобби', 'спорт', 'развлечения'],
        isPlayer: false
      })
    }
  }

  return {
    profiles,
    dateProfiles,
    currentPartner,
    datingHistory,
    wealthLeaderboard,
    happinessLeaderboard,
    addProfile,
    meetPerson,
    startDating,
    marry,
    breakUp,
    generateRandomProfiles
  }
})
