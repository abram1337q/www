import { defineStore } from 'pinia'
import { ref } from 'vue'
import { apiService } from '@/services/api'
import { usePlayerStore } from './player'
import { useEconomyStore } from './economy'
import { useSocialStore } from './social'
import { useSessionStore } from './session'
import { useFamilyStore } from './family'

export const useGameStore = defineStore('game', () => {
  const isSaving = ref(false)
  const lastSaveTime = ref<Date | null>(null)
  const autoSaveInterval = ref<number | null>(null)

  // Auto-save every 2 minutes
  const AUTO_SAVE_INTERVAL_MS = 120000

  function startAutoSave() {
    if (autoSaveInterval.value) {
      clearInterval(autoSaveInterval.value)
    }

    autoSaveInterval.value = window.setInterval(() => {
      saveGame()
    }, AUTO_SAVE_INTERVAL_MS)
  }

  function stopAutoSave() {
    if (autoSaveInterval.value) {
      clearInterval(autoSaveInterval.value)
      autoSaveInterval.value = null
    }
  }

  async function saveGame() {
    const sessionStore = useSessionStore()
    const playerStore = usePlayerStore()
    const economyStore = useEconomyStore()
    const socialStore = useSocialStore()

    if (!sessionStore.sessionId) {
      console.warn('No session ID, skipping save')
      return
    }

    isSaving.value = true

    try {
      const gameState = {
        player: {
          name: playerStore.name,
          money: playerStore.money,
          stats: playerStore.stats,
          job: playerStore.job,
          relationships: playerStore.relationships,
          properties: playerStore.properties,
          achievements: playerStore.achievements
        },
        economy: {
          economicHealth: economyStore.economicHealth,
          inflationRate: economyStore.inflationRate,
          unemploymentRate: economyStore.unemploymentRate,
          jobListings: economyStore.jobListings,
          realEstateListings: economyStore.realEstateListings
        },
        social: {
          currentPartner: socialStore.currentPartner,
          datingHistory: socialStore.datingHistory
        },
        session: {
          relationshipLevel: sessionStore.relationshipLevel
        },
        timestamp: new Date().toISOString()
      }

      await apiService.saveGame({
        session_id: sessionStore.sessionId,
        game_state: gameState
      })

      lastSaveTime.value = new Date()
      console.log('Game saved successfully at', lastSaveTime.value)
    } catch (error) {
      console.error('Failed to save game:', error)
    } finally {
      isSaving.value = false
    }
  }

  async function loadGame() {
    const sessionStore = useSessionStore()

    if (!sessionStore.sessionId) {
      console.warn('No session ID, skipping load')
      return false
    }

    try {
      const response = await apiService.loadGame(sessionStore.sessionId)
      const gameState = response.state

      if (!gameState) {
        console.log('No saved game found')
        return false
      }

      const playerStore = usePlayerStore()
      const economyStore = useEconomyStore()
      const socialStore = useSocialStore()

      // Restore player state
      if (gameState.player) {
        playerStore.name = gameState.player.name
        playerStore.money = gameState.player.money
        playerStore.stats = gameState.player.stats
        playerStore.job = gameState.player.job
        playerStore.relationships = gameState.player.relationships
        playerStore.properties = gameState.player.properties
        playerStore.achievements = gameState.player.achievements
      }

      // Restore economy state
      if (gameState.economy) {
        economyStore.economicHealth = gameState.economy.economicHealth
        economyStore.inflationRate = gameState.economy.inflationRate
        economyStore.unemploymentRate = gameState.economy.unemploymentRate
        if (gameState.economy.jobListings) {
          economyStore.jobListings = gameState.economy.jobListings
        }
        if (gameState.economy.realEstateListings) {
          economyStore.realEstateListings = gameState.economy.realEstateListings
        }
      }

      // Restore social state
      if (gameState.social) {
        socialStore.currentPartner = gameState.social.currentPartner
        socialStore.datingHistory = gameState.social.datingHistory
      }

      // Restore session state
      if (gameState.session) {
        sessionStore.relationshipLevel = gameState.session.relationshipLevel
      }

      console.log('Game loaded successfully from', response.saved_at)
      return true
    } catch (error) {
      console.error('Failed to load game:', error)
      return false
    }
  }

  async function resetGame() {
    const sessionStore = useSessionStore()
    const playerStore = usePlayerStore()
    const economyStore = useEconomyStore()
    const socialStore = useSocialStore()
    const familyStore = useFamilyStore()

    // Reset all stores to initial state
    playerStore.$reset()
    economyStore.$reset()
    socialStore.$reset()
    familyStore.$reset()
    sessionStore.resetSession()

    stopAutoSave()
    lastSaveTime.value = null

    console.log('Game reset')
  }

  // NEW: Monthly progression - вызывается каждый игровой месяц
  function progressMonth() {
    const playerStore = usePlayerStore()
    const economyStore = useEconomyStore()
    const socialStore = useSocialStore()
    const familyStore = useFamilyStore()

    console.log('🗓️ Прошел месяц...')

    // 1. Прогресс игрока
    playerStore.passMonth()

    // 2. Прогресс экономики
    economyStore.progressMonth()

    // 3. Прогресс отношений
    socialStore.monthlyRelationshipCheck()

    // 4. Прогресс беременности
    if (familyStore.currentPregnancy?.isActive) {
      familyStore.progressPregnancy()
    }

    // 5. Прогресс детей
    if (familyStore.children.length > 0) {
      familyStore.progressChildren()
    }

    // 6. Вычет расходов на детей
    const childExpenses = familyStore.totalMonthlyChildExpenses
    if (childExpenses > 0) {
      playerStore.addMoney(-childExpenses)
      console.log(`💸 Расходы на детей: -${childExpenses.toLocaleString()}₽`)
    }

    // 7. Доход партнера (если в браке и общий бюджет)
    if (socialStore.currentPartner?.relationshipStage === 'married' && socialStore.currentPartner?.sharedBudget) {
      const partnerIncome = socialStore.currentPartner.income
      if (partnerIncome > 0) {
        playerStore.addMoney(partnerIncome)
        console.log(`💰 Доход партнера: +${partnerIncome.toLocaleString()}₽`)
      }
    }

    // 8. Автосохранение
    saveGame()

    console.log('✅ Месяц завершен')
  }

  return {
    isSaving,
    lastSaveTime,
    startAutoSave,
    stopAutoSave,
    saveGame,
    loadGame,
    resetGame,
    progressMonth  // NEW
  }
})
