import { defineStore } from 'pinia'
import { ref } from 'vue'

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: Date
}

export const useChatStore = defineStore('chat', () => {
  const messages = ref<ChatMessage[]>([])
  const isTyping = ref(false)
  const currentMode = ref<'story' | 'free' | null>(null)
  const currentScene = ref<string | null>(null)
  const currentArc = ref<string | null>(null)
  const selectedLocation = ref<string | null>(null)

  function addMessage(role: ChatMessage['role'], content: string, customId?: string) {
    const id = customId || `${Date.now()}-${Math.random()}`
    messages.value.push({
      id,
      role,
      content,
      timestamp: new Date(),
    })
    return id
  }

  function updateMessageContent(messageId: string, content: string) {
    const msg = messages.value.find(m => m.id === messageId)
    if (msg) {
      msg.content = content
    }
  }

  function clearMessages() {
    messages.value = []
  }

  function setMode(mode: 'story' | 'free') {
    currentMode.value = mode
  }

  function setScene(sceneId: string) {
    currentScene.value = sceneId
  }

  function setArc(arcId: string) {
    currentArc.value = arcId
  }

  function setLocation(location: string) {
    selectedLocation.value = location
  }

  function resetChat() {
    messages.value = []
    currentMode.value = null
    currentScene.value = null
    currentArc.value = null
    selectedLocation.value = null
  }

  return {
    messages,
    isTyping,
    currentMode,
    currentScene,
    currentArc,
    selectedLocation,
    addMessage,
    updateMessageContent,
    clearMessages,
    setMode,
    setScene,
    setArc,
    setLocation,
    resetChat,
  }
})
