from flask import Flask, request, jsonify, Response, stream_with_context
from flask_cors import CORS
import requests
import json
import os
from datetime import datetime
import uuid

app = Flask(__name__)
CORS(app)

# OpenRouter configuration
OPENROUTER_API_KEY = os.environ.get('OPENROUTER_API_KEY', '')
OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions'

# In-memory storage (в продакшене использовать базу данных)
user_sessions = {}
user_progress = {}
game_states = {}  # NEW: Store player game state

# AI Characters for dating
AI_CHARACTERS = {
    "date1": {
        "id": "date1",
        "name": "София",
        "age": 24,
        "occupation": "Художница",
        "personality": "creative",
        "description": "Творческая натура, любит искусство и музыку. Мечтательная, романтичная, ценит красоту во всем. Немного эксцентричная, но очень искренняя.",
        "interests": ["искусство", "музыка", "природа", "фотография", "поэзия"],
        "speaking_style": "Говорит образно, использует метафоры. Часто улыбается и задумывается."
    },
    "date2": {
        "id": "date2",
        "name": "Анна",
        "age": 26,
        "occupation": "Учёная",
        "personality": "intellectual",
        "description": "Умная, аналитичная, любит науку и логику. Спокойная и рассудительная, но с тонким чувством юмора. Ценит глубокие разговоры.",
        "interests": ["наука", "книги", "шахматы", "философия", "документальное кино"],
        "speaking_style": "Точная, вдумчивая речь. Любит факты и интересные теории."
    },
    "date3": {
        "id": "date3",
        "name": "Виктория",
        "age": 29,
        "occupation": "Предприниматель",
        "personality": "confident",
        "description": "Уверенная в себе, амбициозная, целеустремленная. Деловая хватка сочетается с обаянием. Любит роскошь и успех.",
        "interests": ["бизнес", "путешествия", "спорт", "инвестиции", "нетворкинг"],
        "speaking_style": "Прямая, энергичная. Говорит уверенно и по делу."
    },
    "date4": {
        "id": "date4",
        "name": "Ксения",
        "age": 23,
        "occupation": "Музыкант",
        "personality": "outgoing",
        "description": "Открытая, жизнерадостная, душа компании. Любит веселиться и знакомиться с людьми. Спонтанная и эмоциональная.",
        "interests": ["музыка", "вечеринки", "танцы", "концерты", "новые знакомства"],
        "speaking_style": "Эмоциональная, много смеется. Энергичная и непосредственная."
    }
}

def create_character_prompt(character_id, context=None, relationship_data=None):
    """Create AI prompt for dating character with relationship context"""
    char = AI_CHARACTERS.get(character_id)
    if not char:
        return None

    prompt = f"""Ты - {char['name']}, {char['age']}-летняя {char['occupation']}.

ЛИЧНОСТЬ: {char['description']}

ИНТЕРЕСЫ: {', '.join(char['interests'])}

СТИЛЬ ОБЩЕНИЯ: {char['speaking_style']}

ПРАВИЛА:
1. Отвечай ТОЛЬКО от первого лица как {char['name']}
2. Будь естественной и живой в диалоге
3. Используй эмоции и действия (*улыбается*, *задумывается*, *смеется*)
4. Помни контекст разговора
5. Веди себя согласно своей личности ({char['personality']})
6. Отвечай на русском языке
7. Не выходи из роли никогда
8. Будь романтичной, если разговор к этому идет
"""

    if relationship_data:
        prompt += f"\n\nСТАТУС ОТНОШЕНИЙ:"
        prompt += f"\n- Стадия: {relationship_data.get('stage', 'stranger')}"
        prompt += f"\n- Уровень отношений: {relationship_data.get('level', 0)}%"
        prompt += f"\n- Доверие: {relationship_data.get('trust', 50)}%"
        prompt += f"\n- Напряжение: {relationship_data.get('tension', 0)}%"

        if relationship_data.get('married'):
            prompt += f"\n- ВЫ В БРАКЕ! Веди себя как любящая жена."
            prompt += f"\n- Годовщина: {relationship_data.get('anniversary_years', 0)} лет"

        if relationship_data.get('children'):
            prompt += f"\n\nВАШИ ДЕТИ:"
            for child in relationship_data['children']:
                prompt += f"\n- {child['name']}, {child['age']} лет ({child['gender']})"
                prompt += f"\n  Здоровье: {child.get('health', 100)}%, Счастье: {child.get('happiness', 100)}%"
            prompt += "\n\nУчитывай детей в разговоре! Спрашивай о них, обсуждай воспитание."

        if relationship_data.get('conflicts'):
            prompt += f"\n\nТЕКУЩИЕ ПРОБЛЕМЫ:"
            for conflict in relationship_data['conflicts']:
                prompt += f"\n- {conflict}"
            prompt += "\n\nБудь обеспокоена этими проблемами в диалоге."

        if relationship_data.get('pregnancy'):
            prompt += f"\n\nТЫ БЕРЕМЕННА! Осталось {relationship_data['pregnancy_months']} месяцев."
            prompt += "\nУпоминай это в разговоре, делись переживаниями."

    if context:
        prompt += f"\n\nКОНТЕКСТ СИТУАЦИИ: {context}"

    return prompt

def create_job_interview_prompt(job_title, company, requirements):
    """Create AI prompt for job interview"""
    return f"""Ты - HR менеджер компании {company}, проводишь собеседование на позицию {job_title}.

ТРЕБОВАНИЯ К КАНДИДАТУ:
- Интеллект: {requirements.get('intelligence', 50)}+
- Харизма: {requirements.get('charisma', 50)}+
- Опыт: {requirements.get('experience', 0)}+ лет

ТВОЯ РОЛЬ:
1. Задавай профессиональные вопросы о навыках и опыте
2. Оценивай ответы кандидата
3. Будь дружелюбным, но профессиональным
4. Веди себя как настоящий HR
5. В конце скажи, прошёл ли кандидат собеседование

Отвечай на русском языке."""

def create_advisor_prompt(player_stats, economic_situation):
    """Create AI prompt for career/life advisor"""
    return f"""Ты - AI карьерный советник и коуч по жизни.

СТАТИСТИКА ИГРОКА:
- Возраст: {player_stats.get('age', 18)} лет
- Деньги: {player_stats.get('money', 0)} ₽
- Интеллект: {player_stats.get('intelligence', 50)}/100
- Харизма: {player_stats.get('charisma', 50)}/100
- Счастье: {player_stats.get('happiness', 50)}/100

ЭКОНОМИЧЕСКАЯ СИТУАЦИЯ:
- Состояние экономики: {economic_situation.get('health', 100)}%
- Инфляция: {economic_situation.get('inflation', 2)}%

ТВОЯ РОЛЬ:
1. Давай конкретные советы по карьере и жизни
2. Рекомендуй вакансии или инвестиции
3. Помогай с финансовым планированием
4. Будь мудрым и полезным
5. Учитывай текущую экономическую ситуацию

Отвечай кратко и по делу на русском языке."""

@app.route('/api/chat', methods=['POST'])
def chat():
    """Main chat endpoint with streaming support"""
    data = request.json
    message = data.get('message')
    session_id = data.get('session_id', str(uuid.uuid4()))
    mode = data.get('mode', 'free')
    scene_id = data.get('scene_id')
    stream = data.get('stream', True)

    if not message:
        return jsonify({'error': 'Message is required'}), 400

    # Get or create session
    if session_id not in user_sessions:
        user_sessions[session_id] = {
            'messages': [],
            'created_at': datetime.now().isoformat(),
            'relationship_level': 0
        }

    session = user_sessions[session_id]

    # Build conversation history - simplified for compatibility
    messages = [{"role": "system", "content": "Ты дружелюбный AI помощник. Отвечай на русском языке."}]
    messages.extend(session['messages'][-10:])
    messages.append({"role": "user", "content": message})

    session['messages'].append({"role": "user", "content": message})

    # Prepare OpenRouter request
    openrouter_request = {
        "model": "anthropic/claude-3.5-sonnet",
        "messages": messages,
        "stream": stream,
        "temperature": 0.8,
        "max_tokens": 500
    }

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "HTTP-Referer": "https://life-simulator.app",
        "X-Title": "Life Simulator",
        "Content-Type": "application/json"
    }

    if stream:
        def generate():
            try:
                response = requests.post(
                    OPENROUTER_API_URL,
                    headers=headers,
                    json=openrouter_request,
                    stream=True
                )

                full_response = ""

                for line in response.iter_lines():
                    if line:
                        line_text = line.decode('utf-8')
                        if line_text.startswith('data: '):
                            data_str = line_text[6:]
                            if data_str == '[DONE]':
                                break

                            try:
                                chunk_data = json.loads(data_str)
                                if 'choices' in chunk_data and len(chunk_data['choices']) > 0:
                                    delta = chunk_data['choices'][0].get('delta', {})
                                    content = delta.get('content', '')
                                    if content:
                                        full_response += content
                                        yield f"data: {json.dumps({'content': content, 'session_id': session_id})}\n\n"
                            except json.JSONDecodeError:
                                pass

                if full_response:
                    session['messages'].append({"role": "assistant", "content": full_response})

                yield f"data: {json.dumps({'done': True, 'session_id': session_id})}\n\n"

            except Exception as e:
                yield f"data: {json.dumps({'error': str(e)})}\n\n"

        return Response(stream_with_context(generate()), mimetype='text/event-stream')

    else:
        try:
            response = requests.post(
                OPENROUTER_API_URL,
                headers=headers,
                json=openrouter_request
            )
            response_data = response.json()

            if 'error' in response_data:
                return jsonify({'error': response_data['error']}), 500

            assistant_message = response_data['choices'][0]['message']['content']
            session['messages'].append({"role": "assistant", "content": assistant_message})

            return jsonify({
                'response': assistant_message,
                'session_id': session_id
            })

        except Exception as e:
            return jsonify({'error': str(e)}), 500

# NEW ENDPOINTS FOR LIFE SIMULATOR

@app.route('/api/dating/chat', methods=['POST'])
def dating_chat():
    """Chat with AI dating character"""
    data = request.json
    character_id = data.get('character_id')
    message = data.get('message')
    session_id = data.get('session_id', str(uuid.uuid4()))
    context = data.get('context', 'Вы на свидании в уютном кафе.')
    relationship_data = data.get('relationship_data')  # NEW: relationship context

    if not character_id or not message:
        return jsonify({'error': 'character_id and message required'}), 400

    if character_id not in AI_CHARACTERS:
        return jsonify({'error': 'Character not found'}), 404

    # Get or create session
    chat_session_key = f"{session_id}_{character_id}"
    if chat_session_key not in user_sessions:
        user_sessions[chat_session_key] = {
            'messages': [],
            'created_at': datetime.now().isoformat()
        }

    session = user_sessions[chat_session_key]

    # Build messages with relationship context
    system_prompt = create_character_prompt(character_id, context, relationship_data)
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(session['messages'][-8:])
    messages.append({"role": "user", "content": message})

    session['messages'].append({"role": "user", "content": message})

    # Call OpenRouter
    try:
        openrouter_request = {
            "model": "anthropic/claude-3.5-sonnet",
            "messages": messages,
            "temperature": 0.9,
            "max_tokens": 400
        }

        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "HTTP-Referer": "https://life-simulator.app",
            "X-Title": "Life Simulator Dating",
            "Content-Type": "application/json"
        }

        response = requests.post(OPENROUTER_API_URL, headers=headers, json=openrouter_request)
        response_data = response.json()

        if 'error' in response_data:
            return jsonify({'error': response_data['error']}), 500

        assistant_message = response_data['choices'][0]['message']['content']
        session['messages'].append({"role": "assistant", "content": assistant_message})

        return jsonify({
            'response': assistant_message,
            'character': AI_CHARACTERS[character_id],
            'session_id': session_id
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/job/interview', methods=['POST'])
def job_interview():
    """AI-powered job interview"""
    data = request.json
    job_title = data.get('job_title')
    company = data.get('company')
    requirements = data.get('requirements', {})
    message = data.get('message')
    session_id = data.get('session_id', str(uuid.uuid4()))

    if not all([job_title, company, message]):
        return jsonify({'error': 'Missing required fields'}), 400

    # Session for interview
    interview_key = f"interview_{session_id}_{job_title}"
    if interview_key not in user_sessions:
        user_sessions[interview_key] = {
            'messages': [],
            'created_at': datetime.now().isoformat()
        }

    session = user_sessions[interview_key]

    # Build messages
    system_prompt = create_job_interview_prompt(job_title, company, requirements)
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(session['messages'][-6:])
    messages.append({"role": "user", "content": message})

    session['messages'].append({"role": "user", "content": message})

    try:
        openrouter_request = {
            "model": "anthropic/claude-3.5-sonnet",
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 300
        }

        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "HTTP-Referer": "https://life-simulator.app",
            "X-Title": "Life Simulator Jobs",
            "Content-Type": "application/json"
        }

        response = requests.post(OPENROUTER_API_URL, headers=headers, json=openrouter_request)
        response_data = response.json()

        if 'error' in response_data:
            return jsonify({'error': response_data['error']}), 500

        assistant_message = response_data['choices'][0]['message']['content']
        session['messages'].append({"role": "assistant", "content": assistant_message})

        # Check if interview is concluded
        is_hired = "поздравля" in assistant_message.lower() or "приняты" in assistant_message.lower()

        return jsonify({
            'response': assistant_message,
            'is_hired': is_hired,
            'session_id': session_id
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/advisor/advice', methods=['POST'])
def get_advice():
    """Get AI career/life advice"""
    data = request.json
    player_stats = data.get('player_stats', {})
    economic_situation = data.get('economic_situation', {})
    question = data.get('question', 'Дай мне совет по карьере и жизни.')

    try:
        system_prompt = create_advisor_prompt(player_stats, economic_situation)
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": question}
        ]

        openrouter_request = {
            "model": "anthropic/claude-3.5-sonnet",
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 300
        }

        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "HTTP-Referer": "https://life-simulator.app",
            "X-Title": "Life Simulator Advisor",
            "Content-Type": "application/json"
        }

        response = requests.post(OPENROUTER_API_URL, headers=headers, json=openrouter_request)
        response_data = response.json()

        if 'error' in response_data:
            return jsonify({'error': response_data['error']}), 500

        advice = response_data['choices'][0]['message']['content']

        return jsonify({
            'advice': advice
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/game/save', methods=['POST'])
def save_game():
    """Save game state"""
    data = request.json
    session_id = data.get('session_id')
    game_state = data.get('game_state')

    if not session_id or not game_state:
        return jsonify({'error': 'session_id and game_state required'}), 400

    game_states[session_id] = {
        'state': game_state,
        'saved_at': datetime.now().isoformat()
    }

    return jsonify({'success': True, 'saved_at': game_states[session_id]['saved_at']})

@app.route('/api/game/load', methods=['GET'])
def load_game():
    """Load game state"""
    session_id = request.args.get('session_id')

    if not session_id:
        return jsonify({'error': 'session_id required'}), 400

    if session_id not in game_states:
        return jsonify({'error': 'No saved game found'}), 404

    return jsonify(game_states[session_id])

@app.route('/api/characters', methods=['GET'])
def get_characters():
    """Get all AI dating characters"""
    return jsonify({'characters': list(AI_CHARACTERS.values())})

@app.route('/api/session/create', methods=['POST'])
def create_session():
    """Create new session"""
    session_id = str(uuid.uuid4())
    user_sessions[session_id] = {
        'messages': [],
        'created_at': datetime.now().isoformat(),
        'relationship_level': 0
    }
    return jsonify({'session_id': session_id})

@app.route('/api/family/generate-name', methods=['POST'])
def generate_child_name():
    """Generate AI child name"""
    data = request.json
    gender = data.get('gender', 'male')
    parent_names = data.get('parent_names', [])

    try:
        prompt = f"""Сгенерируй ОДНО красивое русское имя для новорожденного ребенка.

Пол: {gender}
Имена родителей: {', '.join(parent_names) if parent_names else 'не указаны'}

Требования:
- Только имя, без фамилии
- Современное русское имя
- Короткий ответ: только имя
- Одно слово

Примеры для мальчиков: Александр, Максим, Артём, Даниил, Михаил
Примеры для девочек: София, Мария, Анастасия, Виктория, Алиса

Твой ответ (только имя):"""

        messages = [{"role": "user", "content": prompt}]

        openrouter_request = {
            "model": "anthropic/claude-3.5-sonnet",
            "messages": messages,
            "temperature": 0.9,
            "max_tokens": 20
        }

        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "HTTP-Referer": "https://life-simulator.app",
            "X-Title": "Life Simulator Family",
            "Content-Type": "application/json"
        }

        response = requests.post(OPENROUTER_API_URL, headers=headers, json=openrouter_request)
        response_data = response.json()

        if 'error' in response_data:
            return jsonify({'error': response_data['error']}), 500

        name = response_data['choices'][0]['message']['content'].strip()

        return jsonify({'name': name})

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/family/chat-with-child', methods=['POST'])
def chat_with_child():
    """Chat with AI child"""
    data = request.json
    child_data = data.get('child')
    message = data.get('message')
    session_id = data.get('session_id', str(uuid.uuid4()))

    if not child_data or not message:
        return jsonify({'error': 'child and message required'}), 400

    try:
        age = child_data.get('age', 5)
        name = child_data.get('name', 'ребенок')
        personality = child_data.get('personality', 'calm')

        personalities_ru = {
            'calm': 'спокойный',
            'energetic': 'энергичный',
            'shy': 'стеснительный',
            'rebellious': 'бунтарь'
        }

        prompt = f"""Ты - {name}, {age}-летний ребенок. Характер: {personalities_ru.get(personality, 'спокойный')}.

ПРАВИЛА:
1. Говори как ребенок {age} лет
2. Будь искренним и непосредственным
3. Если возраст до 5 лет - говори простыми фразами
4. Если возраст 6-12 лет - говори как школьник
5. Если возраст 13-17 лет - говори как подросток
6. Веди себя согласно характеру: {personality}
7. Реагируй на родителя эмоционально
8. Отвечай на русском языке

Твой возраст: {age} лет
Твой характер: {personalities_ru.get(personality, 'спокойный')}"""

        chat_key = f"child_{session_id}_{child_data.get('id', 'unknown')}"
        if chat_key not in user_sessions:
            user_sessions[chat_key] = {
                'messages': [],
                'created_at': datetime.now().isoformat()
            }

        session = user_sessions[chat_key]

        messages = [{"role": "system", "content": prompt}]
        messages.extend(session['messages'][-6:])
        messages.append({"role": "user", "content": message})

        session['messages'].append({"role": "user", "content": message})

        openrouter_request = {
            "model": "anthropic/claude-3.5-sonnet",
            "messages": messages,
            "temperature": 0.9,
            "max_tokens": 200
        }

        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "HTTP-Referer": "https://life-simulator.app",
            "X-Title": "Life Simulator Family",
            "Content-Type": "application/json"
        }

        response = requests.post(OPENROUTER_API_URL, headers=headers, json=openrouter_request)
        response_data = response.json()

        if 'error' in response_data:
            return jsonify({'error': response_data['error']}), 500

        child_response = response_data['choices'][0]['message']['content']
        session['messages'].append({"role": "assistant", "content": child_response})

        return jsonify({
            'response': child_response,
            'child': child_data,
            'session_id': session_id
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health():
    """Health check"""
    return jsonify({
        'status': 'ok',
        'api_key_configured': bool(OPENROUTER_API_KEY),
        'active_sessions': len(user_sessions),
        'game_states': len(game_states)
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
