'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import {
  Users,
  Search,
  ChevronLeft,
  ChevronRight,
  Edit,
  DollarSign,
  Trophy,
  Calendar,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  Star,
  Coins,
  Ban,
  Shield,
  MessageCircleOff,
  UserX,
  Check
} from 'lucide-react';

interface User {
  id: number;
  telegram_id: string;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  ton_balance: number;
  stars_balance: number;
  registration_date: string;
  last_activity: string | null;
  total_bets_created: number;
  total_bets_joined: number;
  completed_bets_created: number;
  refunded_bets_created: number;
  open_bets_created: number;
  total_bets: number;
  total_ton_created: number;
  total_stars_created: number;
  total_ton_joined: number;
  total_stars_joined: number;
  wins: number;
  losses: number;
  referral_earnings: number;
  total_referrals: number;
  is_blocked_app: boolean;
  is_blocked_chat: boolean;
  blocked_at: string | null;
  blocked_by_admin: string | null;
  block_reason: string | null;
}

interface UsersManagementProps {
  adminPassword: string;
}

export default function UsersManagement({ adminPassword }: UsersManagementProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'success' | 'error'>('success');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('registration_date');
  const [sortOrder, setSortOrder] = useState('DESC');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [balanceModalOpen, setBalanceModalOpen] = useState(false);
  const [balanceOperation, setBalanceOperation] = useState<'add' | 'subtract' | 'set'>('add');
  const [balanceCurrency, setBalanceCurrency] = useState<'TON' | 'STARS'>('TON');
  const [balanceAmount, setBalanceAmount] = useState('');
  const [balanceDescription, setBalanceDescription] = useState('');

  // Состояния для блокировки пользователей
  const [blockModalOpen, setBlockModalOpen] = useState(false);
  const [blockType, setBlockType] = useState<'app' | 'chat' | 'both'>('both');
  const [blockReason, setBlockReason] = useState('');

  const loadUsers = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        adminPassword,
        page: currentPage.toString(),
        limit: '20',
        search: searchTerm,
        sortBy,
        sortOrder
      });

      const response = await fetch(`/api/admin/users?${params}`);
      const data = await response.json();

      if (data.success) {
        setUsers(data.users);
        setTotalPages(data.pagination.totalPages);
        setMessage('');
      } else {
        setMessage(data.error);
        setMessageType('error');
      }
    } catch (error) {
      setMessage('Ошибка при загрузке пользователей');
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, [currentPage, sortBy, sortOrder]);

  const handleSearch = () => {
    setCurrentPage(1);
    loadUsers();
  };

  const handleBalanceChange = async () => {
    if (!selectedUser || !balanceAmount) {
      setMessage('Заполните все поля');
      setMessageType('error');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/admin/users/${selectedUser.id}/balance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          adminPassword,
          currency: balanceCurrency,
          amount: parseFloat(balanceAmount),
          operation: balanceOperation,
          description: balanceDescription
        }),
      });

      // Проверяем статус ответа
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        const operationText = balanceOperation === 'add' ? 'добавлено' :
                             balanceOperation === 'subtract' ? 'списано' : 'установлено';
        setMessage(`Баланс успешно обновлен: ${operationText} ${balanceAmount} ${balanceCurrency}`);
        setMessageType('success');
        setBalanceModalOpen(false);
        setBalanceAmount('');
        setBalanceDescription('');

        // Показываем сообщение об успехе на 3 секунды
        setTimeout(() => {
          setMessage('');
        }, 3000);

        loadUsers(); // Перезагружаем список пользователей
      } else {
        setMessage(data.error || 'Неизвестная ошибка');
        setMessageType('error');
      }
    } catch (error) {
      console.error('Ошибка при изменении баланса:', error);
      setMessage(`Ошибка сети: ${error instanceof Error ? error.message : 'Неизвестная ошибка'}`);
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };

  const handleBlockUser = async (action: 'block' | 'unblock') => {
    if (!selectedUser) {
      setMessage('Пользователь не выбран');
      setMessageType('error');
      return;
    }

    if (action === 'block' && !blockReason.trim()) {
      setMessage('Введите причину блокировки');
      setMessageType('error');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/admin/users/${selectedUser.id}/block`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          adminPassword,
          blockType,
          action,
          reason: blockReason
        }),
      });

      const data = await response.json();

      if (data.success) {
        setMessage(data.message);
        setMessageType('success');
        setBlockModalOpen(false);
        setBlockReason('');
        loadUsers(); // Перезагружаем список пользователей
      } else {
        setMessage(data.error);
        setMessageType('error');
      }
    } catch (error) {
      setMessage('Ошибка при изменении статуса блокировки');
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getUserDisplayName = (user: User) => {
    const name = [user.first_name, user.last_name].filter(Boolean).join(' ');
    const username = user.username ? `@${user.username}` : '';
    return name || username || `ID: ${user.telegram_id}`;
  };

  return (
    <div className="space-y-6">
      {/* Заголовок и поиск */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-6 h-6 text-blue-600" />
            Управление пользователями
          </CardTitle>
          <CardDescription>
            Просмотр и управление всеми пользователями платформы
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <div className="flex-1 flex gap-2">
              <Input
                placeholder="Поиск по имени, username или Telegram ID"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button onClick={handleSearch} disabled={loading}>
                <Search className="w-4 h-4" />
              </Button>
            </div>
            <Button onClick={loadUsers} variant="outline" disabled={loading}>
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>

          {/* Сортировка */}
          <div className="flex gap-1 mt-4">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="flex-1 px-2 py-1.5 text-xs sm:text-sm border rounded-md bg-white text-gray-900 dark:bg-gray-800 dark:text-white dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="registration_date">Дата рег.</option>
              <option value="last_activity">Активность</option>
              <option value="ton_balance">TON</option>
              <option value="total_bets">Ставки</option>
              <option value="username">Username</option>
            </select>
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
              className="flex-1 px-2 py-1.5 text-xs sm:text-sm border rounded-md bg-white text-gray-900 dark:bg-gray-800 dark:text-white dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="DESC">Убыв.</option>
              <option value="ASC">Возр.</option>
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Сообщения */}
      {message && (
        <Alert className={messageType === 'error' ? 'border-red-500 bg-red-50' : 'border-green-500 bg-green-50'}>
          <AlertDescription className={messageType === 'error' ? 'text-red-700' : 'text-green-700'}>
            {message}
          </AlertDescription>
        </Alert>
      )}

      {/* Список пользователей */}
      <div className="grid gap-4">
        {users.map((user) => (
          <Card key={user.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                {/* Основная информация */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-lg">{getUserDisplayName(user)}</h3>
                    {user.username && (
                      <Badge variant="outline">@{user.username}</Badge>
                    )}
                    {user.is_blocked_app && (
                      <Badge variant="destructive" className="bg-red-500 text-white">
                        <UserX className="w-3 h-3 mr-1" />
                        Заблокирован
                      </Badge>
                    )}
                    {user.is_blocked_chat && !user.is_blocked_app && (
                      <Badge variant="secondary" className="bg-orange-500 text-white">
                        <MessageCircleOff className="w-3 h-3 mr-1" />
                        Чат заблокирован
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-700 dark:text-slate-300 font-medium">ID: {user.telegram_id}</p>
                  <p className="text-sm text-slate-700 dark:text-slate-300 font-medium">
                    Регистрация: {formatDate(user.registration_date)}
                  </p>
                  {user.last_activity && (
                    <p className="text-sm text-slate-700 dark:text-slate-300 font-medium">
                      Активность: {formatDate(user.last_activity)}
                    </p>
                  )}
                  {user.blocked_at && (
                    <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded">
                      <p className="text-sm text-red-700 font-medium">
                        Заблокирован: {formatDate(user.blocked_at)}
                      </p>
                      {user.block_reason && (
                        <p className="text-xs text-red-600 mt-1">
                          Причина: {user.block_reason}
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {/* Балансы */}
                <div className="space-y-2">
                  <h4 className="font-medium text-slate-800 dark:text-slate-200">Балансы</h4>
                  <div className="flex items-center gap-2">
                    <Coins className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">{user.ton_balance.toFixed(4)} TON</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm">{user.stars_balance.toFixed(0)} STARS</span>
                  </div>
                  <Dialog open={balanceModalOpen && selectedUser?.id === user.id} onOpenChange={setBalanceModalOpen}>
                    <DialogTrigger asChild>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedUser(user)}
                        className="mt-2"
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        Изменить
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Изменить баланс пользователя</DialogTitle>
                        <DialogDescription>
                          {getUserDisplayName(user)}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>Валюта</Label>
                          <select
                            value={balanceCurrency}
                            onChange={(e) => setBalanceCurrency(e.target.value as 'TON' | 'STARS')}
                            className="w-full px-3 py-2 border rounded-md mt-1"
                          >
                            <option value="TON">TON</option>
                            <option value="STARS">STARS</option>
                          </select>
                        </div>
                        <div>
                          <Label>Операция</Label>
                          <select
                            value={balanceOperation}
                            onChange={(e) => setBalanceOperation(e.target.value as 'add' | 'subtract' | 'set')}
                            className="w-full px-3 py-2 border rounded-md mt-1"
                          >
                            <option value="add">Добавить</option>
                            <option value="subtract">Вычесть</option>
                            <option value="set">Установить</option>
                          </select>
                        </div>
                        <div>
                          <Label>Сумма</Label>
                          <Input
                            type="number"
                            step="0.0001"
                            min="0"
                            value={balanceAmount}
                            onChange={(e) => setBalanceAmount(e.target.value)}
                            placeholder="Введите сумму"
                          />
                        </div>
                        <div>
                          <Label>Описание (необязательно)</Label>
                          <Input
                            value={balanceDescription}
                            onChange={(e) => setBalanceDescription(e.target.value)}
                            placeholder="Причина изменения баланса"
                          />
                        </div>
                        <Button onClick={handleBalanceChange} disabled={loading} className="w-full">
                          {loading ? 'Обновление...' : 'Обновить баланс'}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>

                {/* Статистика ставок */}
                <div className="space-y-2">
                  <h4 className="font-medium text-gray-900">Статистика ставок</h4>
                  <div className="text-sm space-y-1">
                    <div>Создано: {user.total_bets_created}</div>
                    <div>Участвовал: {user.total_bets_joined}</div>
                    <div>Всего: {user.total_bets}</div>
                    <div className="pt-1">
                      <Badge variant="outline" className="mr-1">
                        ✅ {user.completed_bets_created}
                      </Badge>
                      <Badge variant="outline" className="mr-1">
                        🔄 {user.refunded_bets_created}
                      </Badge>
                      <Badge variant="outline">
                        ⏳ {user.open_bets_created}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Объемы и управление */}
                <div className="space-y-4">
                  {/* Объемы */}
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Объемы</h4>
                    <div className="text-sm space-y-1">
                      <div>TON создано: {user.total_ton_created.toFixed(2)}</div>
                      <div>TON участие: {user.total_ton_joined.toFixed(2)}</div>
                      <div>STARS создано: {user.total_stars_created.toFixed(0)}</div>
                      <div>STARS участие: {user.total_stars_joined.toFixed(0)}</div>
                    </div>
                    {user.total_referrals > 0 && (
                      <div className="pt-2">
                        <Badge variant="outline">
                          Рефералов: {user.total_referrals}
                        </Badge>
                      </div>
                    )}
                  </div>

                  {/* Управление блокировкой */}
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Управление</h4>
                    <div className="space-y-2">
                      {user.is_blocked_app || user.is_blocked_chat ? (
                        <div className="space-y-1">
                          {user.is_blocked_app && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedUser(user);
                                setBlockType('app');
                                handleBlockUser('unblock');
                              }}
                              className="w-full text-green-600 border-green-600 hover:bg-green-50"
                            >
                              <Check className="w-3 h-3 mr-1" />
                              Разблокировать приложение
                            </Button>
                          )}
                          {user.is_blocked_chat && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedUser(user);
                                setBlockType('chat');
                                handleBlockUser('unblock');
                              }}
                              className="w-full text-green-600 border-green-600 hover:bg-green-50"
                            >
                              <Check className="w-3 h-3 mr-1" />
                              Разблокировать чат
                            </Button>
                          )}
                        </div>
                      ) : (
                        <Dialog open={blockModalOpen && selectedUser?.id === user.id} onOpenChange={setBlockModalOpen}>
                          <DialogTrigger asChild>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setSelectedUser(user)}
                              className="w-full text-red-600 border-red-600 hover:bg-red-50"
                            >
                              <Ban className="w-3 h-3 mr-1" />
                              Заблокировать
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Заблокировать пользователя</DialogTitle>
                              <DialogDescription>
                                {getUserDisplayName(user)}
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <Label>Тип блокировки</Label>
                                <select
                                  value={blockType}
                                  onChange={(e) => setBlockType(e.target.value as 'app' | 'chat' | 'both')}
                                  className="w-full px-3 py-2 border rounded-md mt-1"
                                >
                                  <option value="app">Приложение (полная блокировка)</option>
                                  <option value="chat">Только чат</option>
                                  <option value="both">Приложение и чат</option>
                                </select>
                              </div>
                              <div>
                                <Label>Причина блокировки</Label>
                                <Input
                                  value={blockReason}
                                  onChange={(e) => setBlockReason(e.target.value)}
                                  placeholder="Укажите причину блокировки"
                                  className="mt-1"
                                />
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  onClick={() => handleBlockUser('block')}
                                  disabled={loading}
                                  className="flex-1 bg-red-600 hover:bg-red-700"
                                >
                                  {loading ? 'Блокировка...' : 'Заблокировать'}
                                </Button>
                                <Button
                                  onClick={() => setBlockModalOpen(false)}
                                  variant="outline"
                                  className="flex-1"
                                >
                                  Отмена
                                </Button>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Пагинация */}
      {totalPages > 1 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={() => setCurrentPage(currentPage - 1)}
                disabled={currentPage === 1 || loading}
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Назад
              </Button>

              <span className="text-sm text-gray-800">
                Страница {currentPage} из {totalPages}
              </span>

              <Button
                variant="outline"
                onClick={() => setCurrentPage(currentPage + 1)}
                disabled={currentPage === totalPages || loading}
              >
                Вперед
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {loading && (
        <div className="text-center py-8">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-blue-600" />
          <p className="text-gray-800 mt-2">Загрузка пользователей...</p>
        </div>
      )}

      {users.length === 0 && !loading && (
        <div className="text-center py-8 text-gray-500">
          Пользователи не найдены
        </div>
      )}
    </div>
  );
}
