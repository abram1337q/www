"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { flushSync } from "react-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { UserAvatar } from "@/components/ui/user-avatar";
import {
  Send,
  Pin,
  Flag,
  MoreHorizontal,
  Shield,
  MessageCircle,
  Users,
  Paperclip,
  Loader2,
  Trash2,
  ChevronDown
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { ChatService } from "@/lib/chat-service";
import type { ChatMessage as ChatMessageType, ChatRoom } from "@/types/chat";
import { ChatI18nProvider, useChatI18n } from "@/components/providers/ChatI18nProvider";
import { useBlockStatus } from "@/components/providers/BlockStatusProvider";
import ChatBlockNotification from "@/components/chat/ChatBlockNotification";

interface ChatPageMessage {
  id: string;
  user: {
    id: number;
    name: string;
    avatar?: string;
    role?: "admin" | "moderator";
  };
  message: string;
  timestamp: string;
  isOwn?: boolean;
  dbId?: number;
}

interface ChatPageProps {
  onInputFocusChange?: (focused: boolean) => void;
  currentUser?: {
    id: number;
    username?: string;
    first_name?: string;
    last_name?: string;
    role?: 'admin' | 'moderator' | 'user';
  };
}

const ChatPageContent = ({ onInputFocusChange, currentUser }: ChatPageProps) => {
  const { t } = useChatI18n();
  const { isBlockedChat, blockReason } = useBlockStatus();
  const [messages, setMessages] = useState<ChatPageMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [showRules, setShowRules] = useState(true);
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [currentRoom, setCurrentRoom] = useState<ChatRoom | null>(null);
  const [rooms, setRooms] = useState<ChatRoom[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [shouldAutoScroll, setShouldAutoScroll] = useState(true);
  const [isNearBottom, setIsNearBottom] = useState(true);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [loadedRooms, setLoadedRooms] = useState<Set<number>>(new Set());
  // Detect fullscreen mode via Telegram WebApp or heuristic
  const [isFullscreen, setIsFullscreen] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const initialViewportHeight = useRef<number>(0);
  const stopPollingRef = useRef<(() => void) | null>(null);
  const lastMessageIdRef = useRef<number>(0);
  const lastReadMessageIdRef = useRef<number>(0);

  // Загрузка комнат при монтировании
  const loadRooms = useCallback(async () => {
    try {
      const roomsData = await ChatService.getRooms();
      setRooms(roomsData);

      // Выбираем общую комнату по умолчанию
      const generalRoom = roomsData.find(room => room.is_general) || roomsData[0];
      if (generalRoom) {
        setCurrentRoom(generalRoom);
      }
    } catch (error) {
      console.error('Error loading rooms:', error);
      setError(t('error_loading_rooms'));
    }
  }, [t]);

  useEffect(() => {
    loadRooms();
  }, [loadRooms]);

  useEffect(() => {
    try {
      // Telegram WebApp global if available
      type WaType = { Telegram?: { WebApp?: { isExpanded?: boolean; onEvent?: (ev: string, cb: () => void) => void } } };
      const wa = (window as unknown as WaType).Telegram?.WebApp;
      // Platform detection
      const ua = navigator.userAgent || '';
      // Safely read maxTouchPoints without using any
      const navAny = navigator as Navigator & { maxTouchPoints?: number };
      const isiOS = /iPhone|iPad|iPod/.test(ua) || (navigator.platform === 'MacIntel' && (navAny.maxTouchPoints ?? 0) > 1);
      const isAndroidUA = /Android/.test(ua);
      setIsIOS(isiOS);
      setIsAndroid(isAndroidUA);
      if (wa && typeof wa.isExpanded === 'boolean') {
        setIsFullscreen(Boolean(wa.isExpanded));
        // Listen to viewport changes to update padding dynamically
        if (wa.onEvent) {
          const handler = () => setIsFullscreen(Boolean(wa.isExpanded));
          wa.onEvent('viewportChanged', handler);
        }
      } else {
        // Fallback: consider fullscreen when visualViewport height is large relative to innerHeight
        const onResize = () => {
          const vv = window.visualViewport;
          if (vv) {
            setIsFullscreen(vv.height > window.innerHeight - 60);
          }
        };
        window.addEventListener('resize', onResize);
        onResize();
        return () => window.removeEventListener('resize', onResize);
      }
    } catch {}
  }, []);

  // Загрузка сообщений при смене комнаты
  useEffect(() => {
    const initializeRoom = async () => {
      if (!currentRoom) return;

      // Останавливаем предыдущий polling
      if (stopPollingRef.current) {
        stopPollingRef.current();
        stopPollingRef.current = null;
      }

      // Загружаем сообщения напрямую
      try {
        setIsLoading(true);
        const messagesData = await ChatService.getMessages(currentRoom.id);

        const formattedMessages: ChatPageMessage[] = messagesData.map(msg => ({
          id: msg.id.toString(),
          dbId: msg.id,
          user: {
            id: msg.user_id,
            name: getUserDisplayName(msg),
            role: getUserRole(msg.user_id)
          },
          message: msg.message,
          timestamp: formatTime(msg.created_at),
          isOwn: currentUser ? msg.user_id === currentUser.id : false
        }));

        setMessages(formattedMessages);

        // Проверяем, первая ли это загрузка для данной комнаты
        const isFirstLoadForRoom = !loadedRooms.has(currentRoom.id);

        if (isFirstLoadForRoom) {
          // При первой загрузке комнаты сразу устанавливаем скролл внизу без анимации
          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              if (messagesContainerRef.current) {
                messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
              }
              setIsInitialLoad(false);
              setLoadedRooms(prev => new Set(prev).add(currentRoom.id));
            });
          });
        } else {
          setShouldAutoScroll(true);
        }

        // Обновляем последний ID сообщения
        if (formattedMessages.length > 0) {
          const dbIds = formattedMessages.map(m => m.dbId).filter((id): id is number => id !== undefined);
          if (dbIds.length > 0) {
            lastMessageIdRef.current = Math.max(...dbIds);

            // Отмечаем все сообщения как прочитанные при загрузке чата
            if (currentUser?.id && currentRoom) {
              ChatService.markAsRead(currentUser.id, currentRoom.id, lastMessageIdRef.current)
                .catch(error => console.error('Error marking messages as read on load:', error));
            }
          }
        }
      } catch (error) {
        console.error('Error loading messages:', error);
        setError(t('error_loading_messages'));
      } finally {
        setIsLoading(false);
      }

      // Запускаем polling
      if (currentRoom) {
        stopPollingRef.current = await ChatService.pollMessagesWithDeletion(
          currentRoom.id,
          lastMessageIdRef.current,
          (newMessages) => {
            const formattedNewMessages: ChatPageMessage[] = newMessages
              .filter(msg => msg.message && msg.message.trim() !== '') // Исключаем пустые сообщения
              .map(msg => ({
                id: msg.id.toString(),
                dbId: msg.id,
                user: {
                  id: msg.user_id,
                  name: getUserDisplayName(msg),
                  role: getUserRole(msg.user_id)
                },
                message: msg.message,
                timestamp: formatTime(msg.created_at),
                isOwn: currentUser ? msg.user_id === currentUser.id : false
              }));

            setMessages(prevMessages => {
              // Фильтруем новые сообщения: исключаем только дубли
              const newUniqueMessages = formattedNewMessages.filter(msg => {
                // Исключаем уже существующие по dbId
                const alreadyExists = prevMessages.some(existing => existing.dbId === msg.dbId);
                return !alreadyExists;
              });

              if (newUniqueMessages.length === 0) {
                return prevMessages; // Нет новых сообщений для добавления
              }

              // Просто добавляем новые сообщения (только чужие)
              const allMessages = [...prevMessages, ...newUniqueMessages];
              return allMessages.slice(-100);
            });

            // Автоскролл для новых сообщений если пользователь внизу
            if (isNearBottom) {
              setTimeout(() => scrollToBottom('smooth'), 100);
            }

            // Обновляем последний ID сообщения
            if (formattedNewMessages.length > 0) {
              const dbIds = formattedNewMessages.map(m => m.dbId).filter((id): id is number => id !== undefined);
              if (dbIds.length > 0) {
                lastMessageIdRef.current = Math.max(...dbIds);

                // Отмечаем новые сообщения как прочитанные если пользователь в чате
                if (currentUser?.id && currentRoom) {
                  ChatService.markAsRead(currentUser.id, currentRoom.id, lastMessageIdRef.current)
                    .catch(error => console.error('Error marking new messages as read:', error));
                }
              }
            }
          },
          (allMessages) => {
            // Полная синхронизация - просто заменяем все сообщения
            const formattedMessages: ChatPageMessage[] = allMessages
              .filter(msg => msg.message && msg.message.trim() !== '') // Исключаем пустые сообщения
              .map(msg => ({
                id: msg.id.toString(),
                dbId: typeof msg.id === 'string' ? parseInt(msg.id) : msg.id,
                user: {
                  id: msg.user_id,
                  name: getUserDisplayName(msg),
                  role: getUserRole(msg.user_id)
                },
                message: msg.message,
                timestamp: formatTime(msg.created_at),
                isOwn: currentUser ? msg.user_id === currentUser.id : false
              }));

            setMessages(formattedMessages.slice(-100));
          }
        );
      }
    };

    initializeRoom();

    return () => {
      if (stopPollingRef.current) {
        stopPollingRef.current();
        stopPollingRef.current = null;
      }
    };
  }, [currentRoom]);

  const getUserDisplayName = (msg: ChatMessageType): string => {
    if (msg.first_name && msg.last_name) {
      return `${msg.first_name} ${msg.last_name}`;
    }
    if (msg.first_name) {
      return msg.first_name;
    }
    if (msg.username) {
      return msg.username;
    }
    return `${t('default_username')} ${msg.user_id}`;
  };

  const getUserRole = (userId: number): "admin" | "moderator" | undefined => {
    // Здесь можно добавить логику определения роли пользователя
    // Пока возвращаем undefined для всех кроме админа (id = 1)
    return userId === 1 ? "admin" : undefined;
  };

  const formatTime = (dateString: string): string => {
    return new Date(dateString).toLocaleTimeString("ru", {
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  // Проверяем, находится ли пользователь рядом с низом чата
  const checkIfNearBottom = () => {
    const container = messagesContainerRef.current;
    if (!container) return false;

    const { scrollTop, scrollHeight, clientHeight } = container;
    const threshold = 100; // 100px от низа
    return scrollHeight - scrollTop - clientHeight < threshold;
  };

  // Умный скролл
  const scrollToBottom = (behavior: 'smooth' | 'auto' = 'smooth') => {
    // Если клавиатура открыта, используем прямой скролл контейнера
    if (isInputFocused && messagesContainerRef.current) {
      const container = messagesContainerRef.current;
      if (behavior === 'smooth') {
        container.scrollTo({
          top: container.scrollHeight,
          behavior: 'smooth'
        });
      } else {
        container.scrollTop = container.scrollHeight;
      }
    } else {
      // Обычный скролл через scrollIntoView
      messagesEndRef.current?.scrollIntoView({ behavior });
    }
  };

  const scrollToMessage = (messageId: number, behavior: 'smooth' | 'auto' = 'smooth') => {
    const messageElement = document.querySelector(`[data-message-id="${messageId}"]`);
    if (messageElement) {
      messageElement.scrollIntoView({ behavior, block: 'center' });
    }
  };

  // Обработчик скролла
  const handleScroll = () => {
    setIsNearBottom(checkIfNearBottom());
  };

  // Автоскролл только при определенных условиях (НЕ при первой загрузке)
  useEffect(() => {
    // Автоскролл только для новых сообщений, не при первой загрузке комнаты
    if (shouldAutoScroll && messages.length > 0 && currentRoom && loadedRooms.has(currentRoom.id)) {
      // Если есть информация о последнем прочитанном сообщении
      if (lastReadMessageIdRef.current > 0) {
        const firstUnreadMessage = messages.find(msg =>
          (msg.dbId || 0) > lastReadMessageIdRef.current
        );
        if (firstUnreadMessage) {
          setTimeout(() => scrollToMessage(firstUnreadMessage.dbId || 0, 'auto'), 50);
        } else {
          setTimeout(() => scrollToBottom('auto'), 50);
        }
      } else {
        // Если нет информации о прочитанных - скроллим к низу
        setTimeout(() => scrollToBottom('auto'), 50);
      }
      setShouldAutoScroll(false);
    }
  }, [messages, shouldAutoScroll, currentRoom, loadedRooms]);

  // Отслеживание открытия/закрытия клавиатуры через изменение размера
  useEffect(() => {
    initialViewportHeight.current = window.innerHeight;

    const handleViewportChange = () => {
      const currentHeight = window.innerHeight;
      const heightDifference = initialViewportHeight.current - currentHeight;

      // Если высота экрана уменьшилась (клавиатура открылась)
      if (heightDifference > 100 && isInputFocused) {
        console.log('Keyboard opened - not auto-scrolling, user can use scroll button');
        // Убрали автоматический скролл - теперь пользователь сам может нажать кнопку "скролл вниз"
      }

      // Если инпут в фокусе, но высота экрана восстановилась (клавиатура закрылась)
      if (isInputFocused && heightDifference < 100) {
        console.log('Keyboard closed detected - showing bottom nav');
        setIsInputFocused(false);
        onInputFocusChange?.(false);

        // Убираем фокус с инпута
        if (inputRef.current) {
          inputRef.current.blur();
        }
      }
    };

    // Используем Visual Viewport API если доступно, иначе resize
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', handleViewportChange);
    } else {
      window.addEventListener('resize', handleViewportChange);
    }

    return () => {
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', handleViewportChange);
      } else {
        window.removeEventListener('resize', handleViewportChange);
      }
    };
  }, [isInputFocused, onInputFocusChange]);

  const handleSendMessage = useCallback(async () => {
    if (!newMessage.trim() || !currentRoom || !currentUser || isSending) return;

    // Проверяем, не заблокирован ли пользователь в чате
    if (isBlockedChat) {
      setError(blockReason || t('chat_access_limited_admin'));
      return;
    }

    const messageText = newMessage.trim();

    try {
      setIsSending(true);
      setError(null);

      // Очищаем поле ввода сразу
      setNewMessage("");

      // Сбрасываем высоту textarea к исходному состоянию
      if (inputRef.current) {
        inputRef.current.style.height = '36px';
        inputRef.current.style.overflowY = 'hidden';
      }

      const sentMessage = await ChatService.sendMessage({
        roomId: currentRoom.id,
        userId: currentUser.id,
        message: messageText
      });

      // Добавляем отправленное сообщение сразу в UI
      if (sentMessage) {
        const newMessage: ChatPageMessage = {
          id: sentMessage.id.toString(),
          dbId: sentMessage.id,
          user: {
            id: sentMessage.user_id,
            name: getUserDisplayName(sentMessage),
            role: getUserRole(sentMessage.user_id)
          },
          message: sentMessage.message,
          timestamp: formatTime(sentMessage.created_at),
          isOwn: true
        };

        setMessages(prev => [...prev, newMessage]);

        // Обновляем lastMessageIdRef чтобы polling не подхватил это сообщение как дубль
        lastMessageIdRef.current = Math.max(lastMessageIdRef.current, sentMessage.id);

        // Скроллим к низу только если пользователь был внизу чата
        if (isNearBottom) {
          setTimeout(() => scrollToBottom('smooth'), 50);
        }
      }

    } catch (error) {
      console.error('Error sending message:', error);
      setError(t('error_sending_message'));

      // Возвращаем текст в поле ввода при ошибке
      setNewMessage(messageText);
    } finally {
      setIsSending(false);
    }
  }, [newMessage, currentRoom, currentUser, isSending, scrollToBottom, formatTime]);

  const handleReportMessage = async (messageId: string) => {
    const message = messages.find(msg => msg.id === messageId);
    if (!message) return;

    // TODO: Добавить API для жалоб
    alert(t('report_sent', { username: message.user.name }));
  };

  const handleDeleteMessage = async (messageId: string) => {
    const message = messages.find(msg => msg.id === messageId);
    if (!message || !currentUser) return;

    // Подтверждение удаления
    if (!confirm(t('delete_confirmation'))) {
      return;
    }

    try {
      await ChatService.deleteMessage({
        messageId: message.dbId || Number.parseInt(messageId),
        userId: currentUser.id,
        isAdmin: currentUser.role === 'admin'
      });

      // Сообщение будет удалено автоматически через полную синхронизацию в polling (каждые 10 секунд)
      // Не удаляем локально - это сделает обработчик onMessagesSync в polling
    } catch (error) {
      console.error('Error deleting message:', error);
      setError(t('error_deleting_message'));
    }
  };

  const getRoleColor = (role?: string) => {
    switch (role) {
      case "admin":
        return "bg-gradient-to-r from-red-500 to-rose-500";
      case "moderator":
        return "bg-gradient-to-r from-blue-500 to-blue-600";
      default:
        return "bg-gradient-to-br from-blue-500 to-purple-600";
    }
  };

  const getRoleBadge = (role?: string) => {
    switch (role) {
      case "admin":
        return <Badge className="text-xs bg-gradient-to-r from-red-500 to-rose-500 text-white border-none">{t('admin')}</Badge>;
      case "moderator":
        return <Badge className="text-xs bg-gradient-to-r from-blue-500 to-blue-600 text-white border-none">{t('moderator')}</Badge>;
      default:
        return null;
    }
  };

  const handleToggleRules = () => {
    setShowRules(!showRules);
  };

  const handleAttachFile = () => {
    alert(t('attach_files_soon'));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNewMessage(e.target.value);
  };

  // Автоматическое изменение высоты textarea
  useEffect(() => {
    const textarea = inputRef.current;
    if (textarea) {
      // Если поле пустое, принудительно сбрасываем к исходному размеру
      if (newMessage.trim() === '') {
        textarea.style.height = '36px';
        textarea.style.overflowY = 'hidden';
        return;
      }

      // Сбрасываем высоту до минимальной (как в Telegram)
      textarea.style.height = '36px';

      // Вычисляем нужную высоту (максимум 108px = ~3 строки как в Telegram)
      const scrollHeight = textarea.scrollHeight;
      const maxHeight = 108;
      const newHeight = Math.min(scrollHeight, maxHeight);

      textarea.style.height = newHeight + 'px';
      textarea.style.overflowY = scrollHeight > maxHeight ? 'auto' : 'hidden';
    }
  }, [newMessage]);

  // ПРОСТЫЕ обработчики фокуса
  const handleInputFocus = () => {
    console.log('Input focused - hiding bottom nav');
    setIsInputFocused(true);
    onInputFocusChange?.(true);
    // Убираем автоматический скролл при фокусе на инпут
    // Теперь пользователь сам может нажать кнопку "скролл вниз" если нужно
  };

  const handleInputBlur = () => {
    console.log('Input blurred - showing bottom nav');
    setIsInputFocused(false);
    onInputFocusChange?.(false);
  };

  if (isLoading) {
    return (
      <div className="flex flex-col h-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
        <p className="mt-2 text-foreground/60">{t('loading_chat')}</p>
      </div>
    );
  }

  if (error && !currentRoom) {
    return (
      <div className="flex flex-col h-full items-center justify-center p-4">
        <div className="text-center">
          <p className="text-red-500 mb-4">{error}</p>
          <Button onClick={loadRooms} variant="outline">
            {t('try_again')}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full relative">
      {/* Chat block notification */}
      <ChatBlockNotification />

      {/* Error display */}
      {error && (
        <div className="p-2 bg-red-500/10 border-b border-red-500/20">
          <p className="text-red-500 text-sm text-center">{error}</p>
        </div>
      )}

      {/* Room selector */}
      {rooms.length > 1 && (
        <div className="p-4 border-b border-white/10">
          <div className="flex space-x-2 overflow-x-auto">
            {rooms.map(room => (
              <Button
                key={room.id}
                variant={currentRoom?.id === room.id ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentRoom(room)}
                className="whitespace-nowrap"
              >
                {room.name}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Messages */}
      <div
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide"
        onScroll={handleScroll}
        style={{
          // Fine tuning for platform and keyboard state
          paddingBottom: isFullscreen
            ? (
                isInputFocused
                  ? 'calc(10px + env(safe-area-inset-bottom, 0px))' // lower when keyboard open
                  : (
                      // On iOS, give extra bottom space when keyboard is closed
                      isIOS ? 'calc(-40px + env(safe-area-inset-bottom, 0px))' : 'calc(max(25px, 3.2vh) + env(safe-area-inset-bottom, 0px))'
                    )
              )
            : undefined,
        }}
      >
        {messages.map((message, index) => (
          <motion.div
            key={message.id}
            data-message-id={message.dbId}
            initial={{ opacity: 1, y: 0 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0 }}
            className={`flex ${message.isOwn ? "justify-end" : "justify-start"}`}
          >
            <div className={`max-w-[80%] ${message.isOwn ? "order-2" : ""}`}>
              {!message.isOwn && (
                <div className="flex items-center space-x-2 mb-1 ml-2">
                  <UserAvatar
                    userId={message.user.id}
                    userName={message.user.name}
                    role={message.user.role}
                    size="sm"
                  />
                  <div className="flex items-center space-x-1">
                    <span className="font-semibold text-sm">{message.user.name}</span>
                    {getRoleBadge(message.user.role)}
                  </div>
                  <span className="text-xs text-foreground/50">{message.timestamp}</span>
                </div>
              )}

              <div className={`flex items-start group ${message.isOwn ? 'flex-row-reverse space-x-reverse space-x-2' : 'space-x-2'}`}>
                <Card className={`border-none shadow-md overflow-hidden
                  ${message.isOwn
                    ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-2xl rounded-br-none"
                    : "glass-card bg-white/5 backdrop-blur-sm rounded-2xl rounded-bl-none"
                  }
                `}>
                  <CardContent className="p-3 overflow-hidden">
                    <p className="text-sm leading-relaxed break-words whitespace-pre-wrap">{message.message}</p>
                    {message.isOwn && (
                      <div className="text-xs opacity-80 mt-1 text-right">
                        {message.timestamp}
                      </div>
                    )}
                  </CardContent>
                </Card>

                <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  {message.isOwn && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteMessage(message.id);
                      }}
                      className="hover:bg-red-500/20 rounded-full h-7 w-7 p-0 flex items-center justify-center"
                      title={t('delete_message')}
                    >
                      <Trash2 className="h-3.5 w-3.5 text-red-400" />
                    </Button>
                  )}
                  {!message.isOwn && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleReportMessage(message.id);
                      }}
                      className="hover:bg-white/10 rounded-full h-7 w-7 p-0 flex items-center justify-center"
                      title={t('report_message')}
                    >
                      <Flag className="h-3.5 w-3.5 text-foreground/70" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Scroll to bottom button */}
      <AnimatePresence>
        {!isNearBottom && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            transition={{ duration: 0.2 }}
            className="absolute right-4 bottom-[120px] z-50"
          >
            <Button
              onMouseDown={(e) => {
                e.preventDefault(); // Предотвращаем потерю фокуса
                e.stopPropagation();
              }}
              onTouchStart={(e) => {
                e.preventDefault(); // Предотвращаем потерю фокуса на мобильных
                e.stopPropagation();
              }}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                scrollToBottom('smooth');
                // Возвращаем фокус на инпут если он был активен
                if (isInputFocused && inputRef.current) {
                  setTimeout(() => {
                    inputRef.current?.focus();
                  }, 10);
                }
              }}
              size="sm"
              className="rounded-full h-10 w-10 p-0 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 shadow-md"
              aria-label="Прокрутить вниз"
            >
              <ChevronDown className="h-5 w-5" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Message Input - фиксированный внизу */}
      <div
        className="p-4 backdrop-blur-md bg-background/50 border-t border-white/10"
        style={{
          // lift the input bar slightly in fullscreen to clear bottom nav/button
          paddingBottom: isFullscreen
            ? ( isInputFocused
                ? 'calc(8px + env(safe-area-inset-bottom, 0px))'  // lower when keyboard open
                : (
                    // Increase bottom padding on iOS when keyboard is closed
                    isIOS ? 'calc(-14px + env(safe-area-inset-bottom, 0px))' : (isAndroid ? 'calc(max(20px, 2.8vh) + env(safe-area-inset-bottom, 0px))' : 'calc(22px + env(safe-area-inset-bottom, 0px))')
                  ) )
            : undefined,
          // add small bottom margin to keep moderation row visible above nav
          marginBottom: isFullscreen
            ? ( isInputFocused ? '6px' : (isIOS ? '-14px' : (isAndroid ? 'max(15px, 1.8vh)' : '16px')) )
            : undefined,
        }}
      >
        <div className="flex items-end space-x-2 mb-4">
          <div className="flex-1 relative">
            <Textarea
              ref={inputRef}
              placeholder={
                isBlockedChat
                  ? t('chat_access_limited')
                  : (currentUser ? t('write_message_placeholder') : t('login_to_write'))
              }
              value={newMessage}
              onChange={handleInputChange}
              onKeyDown={(e) => {
                // Убираем отправку по Enter - только Shift+Enter для новой строки
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  // Не отправляем сообщение, только переводим строку если нужно
                }
              }}
              onFocus={handleInputFocus}
              onBlur={handleInputBlur}
              disabled={!currentUser || isSending || isBlockedChat}
              className="pl-4 pr-10 rounded-full bg-white/5 backdrop-blur-sm border border-white/20 focus:outline-0 focus:border-blue-500 resize-none overflow-hidden transition-all duration-200"
              style={{
                minHeight: '36px',
                height: '36px',
                paddingTop: '8px',
                paddingBottom: '8px',
                lineHeight: '20px',
                outline: 'none !important',
                boxShadow: 'none'
              }}

              maxLength={500}
              rows={1}
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center space-x-2">
              <Paperclip className="h-4 w-4 text-foreground/50 hover:text-foreground/80 cursor-pointer" onClick={handleAttachFile} />
            </div>
          </div>
          <Button
            onTouchStart={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (!newMessage.trim() || !currentUser || isSending || isBlockedChat) return;
              handleSendMessage();
            }}
            onMouseDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (!newMessage.trim() || !currentUser || isSending || isBlockedChat) return;
              handleSendMessage();
            }}
            disabled={!newMessage.trim() || !currentUser || isSending || isBlockedChat}
            className="rounded-full h-9 w-9 p-0 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 shadow-md"
          >
            {isSending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </div>

        <div
          className="flex items-center justify-between mt-2 text-xs text-foreground/60"
          style={{
            paddingBottom: isFullscreen ? 'env(safe-area-inset-bottom, 0px)' : undefined,
          }}
        >
          <div className="flex items-center space-x-2">
            <Shield className="h-3 w-3 text-blue-400" />
            <span>{t('moderation_enabled')}</span>
          </div>
          <span className={newMessage.length > 400 ? 'text-yellow-400' : ''}>{newMessage.length}/500</span>
        </div>
      </div>
    </div>
  );
};

export const ChatPage = (props: ChatPageProps) => {
  return (
    <ChatI18nProvider>
      <ChatPageContent {...props} />
    </ChatI18nProvider>
  );
};
