"use client";

import { useState, useEffect } from "react";
import type { PageType } from "@/app/page";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { UserAvatar } from "@/components/ui/user-avatar";
import { useTelegram } from "@/components/providers/TelegramProvider";
import { ChatService } from "@/lib/chat-service";
import { TrendingUp, Award, Sparkles, MessageCircle, Users, Pin, MoreHorizontal, Plus, Coins, Star, Wallet, DollarSign, ArrowRight } from "lucide-react";
import { ChatRulesAcceptance } from "@/components/chat/ChatRulesAcceptance";
import { ChatI18nProvider, useChatI18n } from "@/components/providers/ChatI18nProvider";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { TonTopUpModal } from "@/components/ton/TonTopUpModal";
import { StarsTopUpModal } from "@/components/stars/StarsTopUpModal";
import { useBalance } from "@/hooks/useBalance";
import { useI18n } from "@/components/providers/I18nProvider";
import { FEATURES } from "@/lib/features";

// Функция для определения iPhone
const isIPhone = () => {
  if (typeof window === 'undefined') return false;
  return /iPhone|iPad|iPod/.test(navigator.userAgent) ||
         (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
};

interface HeaderProps {
  currentPage: PageType;
  isFullscreen?: boolean;
}

const pageNameKeys: Record<PageType, string> = {
  "home": "header_sports",
  "create-bet": "header_create_bet",
  "open-bets": "header_open_bets",
  "chat": "header_chat",
  "my-bets": "header_my_bets",
  "menu": "header_menu"
};

const pageIcons = {
  "home": TrendingUp,
  "create-bet": Award,
  "open-bets": TrendingUp,
  "chat": MessageCircle,
  "my-bets": TrendingUp,
  "menu": TrendingUp
};

// Специальный header для чата
const ChatPageHeaderContent = ({ isFullscreen }: { isFullscreen: boolean }) => {
  const chatT = useChatI18n().t; // keep chat-specific translations for rules, etc.
  const { t } = useI18n(); // use global i18n for page title to match other pages

  const pinnedRules = [
    chatT('rule_no_insults'),
    chatT('rule_no_spam'),
    chatT('rule_disputes_only_platform')
  ];
  const [showRules, setShowRules] = useState(() => {
    // Проверяем localStorage при инициализации
    if (typeof window !== 'undefined') {
      const rulesAccepted = localStorage.getItem('chat_rules_accepted');
      const rulesManuallyHidden = localStorage.getItem('chat_rules_manually_hidden');

      // Если правила приняты или вручную скрыты - не показываем
      if (rulesAccepted === 'true' || rulesManuallyHidden === 'true') {
        return false;
      }
    }
    // По умолчанию показываем правила
    return true;
  });

  const [rulesAccepted, setRulesAccepted] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('chat_rules_accepted') === 'true';
    }
    return false;
  });

  const [onlineCount, setOnlineCount] = useState(0);
  const isIPhoneDevice = isIPhone();

  useEffect(() => {
    // Загружаем количество онлайн пользователей
    const fetchOnlineCount = async () => {
      try {
        const data = await ChatService.getOnlineCount();
        setOnlineCount(data.onlineCount);
      } catch (error) {
        console.error('Error fetching online count:', error);
        // Оставляем 0 при ошибке
      }
    };

    fetchOnlineCount();

    // Обновляем каждые 30 секунд
    const interval = setInterval(fetchOnlineCount, 30000);

    return () => clearInterval(interval);
  }, []);

  const handleToggleRules = () => {
    if (!rulesAccepted) {
      // Если правила не приняты, сохраняем что пользователь вручную скрыл их
      localStorage.setItem('chat_rules_manually_hidden', 'true');
    }
    setShowRules(!showRules);
  };

  const handleAcceptRules = () => {
    setRulesAccepted(true);
    setShowRules(false);
  };

  const handleSkipRules = () => {
    // Сохраняем что пользователь вручную скрыл правила
    localStorage.setItem('chat_rules_manually_hidden', 'true');
    setShowRules(false);
  };

  return (
    <header
      className="sticky left-0 right-0 z-50"
      style={({
        position: "sticky",
        top: isIPhoneDevice ? '30px' : '0',
        zIndex: 50,
        paddingTop: isFullscreen ? 'var(--system-safe-top)' : '0'
      })}
    >
      <div
        className="glass-header backdrop-blur-xl bg-black/70 border-b border-white/10"
        style={{
          backdropFilter: "blur(10px)",
          WebkitBackdropFilter: "blur(10px)",
          background: "linear-gradient(135deg, rgba(0, 0, 0, 0.8), rgba(20, 20, 20, 0.7))"
        }}
      >
        <div className="p-2">
          <div className="flex items-center justify-between mb-2">
            {/* Центральная часть - логотип и текст */}
            <div className="flex items-center space-x-2 ml-2">
              {/* Логотип */}
              <div className="w-20 h-14 rounded-xl flex items-center justify-center shadow-md overflow-hidden relative group">
                <img
                  src="/logoapps.jpg"
                  alt="Logo"
                  className="w-full h-full object-cover rounded-xl"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-all duration-700 rounded-xl"></div>
              </div>
              <div>
                <h2 className="font-bold text-base bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">{t(pageNameKeys['chat'])}</h2>
                <div className="flex items-center space-x-2 text-xs text-foreground/70">
                  <Users className="h-3 w-3 text-blue-400" />
                  <span>{onlineCount} онлайн</span>
                  <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                </div>
              </div>
            </div>

            {/* Правая часть - кнопка скрепки */}
            <div className="flex pr-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleToggleRules}
                className="hover:bg-white/10 rounded-full h-7 w-7 p-0 flex items-center justify-center"
              >
                <Pin className={`h-3.5 w-3.5 ${showRules ? 'text-yellow-400' : 'text-foreground/70'}`} />
              </Button>
            </div>
          </div>

          {/* Chat Rules */}
          <AnimatePresence>
            {showRules && !rulesAccepted && (
              <ChatI18nProvider>
                <ChatRulesAcceptance
                  onAccept={handleAcceptRules}
                  onSkip={handleSkipRules}
                />
              </ChatI18nProvider>
            )}
            {showRules && rulesAccepted && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="glass-card border-none overflow-hidden relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 to-amber-500/10 rounded-xl"></div>
                  <CardContent className="p-3 relative z-10">
                    <div className="flex items-center space-x-2 mb-2">
                      <Pin className="h-4 w-4 text-yellow-400" />
                      <span className="font-semibold text-yellow-400 text-sm">
                        {chatT('chat_rules_title')}
                      </span>
                    </div>
                    <ul className="space-y-1">
                      {pinnedRules.map((rule, index) => (
                        <li key={index} className="text-sm text-foreground/80 flex items-start space-x-2">
                          <div className="min-w-4 text-yellow-400">•</div>
                          <span>{rule}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
};

const ChatPageHeader = ({ isFullscreen }: { isFullscreen: boolean }) => {
  return (
    <ChatI18nProvider>
      <ChatPageHeaderContent isFullscreen={isFullscreen} />
    </ChatI18nProvider>
  );
};

export const Header = ({ currentPage, isFullscreen = false }: HeaderProps) => {
  const { user } = useTelegram();
  const { t } = useI18n();
  const PageIcon = pageIcons[currentPage];
  const isIPhoneDevice = isIPhone();

  // Используем реальный баланс
  const { balance, loading: balanceLoading, refreshBalance } = useBalance();

  // Modal states
  const [showTonTopUp, setShowTonTopUp] = useState(false);
  const [showStarsTopUp, setShowStarsTopUp] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  // Modal handlers
  const handleOpenTonTopUp = () => {
    setShowTonTopUp(true);
    setDropdownOpen(false);
  };

  const handleOpenStarsTopUp = () => {
    setShowStarsTopUp(true);
    setDropdownOpen(false);
  };

  // Обновляем баланс после закрытия модальных окон
  const handleCloseTonModal = () => {
    setShowTonTopUp(false);
    setDropdownOpen(false);
    setTimeout(() => refreshBalance(), 1000);
  };

  const handleCloseStarsModal = () => {
    setShowStarsTopUp(false);
    setDropdownOpen(false);
    setTimeout(() => refreshBalance(), 1000);
  };

  // Если это страница чата, используем специальный header
  if (currentPage === 'chat') {
    return <ChatPageHeader isFullscreen={isFullscreen} />;
  }

  return (
    <header
      className="sticky left-0 right-0 z-50"
      style={{
        position: "sticky",
        top: isIPhoneDevice ? '30px' : '0',
        zIndex: 50,
        paddingTop: isFullscreen ? 'var(--system-safe-top)' : '0'
      }}
    >
      <div
        className=""
        style={{}}
      >
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 500, damping: 30 }}
              className="flex items-center space-x-3"
            >
              {/* Логотип */}
              <div className="w-20 h-14 rounded-xl flex items-center justify-center shadow-md relative overflow-hidden group">
                <img
                  src="/logoapps.jpg"
                  alt="Logo"
                  className="w-full h-full object-cover rounded-xl"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-all duration-700 rounded-xl"></div>
              </div>

              {/* Название страницы - показываем только если это НЕ главная страница */}
              {currentPage !== 'home' && (
                <div>
                  <motion.h1
                    key={currentPage}
                    initial={{ opacity: 0, x: -5 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.2 }}
                    className="font-bold text-lg leading-none bg-gradient-to-r from-blue-500 to-purple-500 text-transparent bg-clip-text"
                  >
                    {t(pageNameKeys[currentPage])}
                  </motion.h1>
                </div>
              )}
            </motion.div>

            {/* Интегрированный баланс и кнопка пополнения везде, кроме страниц меню и чата */}
            {!['menu', 'chat'].includes(currentPage) && (
              <div className="flex items-center space-x-2 bg-white/5 backdrop-blur-md rounded-full border border-white/10 pl-2 pr-1 py-1">
                {/* Баланс в долларах */}
                <div className="flex items-center space-x-1">
                  <div className="h-4 w-4 rounded-full bg-gradient-to-r from-green-500 to-green-600 flex items-center justify-center">
                    <DollarSign className="h-2.5 w-2.5 text-white" />
                  </div>
                  {balanceLoading ? (
                    <div className="animate-spin h-3 w-3 border border-white/30 border-t-white rounded-full"></div>
                  ) : (
                    <span className="text-xs font-medium">${balance.totalUSD.toFixed(2)}</span>
                  )}
                </div>

                {/* Кнопка пополнения с красивым выпадающим меню */}
                <DropdownMenu open={dropdownOpen} onOpenChange={setDropdownOpen}>
                  <DropdownMenuTrigger asChild>
                    <Button
                      size="sm"
                      className="h-6 w-6 rounded-full bg-gradient-to-r from-green-400 to-emerald-500 hover:from-green-500 hover:to-emerald-600 text-white border-none shadow-sm p-0 ml-1 relative overflow-hidden group animate-pulse shadow-[0_0_15px_rgba(0,200,100,0.3)]"
                    >
                      <div className="absolute inset-0 bg-white/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                      <Plus className="h-3 w-3 relative z-10" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    side="bottom"
                    align="end"
                    className="w-52 border-0 overflow-hidden p-0 bg-transparent shadow-none"
                    sideOffset={5}
                    alignOffset={10}
                    forceMount
                  >
                    <motion.div
                      initial={{ opacity: 1, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      transition={{ duration: 0.2, type: "spring", stiffness: 500, damping: 30 }}
                      className="relative overflow-hidden rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.2)]"
                    >
                      {/* Фоновый эффект - внешний градиент и свечение */}
                      <div className="absolute inset-0 rounded-2xl blur-[2px] bg-gradient-to-br from-purple-500/20 via-blue-500/20 to-emerald-500/20"></div>

                      {/* Основной контейнер с стеклянным эффектом */}
                      <div className="relative overflow-hidden rounded-2xl backdrop-blur-xl border border-white/20 bg-background/50 shadow-[0_0_30px_rgba(100,200,255,0.1)]">
                        {/* Внутренний градиент эффект */}
                        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-blue-500/5 to-emerald-500/10 rounded-2xl"></div>

                        {/* Движущееся свечение */}
                        <div className="absolute inset-0 opacity-30 overflow-hidden rounded-2xl">
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full animate-[shimmer_2s_infinite]"></div>
                        </div>

                        {/* Содержимое меню */}
                        <div className="p-2 relative z-10">
                          <div className="text-xs text-foreground/70 font-medium mb-1 ml-1">{t('header_topup_choose_method')}</div>

                          {/* TON Option */}
                          <DropdownMenuItem className="focus:outline-none p-0 m-0" asChild>
                            <motion.div
                              whileHover={{ x: 3, scale: 1.02 }}
                              className="rounded-xl p-2.5 cursor-pointer hover:bg-white/10 transition-colors relative overflow-hidden group"
                              onClick={handleOpenTonTopUp}
                            >
                              {/* Обводка */}
                              <div className="absolute -inset-[0.5px] rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-r from-blue-500/30 to-blue-600/30"></div>

                              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-blue-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl"></div>
                              <div className="flex items-center space-x-3 relative z-10">
                                <div className="h-10 w-10 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center shadow-md relative overflow-hidden group-hover:shadow-[0_0_20px_rgba(59,130,246,0.4)] transition-all duration-300 border border-blue-400/20">
                                  <div className="absolute inset-0 bg-white/20 rounded-xl translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                                  <img src="/images/ton.png" alt="TON" className="h-5 w-5 relative z-10" />
                                </div>
                                <div className="flex-1">
                                  <div className="font-semibold text-sm bg-gradient-to-r from-blue-500 to-blue-400 bg-clip-text text-transparent group-hover:from-blue-400 group-hover:to-blue-300 transition-all duration-300">{t('header_topup_ton')}</div>
                                  <div className="text-xs text-foreground/60 group-hover:text-foreground/80 transition-colors duration-300">{t('header_topup_ton_hint')}</div>
                                </div>
                                <ArrowRight className="h-4 w-4 text-blue-500/50 group-hover:text-blue-400 transform translate-x-0 group-hover:translate-x-1 transition-all duration-300" />
                              </div>
                            </motion.div>
                          </DropdownMenuItem>

                          {/* STARS Option */}
                          {FEATURES.SHOW_STARS && (
                            <DropdownMenuItem className="focus:outline-none p-0 m-0" asChild>
                              <motion.div
                                whileHover={{ x: 3, scale: 1.02 }}
                                className="rounded-xl p-2.5 cursor-pointer hover:bg-white/10 transition-colors relative overflow-hidden group mt-1"
                                onClick={handleOpenStarsTopUp}
                              >
                                {/* Обводка */}
                                <div className="absolute -inset-[0.5px] rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-r from-yellow-500/30 to-amber-600/30"></div>

                                <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 to-amber-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl"></div>
                                <div className="flex items-center space-x-3 relative z-10">
                                  <div className="h-10 w-10 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-500 flex items-center justify-center shadow-md relative overflow-hidden group-hover:shadow-[0_0_20px_rgba(245,158,11,0.4)] transition-all duration-300 border border-yellow-400/20">
                                    <div className="absolute inset-0 bg-white/20 rounded-xl translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                                    <img src="/images/stars.png" alt="Stars" className="h-5 w-5 relative z-10" />
                                  </div>
                                  <div className="flex-1">
                                    <div className="font-semibold text-sm bg-gradient-to-r from-yellow-500 to-amber-400 bg-clip-text text-transparent group-hover:from-yellow-400 group-hover:to-amber-300 transition-all duration-300">{t('header_topup_stars')}</div>
                                    <div className="text-xs text-foreground/60 group-hover:text-foreground/80 transition-colors duration-300">{t('header_topup_stars_hint')}</div>
                                  </div>
                                  <ArrowRight className="h-4 w-4 text-yellow-500/50 group-hover:text-yellow-400 transform translate-x-0 group-hover:translate-x-1 transition-all duration-300" />
                                </div>
                              </motion.div>
                            </DropdownMenuItem>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal Components */}
      <TonTopUpModal
        isOpen={showTonTopUp}
        onClose={handleCloseTonModal}
      />

      {FEATURES.SHOW_STARS && (
        <StarsTopUpModal
          isOpen={showStarsTopUp}
          onClose={handleCloseStarsModal}
        />
      )}
    </header>
  );
};
