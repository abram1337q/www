"use client";

import type { ReactNode } from "react";
import type { PageType } from "@/app/page";
import { BottomNavigation } from "./BottomNavigation";
import { Header } from "./Header";

import { motion } from "framer-motion";
import { useTelegram } from "@/components/providers/TelegramProvider";

// Функция для определения iPhone
const isIPhone = () => {
  if (typeof window === 'undefined') return false;
  return /iPhone|iPad|iPod/.test(navigator.userAgent) ||
         (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
};

interface MainLayoutProps {
  children: ReactNode;
  currentPage: PageType;
  onPageChange: (page: PageType) => void;
  hideBottomNav?: boolean;
}

export const MainLayout = ({ children, currentPage, onPageChange, hideBottomNav }: MainLayoutProps) => {
  const { isFullscreen } = useTelegram();
  const isIPhoneDevice = isIPhone();

  return (
    <div className={`bg-background flex flex-col ${isFullscreen ? 'fullscreen-app' : 'min-h-screen'}`}
         style={{ height: '100vh', overflow: 'hidden' }}>
      <Header currentPage={currentPage} isFullscreen={isFullscreen} />

      <motion.main
        className="flex-1 overflow-y-auto"
        style={{
          height: isIPhoneDevice ? 'calc(100vh - 100px)' : 'calc(100vh - 70px)',
          paddingBottom: hideBottomNav ? '0px' : '80px',
          marginTop: isIPhoneDevice ? '30px' : '0'
        }}
        key={currentPage}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.2 }}
      >
        {children}
      </motion.main>

      {!hideBottomNav && (
        <BottomNavigation
          currentPage={currentPage}
          onPageChange={onPageChange}
          isFullscreen={isFullscreen}
        />
      )}
    </div>
  );
};
