"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useUserGuideI18n } from "@/components/providers/UserGuideI18nProvider";
import {
  X,
  BookOpen,
  Target,
  Users,
  Coins,
  TrendingUp,
  Shield,
  Gift,
  Globe,
  MessageCircle,
  Settings,
  HelpCircle,
  ArrowRight,
  Check,
  ChevronDown,
  ChevronRight
} from "lucide-react";

interface UserGuideModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const UserGuideModal = ({ open, onOpenChange }: UserGuideModalProps) => {
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const { t } = useUserGuideI18n();

  const toggleSection = (sectionId: string) => {
    setActiveSection(activeSection === sectionId ? null : sectionId);
  };

  const sections = [
    { id: "intro", title: t('section_intro'), icon: BookOpen },
    { id: "how-it-works", title: t('section_how_it_works'), icon: Target },
    { id: "pages", title: t('section_pages'), icon: Globe },
    { id: "balance", title: t('section_balance'), icon: Coins },
    { id: "referral", title: t('section_referral'), icon: Gift },
  ];

  const renderContent = () => {
    if (!activeSection) return null;

    switch (activeSection) {
      case "intro":
        return (
          <div className="space-y-4">
            <div className="p-4 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl border border-white/10">
              <h3 className="font-bold text-lg mb-2 flex items-center space-x-2">
                <Shield className="h-5 w-5 text-blue-400" />
                <span>{t('intro_what_is_title')}</span>
              </h3>
              <p className="text-sm text-foreground/80 leading-relaxed mb-3">
                {t('intro_description_1')}
              </p>
              <p className="text-sm text-foreground/80 leading-relaxed">
                {t('intro_description_2')}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3">
              <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-400" />
                  <span className="font-medium text-sm">{t('intro_point_1')}</span>
                </div>
              </div>
              <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-400" />
                  <span className="font-medium text-sm">{t('intro_point_2')}</span>
                </div>
              </div>
              <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-400" />
                  <span className="font-medium text-sm">{t('intro_point_3')}</span>
                </div>
                <p className="text-xs text-foreground/70 mt-1">
                  {t('intro_point_3_desc')}
                </p>
              </div>
            </div>

            <div className="p-4 bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-xl border border-white/10">
              <h4 className="font-bold text-sm mb-2 text-green-400">{t('intro_example_title')}</h4>
              <p className="text-sm text-foreground/80 leading-relaxed">
                {t('intro_example_text')}
              </p>
            </div>
          </div>
        );

      case "how-it-works":
        return (
          <div className="space-y-4">
            <h3 className="font-bold text-lg mb-3 flex items-center space-x-2">
              <Target className="h-5 w-5 text-purple-400" />
              <span>{t('how_it_works_title')}</span>
            </h3>

            <div className="space-y-3">
              {[
                t('how_it_works_step_1'),
                t('how_it_works_step_2'),
                t('how_it_works_step_3'),
                t('how_it_works_step_4'),
                t('how_it_works_step_5')
              ].map((step, index) => (
                <div key={index} className="flex items-start space-x-3 p-3 bg-white/5 rounded-lg border border-white/10">
                  <div className="w-6 h-6 min-w-[24px] bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5 flex-shrink-0">
                    {index + 1}
                  </div>
                  <p className="text-sm text-foreground/80 leading-relaxed">{step}</p>
                </div>
              ))}
            </div>

            <div className="p-4 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-xl border border-white/10">
              <h4 className="font-bold text-sm mb-2 text-yellow-400">{t('bet_statuses_title')}</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">{t('status_active')}</Badge>
                  <span className="text-xs text-foreground/70">{t('status_active_desc')}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30">{t('status_won')}</Badge>
                  <span className="text-xs text-foreground/70">{t('status_won_desc')}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-red-500/20 text-red-400 border-red-500/30">{t('status_lost')}</Badge>
                  <span className="text-xs text-foreground/70">{t('status_lost_desc')}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30">{t('status_refund')}</Badge>
                  <span className="text-xs text-foreground/70">{t('status_refund_desc')}</span>
                </div>
              </div>
            </div>
          </div>
        );

      case "pages":
        return (
          <div className="space-y-4">
            <h3 className="font-bold text-lg mb-3 flex items-center space-x-2">
              <Globe className="h-5 w-5 text-blue-400" />
              <span>{t('pages_title')}</span>
            </h3>

            <div className="space-y-3">
              <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                <h4 className="font-bold text-sm mb-2 text-blue-400">{t('page_home_title')}</h4>
                <ul className="text-xs text-foreground/70 space-y-1">
                  <li>{t('page_home_1')}</li>
                  <li>{t('page_home_2')}</li>
                  <li>{t('page_home_3')}</li>
                  <li>{t('page_home_4')}</li>
                </ul>
              </div>

              <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                <h4 className="font-bold text-sm mb-2 text-purple-400">{t('page_bets_title')}</h4>
                <ul className="text-xs text-foreground/70 space-y-1">
                  <li>{t('page_bets_1')}</li>
                  <li>{t('page_bets_2')}</li>
                  <li>{t('page_bets_3')}</li>
                  <li>{t('page_bets_4')}</li>
                </ul>
              </div>

              <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                <h4 className="font-bold text-sm mb-2 text-green-400">{t('page_create_title')}</h4>
                <ul className="text-xs text-foreground/70 space-y-1">
                  <li>{t('page_create_1')}</li>
                  <li>{t('page_create_2')}</li>
                  <li>{t('page_create_3')}</li>
                  <li>{t('page_create_4')}</li>
                </ul>
              </div>

              <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                <h4 className="font-bold text-sm mb-2 text-yellow-400">{t('page_my_title')}</h4>
                <ul className="text-xs text-foreground/70 space-y-1">
                  <li>{t('page_my_1')}</li>
                  <li>{t('page_my_2')}</li>
                  <li>{t('page_my_3')}</li>
                </ul>
              </div>

              <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                <h4 className="font-bold text-sm mb-2 text-pink-400">{t('page_chat_title')}</h4>
                <ul className="text-xs text-foreground/70 space-y-1">
                  <li>{t('page_chat_1')}</li>
                  <li>{t('page_chat_2')}</li>
                  <li>{t('page_chat_3')}</li>
                </ul>
              </div>

              <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                <h4 className="font-bold text-sm mb-2 text-orange-400">{t('page_menu_title')}</h4>
                <ul className="text-xs text-foreground/70 space-y-1">
                  <li>{t('page_menu_1')}</li>
                  <li>{t('page_menu_2')}</li>
                  <li>{t('page_menu_3')}</li>
                  <li>{t('page_menu_4')}</li>
                  <li>{t('page_menu_5')}</li>
                </ul>
              </div>
            </div>
          </div>
        );

      case "balance":
        return (
          <div className="space-y-4">
            <h3 className="font-bold text-lg mb-3 flex items-center space-x-2">
              <Coins className="h-5 w-5 text-blue-400" />
              <span>{t('balance_title')}</span>
            </h3>

            <div className="p-4 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-xl border border-white/10">
              <h4 className="font-bold text-sm mb-2 text-blue-400">{t('deposit_title')}</h4>
              <ol className="text-sm text-foreground/80 space-y-2">
                <li className="flex items-start space-x-2">
                  <span className="w-5 h-5 min-w-[20px] bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5 flex-shrink-0">1</span>
                  <span>{t('deposit_step_1')}</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="w-5 h-5 min-w-[20px] bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5 flex-shrink-0">2</span>
                  <span>{t('deposit_step_2')}</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="w-5 h-5 min-w-[20px] bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5 flex-shrink-0">3</span>
                  <span>{t('deposit_step_3')}</span>
                </li>
              </ol>
            </div>

            <div className="p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-xl border border-white/10">
              <h4 className="font-bold text-sm mb-2 text-purple-400">{t('withdrawal_title')}</h4>
              <ol className="text-sm text-foreground/80 space-y-2">
                <li className="flex items-start space-x-2">
                  <span className="w-5 h-5 min-w-[20px] bg-purple-500 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5 flex-shrink-0">1</span>
                  <span>{t('withdrawal_step_1')}</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="w-5 h-5 min-w-[20px] bg-purple-500 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5 flex-shrink-0">2</span>
                  <span>{t('withdrawal_step_2')}</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="w-5 h-5 min-w-[20px] bg-purple-500 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5 flex-shrink-0">3</span>
                  <span>{t('withdrawal_step_3')}</span>
                </li>
              </ol>
            </div>

            <div className="p-3 bg-white/5 rounded-lg border border-white/10">
              <div className="flex items-center space-x-2 mb-2">
                <Shield className="h-4 w-4 text-green-400" />
                <span className="font-medium text-sm text-green-400">{t('security_title')}</span>
              </div>
              <p className="text-xs text-foreground/70">
                {t('security_desc')}
              </p>
            </div>
          </div>
        );

      case "referral":
        return (
          <div className="space-y-4">
            <h3 className="font-bold text-lg mb-3 flex items-center space-x-2">
              <Gift className="h-5 w-5 text-purple-400" />
              <span>{t('referral_title')}</span>
            </h3>

            <div className="p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-xl border border-white/10">
              <div className="text-center mb-4">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Gift className="h-8 w-8 text-white" />
                </div>
                <h4 className="font-bold text-lg text-purple-400 mb-2">{t('referral_main_title')}</h4>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-8 h-8 min-w-[32px] bg-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">1</div>
                  <span className="text-sm">{t('referral_step_1')}</span>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-8 h-8 min-w-[32px] bg-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">2</div>
                  <span className="text-sm">{t('referral_step_2')}</span>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-8 h-8 min-w-[32px] bg-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">3</div>
                  <span className="text-sm">{t('referral_step_3')}</span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-white/5 rounded-lg border border-white/10">
              <p className="text-xs text-foreground/70 text-center">
                {t('referral_tip')}
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[95vw] max-h-[85vh] p-0 gap-0 bg-background/95 backdrop-blur-lg border border-white/10 rounded-2xl shadow-2xl mx-2">
        <DialogHeader className="p-4 pb-2">
          <DialogTitle className="flex items-center space-x-2 text-lg">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
              <BookOpen className="h-4 w-4 text-white" />
            </div>
            <span className="bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text text-base">
              {t('modal_title')}
            </span>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 px-4 pb-4">
          <ScrollArea className="h-full max-h-[65vh]">
            <div className="space-y-2">
              {sections.map((section, index) => (
                <div
                  key={section.id}
                  className="border border-white/10 bg-white/5 backdrop-blur-sm rounded-xl overflow-hidden"
                >
                  <Button
                    variant="ghost"
                    className="w-full p-4 h-auto justify-between hover:bg-white/10 rounded-xl"
                    onClick={() => toggleSection(section.id)}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        activeSection === section.id
                          ? "bg-gradient-to-r from-blue-500 to-purple-500"
                          : "bg-white/10"
                      }`}>
                        <section.icon className={`h-4 w-4 ${
                          activeSection === section.id ? "text-white" : "text-blue-400"
                        }`} />
                      </div>
                      <span className="font-medium text-sm text-left">{section.title}</span>
                    </div>
                    {activeSection === section.id ? (
                      <ChevronDown className="h-4 w-4 text-foreground/70" />
                    ) : (
                      <ChevronRight className="h-4 w-4 text-foreground/70" />
                    )}
                  </Button>

                  {activeSection === section.id && (
                    <div className="px-4 pb-4">
                      <Separator className="mb-4 bg-white/10" />
                      {renderContent()}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>

        <div className="p-4 pt-0 flex justify-end">
          <Button
            onClick={() => onOpenChange(false)}
            className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white border-none rounded-xl px-6"
          >
            {t('close_button')}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
