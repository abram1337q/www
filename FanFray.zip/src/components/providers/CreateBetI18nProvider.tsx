"use client";
import type React from "react";
import { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  selected_match: "Выбранный матч",
  currency: "Валюта",
  amount: "Сумма",
  outcome: "Прогноз",
  comment_optional: "Комментарий (необязательно)",
  comment_placeholder: "Ваш комментарий к спору...",
  create_bet: "Создать спор",
  confirm_bet: "Подтвердить спор",
  creating: "Создание...",
  change: "Изменить",
  bet_details: "Детали спора",
  match: "Матч:",
  league: "Лига:",
  time: "Время:",
  prediction: "Прогноз:",
  sum_label: "Сумма:",
  minimum_label_short: "мин.",
  minimum_amount_inline: "Минимальная сумма: {min} {currency} (~${usdMin})",
  minimum_placeholder: "Минимум {min} {currency} (~${usdMin})",
  global_minimum_note: "Минимальная сумма {usdMin}$ в TON",
  choose_prediction: "Выберите прогноз",
  p1_win: "П1 - Победа {homeTeam}",
  draw: "X - Ничья",
  p2_win: "П2 - Победа {awayTeam}",
  auth_error: "Ошибка авторизации. Перезапустите приложение.",
  created_success: "Спор успешно создан!",
  validation_error_prefix: "Ошибка валидации:\n{details}",
  error_generic: "Ошибка: {message}",
  error_create_generic: "Произошла ошибка при создании спора",
  select_match: "Выбрать матч",
  no_match_selected_hint: "Сначала выберите матч",
  min_btn: "MIN",
  max_btn: "MAX",
  loading_settings: "Загрузка...",
  balance_ton: "Баланс TON",
};

const en: Dict = {
  selected_match: "Selected match",
  currency: "Currency",
  amount: "Amount",
  outcome: "Prediction",
  comment_optional: "Comment (optional)",
  comment_placeholder: "Your comment for the bet...",
  create_bet: "Create bet",
  confirm_bet: "Confirm bet",
  creating: "Creating...",
  change: "Change",
  bet_details: "Bet details",
  match: "Match:",
  league: "League:",
  time: "Time:",
  prediction: "Prediction:",
  sum_label: "Amount:",
  minimum_label_short: "min.",
  minimum_amount_inline: "Minimum amount: {min} {currency} (~${usdMin})",
  minimum_placeholder: "Minimum {min} {currency} (~${usdMin})",
  global_minimum_note: "Minimum amount is ${usdMin} in TON",
  choose_prediction: "Choose a prediction",
  p1_win: "H1 - {homeTeam} to win",
  draw: "Draw",
  p2_win: "H2 - {awayTeam} to win",
  auth_error: "Authorization error. Please restart the app.",
  created_success: "Bet created successfully!",
  validation_error_prefix: "Validation error:\n{details}",
  error_generic: "Error: {message}",
  error_create_generic: "An error occurred while creating the bet",
  select_match: "Select match",
  no_match_selected_hint: "Please select a match first",
  min_btn: "MIN",
  max_btn: "MAX",
  loading_settings: "Loading...",
  balance_ton: "TON Balance",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const CreateBetI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();

  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);

  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useCreateBetI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCreateBetI18n must be used within CreateBetI18nProvider");
  return ctx;
};
