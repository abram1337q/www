"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  header_title: "Вывод TON",
  header_sub: "Быстро и безопасно",
  tab_withdraw: "Вывод",
  tab_history: "История",
  withdraw_title: "Вывод средств",
  withdraw_desc: "Создайте запрос на вывод. Он будет автоматически обработан в течение нескольких минут.",
  amount_label: "Сумма для вывода",
  available: "Доступно: {balance} TON",
  wallet_label: "Адрес кошелька",
  wallet_hint: "Введите адрес TON кошелька для вывода средств",
  summary_amount: "Сумма:",
  summary_fee: "Комиссия:",
  summary_receive: "К получению:",
  create_request: "Создать запрос на вывод",
  history_title: "История выводов",
  history_empty: "История пуста",
  auto_withdraw: "Автовывод",
  status_completed: "Завершен",
  status_pending: "Ожидает",
  status_processing: "В обработке",
  status_failed: "Ошибка",
  fee_label: "Комиссия: {fee} TON",
  hash_label: "Hash: {hash}",
  error_invalid_amount: "Неверная сумма для вывода",
  success_created: "Запрос на вывод создан успешно!",
  error_timeout: "Запрос превысил время ожидания. Попробуйте еще раз.",
  error_create: "Ошибка при создании запроса на вывод. Проверьте соединение.",
};

const en: Dict = {
  header_title: "Withdraw TON",
  header_sub: "Fast and secure",
  tab_withdraw: "Withdraw",
  tab_history: "History",
  withdraw_title: "Withdraw funds",
  withdraw_desc: "Create a withdrawal request. It will be processed automatically within a few minutes.",
  amount_label: "Amount to withdraw",
  available: "Available: {balance} TON",
  wallet_label: "Wallet address",
  wallet_hint: "Enter TON wallet address to withdraw to",
  summary_amount: "Amount:",
  summary_fee: "Fee:",
  summary_receive: "To receive:",
  create_request: "Create withdrawal request",
  history_title: "Withdrawal history",
  history_empty: "No history",
  auto_withdraw: "Auto-withdraw",
  status_completed: "Completed",
  status_pending: "Pending",
  status_processing: "Processing",
  status_failed: "Failed",
  fee_label: "Fee: {fee} TON",
  hash_label: "Hash: {hash}",
  error_invalid_amount: "Invalid amount to withdraw",
  success_created: "Withdrawal request created successfully!",
  error_timeout: "Request timed out. Please try again.",
  error_create: "Error creating withdrawal request. Check connection.",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const TonWithdrawalI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();
  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);
  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useTonWithdrawalI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useTonWithdrawalI18n must be used within TonWithdrawalI18nProvider");
  return ctx;
};
