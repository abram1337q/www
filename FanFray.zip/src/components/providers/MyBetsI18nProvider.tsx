"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type MyBetsDict = Record<string, string>;

const myBetsRu: MyBetsDict = {
  // Statistics
  loading_bets: "Загрузка ваших споров...",
  error_loading: "Ошибка загрузки данных",
  try_again: "Попробовать снова",
  win_rate: "Процент побед",
  won_bets_count: "Выигранных споров",
  out_of_finished: "из завершенных споров",

  // Status filters
  all: "Все",
  active: "Активный",
  won: "Выигран",
  lost: "Проигран",
  refunded: "Возврат",
  cancelled: "Отменен",

  // Bet card
  vs: "vs",
  prediction: "Прогноз",
  amount: "Сумма",
  participants: "Участники",
  bet_status: "Статус спора",
  final_score: "Итоговый счет:",
  payout: "Выплата:",
  refund_amount: "Возврат средств:",
  refund_reason: "Средства возвращены на ваш баланс, так как к спору никто не присоединился",

  // Bet status texts
  status_won: "Выигран",
  status_lost: "Проигран",
  status_refunded: "Возврат",
  status_active: "Активный",
  status_cancelled: "Отменен",
  status_unknown: "Неизвестно",

  // Detailed status
  status_waiting: "В ожидании",
  status_completed: "Завершен",
  status_refund_money: "Возврат средств",

  // Actions
  repeat_bet: "Повторить спор",
  view_details: "Подробности",

  // Match status
  date_not_specified: "Дата не указана",
  finished: "Завершен",
  match_live: "Идет",
  match_in_progress: "Идет матч",
  match_finished: "Матч завершен",
  match_cancelled: "Отменен",
  match_postponed: "Отложен",
  today_at: "Сегодня",
  tomorrow_at: "Завтра",
  waiting_result: "Ожидание результата",

  // Empty states
  no_bets: "У вас пока нет споров",
  no_bets_with_status: "Нет споров со статусом",
  show_all_bets: "Показать все споры",

  // Prediction types
  home_win: "П1 - победа",
  away_win: "П2 - победа",
  draw: "X - Ничья",
  over: "Больше",
  under: "Меньше",
  both_teams_score: "Обе забьют",
  both_teams_not_score: "Обе не забьют",
  home_team: "П1",
  away_team: "П2",
};

const myBetsEn: MyBetsDict = {
  // Statistics
  loading_bets: "Loading your bets...",
  error_loading: "Error loading data",
  try_again: "Try again",
  win_rate: "Win Rate",
  won_bets_count: "Won Bets",
  out_of_finished: "out of finished bets",

  // Status filters
  all: "All",
  active: "Active",
  won: "Won",
  lost: "Lost",
  refunded: "Refunded",
  cancelled: "Cancelled",

  // Bet card
  vs: "vs",
  prediction: "Prediction",
  amount: "Amount",
  participants: "Participants",
  bet_status: "Bet Status",
  final_score: "Final Score:",
  payout: "Payout:",
  refund_amount: "Refund:",
  refund_reason: "Funds returned to your balance as no one joined the bet",

  // Bet status texts
  status_won: "Won",
  status_lost: "Lost",
  status_refunded: "Refunded",
  status_active: "Active",
  status_cancelled: "Cancelled",
  status_unknown: "Unknown",

  // Detailed status
  status_waiting: "Waiting",
  status_completed: "Completed",
  status_refund_money: "Refunded",

  // Actions
  repeat_bet: "Repeat Bet",
  view_details: "Details",

  // Match status
  date_not_specified: "Date not specified",
  finished: "Finished",
  match_live: "Live",
  match_in_progress: "Live Match",
  match_finished: "Match Finished",
  match_cancelled: "Cancelled",
  match_postponed: "Postponed",
  today_at: "Today",
  tomorrow_at: "Tomorrow",
  waiting_result: "Awaiting Result",

  // Empty states
  no_bets: "You have no bets yet",
  no_bets_with_status: "No bets with status",
  show_all_bets: "Show all bets",

  // Prediction types
  home_win: "Home Win",
  away_win: "Away Win",
  draw: "Draw",
  over: "Over",
  under: "Under",
  both_teams_score: "Both Teams Score",
  both_teams_not_score: "Both Teams Not Score",
  home_team: "Home",
  away_team: "Away",
};

const myBetsDicts = { ru: myBetsRu, en: myBetsEn };

type MyBetsI18nContextType = {
  t: (key: string) => string;
};

const MyBetsI18nContext = createContext<MyBetsI18nContextType | undefined>(undefined);

export const MyBetsI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();

  const t = useCallback((key: string) => {
    const dict = myBetsDicts[lang] || myBetsEn;
    return dict[key] ?? key;
  }, [lang]);

  const value = useMemo(() => ({ t }), [t]);

  return <MyBetsI18nContext.Provider value={value}>{children}</MyBetsI18nContext.Provider>;
};

// Функция для перевода типов прогнозов
export const translatePrediction = (predictionText: string, t: (key: string) => string): string => {
  if (!predictionText) return predictionText;

  const lowerText = predictionText.toLowerCase();

  // Точные совпадения
  if (lowerText.includes('п1') && lowerText.includes('побед')) return t('home_win');
  if (lowerText.includes('п2') && lowerText.includes('побед')) return t('away_win');
  if (lowerText === 'x - ничья' || lowerText === 'draw' || lowerText.includes('ничь')) return t('draw');
  if (lowerText.includes('больше') || lowerText.includes('over')) return t('over');
  if (lowerText.includes('меньше') || lowerText.includes('under')) return t('under');
  if (lowerText.includes('обе заб') || lowerText.includes('both') && lowerText.includes('score') && !lowerText.includes('not')) return t('both_teams_score');
  if (lowerText.includes('обе не заб') || (lowerText.includes('both') && lowerText.includes('not'))) return t('both_teams_not_score');

  // Для коротких форматов
  if (predictionText === 'П1' || predictionText === 'Home' || predictionText === 'home') return t('home_team');
  if (predictionText === 'П2' || predictionText === 'Away' || predictionText === 'away') return t('away_team');
  if (predictionText === 'X' || predictionText === 'x') return t('draw');

  // Если не найдено совпадение, возвращаем оригинальный текст
  return predictionText;
};

export const useMyBetsI18n = () => {
  const ctx = useContext(MyBetsI18nContext);
  if (!ctx) throw new Error("useMyBetsI18n must be used within MyBetsI18nProvider");
  return ctx;
};
