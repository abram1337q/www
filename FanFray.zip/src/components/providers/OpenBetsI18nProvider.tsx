"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  active_count: "{count} активных",
  all_currencies: "Все валюты",
  swipe_to_sort: "Свайп для сортировки",
  sort_time: "По времени",
  sort_amount: "По сумме",
  total_bets: "Всего споров",
  ton_in_game: "TON в игре",
  stars_in_game: "STARS в игре",
  loading_bets: "Загрузка споров...",
  anonymous: "Анонимный",
  unavailable: "Недоступно",
  join: "Присоединиться",
  participants: "участников",
  potential_win: "Потенциальный выигрыш:",
  no_open_bets: "Нет открытых споров с выбранными фильтрами",
  reset_filters: "Сбросить фильтры",
  auth_error: "Ошибка авторизации. Перезапустите приложение.",
  cannot_join: "Невозможно присоединиться к спору",
  details_title: "Детали спора #{id}",
  details_match: "Матч: {home} vs {away}",
  details_league: "Лига: {league}",
  details_time: "Время: {time}",
  details_prediction: "Прогноз: {prediction}",
  details_amount: "Сумма: {amount} {currency}",
  details_creator: "Создатель: {creator}",
  details_participants: "Участники: {current}/{max}",
  details_match_status: "Статус матча: {status}",
  details_comment: "Комментарий: {comment}",
  // match status
  halftime: "Перерыв",
  finished: "ЗАВЕРШЕН",
  soon: "СКОРО",
  in_minutes: "через {m}м",
  in_hours_minutes: "через {h}ч {m}м",
  // outcomes mapping as in MyBets cards (keep RU originals visible when RU)
  outcome_h1: "П1 - Победа {homeTeam}",
  outcome_draw: "X - Ничья",
  outcome_h2: "П2 - Победа {awayTeam}",
};

const en: Dict = {
  active_count: "{count} active",
  all_currencies: "All currencies",
  swipe_to_sort: "Swipe to sort",
  sort_time: "By time",
  sort_amount: "By amount",
  total_bets: "Total bets",
  ton_in_game: "TON in play",
  stars_in_game: "STARS in play",
  loading_bets: "Loading bets...",
  anonymous: "Anonymous",
  unavailable: "Unavailable",
  join: "Join",
  participants: "participants",
  potential_win: "Potential win:",
  no_open_bets: "No open bets with current filters",
  reset_filters: "Reset filters",
  auth_error: "Authorization error. Please restart the app.",
  cannot_join: "Cannot join the bet",
  details_title: "Bet details #{id}",
  details_match: "Match: {home} vs {away}",
  details_league: "League: {league}",
  details_time: "Time: {time}",
  details_prediction: "Prediction: {prediction}",
  details_amount: "Amount: {amount} {currency}",
  details_creator: "Creator: {creator}",
  details_participants: "Participants: {current}/{max}",
  details_match_status: "Match status: {status}",
  details_comment: "Comment: {comment}",
  halftime: "Half-time",
  finished: "FINISHED",
  soon: "SOON",
  in_minutes: "in {m}m",
  in_hours_minutes: "in {h}h {m}m",
  // outcomes mapping same as MyBets cards EN
  outcome_h1: "H1 - {homeTeam} to win",
  outcome_draw: "Draw",
  outcome_h2: "H2 - {awayTeam} to win",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const OpenBetsI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();

  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);

  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useOpenBetsI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useOpenBetsI18n must be used within OpenBetsI18nProvider");
  return ctx;
};
