"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
}

interface TelegramWebApp {
  ready: () => void;
  expand: () => void;
  colorScheme: string;
  isFullscreen: boolean;
  isActive: boolean;
  viewportHeight: number;
  safeAreaInset: {
    top: number;
    bottom: number;
    left: number;
    right: number;
  };
  contentSafeAreaInset: {
    top: number;
    bottom: number;
    left: number;
    right: number;
  };
  initDataUnsafe?: {
    user?: TelegramUser;
    start_param?: string;
  };
  MainButton: {
    color: string;
    textColor: string;
  };
  onEvent: (event: string, callback: () => void) => void;
  openLink?: (url: string) => void;
  requestFullscreen?: () => void;
  exitFullscreen?: () => void;
}

interface TelegramContextType {
  webApp: TelegramWebApp | null;
  user: TelegramUser | null;
  isReady: boolean;
  theme: "light" | "dark";
  isFullscreen: boolean;
  isActive: boolean;
  safeAreaInset: {
    top: number;
    bottom: number;
    left: number;
    right: number;
  };
  contentSafeAreaInset: {
    top: number;
    bottom: number;
    left: number;
    right: number;
  };
}

const TelegramContext = createContext<TelegramContextType>({
  webApp: null,
  user: null,
  isReady: false,
  theme: "light",
  isFullscreen: false,
  isActive: true,
  safeAreaInset: { top: 0, bottom: 0, left: 0, right: 0 },
  contentSafeAreaInset: { top: 0, bottom: 0, left: 0, right: 0 },
});

export const useTelegram = () => useContext(TelegramContext);

interface TelegramProviderProps {
  children: ReactNode;
}

export const TelegramProvider = ({ children }: TelegramProviderProps) => {
  const [webApp, setWebApp] = useState<TelegramWebApp | null>(null);
  const [user, setUser] = useState<TelegramUser | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isActive, setIsActive] = useState(true);
  const [safeAreaInset, setSafeAreaInset] = useState({ top: 0, bottom: 0, left: 0, right: 0 });
  const [contentSafeAreaInset, setContentSafeAreaInset] = useState({ top: 0, bottom: 0, left: 0, right: 0 });

  useEffect(() => {
    if (typeof window === "undefined") return;

    // Функция для установки CSS переменных safe area
    const updateSafeAreaVars = (
      safeArea: { top: number; bottom: number; left: number; right: number },
      contentSafeArea?: { top: number; bottom: number; left: number; right: number }
    ) => {
      document.documentElement.style.setProperty('--tg-safe-area-inset-top', `${safeArea.top}px`);
      document.documentElement.style.setProperty('--tg-safe-area-inset-bottom', `${safeArea.bottom}px`);
      document.documentElement.style.setProperty('--tg-safe-area-inset-left', `${safeArea.left}px`);
      document.documentElement.style.setProperty('--tg-safe-area-inset-right', `${safeArea.right}px`);

      if (contentSafeArea) {
        document.documentElement.style.setProperty('--tg-content-safe-area-inset-top', `${contentSafeArea.top}px`);
        document.documentElement.style.setProperty('--tg-content-safe-area-inset-bottom', `${contentSafeArea.bottom}px`);
        document.documentElement.style.setProperty('--tg-content-safe-area-inset-left', `${contentSafeArea.left}px`);
        document.documentElement.style.setProperty('--tg-content-safe-area-inset-right', `${contentSafeArea.right}px`);
      }
    };

    // Функция инициализации Telegram WebApp
    const initTelegramWebApp = (tg: TelegramWebApp) => {
      console.log('🚀 Инициализация Telegram WebApp');

      // Инициализируем Telegram WebApp
      if (tg.ready) tg.ready();
      if (tg.expand) tg.expand();

      setWebApp(tg);
      setUser(tg.initDataUnsafe?.user || null);
      setTheme(tg.colorScheme === "dark" ? "dark" : "light");

      // Устанавливаем начальные значения
      setIsFullscreen(Boolean(tg.isFullscreen));
      setIsActive(Boolean(tg.isActive));

      const defaultSafeArea = tg.safeAreaInset || { top: 0, bottom: 0, left: 0, right: 0 };
      const defaultContentSafeArea = tg.contentSafeAreaInset || { top: 0, bottom: 0, left: 0, right: 0 };

      setSafeAreaInset(defaultSafeArea);
      setContentSafeAreaInset(defaultContentSafeArea);
      updateSafeAreaVars(defaultSafeArea, defaultContentSafeArea);

      // Полноэкранный режим отключен - пусть пользователь сам решает
      // if (tg.requestFullscreen && !tg.isFullscreen) {
      //   try {
      //     tg.requestFullscreen();
      //   } catch (error) {
      //     console.log("Не удалось включить полноэкранный режим:", error);
      //   }
      // }

      // Настройка главной кнопки
      tg.MainButton.color = "#3b82f6";
      tg.MainButton.textColor = "#ffffff";

      // Обработчики событий
      tg.onEvent("themeChanged", () => {
        setTheme(tg.colorScheme === "dark" ? "dark" : "light");
      });

      tg.onEvent("viewportChanged", () => {
        const newSafeArea = tg.safeAreaInset || { top: 0, bottom: 0, left: 0, right: 0 };
        const newContentSafeArea = tg.contentSafeAreaInset || { top: 0, bottom: 0, left: 0, right: 0 };
        setSafeAreaInset(newSafeArea);
        setContentSafeAreaInset(newContentSafeArea);
        updateSafeAreaVars(newSafeArea, newContentSafeArea);
      });

      // Новые обработчики событий согласно документации
      tg.onEvent("activated", () => {
        setIsActive(true);
        console.log("TMA активировано");
      });

      tg.onEvent("deactivated", () => {
        setIsActive(false);
        console.log("TMA деактивировано");
      });

      tg.onEvent("safeAreaChanged", () => {
        const newSafeArea = tg.safeAreaInset || { top: 0, bottom: 0, left: 0, right: 0 };
        setSafeAreaInset(newSafeArea);
        updateSafeAreaVars(newSafeArea, tg.contentSafeAreaInset);
        console.log("Safe area изменено:", newSafeArea);
      });

      tg.onEvent("contentSafeAreaChanged", () => {
        const newContentSafeArea = tg.contentSafeAreaInset || { top: 0, bottom: 0, left: 0, right: 0 };
        setContentSafeAreaInset(newContentSafeArea);
        updateSafeAreaVars(tg.safeAreaInset, newContentSafeArea);
        console.log("Content safe area изменено:", newContentSafeArea);
      });

      tg.onEvent("fullscreenChanged", () => {
        const newFullscreen = Boolean(tg.isFullscreen);
        setIsFullscreen(newFullscreen);
        console.log("Полноэкранный режим изменен:", newFullscreen);
      });

      tg.onEvent("fullscreenFailed", () => {
        console.log("Не удалось изменить полноэкранный режим");
        // Пробуем альтернативный способ - expand
        if (tg.expand) {
          tg.expand();
        }
      });

      // Даем небольшую задержку для полной инициализации Telegram данных
      setTimeout(() => {
        // Повторно проверяем пользователя перед установкой isReady
        const finalUser = tg.initDataUnsafe?.user;
        if (finalUser && finalUser.username) {
          console.log('🔄 Обновляем данные пользователя после задержки:', finalUser);
          setUser(finalUser);
        }
        setIsReady(true);
        console.log('✅ TelegramProvider готов');
      }, 200);
    };

    // Функция инициализации для режима разработки (без Telegram)
    const initDevMode = () => {
      console.log('🔧 Режим разработки (без Telegram)');
      const devSafeArea = { top: 60, bottom: 34, left: 0, right: 0 };
      const devContentSafeArea = { top: 60, bottom: 34, left: 0, right: 0 };

      setIsReady(true);
      setIsFullscreen(window.innerHeight >= screen.height * 0.9);
      setIsActive(true);
      setSafeAreaInset(devSafeArea);
      setContentSafeAreaInset(devContentSafeArea);
      updateSafeAreaVars(devSafeArea, devContentSafeArea);

      // Убираем тестового пользователя - в продакшене не нужен
      setUser(null);
    };

    // Ожидание загрузки скрипта telegram-web-app.js
    const MAX_WAIT_TIME = 5000; // Максимальное время ожидания - 5 секунд
    const CHECK_INTERVAL = 50; // Проверяем каждые 50ms
    let elapsed = 0;

    const checkTelegramReady = () => {
      const tg = window.Telegram?.WebApp;

      if (tg) {
        // Скрипт загружен, инициализируем
        const typedTg = tg as unknown as TelegramWebApp;
        initTelegramWebApp(typedTg);
        return;
      }

      elapsed += CHECK_INTERVAL;

      if (elapsed >= MAX_WAIT_TIME) {
        // Время ожидания истекло, переходим в режим разработки
        console.warn('⚠️ Telegram WebApp не загружен за 5 секунд, переходим в режим разработки');
        initDevMode();
        return;
      }

      // Продолжаем ждать
      setTimeout(checkTelegramReady, CHECK_INTERVAL);
    };

    // Начинаем проверку
    checkTelegramReady();
  }, []);

  return (
    <TelegramContext.Provider value={{
      webApp,
      user,
      isReady,
      theme,
      isFullscreen,
      isActive,
      safeAreaInset,
      contentSafeAreaInset
    }}>
      {children}
    </TelegramContext.Provider>
  );
};
