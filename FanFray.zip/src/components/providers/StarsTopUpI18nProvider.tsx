"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  header_title: "Пополнение Stars",
  header_sub: "Мгновенное пополнение",
  success_title: "Платеж успешен!",
  success_desc: "Баланс обновляется автоматически",
  error_title: "Ошибка",
  choose_package: "Выберите пакет Stars",
  or_enter_amount: "Или введите свою сумму",
  amount_placeholder: "1 - 10,000",
  rate_note: "1 Stars ≈ $0.01 USD • Без дополнительных комиссий",
  info_instant: "Мгновенно",
  info_secure: "Безопасно",
  info_no_fees: "Без комиссий",
  creating_payment: "Создание платежа...",
  topup_btn: "Пополнить {amount} Stars",
  error_not_auth: "Пользователь не авторизован",
  error_min: "Минимальная сумма пополнения 1 Star",
  error_max: "Максимальная сумма пополнения 10,000 Stars",
  error_create_invoice: "Не удалось создать платеж",
  error_payment_failed: "Ошибка при обработке платежа",
  error_payment_pending: "Платеж обрабатывается, попробуйте позже",
  error_unknown_status: "Неизвестный статус платежа: {status}",
  error_no_link: "Не удалось получить ссылку для оплаты",
  error_generic: "Произошла ошибка",
  connect_close: "Закрыть",
  pkg_start: "Старт",
  pkg_popular: "Популярно",
  pkg_value: "Выгодно",
  pkg_premium: "Премиум",
};

const en: Dict = {
  header_title: "Top up Stars",
  header_sub: "Instant top up",
  success_title: "Payment successful!",
  success_desc: "Balance updates automatically",
  error_title: "Error",
  choose_package: "Choose a Stars package",
  or_enter_amount: "Or enter your amount",
  amount_placeholder: "1 - 10,000",
  rate_note: "1 Stars ≈ $0.01 USD • No extra fees",
  info_instant: "Instant",
  info_secure: "Secure",
  info_no_fees: "No fees",
  creating_payment: "Creating payment...",
  topup_btn: "Top up {amount} Stars",
  error_not_auth: "User is not authorized",
  error_min: "Minimum top up is 1 Star",
  error_max: "Maximum top up is 10,000 Stars",
  error_create_invoice: "Failed to create payment",
  error_payment_failed: "Payment processing error",
  error_payment_pending: "Payment is being processed, please try later",
  error_unknown_status: "Unknown payment status: {status}",
  error_no_link: "Failed to get payment link",
  error_generic: "An error occurred",
  connect_close: "Close",
  pkg_start: "Starter",
  pkg_popular: "Popular",
  pkg_value: "Value",
  pkg_premium: "Premium",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const StarsTopUpI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();
  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);
  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useStarsTopUpI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStarsTopUpI18n must be used within StarsTopUpI18nProvider");
  return ctx;
};
