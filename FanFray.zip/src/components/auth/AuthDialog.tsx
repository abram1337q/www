"use client";

import { useState, useRef, useEffect } from "react";
import { Trophy, Shield, Zap, Users, ChevronRight, Sparkles, Check, Star } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { AuthDialogI18nProvider, useAuthDialogI18n } from "@/components/providers/AuthDialogI18nProvider";

interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
}

const AuthDialogInner = ({ open, onLogin, onSkip, isFirstTime = true, user }: {
  open: boolean;
  onLogin: () => void;
  onSkip: () => void;
  isFirstTime?: boolean;
  user?: TelegramUser | null;
}) => {
  const { t } = useAuthDialogI18n();
  const [isAgeConfirmed, setIsAgeConfirmed] = useState(false);

  // Drag scroll для ПК
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!scrollRef.current) return;
    setIsDragging(true);
    setStartX(e.pageX - scrollRef.current.offsetLeft);
    setScrollLeft(scrollRef.current.scrollLeft);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !scrollRef.current) return;
    e.preventDefault();
    const x = e.pageX - scrollRef.current.offsetLeft;
    const walk = (x - startX) * 1.5;
    scrollRef.current.scrollLeft = scrollLeft - walk;
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
  };

  const features = [
    {
      icon: Trophy,
      title: t("feature_p2p_title"),
      description: t("feature_p2p_desc"),
      gradient: "from-blue-500 via-blue-600 to-indigo-600",
      iconBg: "bg-blue-500"
    },
    {
      icon: Shield,
      title: t("feature_secure_title"),
      description: t("feature_secure_desc"),
      gradient: "from-emerald-500 via-emerald-600 to-teal-600",
      iconBg: "bg-emerald-500"
    },
    {
      icon: Zap,
      title: t("feature_fast_title"),
      description: t("feature_fast_desc"),
      gradient: "from-amber-500 via-orange-500 to-orange-600",
      iconBg: "bg-amber-500"
    },
    {
      icon: Users,
      title: t("feature_community_title"),
      description: t("feature_community_desc"),
      gradient: "from-purple-500 via-purple-600 to-pink-600",
      iconBg: "bg-purple-500"
    }
  ];

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
          style={{
            background: "linear-gradient(135deg, rgba(15, 23, 42, 0.98) 0%, rgba(30, 27, 75, 0.98) 50%, rgba(20, 20, 40, 0.98) 100%)",
            backdropFilter: "blur(20px)"
          }}
        >
          {/* Animated background particles */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 rounded-full bg-white/10"
                initial={{
                  x: Math.random() * 400,
                  y: Math.random() * 600,
                  scale: 0
                }}
                animate={{
                  y: [null, -100],
                  scale: [0, 1, 0],
                  opacity: [0, 0.5, 0]
                }}
                transition={{
                  duration: 4 + Math.random() * 2,
                  repeat: Infinity,
                  delay: i * 0.5,
                  ease: "easeOut"
                }}
                style={{ left: `${15 + i * 15}%` }}
              />
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="relative w-full max-w-sm bg-gradient-to-b from-slate-800/80 to-slate-900/90 rounded-3xl border border-white/10 shadow-2xl overflow-hidden"
            style={{ maxHeight: "calc(100vh - 32px)" }}
          >
            {/* Top glow effect */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-px bg-gradient-to-r from-transparent via-blue-400/50 to-transparent" />

            {/* Content wrapper with scroll */}
            <div className="overflow-y-auto" style={{ maxHeight: "calc(100vh - 32px)" }}>
              {/* Header */}
              <div className="pt-6 pb-4 px-6 text-center">
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                  className="relative mx-auto mb-4"
                >
                  {/* Logo container */}
                  <div className="relative w-20 h-20 mx-auto">
                    {/* Outer ring */}
                    <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 animate-spin-slow" style={{ animationDuration: "8s" }} />
                    <div className="absolute inset-[3px] rounded-full bg-slate-900" />
                    {/* Inner icon */}
                    <div className="absolute inset-[6px] rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                      <Star className="w-8 h-8 text-white fill-white/20" />
                    </div>
                    {/* Sparkle badge */}
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.4, type: "spring" }}
                      className="absolute -right-1 -top-1 w-7 h-7 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center shadow-lg shadow-orange-500/30"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-white" />
                    </motion.div>
                  </div>
                </motion.div>

                <motion.h1
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="text-2xl font-bold text-white mb-1"
                >
                  Fan Fray
                </motion.h1>

                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.25 }}
                  className="text-sm text-slate-400"
                >
                  {user ? `${t('hello_user', { name: user.first_name })}` : t('subtitle_guest')}
                </motion.p>
              </div>

              {/* Features - horizontal scroll */}
              <div className="px-4 pb-4">
                <div
                  ref={scrollRef}
                  onMouseDown={handleMouseDown}
                  onMouseUp={handleMouseUp}
                  onMouseMove={handleMouseMove}
                  onMouseLeave={handleMouseLeave}
                  className={`flex gap-3 overflow-x-auto pb-2 scrollbar-none snap-x snap-mandatory ${isDragging ? 'cursor-grabbing select-none' : 'cursor-grab'}`}
                  style={{ WebkitOverflowScrolling: 'touch' }}
                >
                  {features.map((feature, index) => (
                    <motion.div
                      key={feature.title}
                      initial={{ opacity: 0, x: 50 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.3 + index * 0.08 }}
                      className="flex-shrink-0 w-[140px] snap-start"
                    >
                      <div className={`relative h-full p-3 rounded-2xl bg-gradient-to-br ${feature.gradient} overflow-hidden group`}>
                        {/* Shine effect */}
                        <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                        <div className="relative z-10">
                          <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center mb-2">
                            <feature.icon className="w-5 h-5 text-white" />
                          </div>
                          <h3 className="font-semibold text-white text-sm mb-1 leading-tight">{feature.title}</h3>
                          <p className="text-[11px] text-white/80 leading-snug">{feature.description}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Tags */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="flex justify-center gap-2 px-6 pb-4"
              >
                <span className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-slate-300 font-medium">
                  TON
                </span>
                <span className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-slate-300 font-medium">
                  Real-time
                </span>
                <span className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-slate-300 font-medium">
                  P2P
                </span>
              </motion.div>

              {/* Age confirmation & Button */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.55 }}
                className="px-5 pb-6 space-y-4"
              >
                {/* Age checkbox */}
                <button
                  onClick={() => setIsAgeConfirmed(!isAgeConfirmed)}
                  className="w-full flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors text-left group"
                >
                  <div className={`flex-shrink-0 w-5 h-5 rounded-md border-2 transition-all duration-200 flex items-center justify-center ${
                    isAgeConfirmed
                      ? 'bg-gradient-to-br from-blue-500 to-purple-600 border-transparent'
                      : 'border-slate-500 group-hover:border-slate-400'
                  }`}>
                    <Check className={`w-3 h-3 text-white transition-all ${isAgeConfirmed ? 'scale-100' : 'scale-0'}`} />
                  </div>
                  <span className="text-xs text-slate-300 leading-relaxed">
                    Мне исполнилось <span className="text-white font-semibold">18 лет</span> и я согласен с правилами
                  </span>
                </button>

                {/* CTA Button */}
                <button
                  onClick={onLogin}
                  disabled={!isAgeConfirmed}
                  className={`relative w-full py-4 rounded-2xl font-semibold text-base overflow-hidden transition-all duration-300 ${
                    isAgeConfirmed
                      ? 'bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:scale-[1.02] active:scale-[0.98]'
                      : 'bg-slate-700/50 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  {isAgeConfirmed && (
                    <motion.span
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent"
                      initial={{ x: "-100%" }}
                      animate={{ x: "200%" }}
                      transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 1 }}
                    />
                  )}
                  <span className="relative flex items-center justify-center gap-2">
                    Начать
                    <ChevronRight className="w-5 h-5" />
                  </span>
                </button>

                {/* Terms */}
                <p className="text-center text-[10px] text-slate-500 leading-relaxed">
                  Продолжая, вы соглашаетесь с{" "}
                  <span className="text-slate-400 hover:text-white transition-colors cursor-pointer">условиями</span>
                  {" "}и{" "}
                  <span className="text-slate-400 hover:text-white transition-colors cursor-pointer">политикой</span>
                </p>
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export const AuthDialog = (props: { open: boolean; onLogin: () => void; onSkip: () => void; isFirstTime?: boolean; user?: TelegramUser | null; }) => (
  <AuthDialogI18nProvider>
    <AuthDialogInner {...props} />
  </AuthDialogI18nProvider>
);
