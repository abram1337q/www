"use client";

import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Shield, Zap, Users, ChevronRight, Sparkles, Trophy, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { AuthDialogI18nProvider, useAuthDialogI18n } from "@/components/providers/AuthDialogI18nProvider";

interface AuthDialogProps {
  open: boolean;
  onLogin: () => void;
  onSkip: () => void;
}

interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
}

const AuthDialogInner = ({ open, onLogin, onSkip, isFirstTime = true, user }: {
  open: boolean;
  onLogin: () => void;
  onSkip: () => void;
  isFirstTime?: boolean;
  user?: TelegramUser | null;
}) => {
  const { t } = useAuthDialogI18n();
  const [isAgeConfirmed, setIsAgeConfirmed] = useState(false);
  const features = [
    {
      icon: Trophy,
      title: t("feature_p2p_title"),
      description: t("feature_p2p_desc"),
      color: "from-blue-500 to-indigo-500"
    },
    {
      icon: Shield,
      title: t("feature_secure_title"),
      description: t("feature_secure_desc"),
      color: "from-emerald-500 to-teal-500"
    },
    {
      icon: Zap,
      title: t("feature_fast_title"),
      description: t("feature_fast_desc"),
      color: "from-amber-500 to-orange-500"
    },
    {
      icon: Users,
      title: t("feature_community_title"),
      description: t("feature_community_desc"),
      color: "from-pink-500 to-rose-500"
    }
  ];

  return (
    <AnimatePresence>
      {open && (
        <Dialog open={open} onOpenChange={() => {}}>
          <DialogContent className="max-w-md mx-auto p-0 border-0 shadow-2xl bg-white">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", stiffness: 350, damping: 25 }}
              className="overflow-hidden"
            >
              <Card className="border-none overflow-hidden shadow-xl bg-white">
                <CardHeader className="text-center pb-4 relative z-10">
                  <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1, type: "spring" }}
                  >
                    <div className="relative w-20 h-20 mx-auto mb-5">
                      <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full blur-sm animate-pulse"></div>
                      <div className="absolute inset-0 w-full h-full bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                        <TrendingUp className="h-10 w-10 text-white" />
                      </div>
                      <div className="absolute -right-1 -top-1 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full p-1.5 flex items-center justify-center shadow-lg">
                        <Sparkles className="h-3 w-3 text-white" />
                      </div>
                    </div>

                    <CardTitle className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                      {user ? t('hello_user', { name: user.first_name }) : t('title_guest')}
                    </CardTitle>
                    <p className="text-sm text-foreground/80 mt-2 max-w-xs mx-auto">
                      {user
                        ? t('subtitle_user')
                        : t('subtitle_guest')
                      }
                    </p>
                  </motion.div>
                </CardHeader>

                <CardContent className="space-y-6 relative z-10">
                  <div className="grid grid-cols-2 gap-3">
                    {features.map((feature, index) => (
                      <motion.div
                        key={feature.title}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 + index * 0.1, type: "spring" }}
                      >
                        <Card className="p-3 h-full border-none bg-white dark:bg-gray-800 backdrop-blur-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-all rounded-xl overflow-hidden relative">
                          <div className={`absolute inset-0 opacity-20 bg-gradient-to-br ${feature.color}`}></div>
                          <div className="flex flex-col items-center text-center space-y-2 relative z-10">
                            <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${feature.color} flex items-center justify-center shadow-md`}>
                              <feature.icon className="h-4 w-4 text-white" />
                            </div>
                            <h4 className="font-semibold text-sm">{feature.title}</h4>
                            <p className="text-xs text-foreground/70 leading-snug">
                              {feature.description}
                            </p>
                          </div>
                        </Card>
                      </motion.div>
                    ))}
                  </div>

                  <div className="flex flex-wrap gap-2 justify-center">
                    <Badge variant="secondary" className="bg-gray-100 dark:bg-gray-700 border-none text-xs font-medium px-3 py-1 rounded-full">
                      {t('badges_ton')}
                    </Badge>
                    <Badge variant="secondary" className="bg-gray-100 dark:bg-gray-700 border-none text-xs font-medium px-3 py-1 rounded-full">
                      {t('badges_realtime')}
                    </Badge>
                  </div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6, type: "spring" }}
                    className="space-y-4 pt-2"
                  >
                    {/* Подтверждение возраста 18+ */}
                    <div className="flex items-start space-x-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-xl">
                      <button
                        onClick={() => setIsAgeConfirmed(!isAgeConfirmed)}
                        className={`flex-shrink-0 w-5 h-5 rounded border-2 transition-all duration-200 flex items-center justify-center ${
                          isAgeConfirmed
                            ? 'bg-blue-500 border-blue-500'
                            : 'bg-transparent border-gray-300 dark:border-gray-600 hover:border-blue-400'
                        }`}
                      >
                        {isAgeConfirmed && (
                          <Check className="h-3 w-3 text-white" />
                        )}
                      </button>
                      <div className="flex-1">
                        <p className="text-sm text-foreground/80 leading-relaxed">
                          Я подтверждаю, что мне исполнилось <span className="font-semibold">18 лет</span>, и я согласен с правилами использования платформы
                        </p>
                      </div>
                    </div>

                    <Button
                      onClick={onLogin}
                      disabled={!isAgeConfirmed}
                      className={`w-full h-12 rounded-xl border-none relative overflow-hidden shadow-lg group transition-all duration-200 ${
                        isAgeConfirmed
                          ? 'bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700'
                          : 'bg-gray-300 dark:bg-gray-700 cursor-not-allowed'
                      }`}
                    >
                      {isAgeConfirmed && (
                        <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-all duration-700"></span>
                      )}
                      <div className="flex items-center justify-center space-x-2">
                        <span className={`font-semibold ${isAgeConfirmed ? 'text-white' : 'text-gray-500'}`}>
                          Начать приключение
                        </span>
                        <ChevronRight className={`h-4 w-4 ${isAgeConfirmed ? 'text-white' : 'text-gray-500'}`} />
                      </div>
                    </Button>
                  </motion.div>

                  <p className="text-xs text-foreground/60 text-center leading-relaxed">
                    {t('tos_text')}{" "}<span className="text-blue-400 hover:text-blue-300 transition-colors cursor-pointer">{t('tos_terms')}</span> {" "}{t('and') || 'and'} {" "}<span className="text-blue-400 hover:text-blue-300 transition-colors cursor-pointer">{t('tos_privacy')}</span>
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </DialogContent>
        </Dialog>
      )}
    </AnimatePresence>
  );
};

export const AuthDialog = (props: { open: boolean; onLogin: () => void; onSkip: () => void; isFirstTime?: boolean; user?: TelegramUser | null; }) => (
  <AuthDialogI18nProvider>
    <AuthDialogInner {...props} />
  </AuthDialogI18nProvider>
);
