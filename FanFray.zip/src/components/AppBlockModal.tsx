'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { UserX, Shield, Calendar } from 'lucide-react';
import { useChatI18n } from '@/components/providers/ChatI18nProvider';

interface BlockedUser {
  id: number;
  telegram_id: string;
  is_blocked_app: boolean;
  is_blocked_chat: boolean;
  blocked_at: string | null;
  block_reason: string | null;
  first_name: string | null;
  username: string | null;
}

interface AppBlockModalProps {
  telegramId: string;
}

export default function AppBlockModal({ telegramId }: AppBlockModalProps) {
  const { t } = useChatI18n();
  const [blockedUser, setBlockedUser] = useState<BlockedUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkBlockStatus();
  }, [telegramId]);

  const checkBlockStatus = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/user/check-block-status?telegramId=${telegramId}`);
      const data = await response.json();

      if (data.success) {
        const user = data.user;

        // Показываем только если заблокировано приложение
        if (user.is_blocked_app) {
          setBlockedUser(user);
        } else {
          setBlockedUser(null);
        }
      }
    } catch (error) {
      console.error('Ошибка при проверке статуса блокировки:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getUserDisplayName = (user: BlockedUser) => {
    const name = user.first_name || '';
    const username = user.username ? `@${user.username}` : '';
    return name || username || `ID: ${user.telegram_id}`;
  };

  // Если нет блокировки приложения или загружается, ничего не показываем
  if (!blockedUser || loading || !blockedUser.is_blocked_app) {
    return null;
  }

  // Полноэкранная блокировка приложения
  return (
    <div className="fixed inset-0 bg-white z-[9999] flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-red-200">
        <CardHeader className="text-center pb-4">
          <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <UserX className="w-8 h-8 text-red-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-red-700">
            {t('access_blocked')}
          </CardTitle>
          <CardDescription className="text-red-600">
            {t('account_blocked_admin')}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center gap-2 text-red-700 font-medium mb-2">
              <Shield className="w-4 h-4" />
              {t('block_info')}
            </div>

            <div className="space-y-2 text-sm text-red-600">
              <div>
                <strong>{t('user_label')}:</strong> {getUserDisplayName(blockedUser)}
              </div>

              {blockedUser.blocked_at && (
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>
                    <strong>{t('blocked_at_label')}</strong> {formatDate(blockedUser.blocked_at)}
                  </span>
                </div>
              )}

              {blockedUser.block_reason && (
                <div className="mt-3 p-3 bg-white border border-red-200 rounded">
                  <strong>{t('block_reason')}:</strong>
                  <div className="mt-1">{blockedUser.block_reason}</div>
                </div>
              )}
            </div>
          </div>

          <div className="text-center text-sm text-gray-600">
            {t('contact_admin_info')}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
