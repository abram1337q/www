'use client';

import { TonConnectButton, useTonWallet, useTonAddress } from '@tonconnect/ui-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Wallet, Copy, CheckCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { TonWalletI18nProvider, useTonWalletI18n } from '@/components/providers/TonWalletI18nProvider';

function TonWalletButtonInner() {
  const { t } = useTonWalletI18n();
  const wallet = useTonWallet();
  const userFriendlyAddress = useTonAddress();
  const rawAddress = useTonAddress(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Обработка специфичных ошибок TON Connect для кошелька
    const handleTonConnectError = (event: PromiseRejectionEvent) => {
      if (event.reason?.message?.includes('TON_CONNECT_SDK_ERROR') &&
          event.reason?.message?.includes('Operation aborted')) {
        console.warn('TON Connect wallet operation aborted due to app state change');
        // Не показываем ошибку пользователю, так как это ожидаемое поведение
        event.preventDefault();
      }
    };

    window.addEventListener('unhandledrejection', handleTonConnectError);

    return () => {
      window.removeEventListener('unhandledrejection', handleTonConnectError);
    };
  }, []);

  const handleCopyAddress = async () => {
    if (userFriendlyAddress) {
      await navigator.clipboard.writeText(userFriendlyAddress);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (wallet) {
    return (
      <Card className="glass-card border-none">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 flex items-center justify-center">
              <Wallet className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-sm">{wallet.device?.appName || 'TON Wallet'}</p>
              <p className="text-xs text-foreground/60">{t('connected')}</p>
            </div>
          </div>

          {userFriendlyAddress && (
            <div className="space-y-2">
              <p className="text-xs text-foreground/60">{t('wallet_address')}</p>
              <div className="flex items-center space-x-2 p-2 bg-background/50 rounded-lg">
                <code className="text-xs flex-1 truncate">
                  {userFriendlyAddress}
                </code>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleCopyAddress}
                  className="p-1 h-6 w-6"
                >
                  {copied ? (
                    <CheckCircle className="h-3 w-3 text-green-500" />
                  ) : (
                    <Copy className="h-3 w-3" />
                  )}
                </Button>
              </div>
            </div>
          )}

          <div className="flex justify-center">
            <TonConnectButton />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card border-none">
      <CardContent className="p-4 space-y-3">
        <div className="text-center space-y-2">
          <Wallet className="h-8 w-8 mx-auto text-foreground/60" />
          <div>
            <p className="font-semibold text-sm">{t('connect_title')}</p>
            <p className="text-xs text-foreground/60">
              {t('connect_sub')}
            </p>
          </div>
        </div>
        <div className="flex justify-center">
          <TonConnectButton />
        </div>
      </CardContent>
    </Card>
  );
}

export function TonWalletButton() {
  return (
    <TonWalletI18nProvider>
      <TonWalletButtonInner />
    </TonWalletI18nProvider>
  );
}
