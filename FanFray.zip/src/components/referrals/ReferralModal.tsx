"use client";

import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Share2,
  Copy,
  Users,
  TrendingUp,
  Star,
  Calendar,
  Coins,
  CheckCircle,
  UserPlus,
  Gift,
  DollarSign
} from "lucide-react";
import { motion } from "framer-motion";
import { useTelegram } from "@/components/providers/TelegramProvider";
import { useClipboard } from "@/hooks/useClipboard";
import { FEATURES } from "@/lib/features";
import { useReferralI18n } from "@/components/providers/ReferralI18nProvider";

interface ReferralInfo {
  user: {
    telegram_id: string;
    username: string;
    first_name: string;
    referral_code: string;
    referral_link: string;
    total_referrals: number;
    active_referrals: number;
    total_earnings: number;
    pending_ton_earnings: number;
    pending_stars_earnings: number;
  };
  referrals: Array<{
    id: number;
    telegram_id: string;
    username: string;
    first_name: string;
    last_name: string;
    status: string;
    joined_date: string;
    activated_date?: string;
    first_bet_amount?: number;
    first_bet_date?: string;
    total_earned: number;
  }>;
  earnings_breakdown: Array<{
    type: string;
    currency: string;
    total_amount: number;
    transactions_count: number;
  }>;
  referred_by?: {
    telegram_id: string;
    username: string;
    first_name: string;
    referral_code: string;
    referral_date: string;
  };
}

interface ReferralModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const ReferralModal = ({ open, onOpenChange }: ReferralModalProps) => {
  const { user } = useTelegram();
  const { writeToClipboard } = useClipboard();
  const { t } = useReferralI18n();
  const [copied, setCopied] = useState(false);

  const copyToClipboard = async (text: string) => {
    await writeToClipboard(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  const [referralInfo, setReferralInfo] = useState<ReferralInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [transferring, setTransferring] = useState<{ ton: boolean; stars: boolean }>({ ton: false, stars: false });
  const [exchangeRates, setExchangeRates] = useState<{ tonToUsd: number; starsToUsd: number }>({ tonToUsd: 0, starsToUsd: 0 });

  useEffect(() => {
    if (open && user?.id) {
      fetchReferralInfo();
      fetchExchangeRates();
    }
  }, [open, user?.id]);

  const fetchReferralInfo = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/referrals/info?telegram_id=${user?.id}`);

      if (!response.ok) {
        throw new Error('Failed to fetch referral info');
      }

      const data = await response.json();
      setReferralInfo(data);
    } catch (err) {
      console.error('Error fetching referral info:', err);
      setError(t('error_loading'));
    } finally {
      setLoading(false);
    }
  };

  const fetchExchangeRates = async () => {
    try {
      const response = await fetch('/api/ton-rate');
      if (response.ok) {
        const rates = await response.json();
        setExchangeRates({
          tonToUsd: rates.tonToUsd || 0,
          starsToUsd: rates.starsToUsd || 0
        });
      }
    } catch (err) {
      console.error('Error fetching exchange rates:', err);
    }
  };

  const calculateTotalEarningsUSD = () => {
    if (!referralInfo) return 0;

    const tonEarnings = referralInfo.user.pending_ton_earnings * exchangeRates.tonToUsd;
    const starsEarnings = referralInfo.user.pending_stars_earnings * exchangeRates.starsToUsd;

    // Добавляем заработок из breakdown по курсу
    let totalFromBreakdown = 0;
    referralInfo.earnings_breakdown.forEach(earning => {
      if (earning.currency === 'TON') {
        totalFromBreakdown += earning.total_amount * exchangeRates.tonToUsd;
      } else if (earning.currency === 'STARS') {
        totalFromBreakdown += earning.total_amount * exchangeRates.starsToUsd;
      }
    });

    return tonEarnings + starsEarnings + totalFromBreakdown;
  };

  const handleShare = () => {
    if (!referralInfo?.user.referral_link) return;

    if (window.Telegram?.WebApp?.openLink) {
      // Используем Telegram WebApp API для шаринга
      window.Telegram.WebApp.openLink!(
        `https://t.me/share/url?url=${encodeURIComponent(referralInfo.user.referral_link)}&text=${encodeURIComponent('Присоединяйся к игре! Используй мою реферальную ссылку и получи бонус!')}`
      );
    } else {
      // Fallback для копирования в буфер обмена
      copyToClipboard(referralInfo.user.referral_link);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'deposit_commission_ton': return t('deposit_commission_ton');
      case 'deposit_commission_stars': return t('deposit_commission_stars');
      case 'bet_commission': return t('bet_commission');
      case 'deposit_bonus': return t('deposit_bonus');
      case 'activity_bonus': return t('activity_bonus');
      default: return type;
    }
  };

  const handleTransferEarnings = async (currency: 'TON' | 'STARS') => {
    if (!user?.id) return;

    setTransferring(prev => ({ ...prev, [currency.toLowerCase()]: true }));

    try {
      const response = await fetch('/api/referrals/transfer-earnings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-telegram-user-id': user.id.toString()
        },
        body: JSON.stringify({ currency })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || t('transfer_error'));
      }

      if (data.success) {
        // Обновляем информацию о рефералах
        await fetchReferralInfo();

        // Показываем уведомление о успешном переводе
        if (window.Telegram?.WebApp?.showAlert) {
          window.Telegram.WebApp.showAlert(
            t('transfer_success', { amount: data.transferred_amount, currency })
          );
        }
      } else {
        throw new Error(data.message || t('transfer_error'));
      }
    } catch (err) {
      console.error('Error transferring earnings:', err);
      const errorMessage = err instanceof Error ? err.message : t('transfer_error');

      if (window.Telegram?.WebApp?.showAlert) {
        window.Telegram.WebApp.showAlert(errorMessage);
      } else {
        setError(errorMessage);
      }
    } finally {
      setTransferring(prev => ({ ...prev, [currency.toLowerCase()]: false }));
    }
  };

  if (loading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[400px] bg-background/95 backdrop-blur-sm border border-white/10 rounded-2xl shadow-2xl">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
            <span className="ml-3 text-foreground/70">{t('loading')}</span>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (error) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[400px] bg-background/95 backdrop-blur-sm border border-white/10 rounded-2xl shadow-2xl">
          <div className="text-center py-12">
            <p className="text-red-400 mb-6">{error}</p>
            <Button onClick={fetchReferralInfo} variant="outline" className="rounded-xl">
              {t('retry')}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!referralInfo) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px] max-h-[75vh] overflow-y-auto bg-background/95 backdrop-blur-sm border border-white/10 rounded-2xl shadow-2xl">
        <DialogHeader className="pb-4">
          <DialogTitle className="flex items-center space-x-2 text-xl">
            <Users className="h-6 w-6 text-blue-400" />
            <span>{t('modal_title')}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5">
          {/* Основная статистика */}
          <div className="grid grid-cols-2 gap-3">
            <Card className="bg-white/5 border-white/10 rounded-xl">
              <CardContent className="p-3 text-center">
                <div className="flex items-center justify-center mb-2">
                  <Users className="h-5 w-5 text-blue-400" />
                </div>
                <p className="text-xl font-bold text-blue-400">{referralInfo.user.total_referrals}</p>
                <p className="text-xs text-foreground/70">{t('stats_total_referrals')}</p>
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/10 rounded-xl">
              <CardContent className="p-3 text-center">
                <div className="flex items-center justify-center mb-2">
                  <DollarSign className="h-5 w-5 text-green-400" />
                </div>
                <p className="text-xl font-bold text-green-400">${calculateTotalEarningsUSD().toFixed(2)}</p>
                <p className="text-xs text-foreground/70">{t('stats_earned')}</p>
              </CardContent>
            </Card>
          </div>

          {/* Накопленные отчисления */}
          <Card className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border-yellow-500/20 rounded-xl">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center space-x-2">
                <Gift className="h-4 w-4 text-yellow-400" />
                <span>{t('pending_earnings_title')}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              {/* TON отчисления */}
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                    <Coins className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-blue-400">{t('ton_earnings')}</p>
                    <p className="text-base font-bold">{referralInfo.user.pending_ton_earnings.toFixed(4)} TON</p>
                    {exchangeRates.tonToUsd > 0 && (
                      <p className="text-xs text-foreground/60">≈ ${(referralInfo.user.pending_ton_earnings * exchangeRates.tonToUsd).toFixed(2)}</p>
                    )}
                  </div>
                </div>
                <Button
                  onClick={() => handleTransferEarnings('TON')}
                  disabled={transferring.ton || referralInfo.user.pending_ton_earnings <= 0}
                  className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-xl text-xs px-3 py-2"
                  size="sm"
                >
                  {transferring.ton ? (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  ) : (
                    referralInfo.user.pending_ton_earnings > 0 ? t('transfer_button') : t('no_funds')
                  )}
                </Button>
              </div>

              {/* Stars отчисления */}
              {FEATURES.SHOW_STARS && (
                <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center">
                      <Star className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-purple-400">{t('stars_earnings')}</p>
                      <p className="text-base font-bold">{referralInfo.user.pending_stars_earnings.toFixed(0)} Stars</p>
                      {exchangeRates.starsToUsd > 0 && (
                        <p className="text-xs text-foreground/60">≈ ${(referralInfo.user.pending_stars_earnings * exchangeRates.starsToUsd).toFixed(2)}</p>
                      )}
                    </div>
                  </div>
                  <Button
                    onClick={() => handleTransferEarnings('STARS')}
                    disabled={transferring.stars || referralInfo.user.pending_stars_earnings <= 0}
                    className="bg-purple-600 hover:bg-purple-700 disabled:opacity-50 rounded-xl text-xs px-3 py-2"
                    size="sm"
                  >
                    {transferring.stars ? (
                      <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                    ) : (
                      referralInfo.user.pending_stars_earnings > 0 ? t('transfer_button') : t('no_funds')
                    )}
                  </Button>
                </div>
              )}

              <div className="p-2 bg-blue-500/10 rounded-xl border border-blue-500/20">
                <p className="text-xs text-blue-300 text-center">
                  {t('pending_hint')}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Реферальная ссылка */}
          <Card className="bg-white/5 border-white/10 rounded-xl">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center space-x-2">
                <Share2 className="h-4 w-4" />
                <span>{t('referral_link_title')}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              <div className="p-3 bg-white/5 rounded-xl border border-white/10">
                <p className="text-xs font-mono break-all">{referralInfo.user.referral_link}</p>
              </div>
              <div className="flex space-x-2">
                <Button
                  onClick={() => copyToClipboard(referralInfo.user.referral_link)}
                  variant="outline"
                  className="flex-1 rounded-xl"
                  size="sm"
                >
                  <Copy className="h-3 w-3 mr-1" />
                  {copied ? t('copied') : t('copy_button')}
                </Button>
                <Button onClick={handleShare} className="flex-1 rounded-xl" size="sm">
                  <Share2 className="h-3 w-3 mr-1" />
                  {t('share_button')}
                </Button>
              </div>
              <p className="text-xs text-foreground/70 text-center">
                {t('referral_code', { code: referralInfo.user.referral_code })}
              </p>
            </CardContent>
          </Card>

          {/* Табы с информацией */}
          <Tabs defaultValue="referrals" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-white/5 rounded-xl h-9">
              <TabsTrigger value="referrals" className="rounded-lg text-sm">{t('tab_referrals')}</TabsTrigger>
              <TabsTrigger value="earnings" className="rounded-lg text-sm">{t('tab_earnings')}</TabsTrigger>
            </TabsList>

            <TabsContent value="referrals" className="space-y-3 mt-3">
              {referralInfo.referrals.length === 0 ? (
                <Card className="bg-white/5 border-white/10 rounded-xl">
                  <CardContent className="p-4 text-center">
                    <UserPlus className="h-10 w-10 text-foreground/30 mx-auto mb-3" />
                    <p className="text-sm text-foreground/70">{t('no_referrals_title')}</p>
                    <p className="text-xs text-foreground/50 mt-2">
                      {t('no_referrals_desc')}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-2">
                  {referralInfo.referrals.map((referral) => (
                    <motion.div
                      key={referral.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3 bg-white/5 rounded-xl border border-white/10"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-r from-blue-400 to-purple-500 rounded-lg flex items-center justify-center">
                            <span className="text-white font-bold text-xs">
                              {referral.first_name?.[0] || '?'}
                            </span>
                          </div>
                          <div>
                            <p className="text-sm font-medium">
                              {referral.first_name} {referral.last_name}
                            </p>
                            <p className="text-xs text-foreground/70">
                              @{referral.username || 'no_username'}
                            </p>
                            <p className="text-xs text-foreground/50">
                              {formatDate(referral.joined_date)}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant={referral.status === 'active' ? 'default' : 'secondary'} className="mb-1 text-xs">
                            {referral.status === 'active' ? t('referral_status_active') : t('referral_status_inactive')}
                          </Badge>
                          <p className="text-sm font-medium text-green-400">
                            +{referral.total_earned.toFixed(2)}
                          </p>
                          {referral.first_bet_amount && (
                            <p className="text-xs text-foreground/50">
                              {t('referral_bet_amount', { amount: referral.first_bet_amount })}
                            </p>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="earnings" className="space-y-3 mt-3">
              {referralInfo.earnings_breakdown.length === 0 ? (
                <Card className="bg-white/5 border-white/10 rounded-xl">
                  <CardContent className="p-4 text-center">
                    <Coins className="h-10 w-10 text-foreground/30 mx-auto mb-3" />
                    <p className="text-sm text-foreground/70">{t('no_earnings_title')}</p>
                    <p className="text-xs text-foreground/50 mt-2">
                      {t('no_earnings_desc')}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-2">
                  {referralInfo.earnings_breakdown.map((earning, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="p-3 bg-white/5 rounded-xl border border-white/10"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">{getTypeLabel(earning.type)}</p>
                          <p className="text-xs text-foreground/70">
                            {t('earnings_transactions', { count: earning.transactions_count })}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold text-green-400">
                            +{earning.total_amount.toFixed(2)} {earning.currency}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>

          {/* Информация о том, кто пригласил */}
          {referralInfo.referred_by && (
            <Card className="bg-white/5 border-white/10 rounded-xl">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center space-x-2">
                  <Gift className="h-4 w-4 text-purple-400" />
                  <span>{t('referred_by_title')}</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-500 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-xs">
                      {referralInfo.referred_by.first_name?.[0] || '?'}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium">{referralInfo.referred_by.first_name}</p>
                    <p className="text-xs text-foreground/70">
                      @{referralInfo.referred_by.username || 'no_username'}
                    </p>
                    <p className="text-xs text-foreground/50">
                      {formatDate(referralInfo.referred_by.referral_date)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Правила */}
          <Card className="bg-white/5 border-white/10 rounded-xl">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">{t('how_it_works_title')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 pt-0">
              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-white text-xs font-bold">1</span>
                </div>
                <p className="text-xs">{t('step_1')}</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-white text-xs font-bold">2</span>
                </div>
                <p className="text-xs">{t('step_2')}</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-white text-xs font-bold">3</span>
                </div>
                <p className="text-xs">{t('step_3')}</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-white text-xs font-bold">4</span>
                </div>
                <p className="text-xs">{t('step_4')}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};
