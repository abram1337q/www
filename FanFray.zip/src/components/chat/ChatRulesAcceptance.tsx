"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Pin, Check, Shield } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useChatI18n } from "@/components/providers/ChatI18nProvider";

interface ChatRulesAcceptanceProps {
  onAccept: () => void;
  onSkip: () => void;
}

export const ChatRulesAcceptance = ({ onAccept, onSkip }: ChatRulesAcceptanceProps) => {
  const { t } = useChatI18n();
  const [isAgreed, setIsAgreed] = useState(false);

  const pinnedRules = [
    t('rule_no_insults'),
    t('rule_no_spam'),
    t('rule_disputes_only_platform')
  ];

  const handleAccept = () => {
    if (isAgreed) {
      // Сохраняем в localStorage, что пользователь принял правила чата
      localStorage.setItem('chat_rules_accepted', 'true');
      localStorage.setItem('chat_rules_accepted_timestamp', new Date().toISOString());
      onAccept();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="glass-card border-none overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl"></div>
        <CardContent className="p-4 relative z-10">
          <div className="flex items-center space-x-2 mb-3">
            <Shield className="h-5 w-5 text-blue-400" />
            <span className="font-semibold text-blue-400 text-base">
              {t('chat_rules_title')}
            </span>
          </div>

          <div className="space-y-3 mb-4">
            <p className="text-sm text-foreground/70">
              {t('rules_intro')}
            </p>

            <ul className="space-y-2">
              {pinnedRules.map((rule, index) => (
                <li key={index} className="text-sm text-foreground/80 flex items-start space-x-2">
                  <div className="min-w-4 text-blue-400">•</div>
                  <span>{rule}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-3">
            <div
              className="flex items-start space-x-3 cursor-pointer p-3 rounded-lg hover:bg-white/5 transition-colors"
              onClick={() => setIsAgreed(!isAgreed)}
            >
              <div className={`flex-shrink-0 w-5 h-5 rounded border-2 transition-all duration-200 ${
                isAgreed
                  ? 'bg-blue-500 border-blue-500'
                  : 'border-gray-300 hover:border-blue-300'
              } flex items-center justify-center`}>
                {isAgreed && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 600, damping: 25 }}
                  >
                    <Check className="h-3 w-3 text-white" />
                  </motion.div>
                )}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">
                  {t('rules_agreement')}
                </p>
              </div>
            </div>

            <div className="flex space-x-2">
              <Button
                onClick={handleAccept}
                disabled={!isAgreed}
                className={`flex-1 h-10 rounded-xl border-none relative overflow-hidden shadow-lg group transition-all duration-200 ${
                  isAgreed
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700'
                    : 'bg-gray-300 cursor-not-allowed'
                }`}
              >
                {isAgreed && (
                  <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-all duration-700"></span>
                )}
                <span className="font-semibold text-sm">
                  {isAgreed ? t('accept_rules') : t('accept_rules_check')}
                </span>
              </Button>

              <Button
                onClick={onSkip}
                variant="ghost"
                className="px-4 h-10 text-foreground/70 hover:text-foreground hover:bg-white/10"
              >
                {t('hide_rules')}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};
