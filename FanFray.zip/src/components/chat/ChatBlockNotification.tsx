'use client';

import { useState } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { MessageCircleOff, X, ChevronUp, ChevronDown } from 'lucide-react';
import { useChatI18n } from '@/components/providers/ChatI18nProvider';
import { useBlockStatus } from '@/components/providers/BlockStatusProvider';

export default function ChatBlockNotification() {
  const { t } = useChatI18n();
  const { isBlockedChat, blockReason } = useBlockStatus();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);

  // Показываем только если заблокирован чат
  if (!isBlockedChat) {
    return null;
  }

  // Если уведомление минимизировано, показываем только маленькую кнопку
  if (isMinimized) {
    return (
      <div className="fixed top-4 right-4 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsMinimized(false)}
          className="bg-orange-50 border-orange-300 text-orange-700 hover:bg-orange-100"
        >
          <MessageCircleOff className="h-4 w-4 mr-1" />
          {t('chat_restricted')}
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed top-0 left-0 right-0 z-50 p-4">
      <Alert className="border-orange-500 bg-orange-50 max-w-md mx-auto relative">
        <MessageCircleOff className="h-4 w-4 text-orange-600" />
        <AlertDescription className="text-orange-700 pr-20 pb-8">
          <div className="flex items-center justify-between mb-1">
            <div className="font-medium">{t('chat_access_restricted')}</div>
          </div>
          {!isCollapsed && (
            <div className="text-sm">
              {t('chat_access_limited_admin')}
              {blockReason && (
                <div className="mt-1">
                  <strong>{t('block_reason_label')}</strong> {blockReason}
                </div>
              )}
            </div>
          )}
        </AlertDescription>

        {/* Кнопки управления */}
        <div className="absolute bottom-2 right-2 flex space-x-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="h-6 w-6 p-0 text-orange-600 hover:bg-orange-100"
          >
            {isCollapsed ? <ChevronDown className="h-3 w-3" /> : <ChevronUp className="h-3 w-3" />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMinimized(true)}
            className="h-6 w-6 p-0 text-orange-600 hover:bg-orange-100"
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      </Alert>
    </div>
  );
}
