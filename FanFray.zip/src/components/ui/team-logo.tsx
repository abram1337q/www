'use client';

import React, { useState } from 'react';
import Image from 'next/image';

interface TeamLogoProps {
  teamName: string;
  logoUrl?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export function TeamLogo({ teamName, logoUrl, size = 'md', className = '' }: TeamLogoProps) {
  const [imageError, setImageError] = useState(false);

  const sizeClasses = {
    sm: 'w-6 h-6 text-xs',
    md: 'w-8 h-8 text-sm',
    lg: 'w-10 h-10 text-base',
    xl: 'w-12 h-12 text-lg'
  };

  const handleImageError = () => {
    setImageError(true);
  };

  // Если нет логотипа или произошла ошибка загрузки, показываем буквенный fallback
  if (!logoUrl || imageError) {
    return (
      <div className={`${sizeClasses[size]} rounded-full bg-gradient-cosmic flex items-center justify-center text-white font-bold ${className}`}>
        {teamName.charAt(0).toUpperCase()}
      </div>
    );
  }

  return (
    <div className={`${sizeClasses[size]} relative ${className}`}>
      <Image
        src={logoUrl}
        alt={teamName}
        fill
        className="object-contain rounded-full"
        onError={handleImageError}
      />
    </div>
  );
}
