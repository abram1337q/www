export class AutoBetChecker {
  private interval: number;
  private isRunning: boolean = false;
  private intervalId: NodeJS.Timeout | null = null;
  private baseUrl: string;
  private consecutiveErrors: number = 0;
  private maxErrors: number = 5;
  private lastSuccessTime: Date | null = null;

  constructor(intervalSeconds: number = 20) {
    this.interval = intervalSeconds * 1000;
    this.baseUrl = process.env.APP_URL || process.env.NEXTAUTH_URL || 'http://localhost:3000';

    console.log('🤖 AutoBetChecker инициализирован');
    console.log(`📡 Base URL: ${this.baseUrl}`);
    console.log(`⏰ Интервал: ${intervalSeconds} секунд`);
  }

  private async makeApiCall(): Promise<{
    success: boolean;
    summary?: {
      checked: number;
      completed: number;
      refunded: number;
      pending: number;
    };
    result?: {
      results: Array<{
        status: string;
        bet_id: number;
        match?: string;
        score?: string;
        method?: string;
        error?: string;
        message?: string;
        match_status?: string;
        amount?: number;
        currency?: string;
      }>;
    };
    error?: string;
  }> {
    try {
      const response = await fetch(`${this.baseUrl}/api/cron/check-matches`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'AutoBetChecker/1.0'
        },
        signal: AbortSignal.timeout(30000) // 30 секунд timeout
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      }
      throw new Error('Unknown error occurred');
    }
  }

  private async runSingleCheck(): Promise<void> {
    try {
      const timestamp = new Date().toLocaleString('ru');
      console.log(`🔄 [${timestamp}] Выполнение автопроверки...`);

      const result = await this.makeApiCall();

      if (result.success) {
        this.consecutiveErrors = 0;
        this.lastSuccessTime = new Date();

        const { checked = 0, completed = 0, refunded = 0, pending = 0 } = result.summary || {};

        if (completed > 0 || refunded > 0) {
          console.log(`✅ [${timestamp}] Обработано: ${checked} | Завершено: ${completed} | Возвращено: ${refunded} | Ожидают: ${pending}`);

          // Показываем детали завершенных и возвращенных ставок
          if (result.result?.results) {
            const completedBets = result.result.results.filter(r => r.status === 'completed');
            const refundedBets = result.result.results.filter(r => r.status === 'refunded');

            completedBets.forEach(bet => {
              console.log(`   💰 Ставка #${bet.bet_id}: ${bet.match} → ${bet.score} (${bet.method})`);
            });

            refundedBets.forEach(bet => {
              console.log(`   💸 Возврат #${bet.bet_id}: ${bet.match} → ${bet.amount} ${bet.currency} (${bet.method})`);
            });
          }
        } else if (checked > 0) {
          console.log(`⏳ [${timestamp}] Проверено ставок: ${checked}, новых завершений нет`);
        } else {
          console.log(`💤 [${timestamp}] Нет активных ставок для проверки`);
        }
      } else {
        this.handleError(`API вернул ошибку: ${result.error}`);
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Неизвестная ошибка';
      this.handleError(`Ошибка выполнения проверки: ${errorMessage}`);
    }
  }

  private handleError(errorMessage: string): void {
    this.consecutiveErrors++;
    const timestamp = new Date().toLocaleString('ru');

    console.error(`❌ [${timestamp}] ${errorMessage}`);
    console.error(`⚠️  Подряд ошибок: ${this.consecutiveErrors}/${this.maxErrors}`);

    if (this.consecutiveErrors >= this.maxErrors) {
      console.error(`🚨 Превышено максимальное количество ошибок подряд (${this.maxErrors}). Останавливаю автопроверку.`);
      this.stop();
    }
  }

  public start(): void {
    if (this.isRunning) {
      console.log('⚠️ Автопроверка уже запущена');
      return;
    }

    console.log(`🚀 Запуск автоматической проверки ставок каждые ${this.interval/1000} секунд`);
    this.isRunning = true;
    this.consecutiveErrors = 0;

    // Выполняем первую проверку сразу
    this.runSingleCheck();

    // Настраиваем периодическое выполнение
    this.intervalId = setInterval(() => {
      this.runSingleCheck();
    }, this.interval);
  }

  public stop(): void {
    if (!this.isRunning) {
      console.log('⚠️ Автопроверка не запущена');
      return;
    }

    console.log('🛑 Останавливаю автоматическую проверку...');

    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    this.isRunning = false;
    console.log('✅ Автопроверка остановлена');
  }

  public getStatus() {
    return {
      isRunning: this.isRunning,
      intervalSeconds: this.interval / 1000,
      baseUrl: this.baseUrl,
      consecutiveErrors: this.consecutiveErrors,
      maxErrors: this.maxErrors,
      lastSuccessTime: this.lastSuccessTime?.toLocaleString('ru') || 'Нет данных'
    };
  }

  public updateInterval(seconds: number): void {
    const wasRunning = this.isRunning;

    if (wasRunning) {
      this.stop();
    }

    this.interval = seconds * 1000;
    console.log(`⏰ Интервал изменен на ${seconds} секунд`);

    if (wasRunning) {
      this.start();
    }
  }
}
