import { format, parseISO, type Locale } from 'date-fns';
import { formatInTimeZone, toZonedTime, fromZonedTime } from 'date-fns-tz';
import { ru, enUS } from 'date-fns/locale';

// Автоматически определяем временную зону пользователя
export const getUserTimeZone = (): string => {
  try {
    // Проверяем, что мы на клиенте
    if (typeof window !== 'undefined' && typeof Intl !== 'undefined') {
      return Intl.DateTimeFormat().resolvedOptions().timeZone;
    }
    // На сервере используем UTC как fallback
    return 'UTC';
  } catch (error) {
    return 'UTC';
  }
};

// Получаем локаль пользователя
export const getUserLocale = (): Locale => {
  try {
    // Проверяем, что мы на клиенте
    if (typeof window !== 'undefined' && typeof navigator !== 'undefined') {
      const userLang = navigator.language || 'en';
      return userLang.startsWith('ru') ? ru : enUS;
    }
    // На сервере используем русскую локаль как fallback
    return ru;
  } catch (error) {
    return ru;
  }
};

// Конвертирует UTC время в локальную зону пользователя
export const convertToUserTimeZone = (utcDateString: string): Date => {
  try {
    const utcDate = parseISO(utcDateString);
    const userTimeZone = getUserTimeZone();
    return toZonedTime(utcDate, userTimeZone);
  } catch (error) {
    console.warn('Ошибка конвертации времени:', error);
    return new Date();
  }
};

// Форматирует дату в локальной временной зоне
export const formatInUserTimeZone = (
  date: Date | string,
  formatString: string = 'dd.MM HH:mm',
  timeZone?: string
): string => {
  try {
    const userTimeZone = timeZone || getUserTimeZone();
    const userLocale = getUserLocale();

    if (typeof date === 'string') {
      date = parseISO(date);
    }

    return formatInTimeZone(date, userTimeZone, formatString, { locale: userLocale });
  } catch (error) {
    console.warn('Ошибка форматирования времени:', error);
    return typeof date === 'string' ? date : date.toLocaleString();
  }
};

// Проверяет, является ли дата сегодняшней в локальной зоне
export const isTodayInUserTimeZone = (date: Date | string): boolean => {
  try {
    const userTimeZone = getUserTimeZone();
    const targetDate = typeof date === 'string' ? parseISO(date) : date;
    const today = new Date();

    const targetInUserTZ = formatInTimeZone(targetDate, userTimeZone, 'yyyy-MM-dd');
    const todayInUserTZ = formatInTimeZone(today, userTimeZone, 'yyyy-MM-dd');

    return targetInUserTZ === todayInUserTZ;
  } catch (error) {
    console.warn('Ошибка проверки даты:', error);
    return false;
  }
};

// Правильная функция парсинга времени матча на основе реального Football API
export const parseMatchDateTime = (
  fixtureDate?: string,    // ISO 8601: "2025-09-19T00:00:00+00:00"
  timestamp?: number,      // Unix timestamp: 1758240000
  fallbackTime?: string    // Время как "HH:MM" для обратной совместимости
): {
  localDate: Date;
  formattedDate: string;
  formattedTime: string;
  isToday: boolean;
} => {
  try {
    let matchDate: Date;

    // Приоритет: timestamp > fixtureDate > fallbackTime
    if (timestamp && typeof timestamp === 'number' && timestamp > 0) {
      // Конвертируем Unix timestamp в миллисекунды
      matchDate = new Date(timestamp * 1000);
    } else if (fixtureDate && typeof fixtureDate === 'string') {
      // Парсим ISO 8601 строку
      matchDate = new Date(fixtureDate);
    } else if (fallbackTime && typeof fallbackTime === 'string') {
      // Fallback: если только время - используем сегодняшнюю дату
      const timeParts = fallbackTime.split(':');
      if (timeParts.length >= 2) {
        const hours = parseInt(timeParts[0]);
        const minutes = parseInt(timeParts[1]);

        if (!isNaN(hours) && !isNaN(minutes)) {
          matchDate = new Date();
          matchDate.setHours(hours, minutes, 0, 0);
        } else {
          matchDate = new Date();
        }
      } else {
        matchDate = new Date();
      }
    } else {
      matchDate = new Date();
    }

    // Проверяем валидность даты
    if (isNaN(matchDate.getTime())) {
      throw new Error('Invalid date created');
    }

    // Конвертируем в локальную временную зону пользователя
    const userTimeZone = getUserTimeZone();
    const localDate = toZonedTime(matchDate, userTimeZone);

    // Форматирование
    const formattedDate = formatInTimeZone(localDate, userTimeZone, 'dd.MM');
    const formattedTime = formatInTimeZone(localDate, userTimeZone, 'HH:mm');

    // Проверка на сегодняшний день в локальной зоне
    const isToday = isTodayInUserTimeZone(localDate);

    return {
      localDate,
      formattedDate,
      formattedTime,
      isToday
    };
  } catch (error) {
    console.warn('Ошибка парсинга времени матча:', { fixtureDate, timestamp, fallbackTime, error });

    // Fallback: возвращаем текущее время
    const now = new Date();
    const userTimeZone = getUserTimeZone();

    return {
      localDate: now,
      formattedDate: formatInTimeZone(now, userTimeZone, 'dd.MM'),
      formattedTime: formatInTimeZone(now, userTimeZone, 'HH:mm'),
      isToday: true
    };
  }
};
