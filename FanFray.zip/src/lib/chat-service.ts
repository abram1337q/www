import type { ChatRoom, ChatMessage, SendMessageRequest, DeleteMessageRequest, ChatStats, ChatUpdates, ApiResponse } from '@/types/chat';

const API_BASE = '/api/chat';

export const ChatService = {
  // Получить список комнат
  async getRooms(): Promise<ChatRoom[]> {
    try {
      const response = await fetch(`${API_BASE}/rooms`);
      const result: ApiResponse<ChatRoom[]> = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка получения комнат');
      }

      return result.data || [];
    } catch (error) {
      console.error('Error fetching rooms:', error);
      throw error;
    }
  },

  // Получить сообщения комнаты
  async getMessages(roomId: number, limit = 50, offset = 0): Promise<ChatMessage[]> {
    try {
      const params = new URLSearchParams({
        limit: limit.toString(),
        offset: offset.toString()
      });

      const response = await fetch(`${API_BASE}/messages/${roomId}?${params}`);
      const result: ApiResponse<ChatMessage[]> = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка получения сообщений');
      }

      return result.data || [];
    } catch (error) {
      console.error('Error fetching messages:', error);
      throw error;
    }
  },

  // Отправить сообщение
  async sendMessage(data: SendMessageRequest): Promise<ChatMessage> {
    try {
      const response = await fetch(`${API_BASE}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const result: ApiResponse<ChatMessage> = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка отправки сообщения');
      }

      if (!result.data) {
        throw new Error('Нет данных в ответе');
      }
      return result.data;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  },

  // Удалить сообщение
  async deleteMessage(data: DeleteMessageRequest): Promise<void> {
    try {
      const response = await fetch(`${API_BASE}/messages`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const result: ApiResponse = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка удаления сообщения');
      }
    } catch (error) {
      console.error('Error deleting message:', error);
      throw error;
    }
  },

  // Создать комнату
  async createRoom(name: string, description?: string): Promise<ChatRoom> {
    try {
      const response = await fetch(`${API_BASE}/rooms`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, description }),
      });

      const result: ApiResponse<ChatRoom> = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка создания комнаты');
      }

      if (!result.data) {
        throw new Error('Нет данных в ответе');
      }
      return result.data;
    } catch (error) {
      console.error('Error creating room:', error);
      throw error;
    }
  },

  // Очистить старые сообщения
  async cleanupOldMessages(): Promise<{ deletedCount: number; message: string }> {
    try {
      const response = await fetch(`${API_BASE}/cleanup`, {
        method: 'POST',
      });

      const result: ApiResponse<{ deletedCount: number; message: string }> = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка очистки сообщений');
      }

      return {
        deletedCount: result.data?.deletedCount || 0,
        message: result.data?.message || result.message || 'Очистка выполнена'
      };
    } catch (error) {
      console.error('Error during cleanup:', error);
      throw error;
    }
  },

  // Получить статистику чата
  async getChatStats(): Promise<ChatStats> {
    try {
      const response = await fetch(`${API_BASE}/cleanup`);
      const result: ApiResponse<ChatStats> = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка получения статистики');
      }

      if (!result.data) {
        throw new Error('Нет данных в ответе');
      }
      return result.data;
    } catch (error) {
      console.error('Error fetching chat stats:', error);
      throw error;
    }
  },

  // Получить обновления чата (новые и удаленные сообщения)
  async getChatUpdates(roomId: number, lastMessageId: number, lastSyncTime?: string): Promise<ChatUpdates> {
    try {
      const params = new URLSearchParams({
        roomId: roomId.toString(),
        lastMessageId: lastMessageId.toString()
      });

      if (lastSyncTime) {
        params.append('lastSyncTime', lastSyncTime);
      }

      const response = await fetch(`${API_BASE}/updates?${params}`);
      const result: ApiResponse<ChatUpdates> = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка получения обновлений чата');
      }

      return result.data || { newMessages: [], deletedMessageIds: [], syncTime: new Date().toISOString() };
    } catch (error) {
      console.error('Error fetching chat updates:', error);
      throw error;
    }
  },

  // Подписка на новые сообщения (polling)
  async pollMessages(
    roomId: number,
    initialLastMessageId: number,
    onNewMessages: (messages: ChatMessage[]) => void,
    interval = 3000
  ): Promise<() => void> {
    let isPolling = true;
    let lastMessageId = initialLastMessageId;

    const poll = async () => {
      if (!isPolling) return;

      try {
        const messages = await ChatService.getMessages(roomId, 50, 0);
        const newMessages = messages.filter(msg => msg.id > lastMessageId);

        if (newMessages.length > 0) {
          // Обновляем lastMessageId на самый новый
          lastMessageId = Math.max(...newMessages.map(msg => msg.id));
          onNewMessages(newMessages);
        }
      } catch (error) {
        console.error('Polling error:', error);
      }

      if (isPolling) {
        setTimeout(poll, interval);
      }
    };

    poll();

    // Возвращаем функцию для остановки polling
    return () => {
      isPolling = false;
    };
  },

  // Подписка на новые сообщения (polling) с поддержкой удаления - синхронизация всех сообщений
  async pollMessagesWithDeletion(
    roomId: number,
    initialLastMessageId: number,
    onNewMessages: (messages: ChatMessage[]) => void,
    onMessagesSync: (allMessages: ChatMessage[]) => void,
    interval = 3000
  ): Promise<() => void> {
    let isPolling = true;
    let lastMessageId = initialLastMessageId;
    let lastSyncTime = Date.now();

    const poll = async () => {
      if (!isPolling) return;

      try {
        // Получаем все текущие сообщения
        const messages = await ChatService.getMessages(roomId, 50, 0);

        // Проверяем, есть ли новые сообщения
        const newMessages = messages.filter(msg => msg.id > lastMessageId);

        if (newMessages.length > 0) {
          lastMessageId = Math.max(...messages.map(msg => msg.id));
          onNewMessages(newMessages);
        }

        // Каждые 10 секунд делаем полную синхронизацию для учета удалений
        const now = Date.now();
        if (now - lastSyncTime > 10000) { // 10 секунд
          onMessagesSync(messages);
          lastSyncTime = now;
          if (messages.length > 0) {
            lastMessageId = Math.max(...messages.map(msg => msg.id));
          }
        }
      } catch (error) {
        console.error('Polling error:', error);
      }

      if (isPolling) {
        setTimeout(poll, interval);
      }
    };

    poll();

    // Возвращаем функцию для остановки polling
    return () => {
      isPolling = false;
    };
  },

  // Получить количество онлайн пользователей
  async getOnlineCount(): Promise<{ onlineCount: number; lastUpdated: string }> {
    try {
      const response = await fetch(`${API_BASE}/online`);
      const result: ApiResponse<{ onlineCount: number; lastUpdated: string }> = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка получения онлайн пользователей');
      }

      return result.data || { onlineCount: 0, lastUpdated: new Date().toISOString() };
    } catch (error) {
      console.error('Error fetching online count:', error);
      throw error;
    }
  },

  // Получить количество непрочитанных сообщений
  async getUnreadCount(userId: number): Promise<{ unreadCount: number; lastUpdated: string }> {
    try {
      const response = await fetch(`${API_BASE}/unread?userId=${userId}`);
      const result: ApiResponse<{ unreadCount: number; lastUpdated: string }> = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка получения непрочитанных сообщений');
      }

      return result.data || { unreadCount: 0, lastUpdated: new Date().toISOString() };
    } catch (error) {
      console.error('Error fetching unread count:', error);
      throw error;
    }
  },

  // Отметить сообщения как прочитанные
  async markAsRead(userId: number, roomId: number, lastReadMessageId?: number): Promise<void> {
    try {
      const response = await fetch(`${API_BASE}/unread`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId, roomId, lastReadMessageId }),
      });

      const result: ApiResponse = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка отметки сообщений как прочитанные');
      }
    } catch (error) {
      console.error('Error marking messages as read:', error);
      throw error;
    }
  }
};
