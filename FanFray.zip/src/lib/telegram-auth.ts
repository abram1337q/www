import crypto from 'crypto';

/**
 * Верификация initData от Telegram Web App
 * https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 */

export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
}

export interface ValidatedInitData {
  user: TelegramUser;
  auth_date: number;
  hash: string;
  query_id?: string;
  start_param?: string;
}

/**
 * Проверяет подпись initData от Telegram
 * @param initData - строка initData из Telegram.WebApp.initData
 * @param botToken - токен бота
 * @returns объект с данными пользователя или null если невалидно
 */
export function validateInitData(initData: string, botToken: string): ValidatedInitData | null {
  try {
    if (!initData || !botToken) {
      console.error('validateInitData: Missing initData or botToken');
      return null;
    }

    // Парсим initData
    const params = new URLSearchParams(initData);
    const hash = params.get('hash');

    if (!hash) {
      console.error('validateInitData: Missing hash');
      return null;
    }

    // Удаляем hash из параметров для проверки
    params.delete('hash');

    // Сортируем параметры и формируем data-check-string
    const dataCheckArr: string[] = [];
    params.sort();
    params.forEach((value, key) => {
      dataCheckArr.push(`${key}=${value}`);
    });
    const dataCheckString = dataCheckArr.join('\n');

    // Создаём secret_key = HMAC_SHA256(bot_token, "WebAppData")
    const secretKey = crypto
      .createHmac('sha256', 'WebAppData')
      .update(botToken)
      .digest();

    // Вычисляем HMAC_SHA256(data_check_string, secret_key)
    const calculatedHash = crypto
      .createHmac('sha256', secretKey)
      .update(dataCheckString)
      .digest('hex');

    // Сравниваем хэши
    if (calculatedHash !== hash) {
      console.error('validateInitData: Hash mismatch');
      return null;
    }

    // Проверяем auth_date (не старше 24 часов)
    const authDate = parseInt(params.get('auth_date') || '0', 10);
    const now = Math.floor(Date.now() / 1000);
    const maxAge = 24 * 60 * 60; // 24 часа

    if (now - authDate > maxAge) {
      console.error('validateInitData: Auth data expired');
      return null;
    }

    // Парсим данные пользователя
    const userStr = params.get('user');
    if (!userStr) {
      console.error('validateInitData: Missing user data');
      return null;
    }

    const user: TelegramUser = JSON.parse(userStr);

    return {
      user,
      auth_date: authDate,
      hash,
      query_id: params.get('query_id') || undefined,
      start_param: params.get('start_param') || undefined,
    };
  } catch (error) {
    console.error('validateInitData: Error validating:', error);
    return null;
  }
}

/**
 * Проверяет подпись webhook от Telegram
 * @param body - тело запроса
 * @param secretToken - секретный токен из X-Telegram-Bot-Api-Secret-Token
 * @returns true если валидно
 */
export function validateWebhookSecret(secretToken: string | null, expectedSecret: string): boolean {
  if (!secretToken || !expectedSecret) {
    return false;
  }

  // Безопасное сравнение строк для защиты от timing attacks
  try {
    return crypto.timingSafeEqual(
      Buffer.from(secretToken),
      Buffer.from(expectedSecret)
    );
  } catch {
    return false;
  }
}

/**
 * Извлекает и валидирует telegram_id из заголовков запроса
 * @param headers - заголовки запроса
 * @returns telegram_id или null
 */
export function extractAndValidateTelegramId(
  initData: string | null,
  botToken: string
): number | null {
  if (!initData) {
    return null;
  }

  const validated = validateInitData(initData, botToken);
  if (!validated) {
    return null;
  }

  return validated.user.id;
}
