// Утилиты для API запросов
import type { ApiResponse, GetBetsResponse, RegisterUserResponse } from '@/types/api';

export class ApiError extends Error {
  constructor(public status: number, message: string, public details?: unknown) {
    super(message);
    this.name = 'ApiError';
  }
}

/**
 * Получает initData из Telegram WebApp для аутентификации
 */
function getTelegramInitData(): string | null {
  if (typeof window === 'undefined') return null;
  return window.Telegram?.WebApp?.initData || null;
}

export async function apiRequest<T>(
  url: string,
  options: RequestInit = {},
  telegramUserId?: number
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  // БЕЗОПАСНОСТЬ: Добавляем initData для верификации на сервере
  const initData = getTelegramInitData();
  if (initData) {
    headers['x-telegram-init-data'] = initData;
  }

  // Оставляем для обратной совместимости (будет удалено)
  if (telegramUserId) {
    headers['x-telegram-user-id'] = telegramUserId.toString();
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new ApiError(response.status, data.error || 'API Error', data.details);
  }

  if (!data.success) {
    throw new ApiError(response.status, data.error || 'Request failed', data.details);
  }

  return data;
}

// Специфичные API функции
export const betsApi = {
  create: async (data: Record<string, unknown>, telegramUserId?: number) =>
    apiRequest('/api/bets/create', {
      method: 'POST',
      body: JSON.stringify(data),
    }, telegramUserId),

  join: async (data: Record<string, unknown>, telegramUserId?: number) =>
    apiRequest('/api/bets/join', {
      method: 'POST',
      body: JSON.stringify(data),
    }, telegramUserId),

  getOpen: async (params: Record<string, string> = {}, telegramUserId?: number): Promise<GetBetsResponse> => {
    const searchParams = new URLSearchParams(params);
    return apiRequest(`/api/bets/open?${searchParams}`, {}, telegramUserId) as Promise<GetBetsResponse>;
  },

  getMy: async (params: Record<string, string> = {}, telegramUserId?: number): Promise<GetBetsResponse> => {
    const searchParams = new URLSearchParams(params);
    return apiRequest(`/api/bets/my?${searchParams}`, {}, telegramUserId) as Promise<GetBetsResponse>;
  },
};

export const userApi = {
  register: async (data: Record<string, unknown>): Promise<RegisterUserResponse> =>
    apiRequest('/api/user/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }) as Promise<RegisterUserResponse>,

  getBalance: async (telegramUserId?: number): Promise<RegisterUserResponse> =>
    apiRequest('/api/user/balance', {}, telegramUserId) as Promise<RegisterUserResponse>,
};
