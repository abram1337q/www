import { useState, useEffect } from 'react';

// Кэш для фотографий пользователей
const photoCache = new Map<number, string | null>();

export const useUserPhoto = (userId: number | undefined, telegramId?: number) => {
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Определяем какой ID использовать для кеша и запроса
    const cacheKey = telegramId || userId;

    if (!cacheKey) {
      setPhotoUrl(null);
      return;
    }

    // Проверяем кэш
    if (photoCache.has(cacheKey)) {
      setPhotoUrl(photoCache.get(cacheKey) || null);
      return;
    }

    // Загружаем фотографию
    const fetchPhoto = async () => {
      setLoading(true);
      try {
        // Выбираем правильный параметр для запроса
        const queryParam = telegramId ? `telegramId=${telegramId}` : `userId=${userId}`;
        const response = await fetch(`/api/user/photo?${queryParam}`);

        if (response.ok) {
          const data = await response.json();
          const url = data.photo_url;

          // Кэшируем результат
          photoCache.set(cacheKey, url);
          setPhotoUrl(url);
        } else {
          // Кэшируем отсутствие фото
          photoCache.set(cacheKey, null);
          setPhotoUrl(null);
        }
      } catch (error) {
        console.error('Error loading user photo:', error);
        photoCache.set(cacheKey, null);
        setPhotoUrl(null);
      } finally {
        setLoading(false);
      }
    };

    fetchPhoto();
  }, [userId, telegramId]);

  return { photoUrl, loading };
};

// Функция для предзагрузки фотографий (например, для чата)
export const preloadUserPhotos = (userIds: number[], isTelegramIds = false) => {
  userIds.forEach(userId => {
    if (!photoCache.has(userId)) {
      const queryParam = isTelegramIds ? `telegramId=${userId}` : `userId=${userId}`;
      fetch(`/api/user/photo?${queryParam}`)
        .then(response => response.json())
        .then(data => {
          photoCache.set(userId, data.photo_url || null);
        })
        .catch(error => {
          console.error('Error preloading photo for user', userId, error);
          photoCache.set(userId, null);
        });
    }
  });
};
