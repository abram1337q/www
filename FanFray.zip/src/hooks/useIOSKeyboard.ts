'use client';

import { useEffect, useRef, useCallback } from 'react';

interface UseIOSKeyboardOptions {
  enabled?: boolean;
  delay?: number;
}

export const useIOSKeyboard = ({ enabled = true, delay = 300 }: UseIOSKeyboardOptions = {}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const initialViewportHeight = useRef<number>(0);

  // Определяем iOS устройство
  const isIOS = () => {
    // Используем более надежные способы определения iOS
    return /iPad|iPhone|iPod/.test(navigator.userAgent) ||
           (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1) || // iPad на iOS 13+
           ((window as typeof window & { Telegram?: { WebApp?: { platform?: string } } }).Telegram?.WebApp?.platform === 'ios');
  };

  // Функция автоскроллинга к полю ввода
  const scrollToInput = useCallback(() => {
    if (!enabled || !isIOS() || !inputRef.current) return;

    setTimeout(() => {
      if (inputRef.current) {
        // Пробуем найти скроллируемый контейнер разными способами
        let scrollContainer = inputRef.current.closest('.overflow-y-auto') as HTMLElement;

        if (!scrollContainer) {
          // Ищем контейнер с max-h- классами (часто используется в модальных окнах)
          scrollContainer = inputRef.current.closest('[class*="max-h-"]') as HTMLElement;
        }

        if (!scrollContainer) {
          // Ищем DialogContent
          scrollContainer = inputRef.current.closest('[data-radix-dialog-content]') as HTMLElement;
        }

        if (!scrollContainer) {
          // Последняя попытка - любой родительский элемент с overflow
          let element = inputRef.current.parentElement;
          while (element) {
            const computedStyle = window.getComputedStyle(element);
            if (computedStyle.overflowY === 'auto' || computedStyle.overflowY === 'scroll') {
              scrollContainer = element;
              break;
            }
            element = element.parentElement;
          }
        }

        if (scrollContainer) {
          // Получаем позицию элемента относительно контейнера
          const inputRect = inputRef.current.getBoundingClientRect();
          const containerRect = scrollContainer.getBoundingClientRect();

          // Определяем высоту клавиатуры более точно
          const currentInitialHeight = initialViewportHeight.current || window.innerHeight;
          const currentViewportHeight = window.visualViewport?.height || window.innerHeight;
          const keyboardHeight = Math.max(0, currentInitialHeight - currentViewportHeight);

          // Если клавиатура еще не открыта, используем примерное значение
          const estimatedKeyboardHeight = keyboardHeight > 0 ? keyboardHeight : currentInitialHeight * 0.35;

          // Вычисляем нужную позицию для скролла
          const relativeTop = inputRect.top - containerRect.top;
          const availableHeight = containerRect.height - estimatedKeyboardHeight;
          const targetScrollTop = scrollContainer.scrollTop + relativeTop - availableHeight / 2;

          // Плавный скролл к полю ввода
          scrollContainer.scrollTo({
            top: Math.max(0, targetScrollTop),
            behavior: 'smooth'
          });
        } else {
          // Fallback - скролл всего окна
          inputRef.current.scrollIntoView({
            behavior: 'smooth',
            block: 'center',
            inline: 'nearest'
          });
        }
      }
    }, delay);
  }, [enabled, delay]);

  // Обработчик фокуса на поле ввода
  const handleInputFocus = useCallback(() => {
    if (isIOS()) {
      scrollToInput();
    }
  }, [scrollToInput]);

  // Обработчик изменения размера окна (для обнаружения клавиатуры)
  const handleResize = useCallback(() => {
    if (isIOS() && inputRef.current && document.activeElement === inputRef.current) {
      // Небольшая задержка, чтобы браузер успел изменить viewport
      setTimeout(() => {
        scrollToInput();
      }, 100);
    }
  }, [scrollToInput]);

  // Обработчик изменения Visual Viewport (более точное определение клавиатуры)
  const handleVisualViewportChange = useCallback(() => {
    if (isIOS() && inputRef.current && document.activeElement === inputRef.current) {
      setTimeout(() => {
        scrollToInput();
      }, 50);
    }
  }, [scrollToInput]);

  // Эффект для добавления обработчиков
  useEffect(() => {
    const inputElement = inputRef.current;
    if (!inputElement || !enabled) return;

    inputElement.addEventListener('focus', handleInputFocus);

    // Добавляем обработчики для iOS
    if (isIOS()) {
      window.addEventListener('resize', handleResize);

      // Используем Visual Viewport API если доступен (более точное определение клавиатуры)
      if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', handleVisualViewportChange);
      }
    }

    return () => {
      inputElement.removeEventListener('focus', handleInputFocus);
      if (isIOS()) {
        window.removeEventListener('resize', handleResize);
        if (window.visualViewport) {
          window.visualViewport.removeEventListener('resize', handleVisualViewportChange);
        }
      }
    };
  }, [enabled, handleInputFocus, handleResize, handleVisualViewportChange]);

  // Сохраняем изначальную высоту viewport при инициализации
  useEffect(() => {
    if (typeof window !== 'undefined') {
      initialViewportHeight.current = window.innerHeight;
    }
  }, []);

  return {
    inputRef,
    scrollToInput,
    isIOS: isIOS()
  };
};
