import { useState, useEffect, useCallback } from 'react';
import { betsApi } from '@/lib/api';
import type { Bet } from '@/types/api';

interface UserStats {
  totalBets: number;
  wonBets: number;
  finishedBets: number;
  winRate: number;
  totalWinnings: number;
  loading: boolean;
  error: string | null;
}

export const useUserStats = (userId?: number) => {
  const [stats, setStats] = useState<UserStats>({
    totalBets: 0,
    wonBets: 0,
    finishedBets: 0,
    winRate: 0,
    totalWinnings: 0,
    loading: true,
    error: null
  });

  // Функция для определения результата матча
  const getMatchResult = (homeScore: number, awayScore: number): "home" | "draw" | "away" => {
    if (homeScore > awayScore) return "home";
    if (homeScore < awayScore) return "away";
    return "draw";
  };

  // Маппинг статусов из API в отображаемые статусы
  const mapApiStatusToDisplayStatus = useCallback((bet: Bet): "active" | "won" | "lost" | "cancelled" | "refunded" => {
    // Используем user_status из API, если он есть
    if (bet.user_status) {
      switch (bet.user_status) {
        case "won":
          return "won";
        case "lost":
          return "lost";
        case "refunded":
          return "refunded";
        case "cancelled":
          return "cancelled";
        case "completed":
        case "in_progress":
        case "waiting":
        default:
          return "active";
      }
    }

    // Fallback к старой логике
    const apiStatus = bet.status;

    switch (apiStatus) {
      case "open":
      case "closed":
        return "active";
      case "refunded":
        return "refunded";
      case "completed":
        // Проверяем результат матча
        if (bet.match?.home_score !== undefined && bet.match?.away_score !== undefined) {
          const matchResult = getMatchResult(bet.match.home_score, bet.match.away_score);
          const userPrediction = bet.prediction_type;

          // Определяем, выиграл ли пользователь
          return matchResult === userPrediction ? "won" : "lost";
        }
        return "active"; // Если нет результата матча, считаем активным
      case "cancelled":
        return "cancelled";
      default:
        return "active";
    }
  }, []);

  const fetchUserStats = useCallback(async () => {
    if (!userId) return;

    try {
      setStats(prev => ({ ...prev, loading: true, error: null }));

      const response = await betsApi.getMy({}, userId);

      // Преобразуем данные API в формат для статистики
      const bets = response.bets.map((bet: Bet) => ({
        ...bet,
        displayStatus: mapApiStatusToDisplayStatus(bet)
      }));

      // Вычисляем статистику
      const totalBets = bets.length;
      const wonBets = bets.filter(bet => bet.displayStatus === "won").length;
      const finishedBets = bets.filter(bet => bet.displayStatus === "won" || bet.displayStatus === "lost").length;
      const winRate = finishedBets > 0 ? Math.round((wonBets / finishedBets) * 100) : 0;
      const totalWinnings = bets
        .filter(bet => bet.displayStatus === "won")
        .reduce((sum, bet) => sum + (bet.result?.payout || 0), 0);

      setStats({
        totalBets,
        wonBets,
        finishedBets,
        winRate,
        totalWinnings,
        loading: false,
        error: null
      });
    } catch (err) {
      console.error('Error fetching user stats:', err);
      setStats(prev => ({
        ...prev,
        loading: false,
        error: err instanceof Error ? err.message : 'Ошибка загрузки статистики'
      }));
    }
  }, [userId, mapApiStatusToDisplayStatus]);

  useEffect(() => {
    fetchUserStats();
  }, [fetchUserStats]);

  return {
    ...stats,
    refetch: fetchUserStats
  };
};
