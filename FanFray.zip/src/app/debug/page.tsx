"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useTelegram } from "@/components/providers/TelegramProvider";

interface APIResponse {
  conversionRate?: number;
  minConversionAmount?: number;
  description?: string;
  history?: Array<{
    id: number;
    stars_amount: number;
    ton_amount: number;
    ton_wallet_address: string;
    status: string;
    created_at: string;
    processed_at?: string;
    error_message?: string;
  }>;
  error?: string;
}

export default function DebugPage() {
  const { user } = useTelegram();
  const [result, setResult] = useState<APIResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [telegramId, setTelegramId] = useState<string>("");

  const testConversionAPI = async () => {
    const userId = telegramId || user?.id;
    if (!userId) {
      setResult({ error: "Введите Telegram ID или используйте авторизованного пользователя" });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/stars/convert-to-ton?telegramId=${userId}`);
      const data = await response.json();
      setResult(data);
    } catch (error) {
      setResult({ error: error instanceof Error ? error.message : 'Unknown error' });
    } finally {
      setLoading(false);
    }
  };

  const testAllConversions = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/debug/all-conversions`);
      const data = await response.json();
      setResult(data);
    } catch (error) {
      setResult({ error: error instanceof Error ? error.message : 'Unknown error' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-bold">Debug Conversion API</h1>

      <div className="space-y-2">
        <p>Авторизованный пользователь:</p>
        <p>User ID: {user?.id || "Не авторизован"}</p>
        <p>Username: {user?.username || "N/A"}</p>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium">Или введите Telegram ID для тестирования:</label>
        <Input
          type="text"
          placeholder="Например: 123456789"
          value={telegramId}
          onChange={(e) => setTelegramId(e.target.value)}
          className="max-w-xs"
        />
      </div>

      <div className="flex gap-2">
        <Button onClick={testConversionAPI} disabled={loading}>
          {loading ? "Loading..." : "Test Conversion API"}
        </Button>
        <Button onClick={testAllConversions} disabled={loading} variant="outline">
          {loading ? "Loading..." : "Show All Conversions"}
        </Button>
      </div>

      {result && (
        <div className="bg-slate-800 p-4 rounded-lg">
          <h3 className="font-bold mb-2">API Response:</h3>
          <pre className="text-sm overflow-auto">
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}
