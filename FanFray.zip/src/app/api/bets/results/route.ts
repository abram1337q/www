import { type NextRequest, NextResponse } from 'next/server';
import { getUserBetResults, getBetResultForUser } from '@/lib/database-utils';
import pool from '@/lib/database';

interface BetResultSummary {
  bet_id: number;
  win_amount?: number;
  loss_amount?: number;
  currency: 'TON' | 'STARS';
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);

    // Получаем пользователя из заголовков
    const telegramId = request.headers.get('x-telegram-user-id');

    if (!telegramId) {
      return NextResponse.json(
        { error: 'User not authenticated' },
        { status: 401 }
      );
    }

    // Получаем пользователя из БД
    const userResult = await pool.query(
      'SELECT id FROM users WHERE telegram_id = $1',
      [telegramId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = userResult.rows[0].id;
    const betId = searchParams.get('bet_id');

    // Если запрашивается конкретный спор
    if (betId) {
      const result = await getBetResultForUser(Number(betId), userId);
      return NextResponse.json({ result });
    }

    // Если запрашиваются все результаты пользователя
    const results = await getUserBetResults(userId);

    // Группируем результаты по bet_id для удобства использования
    const resultsByBetId = results.reduce((acc, result) => {
      if (!acc[result.bet_id]) {
        acc[result.bet_id] = {
          bet_id: result.bet_id,
          win_amount: result.win_amount,
          loss_amount: result.loss_amount,
          currency: result.currency
        };
      }
      return acc;
    }, {} as Record<number, BetResultSummary>);

    return NextResponse.json({ results: resultsByBetId });
  } catch (error) {
    console.error('Error in bet results API:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
