import { type NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const betId = searchParams.get('bet_id');

    if (!betId) {
      return NextResponse.json(
        { error: 'bet_id is required' },
        { status: 400 }
      );
    }

    // Получаем участников спора с информацией о пользователях
    const participantsResult = await query(`
      SELECT
        bp.*,
        u.username,
        u.first_name,
        u.last_name,
        u.telegram_id
      FROM bet_participants bp
      JOIN users u ON bp.user_id = u.id
      WHERE bp.bet_id = $1
      ORDER BY bp.joined_at ASC
    `, [betId]);

    // Получаем информацию о создателе спора
    const creatorResult = await query(`
      SELECT
        b.comment as creator_comment,
        u.id as creator_id,
        u.username as creator_username,
        u.first_name as creator_first_name,
        u.last_name as creator_last_name,
        u.telegram_id as creator_telegram_id,
        b.prediction_type as creator_prediction_type,
        b.amount as creator_amount,
        b.created_at as creator_joined_at
      FROM bets b
      JOIN users u ON b.creator_id = u.id
      WHERE b.id = $1
    `, [betId]);

    const participants = participantsResult.rows;
    const creator = creatorResult.rows[0];

    // Формируем ответ с комментариями
    const comments = [];

    // Добавляем комментарий создателя (если есть)
    if (creator && (creator.creator_comment || '').trim()) {
      comments.push({
        id: `creator-${creator.creator_id}`,
        user_id: creator.creator_id,
        username: creator.creator_username,
        first_name: creator.creator_first_name,
        last_name: creator.creator_last_name,
        telegram_id: creator.creator_telegram_id,
        comment: creator.creator_comment,
        prediction_type: creator.creator_prediction_type,
        amount: creator.creator_amount,
        joined_at: creator.creator_joined_at,
        is_creator: true
      });
    }

    // Добавляем комментарии участников (если есть)
    participants.forEach(participant => {
      if ((participant.comment || '').trim()) {
        comments.push({
          id: `participant-${participant.id}`,
          user_id: participant.user_id,
          username: participant.username,
          first_name: participant.first_name,
          last_name: participant.last_name,
          telegram_id: participant.telegram_id,
          comment: participant.comment,
          prediction_type: participant.prediction_type,
          amount: participant.amount,
          joined_at: participant.joined_at,
          is_creator: false
        });
      }
    });

    return NextResponse.json({
      success: true,
      comments: comments.sort((a, b) => new Date(a.joined_at).getTime() - new Date(b.joined_at).getTime())
    });

  } catch (error) {
    console.error('Error fetching bet participants:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
