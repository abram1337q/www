import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';
import { footballService } from '@/lib/football-service';
import { footballApi } from '@/lib/football-api';
import { GetBetsRequest, BetWithDetails } from '@/types/bets';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);

    // Параметры фильтрации
    const currency = searchParams.get('currency') || 'all';
    const sortBy = searchParams.get('sort_by') || 'created_at';
    const sortOrder = searchParams.get('sort_order') || 'desc';
    const limit = Number.parseInt(searchParams.get('limit') || '20');
    const offset = Number.parseInt(searchParams.get('offset') || '0');
    const searchQuery = searchParams.get('search') || '';

    // Получаем текущего пользователя (если авторизован)
    const telegramId = request.headers.get('x-telegram-user-id');
    let currentUserId: number | null = null;

    if (telegramId) {
      const userResult = await pool.query(
        'SELECT id FROM users WHERE telegram_id = $1',
        [telegramId]
      );
      if (userResult.rows.length > 0) {
        currentUserId = userResult.rows[0].id;
      }
    }

    // Построение SQL запроса
    // Показываем ТОЛЬКО открытые ставки, исключаем все остальные статусы
    const whereConditions = ["b.status = 'open'"];
    const queryParams: unknown[] = [];
    let paramIndex = 1;

    // Фильтр по валюте
    if (currency !== 'all' && ['TON', 'STARS'].includes(currency)) {
      whereConditions.push(`b.currency = $${paramIndex}`);
      queryParams.push(currency);
      paramIndex++;
    }

    // Фильтр по поиску (команды, лига)
    if (searchQuery) {
      whereConditions.push(`(
        LOWER(m.home_team) LIKE LOWER($${paramIndex}) OR
        LOWER(m.away_team) LIKE LOWER($${paramIndex}) OR
        LOWER(m.league) LIKE LOWER($${paramIndex}) OR
        LOWER(b.prediction_text) LIKE LOWER($${paramIndex})
      )`);
      queryParams.push(`%${searchQuery}%`);
      paramIndex++;
    }

    // Исключаем истекшие споры
    whereConditions.push('(b.expires_at IS NULL OR b.expires_at > NOW())');

    // Исключаем только завершенные и отмененные матчи
    // Показываем споры на будущие матчи и активные матчи
    whereConditions.push("m.status NOT IN ('finished', 'cancelled')");

    // Определение сортировки
    let orderBy = 'b.created_at DESC';
    switch (sortBy) {
      case 'amount':
        orderBy = `b.amount ${sortOrder.toUpperCase()}`;
        break;
      case 'expires_at':
        orderBy = `b.expires_at ${sortOrder.toUpperCase()}`;
        break;
      case 'participants':
        orderBy = `participants_count ${sortOrder.toUpperCase()}`;
        break;
      default:
        orderBy = `b.created_at ${sortOrder.toUpperCase()}`;
    }

    const whereClause = whereConditions.join(' AND ');

    // Основной запрос
    const query = `
      SELECT
        b.*,
        b.comment,
        u.username as creator_username,
        u.first_name as creator_first_name,
        u.last_name as creator_last_name,
        u.telegram_id as creator_telegram_id,
        m.home_team,
        m.away_team,
        m.home_team_logo,
        m.away_team_logo,
        m.league,
        m.league_logo,
        m.start_time as match_start_time,
        m.venue,
        m.status as match_status,
        (1 + (SELECT COUNT(*) FROM bet_participants WHERE bet_id = b.id)) as participants_count,
        CASE
          WHEN b.expires_at IS NOT NULL THEN
            EXTRACT(EPOCH FROM (b.expires_at - NOW()))
          ELSE
            EXTRACT(EPOCH FROM (m.start_time - NOW() - INTERVAL '1 minute'))
        END as seconds_left,
        ${currentUserId ? `(SELECT COUNT(*) FROM bet_participants WHERE bet_id = b.id AND user_id = ${currentUserId}) > 0 as user_participating` : 'false as user_participating'}
      FROM bets b
      JOIN users u ON b.creator_id = u.id
      JOIN matches m ON b.match_id = m.id
      WHERE ${whereClause}
      ORDER BY ${orderBy}
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;

    queryParams.push(limit, offset);

    const result = await pool.query(query, queryParams);

    // Получаем актуальные данные матчей из внешнего API
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    let liveMatches: Array<{
      homeTeam: string;
      awayTeam: string;
      homeTeamLogo?: string;
      awayTeamLogo?: string;
      status: string;
      startTime?: string;
      minute?: number;
    }> = [];
    let todayMatches: Array<{
      homeTeam: string;
      awayTeam: string;
      homeTeamLogo?: string;
      awayTeamLogo?: string;
      status: string;
      startTime?: string;
      minute?: number;
    }> = [];

    try {
      // Получаем актуальные матчи с логотипами
      liveMatches = await footballService.getLiveMatches();
      todayMatches = await footballService.getTodayMatches();
    } catch (error) {
      console.error('Failed to fetch live match data:', error);
    }

    // Объединяем live и today матчи для поиска актуальных данных
    const allCurrentMatches = [...liveMatches, ...todayMatches];

    // Получаем участников для каждого спора
    const betsWithParticipants = await Promise.all(
      result.rows.map(async (bet) => {
        const participantsResult = await pool.query(`
          SELECT
            bp.*,
            u.username,
            u.first_name,
            u.last_name
          FROM bet_participants bp
          JOIN users u ON bp.user_id = u.id
          WHERE bp.bet_id = $1
          ORDER BY bp.joined_at ASC
        `, [bet.id]);

        // Вычисляем время до истечения
        let timeLeft = '';
        if (bet.seconds_left > 0) {
          const hours = Math.floor(bet.seconds_left / 3600);
          const minutes = Math.floor((bet.seconds_left % 3600) / 60);
          if (hours > 0) {
            timeLeft = `${hours}ч ${minutes}м`;
          } else {
            timeLeft = `${minutes}м`;
          }
        } else {
          timeLeft = 'Истекло';
        }

        // Ищем актуальные данные матча из внешнего API
        const currentMatch = allCurrentMatches.find(match =>
          (match.homeTeam.toLowerCase().includes(bet.home_team.toLowerCase()) ||
           bet.home_team.toLowerCase().includes(match.homeTeam.toLowerCase())) &&
          (match.awayTeam.toLowerCase().includes(bet.away_team.toLowerCase()) ||
           bet.away_team.toLowerCase().includes(match.awayTeam.toLowerCase()))
        );

        // Получаем логотипы команд из API или используем fallback из БД
        let homeTeamLogo = bet.home_team_logo || '';
        let awayTeamLogo = bet.away_team_logo || '';

        if (currentMatch) {
          homeTeamLogo = currentMatch.homeTeamLogo || bet.home_team_logo || '';
          awayTeamLogo = currentMatch.awayTeamLogo || bet.away_team_logo || '';
        }

        // Используем актуальные данные, если найдены
        let matchStatus = bet.match_status;
        let matchStartTime = bet.match_start_time;
        let matchMinute = null;

        if (currentMatch) {
          matchStatus = currentMatch.status;
          matchStartTime = currentMatch.startTime ?
            new Date(`${today}T${currentMatch.startTime}:00.000Z`).toISOString() :
            bet.match_start_time;
          matchMinute = currentMatch.minute;
        }

        // Пропускаем завершенные матчи
        if (matchStatus === 'finished' || matchStatus === 'ft' || matchStatus === 'completed') {
          return null;
        }

        // Ключевая логика: если матч не найден в актуальных данных,
        // это означает что он завершился и больше не отслеживается
        if (!currentMatch) {
          const now = new Date();
          const matchStart = new Date(matchStartTime);
          const hoursElapsed = (now.getTime() - matchStart.getTime()) / (1000 * 60 * 60);

          // Если матч уже должен был начаться, но его нет в актуальных данных - удаляем
          if (hoursElapsed > 0) {
            console.log(`Удаляем спор для завершенного матча: ${bet.home_team} vs ${bet.away_team}`);
            return null;
          }
        }

        // Проверяем, может ли пользователь присоединиться
        // БЛОКИРОВКА: Учитываем статус матча и время до начала
        const now = new Date();
        const oneMinuteBeforeStart = new Date(new Date(matchStartTime).getTime() - 60 * 1000);
        const isMatchStartingSoon = now >= oneMinuteBeforeStart;
        const isMatchNotUpcoming = matchStatus !== 'upcoming';

        const canJoin = !bet.user_participating &&
                       bet.participants_count < bet.max_participants &&
                       bet.seconds_left > 0 &&
                       (currentUserId !== bet.creator_id) &&
                       !isMatchStartingSoon &&
                       !isMatchNotUpcoming;

        // Вычисляем потенциальный выигрыш
        const totalPool = bet.amount + (participantsResult.rows.reduce((sum, p) => sum + Number.parseFloat(p.amount), 0));
        const potentialWinnings = totalPool * bet.odds;

        return {
          ...bet,
          // Добавляем логотипы команд в основной объект bet
          home_team_logo: homeTeamLogo,
          away_team_logo: awayTeamLogo,
          creator: {
            id: bet.creator_id,
            username: bet.creator_username,
            first_name: bet.creator_first_name,
            last_name: bet.creator_last_name,
            telegram_id: bet.creator_telegram_id
          },
          match: {
            id: bet.match_id,
            home_team: bet.home_team,
            away_team: bet.away_team,
            home_team_logo: homeTeamLogo,
            away_team_logo: awayTeamLogo,
            league: bet.league,
            league_logo: bet.league_logo,
            start_time: matchStartTime,
            venue: bet.venue,
            status: matchStatus,
            minute: matchMinute
          },
          participants: participantsResult.rows,
          time_left: timeLeft,
          can_join: canJoin,
          potential_winnings: potentialWinnings,
          amount: Number.parseFloat(bet.amount),
          odds: Number.parseFloat(bet.odds)
        };
      })
    );

    // Фильтруем завершенные матчи (убираем null значения)
    const filteredBets = betsWithParticipants.filter(bet => bet !== null);

    // Получаем общее количество для пагинации
    const countQuery = `
      SELECT COUNT(*) as total
      FROM bets b
      JOIN matches m ON b.match_id = m.id
      WHERE ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams.slice(0, -2)); // убираем limit и offset
    const total = Number.parseInt(countResult.rows[0].total);

    // Получаем статистику - только открытые споры
    const statsResult = await pool.query(`
      SELECT
        COUNT(DISTINCT b.id) as total_open_bets,
        SUM(CASE WHEN b.currency = 'TON' THEN
          b.amount + COALESCE((
            SELECT SUM(bp.amount)
            FROM bet_participants bp
            WHERE bp.bet_id = b.id
          ), 0)
          ELSE 0 END) as total_ton_volume,
        SUM(CASE WHEN b.currency = 'STARS' THEN
          b.amount + COALESCE((
            SELECT SUM(bp.amount)
            FROM bet_participants bp
            WHERE bp.bet_id = b.id
          ), 0)
          ELSE 0 END) as total_stars_volume
      FROM bets b
      JOIN matches m ON b.match_id = m.id
      WHERE b.status = 'open'
        AND (b.expires_at IS NULL OR b.expires_at > NOW())
        AND m.start_time > NOW()
        AND m.status != 'finished'
        AND m.status != 'cancelled'
    `);

    const stats = statsResult.rows[0];

    return NextResponse.json({
      success: true,
      bets: filteredBets,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      },
      stats: {
        total_bets: Number.parseInt(stats.total_open_bets),
        total_amount_ton: Number.parseFloat(stats.total_ton_volume) || 0,
        total_amount_stars: Number.parseFloat(stats.total_stars_volume) || 0
      },
      filters: {
        currency,
        sort_by: sortBy,
        sort_order: sortOrder,
        search: searchQuery
      }
    });

  } catch (error) {
    console.error('Error fetching open bets:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
