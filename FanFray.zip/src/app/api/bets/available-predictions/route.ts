import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';
import { footballService } from '@/lib/football-service';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const betId = searchParams.get('bet_id');

    if (!betId || isNaN(Number(betId))) {
      return NextResponse.json(
        { error: 'Valid bet_id is required' },
        { status: 400 }
      );
    }

    const client = await pool.connect();

    try {
      // Получаем информацию о споре
      const betResult = await client.query(`
        SELECT
          b.id,
          b.prediction_type as creator_prediction,
          b.amount as creator_amount,
          b.currency,
          b.status,
          m.home_team,
          m.away_team,
          m.start_time,
          (SELECT COALESCE(SUM(bp.amount), 0) FROM bet_participants bp WHERE bp.bet_id = b.id) as participants_total
        FROM bets b
        JOIN matches m ON b.match_id = m.id
        WHERE b.id = $1
      `, [betId]);

      if (betResult.rows.length === 0) {
        return NextResponse.json(
          { error: 'Bet not found' },
          { status: 404 }
        );
      }

      const bet = betResult.rows[0];

      if (bet.status !== 'open') {
        return NextResponse.json(
          { error: 'Bet is not open for new participants' },
          { status: 400 }
        );
      }

      // Получаем логотипы команд из football API
      let homeTeamLogo = '';
      let awayTeamLogo = '';

      try {
        // Пытаемся найти матч в сегодняшних матчах по названиям команд
        const todayMatches = await footballService.getTodayMatches();
        const liveMatches = await footballService.getLiveMatches();
        const allMatches = [...todayMatches, ...liveMatches];

        const matchFound = allMatches.find(match =>
          (match.homeTeam.toLowerCase().includes(bet.home_team.toLowerCase()) ||
           bet.home_team.toLowerCase().includes(match.homeTeam.toLowerCase())) &&
          (match.awayTeam.toLowerCase().includes(bet.away_team.toLowerCase()) ||
           bet.away_team.toLowerCase().includes(match.awayTeam.toLowerCase()))
        );

        if (matchFound) {
          homeTeamLogo = matchFound.homeTeamLogo || '';
          awayTeamLogo = matchFound.awayTeamLogo || '';
        }
      } catch (error) {
        console.log('Could not fetch team logos:', error);
        // Продолжаем без логотипов
      }

      // Получаем уже занятые исходы
      const usedPredictions = await client.query(`
        SELECT DISTINCT prediction_type
        FROM bet_participants
        WHERE bet_id = $1 AND prediction_type IS NOT NULL
      `, [betId]);

      const usedPredictionTypes = usedPredictions.rows.map(row => row.prediction_type);

      // Определяем доступные исходы
      const allPredictions = [
        {
          type: 'home',
          text: `Победа ${bet.home_team}`,
          team: bet.home_team
        },
        {
          type: 'draw',
          text: 'Ничья',
          team: null
        },
        {
          type: 'away',
          text: `Победа ${bet.away_team}`,
          team: bet.away_team
        }
      ];

      const availablePredictions = allPredictions.filter(pred => {
        // Нельзя ставить на исход создателя
        if (pred.type === bet.creator_prediction) return false;
        // Нельзя ставить на уже занятый исход
        if (usedPredictionTypes.includes(pred.type)) return false;
        return true;
      });

      // Рассчитываем общий банк и потенциальный выигрыш
      const totalBank = parseFloat(bet.creator_amount) + parseFloat(bet.participants_total);
      const commissionRate = 0.10; // 10%
      const netBank = totalBank * (1 - commissionRate);

      return NextResponse.json({
        success: true,
        bet: {
          id: bet.id,
          creator_prediction: bet.creator_prediction,
          creator_amount: parseFloat(bet.creator_amount),
          currency: bet.currency,
          home_team: bet.home_team,
          away_team: bet.away_team,
          home_team_logo: homeTeamLogo,
          away_team_logo: awayTeamLogo,
          total_bank: totalBank,
          commission_rate: commissionRate
        },
        available_predictions: availablePredictions,
        potential_winnings: {
          total_bank: totalBank,
          commission_amount: totalBank * commissionRate,
          net_winnings: netBank,
          note: "If you win, you get the entire net bank (total bank minus 10% commission)"
        }
      });

    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error getting available predictions:', error);
    console.error('Error details:', {
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined,
    });
    return NextResponse.json(
      {
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
