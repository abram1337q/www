import { type NextRequest, NextResponse } from 'next/server';
import pool, { query } from '@/lib/database';
import type { JoinBetRequest } from '@/types/bets';
import { notificationService } from '@/lib/notifications';

// Функция для получения актуальных минимальных сумм от админки
async function getMinimumAmounts(): Promise<{ TON: number; STARS: number }> {
  try {
    // Получаем минимальную сумму в USD из админки
    const usdResult = await query(
      `SELECT setting_value FROM app_settings WHERE setting_key = $1`,
      ['minimum_usd_amount']
    );

    const usdMin = usdResult.rows.length > 0 ? parseFloat(usdResult.rows[0].setting_value) : 10;

    // Получаем курс TON/STARS (используем тот же API что и frontend)
    const rateResponse = await fetch(process.env.NEXT_PUBLIC_BASE_URL ?
      `${process.env.NEXT_PUBLIC_BASE_URL}/api/ton-rate` :
      'https://api.coingecko.com/api/v3/simple/price?ids=the-open-network&vs_currencies=usd'
    );

    let tonToUsd = 5.1; // fallback
    let starsToUsd = 0.015; // fallback

    if (rateResponse.ok) {
      const rateData = await rateResponse.json();
      if (rateData.tonToUsd) {
        tonToUsd = rateData.tonToUsd;
        starsToUsd = rateData.starsToUsd || 0.015;
      } else if (rateData['the-open-network']?.usd) {
        tonToUsd = rateData['the-open-network'].usd;
      }
    }

    // Рассчитываем минималки
    const tonMin = Math.max(0, parseFloat((usdMin / tonToUsd).toFixed(3)));
    const starsMin = Math.ceil(usdMin / starsToUsd);

    return { TON: tonMin, STARS: starsMin };
  } catch (error) {
    console.error('Error getting minimum amounts:', error);
    // Возвращаем дефолтные значения если ошибка
    return { TON: 2, STARS: 400 };
  }
}

export async function POST(request: NextRequest) {
  try {
    console.log('=== JOIN BET API CALLED ===');
    const body: JoinBetRequest = await request.json();
    console.log('Request body:', body);

    // Получаем минимальные суммы из админки
    const minimums = await getMinimumAmounts();

    // Валидация данных
    const validation = validateJoinBetRequest(body, minimums);
    if (!validation.isValid) {
      console.log('Validation failed:', validation.errors);
      return NextResponse.json(
        { error: 'Validation failed', details: validation.errors },
        { status: 400 }
      );
    }

    const { bet_id, amount, prediction_type, comment } = body;

    // Получаем пользователя из заголовков
    const telegramId = request.headers.get('x-telegram-user-id');
    console.log('Telegram ID from header:', telegramId);
    if (!telegramId) {
      console.log('No telegram ID in header');
      return NextResponse.json(
        { error: 'User not authenticated' },
        { status: 401 }
      );
    }

    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      // Получаем пользователя
      const userResult = await client.query(
        'SELECT id, ton_balance, stars_balance FROM users WHERE telegram_id = $1',
        [telegramId]
      );

      if (userResult.rows.length === 0) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'User not found' },
          { status: 404 }
        );
      }

      const user = userResult.rows[0];
      const userId = user.id;

      // Получаем информацию о споре
      const betResult = await client.query(`
        SELECT
          b.*,
          m.start_time as match_start_time,
          m.status as match_status,
          (1 + (SELECT COUNT(*) FROM bet_participants WHERE bet_id = b.id)) as current_participants
        FROM bets b
        JOIN matches m ON b.match_id = m.id
        WHERE b.id = $1
      `, [bet_id]);

      if (betResult.rows.length === 0) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Bet not found' },
          { status: 404 }
        );
      }

      const bet = betResult.rows[0];

      // Проверяем, что пользователь не ставит на тот же исход, что и создатель
      if (bet.prediction_type === prediction_type) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Cannot bet on the same prediction as the creator' },
          { status: 400 }
        );
      }

      // Проверяем, что на этот исход еще никто не ставил
      const existingPrediction = await client.query(
        'SELECT id FROM bet_participants WHERE bet_id = $1 AND prediction_type = $2',
        [bet_id, prediction_type]
      );

      if (existingPrediction.rows.length > 0) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Someone already bet on this prediction' },
          { status: 400 }
        );
      }

      // Проверки возможности присоединения
      if (bet.status !== 'open') {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Bet is not open for new participants' },
          { status: 400 }
        );
      }

      if (bet.creator_id === userId) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Cannot join your own bet' },
          { status: 400 }
        );
      }

      // Проверяем, что пользователь еще не участвует в этом споре
      const existingParticipation = await client.query(
        'SELECT id FROM bet_participants WHERE bet_id = $1 AND user_id = $2',
        [bet_id, userId]
      );

      if (existingParticipation.rows.length > 0) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'You are already participating in this bet' },
          { status: 400 }
        );
      }

      // Проверяем количество участников (current_participants уже включает создателя)
      // Если max_participants = 3, то уже должно быть меньше 3 участников
      if (bet.current_participants >= bet.max_participants) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Bet is full' },
          { status: 400 }
        );
      }

      // Проверяем время истечения
      if (bet.expires_at && new Date(bet.expires_at) <= new Date()) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Bet has expired' },
          { status: 400 }
        );
      }

      // БЛОКИРОВКА: Проверяем, что матч еще не начался
      const matchStartTime = new Date(bet.match_start_time);
      const now = new Date();
      const oneMinuteBeforeStart = new Date(matchStartTime.getTime() - 60 * 1000); // За 1 минуту до начала

      if (bet.match_status !== 'upcoming' || now >= oneMinuteBeforeStart) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Cannot join bet - match has started or will start in less than 1 minute' },
          { status: 400 }
        );
      }

      // Проверяем валюту и сумму (используем динамические минимумы)
      if (bet.currency === 'TON' && amount < minimums.TON) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: `Minimum amount for TON is ${minimums.TON}` },
          { status: 400 }
        );
      }

      if (bet.currency === 'STARS' && amount < minimums.STARS) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: `Minimum amount for STARS is ${minimums.STARS}` },
          { status: 400 }
        );
      }

      // Проверяем баланс
      const currentBalance = bet.currency === 'TON' ? user.ton_balance : user.stars_balance;
      if (currentBalance < amount) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Insufficient balance' },
          { status: 400 }
        );
      }

      // Добавляем участника к спору
      const participantResult = await client.query(`
        INSERT INTO bet_participants (bet_id, user_id, amount, prediction_type, position, comment)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING *
      `, [bet_id, userId, amount, prediction_type, 'against', comment]);

      const participant = participantResult.rows[0];

      // Списываем средства с баланса пользователя
      if (bet.currency === 'TON') {
        await client.query(
          'UPDATE users SET ton_balance = ton_balance - $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          [amount, userId]
        );
      } else {
        await client.query(
          'UPDATE users SET stars_balance = stars_balance - $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          [amount, userId]
        );
      }

      // Записываем транзакцию
      await client.query(`
        INSERT INTO transactions (user_id, bet_id, transaction_type, currency, amount, description)
        VALUES ($1, $2, 'bet_join', $3, $4, $5)
      `, [
        userId, bet_id, bet.currency, -amount,
        `Joined bet #${bet_id} with amount ${amount} ${bet.currency}`
      ]);

      // Проверяем, заполнился ли спор (создатель + участники = max_participants)
      const newParticipantsCount = Number(bet.current_participants) + 1;
      const maxParticipants = Number(bet.max_participants);

      // Спор закрывается только когда достигнуто точное максимальное количество участников
      if (newParticipantsCount === maxParticipants) {
        await client.query(
          'UPDATE bets SET status = $1 WHERE id = $2',
          ['closed', bet_id]
        );
      }

      // Создаем уведомление для создателя спора
      await client.query(`
        INSERT INTO notifications (user_id, bet_id, notification_type, title, message)
        VALUES ($1, $2, 'bet_joined', $3, $4)
      `, [
        bet.creator_id,
        bet_id,
        'К вашему спору присоединился новый участник',
        `Пользователь присоединился к вашему спору на сумму ${amount} ${bet.currency}`
      ]);

      await client.query('COMMIT');

      // Отправляем уведомление создателю спора асинхронно
      setImmediate(async () => {
        try {
          await notificationService.sendJoinedNotification(
            bet.creator_id,
            bet_id,
            userId
          );
        } catch (error) {
          console.error('Ошибка отправки уведомления о присоединении:', error);
        }
      });

      // Получаем обновленную информацию о споре
      const updatedBetResult = await client.query(`
        SELECT
          b.*,
          u.username as creator_username,
          u.first_name as creator_first_name,
          m.home_team,
          m.away_team,
          m.league,
          m.start_time as match_start_time,
          (1 + (SELECT COUNT(*) FROM bet_participants WHERE bet_id = b.id)) as participants_count
        FROM bets b
        JOIN users u ON b.creator_id = u.id
        JOIN matches m ON b.match_id = m.id
        WHERE b.id = $1
      `, [bet_id]);

      return NextResponse.json({
        success: true,
        participant,
        bet: updatedBetResult.rows[0]
      });

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error joining bet:', error);
    console.error('Error details:', {
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined,
    });
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Unknown server error',
        details: error instanceof Error ? error.message : 'Unknown server error'
      },
      { status: 500 }
    );
  }
}

function validateJoinBetRequest(
  data: unknown,
  minimums: { TON: number; STARS: number }
): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Type guard для проверки что data - это объект
  if (!data || typeof data !== 'object') {
    errors.push('Request data must be an object');
    return { isValid: false, errors };
  }

  const requestData = data as Record<string, unknown>;

  if (!requestData.bet_id || typeof requestData.bet_id !== 'number') {
    errors.push('bet_id is required and must be a number');
  }

  if (!requestData.amount || typeof requestData.amount !== 'number' || (requestData.amount as number) <= 0) {
    errors.push('amount is required and must be a positive number');
  }

  if (!requestData.prediction_type || !['home', 'draw', 'away'].includes(requestData.prediction_type as string)) {
    errors.push('prediction_type must be one of: home, draw, away');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}
