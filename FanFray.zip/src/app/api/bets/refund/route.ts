import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';
import { notificationService } from '@/lib/notifications';
import { telegramBot } from '@/lib/telegram-bot';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { bet_id, reason = 'К вашему спору никто не присоединился' }: { bet_id: number; reason?: string } = body;

    if (!bet_id) {
      return NextResponse.json(
        { error: 'bet_id is required' },
        { status: 400 }
      );
    }

    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      // Получаем информацию о споре
      const betResult = await client.query(`
        SELECT
          b.*,
          m.home_team,
          m.away_team,
          m.league
        FROM bets b
        JOIN matches m ON b.match_id = m.id
        WHERE b.id = $1
      `, [bet_id]);

      if (betResult.rows.length === 0) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Bet not found' },
          { status: 404 }
        );
      }

      const bet = betResult.rows[0];

      if (bet.status === 'completed' || bet.status === 'cancelled') {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Bet is already completed or cancelled' },
          { status: 400 }
        );
      }

      // Получаем всех участников спора
      const participantsResult = await client.query(`
        SELECT
          bp.*,
          u.telegram_id,
          u.username,
          u.first_name
        FROM bet_participants bp
        JOIN users u ON bp.user_id = u.id
        WHERE bp.bet_id = $1
      `, [bet_id]);

      const participants = participantsResult.rows;
      const refunds = [];

      // Возвращаем средства создателю спора
      if (bet.currency === 'TON') {
        await client.query(
          'UPDATE users SET ton_balance = ton_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          [bet.amount, bet.creator_id]
        );
      } else {
        await client.query(
          'UPDATE users SET stars_balance = stars_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          [bet.amount, bet.creator_id]
        );
      }

      // Транзакция возврата для создателя
      await client.query(`
        INSERT INTO transactions (user_id, bet_id, transaction_type, currency, amount, description)
        VALUES ($1, $2, 'bet_refund', $3, $4, $5)
      `, [
        bet.creator_id, bet_id, bet.currency, bet.amount,
        `Refund for cancelled bet #${bet_id} - ${reason}`
      ]);

      refunds.push({
        user_id: bet.creator_id,
        amount: Number.parseFloat(bet.amount),
        is_creator: true
      });

      // Возвращаем средства участникам
      for (const participant of participants) {
        if (bet.currency === 'TON') {
          await client.query(
            'UPDATE users SET ton_balance = ton_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
            [participant.amount, participant.user_id]
          );
        } else {
          await client.query(
            'UPDATE users SET stars_balance = stars_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
            [participant.amount, participant.user_id]
          );
        }

        // Транзакция возврата для участника
        await client.query(`
          INSERT INTO transactions (user_id, bet_id, transaction_type, currency, amount, description)
          VALUES ($1, $2, 'bet_refund', $3, $4, $5)
        `, [
          participant.user_id, bet_id, bet.currency, participant.amount,
          `Refund for cancelled bet #${bet_id} - ${reason}`
        ]);

        refunds.push({
          user_id: participant.user_id,
          amount: Number.parseFloat(participant.amount),
          is_creator: false
        });
      }

      // Обновляем статус спора
      await client.query(
        'UPDATE bets SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        ['cancelled', bet_id]
      );

      await client.query('COMMIT');

      // Получаем telegram_id всех пользователей для уведомлений
      const allUserIds = [bet.creator_id, ...participants.map(p => p.user_id)];
      const usersResult = await client.query(`
        SELECT id, telegram_id, username, first_name
        FROM users
        WHERE id = ANY($1)
      `, [allUserIds]);

      const usersMap = new Map();
      usersResult.rows.forEach(user => {
        usersMap.set(user.id, user);
      });

      // Отправляем уведомления асинхронно после успешного завершения транзакции
      setImmediate(async () => {
        try {
          console.log('Начинаем отправку уведомлений о возврате для bet_id:', bet_id);

          // Уведомление создателю спора
          const creatorUser = usersMap.get(bet.creator_id);
          if (creatorUser) {
            const refundNotification = telegramBot.createRefundNotification({
              user_id: bet.creator_id,
              telegram_id: creatorUser.telegram_id,
              type: 'bet_refund',
              bet_id: bet_id,
              amount: Number.parseFloat(bet.amount),
              currency: bet.currency,
              match_info: { home_team: bet.home_team, away_team: bet.away_team, league: bet.league },
              additional_info: { reason }
            });
            const sent = await telegramBot.sendMessage(
              creatorUser.telegram_id,
              refundNotification.text,
              'HTML',
              refundNotification.keyboard
            );
            console.log(`Уведомление о возврате создателю отправлено: ${sent}`);
          }


          // Уведомления участникам
          for (const participant of participants) {
            const participantUser = usersMap.get(participant.user_id);
            if (participantUser) {
              const refundNotification = telegramBot.createRefundNotification({
                user_id: participant.user_id,
                telegram_id: participantUser.telegram_id,
                type: 'bet_refund',
                bet_id: bet_id,
                amount: Number.parseFloat(participant.amount),
                currency: bet.currency,
                match_info: { home_team: bet.home_team, away_team: bet.away_team, league: bet.league },
                additional_info: { reason }
              });
              const sent = await telegramBot.sendMessage(
                participantUser.telegram_id,
                refundNotification.text,
                'HTML',
                refundNotification.keyboard
              );
              console.log(`Уведомление о возврате участнику отправлено: ${sent}`);
            }
          }

          console.log('Все уведомления о возврате обработаны для bet_id:', bet_id);
        } catch (error) {
          console.error('Ошибка отправки уведомлений о возврате для bet_id:', bet_id, error);
        }
      });

      return NextResponse.json({
        success: true,
        bet_id,
        reason,
        refunds_count: refunds.length,
        total_refunded: refunds.reduce((sum, r) => sum + r.amount, 0),
        currency: bet.currency,
        refunds
      });

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error refunding bet:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
