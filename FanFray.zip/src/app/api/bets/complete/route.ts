import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';
import type { PredictionType } from '@/types/bets';
import { notificationService } from '@/lib/notifications';
import { telegramBot } from '@/lib/telegram-bot';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { bet_id, winning_prediction }: { bet_id: number; winning_prediction: PredictionType } = body;

    if (!bet_id || !winning_prediction) {
      return NextResponse.json(
        { error: 'bet_id and winning_prediction are required' },
        { status: 400 }
      );
    }

    if (!['home', 'draw', 'away'].includes(winning_prediction)) {
      return NextResponse.json(
        { error: 'winning_prediction must be one of: home, draw, away' },
        { status: 400 }
      );
    }

    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      // Получаем информацию о споре
      const betResult = await client.query(`
        SELECT
          b.*,
          m.home_team,
          m.away_team,
          m.league
        FROM bets b
        JOIN matches m ON b.match_id = m.id
        WHERE b.id = $1
      `, [bet_id]);

      if (betResult.rows.length === 0) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Bet not found' },
          { status: 404 }
        );
      }

      const bet = betResult.rows[0];

      if (bet.status !== 'closed') {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Bet is not closed yet' },
          { status: 400 }
        );
      }

      // Получаем всех участников
      const participantsResult = await client.query(`
        SELECT
          bp.*,
          u.telegram_id,
          u.username,
          u.first_name
        FROM bet_participants bp
        JOIN users u ON bp.user_id = u.id
        WHERE bp.bet_id = $1
      `, [bet_id]);

      const participants = participantsResult.rows;

      // Рассчитываем общий банк
      let totalBank = Number.parseFloat(bet.amount);
      participants.forEach(p => {
        totalBank += Number.parseFloat(p.amount);
      });

      const commissionRate = 0.10; // 10%
      const commission = totalBank * commissionRate;
      const netBank = totalBank - commission;

      // Находим победителей
      const winners = [];

      // Проверяем создателя
      if (bet.prediction_type === winning_prediction) {
        winners.push({
          user_id: bet.creator_id,
          amount: Number.parseFloat(bet.amount),
          is_creator: true
        });
      }

      // Проверяем участников
      participants.forEach(p => {
        if (p.prediction_type === winning_prediction) {
          winners.push({
            user_id: p.user_id,
            amount: Number.parseFloat(p.amount),
            is_creator: false
          });
        }
      });

      const winnerResults = [];

      // В системе споров на 3 исхода всегда должен быть ровно 1 победитель
      if (winners.length === 0) {
        throw new Error('No winner found - this should not happen in 3-way betting system');
      }

      if (winners.length > 1) {
        throw new Error('Multiple winners found - this should not happen in 3-way betting system');
      }

      // Есть ровно 1 победитель - он забирает весь банк
      const winner = winners[0];

      // Начисляем весь банк (минус комиссия) победителю
      if (bet.currency === 'TON') {
        await client.query(
          'UPDATE users SET ton_balance = ton_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          [netBank, winner.user_id]
        );
      } else {
        await client.query(
          'UPDATE users SET stars_balance = stars_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          [netBank, winner.user_id]
        );
      }

      // Транзакция выигрыша
      await client.query(`
        INSERT INTO transactions (user_id, bet_id, transaction_type, currency, amount, description)
        VALUES ($1, $2, 'bet_win', $3, $4, $5)
      `, [
        winner.user_id, bet_id, bet.currency, netBank,
        `Won bet #${bet_id} - full bank of ${netBank} ${bet.currency} (${totalBank} minus ${commission} commission)`
      ]);

      // Транзакция комиссии для платформы (сохраняем как отдельную запись)
      await client.query(`
        INSERT INTO transactions (user_id, bet_id, transaction_type, currency, amount, description)
        VALUES ($1, $2, 'platform_commission', $3, $4, $5)
      `, [
        winner.user_id, bet_id, bet.currency, commission,
        `Platform commission from completed bet #${bet_id} - ${commissionRate * 100}% of ${totalBank} ${bet.currency}`
      ]);

      winnerResults.push({
        user_id: winner.user_id,
        bet_amount: winner.amount,
        winnings: netBank,
        proportion: 1.0
      });

      // Обновляем статус спора
      await client.query(
        'UPDATE bets SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        ['completed', bet_id]
      );

      // Создаем уведомления в БД ДО завершения транзакции
      const notificationIds = [];

      // Уведомление победителю
      if (winners.length === 1) {
        const winNotificationId = await client.query(`
          INSERT INTO notifications (user_id, bet_id, notification_type, title, message)
          VALUES ($1, $2, 'bet_completed', $3, $4)
          RETURNING id
        `, [
          winner.user_id,
          bet_id,
          'Поздравляем! Вы выиграли!',
          `Вы выиграли ${netBank} ${bet.currency} в споре на матч`
        ]);
        notificationIds.push({ type: 'win', id: winNotificationId.rows[0].id, user_id: winner.user_id });
      }

      // Уведомления проигравшим - создатель
      if (bet.prediction_type !== winning_prediction) {
        const lossNotificationId = await client.query(`
          INSERT INTO notifications (user_id, bet_id, notification_type, title, message)
          VALUES ($1, $2, 'bet_completed', $3, $4)
          RETURNING id
        `, [
          bet.creator_id,
          bet_id,
          'Вы проиграли спор',
          `К сожалению, вы проиграли ${bet.amount} ${bet.currency} в споре`
        ]);
        notificationIds.push({ type: 'loss', id: lossNotificationId.rows[0].id, user_id: bet.creator_id });
      }

      // Уведомления проигравшим - участники
      for (const participant of participants) {
        if (participant.prediction_type !== winning_prediction) {
          const lossNotificationId = await client.query(`
            INSERT INTO notifications (user_id, bet_id, notification_type, title, message)
            VALUES ($1, $2, 'bet_completed', $3, $4)
            RETURNING id
          `, [
            participant.user_id,
            bet_id,
            'Вы проиграли спор',
            `К сожалению, вы проиграли ${participant.amount} ${bet.currency} в споре`
          ]);
          notificationIds.push({ type: 'loss', id: lossNotificationId.rows[0].id, user_id: participant.user_id });
        }
      }

      // Получаем данные для уведомлений ДО завершения транзакции
      const notificationData = {
        bet_id,
        winning_prediction,
        currency: bet.currency,
        totalBank,
        netBank,
        winner: winners.length === 1 ? winner : null,
        creator: {
          id: bet.creator_id,
          amount: Number.parseFloat(bet.amount),
          prediction: bet.prediction_type
        },
        participants: participants.map(p => ({
          user_id: p.user_id,
          amount: Number.parseFloat(p.amount),
          prediction: p.prediction_type,
          telegram_id: p.telegram_id
        }))
      };

      await client.query('COMMIT');

      // Получаем telegram_id всех пользователей для уведомлений
      const allUserIds = [bet.creator_id, ...participants.map(p => p.user_id)];
      const usersResult = await client.query(`
        SELECT id, telegram_id, username, first_name
        FROM users
        WHERE id = ANY($1)
      `, [allUserIds]);

      const usersMap = new Map();
      usersResult.rows.forEach(user => {
        usersMap.set(user.id, user);
      });

      // Отправляем уведомления в Telegram асинхронно
      setImmediate(async () => {
        try {
          console.log('Начинаем отправку уведомлений в Telegram для bet_id:', bet_id);

          // Уведомление победителю
          if (winners.length === 1) {
            const winnerUser = usersMap.get(winner.user_id);
            if (winnerUser) {
              const winNotification = telegramBot.createWinNotification({
                user_id: winner.user_id,
                telegram_id: winnerUser.telegram_id,
                type: 'bet_win',
                bet_id: bet_id,
                amount: netBank,
                currency: bet.currency,
                match_info: { home_team: bet.home_team, away_team: bet.away_team, league: bet.league },
                additional_info: { total_bank: totalBank }
              });
              const sent = await telegramBot.sendMessage(
                winnerUser.telegram_id,
                winNotification.text,
                'HTML',
                winNotification.keyboard
              );
              console.log(`Уведомление о победе отправлено: ${sent}`);
            }
          }

          // Уведомления проигравшим - создатель
          if (bet.prediction_type !== winning_prediction) {
            const creatorUser = usersMap.get(bet.creator_id);
            if (creatorUser) {
              const lossNotification = telegramBot.createLossNotification({
                user_id: bet.creator_id,
                telegram_id: creatorUser.telegram_id,
                type: 'bet_loss',
                bet_id: bet_id,
                amount: Number.parseFloat(bet.amount),
                currency: bet.currency,
                match_info: { home_team: bet.home_team, away_team: bet.away_team, league: bet.league }
              });
              const sent = await telegramBot.sendMessage(
                creatorUser.telegram_id,
                lossNotification.text,
                'HTML',
                lossNotification.keyboard
              );
              console.log(`Уведомление о проигрыше создателю отправлено: ${sent}`);
            }
          }

          // Уведомления проигравшим - участники
          for (const participant of participants) {
            if (participant.prediction_type !== winning_prediction) {
              const participantUser = usersMap.get(participant.user_id);
              if (participantUser) {
                const lossNotification = telegramBot.createLossNotification({
                  user_id: participant.user_id,
                  telegram_id: participantUser.telegram_id,
                  type: 'bet_loss',
                  bet_id: bet_id,
                  amount: Number.parseFloat(participant.amount),
                  currency: bet.currency,
                  match_info: { home_team: bet.home_team, away_team: bet.away_team, league: bet.league }
                });
                const sent = await telegramBot.sendMessage(
                  participantUser.telegram_id,
                  lossNotification.text,
                  'HTML',
                  lossNotification.keyboard
                );
                console.log(`Уведомление о проигрыше участнику отправлено: ${sent}`);
              }
            }
          }

          console.log('Все уведомления в Telegram обработаны для bet_id:', bet_id);
        } catch (error) {
          console.error('Ошибка отправки уведомлений в Telegram для bet_id:', bet_id, error);
        }
      });

      return NextResponse.json({
        success: true,
        bet_id,
        winning_prediction,
        total_bank: totalBank,
        commission: commission,
        net_bank: netBank,
        winners_count: winners.length,
        results: winnerResults
      });

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error completing bet:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
