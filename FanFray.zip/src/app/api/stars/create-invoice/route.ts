import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

export async function POST(request: NextRequest) {
  try {
    const telegramId = request.headers.get('x-telegram-user-id');
    if (!telegramId) {
      return NextResponse.json({ error: 'User not authenticated' }, { status: 401 });
    }

    const body = await request.json();
    const { amount } = body;

    if (!amount || amount <= 0) {
      return NextResponse.json({ error: 'Invalid amount' }, { status: 400 });
    }

    // Проверяем, что amount - целое число для Stars
    if (!Number.isInteger(amount) || amount < 1 || amount > 10000) {
      return NextResponse.json({ error: 'Amount must be an integer between 1 and 10000 Stars' }, { status: 400 });
    }

    // Проверяем пользователя
    const userResult = await pool.query(
      'SELECT id FROM users WHERE telegram_id = $1',
      [telegramId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      return NextResponse.json({ error: 'Bot token not configured' }, { status: 500 });
    }

    // Создаем invoice через Telegram Bot API (упрощенная версия по примеру)
    const invoiceData = {
      title: 'Пополнение баланса Stars',
      description: `Пополнение баланса на ${amount} Stars`,
      payload: JSON.stringify({
        user_id: userResult.rows[0].id,
        telegram_id: telegramId,
        amount: amount,
        type: 'stars_topup'
      }),
      provider_token: '', // Для Stars должно быть пустым
      currency: 'XTR', // Валюта для Telegram Stars
      prices: [
        {
          label: 'Stars',
          amount: amount // Для XTR amount уже в целых единицах (stars)
        }
      ],
      start_parameter: `stars_topup` // Упрощенный start_parameter
    };

    console.log('Creating invoice with data:', JSON.stringify(invoiceData, null, 2));

    const response = await fetch(`https://api.telegram.org/bot${botToken}/createInvoiceLink`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(invoiceData)
    });

    const result = await response.json();
    console.log('Telegram API response:', result);

    if (!result.ok) {
      console.error('Telegram API error:', result);
      return NextResponse.json({
        error: 'Failed to create invoice',
        details: result.description
      }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      invoiceLink: result.result
    });

  } catch (error) {
    console.error('Error creating Stars invoice:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
