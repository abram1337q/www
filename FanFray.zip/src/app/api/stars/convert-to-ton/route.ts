import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';
import { TonClient, WalletContractV4, Address, beginCell, toNano, internal } from '@ton/ton';
import { mnemonicToWalletKey } from '@ton/crypto';

// Курс конвертации на основе фиксированной стоимости Stars в долларах
const STARS_TO_USD = 0.015; // 1 Star = $0.015 (1000 Stars = $15)
const MIN_CONVERSION_AMOUNT = 100; // Минимум 100 Stars для конвертации

// Функция для получения актуального курса TON к доллару
async function getTonToUsdRate(): Promise<number> {
  try {
    // Прямой запрос к CoinGecko API
    const response = await fetch(
      'https://api.coingecko.com/api/v3/simple/price?ids=the-open-network&vs_currencies=usd',
      {
        headers: {
          'Accept': 'application/json',
        },
        next: { revalidate: 30 } // Кэшируем на 30 секунд
      }
    );

    if (!response.ok) {
      throw new Error('Failed to fetch exchange rates');
    }

    const data = await response.json();
    const tonToUsd = data['the-open-network']?.usd || 5.1; // Fallback значение

    console.log('TON to USD rate fetched:', tonToUsd);
    return tonToUsd;

  } catch (error) {
    console.error('Failed to fetch TON rate:', error);
    return 5.1; // fallback значение
  }
}

export async function POST(request: NextRequest) {
  let starsAmount: number | undefined;
  let tonWalletAddress: string | undefined;
  let expectedTonAmount: number | undefined;
  let withdrawalType: 'standard' | 'accelerated' = 'accelerated';
  let commissionRate: number = 0;
  let commissionAmount: number = 0;
  let finalTonAmount: number | undefined;
  let agreementAccepted: boolean = false;

  try {
    console.log('[CONVERT] Starting conversion request');

    const telegramId = request.headers.get('x-telegram-user-id');
    if (!telegramId) {
      console.log('[CONVERT] No telegram ID provided');
      return NextResponse.json({ error: 'User not authenticated' }, { status: 401 });
    }

    const body = await request.json();
    ({
      starsAmount,
      tonWalletAddress,
      expectedTonAmount,
      withdrawalType = 'accelerated',
      commissionRate = 0,
      commissionAmount = 0,
      finalTonAmount,
      agreementAccepted = false
    } = body);

    console.log('[CONVERT] Request data:', {
      telegramId,
      starsAmount,
      tonWalletAddress: tonWalletAddress ? `${tonWalletAddress.slice(0, 8)}...` : 'not provided',
      expectedTonAmount,
      withdrawalType,
      commissionRate,
      finalTonAmount,
      agreementAccepted
    });

    if (!starsAmount || starsAmount < MIN_CONVERSION_AMOUNT) {
      return NextResponse.json({
        error: `Минимальная сумма для конвертации ${MIN_CONVERSION_AMOUNT} Stars`
      }, { status: 400 });
    }

    if (!tonWalletAddress) {
      return NextResponse.json({ error: 'TON wallet address is required' }, { status: 400 });
    }

    if (!agreementAccepted) {
      return NextResponse.json({ error: 'User agreement must be accepted' }, { status: 400 });
    }

    // Проверяем валидность TON адреса
    console.log('[CONVERT] Validating TON address:', tonWalletAddress);
    try {
      const parsedAddress = Address.parse(tonWalletAddress);
      console.log('[CONVERT] TON address valid:', parsedAddress.toString());
    } catch (error) {
      console.log('[CONVERT] Invalid TON address:', error);
      return NextResponse.json({
        error: 'Неверный адрес TON кошелька',
        debug: {
          address: tonWalletAddress,
          error: error instanceof Error ? error.message : 'Parse error'
        }
      }, { status: 400 });
    }

    // Проверяем пользователя и его баланс
    console.log('[CONVERT] Checking user balance...');
    const userResult = await pool.query(
      'SELECT id, stars_balance FROM users WHERE telegram_id = $1',
      [telegramId]
    );

    if (userResult.rows.length === 0) {
      console.log('[CONVERT] User not found:', telegramId);
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const user = userResult.rows[0];
    const currentBalance = Number.parseFloat(user.stars_balance || 0);

    console.log('[CONVERT] User balance check:', { userId: user.id, currentBalance, requiredAmount: starsAmount });

    if (currentBalance < starsAmount) {
      console.log('[CONVERT] Insufficient balance');
      return NextResponse.json({
        error: 'Недостаточно Stars на балансе',
        currentBalance,
        requiredAmount: starsAmount
      }, { status: 400 });
    }

    // Рассчитываем количество TON для отправки
    let tonAmount: number;

    if (expectedTonAmount && expectedTonAmount > 0) {
      // Используем ожидаемую сумму TON если она передана (защита от абуза курса)
      tonAmount = expectedTonAmount;
      console.log('Using expected TON amount:', tonAmount);
    } else {
      // Получаем актуальный курс TON к доллару и рассчитываем
      const tonToUsdRate = await getTonToUsdRate();
      // 1. Сначала конвертируем Stars в доллары
      const usdAmount = starsAmount * STARS_TO_USD;
      // 2. Затем доллары в TON
      tonAmount = usdAmount / tonToUsdRate;
      console.log('Calculated TON amount:', tonAmount);
    }

    // Дополнительная проверка на корректность суммы TON
    if (tonAmount <= 0 || !isFinite(tonAmount) || isNaN(tonAmount)) {
      console.log('[CONVERT] Invalid TON amount:', tonAmount);
      return NextResponse.json({
        error: 'Некорректная сумма для конвертации. Попробуйте еще раз.',
        debug: {
          expectedTonAmount,
          starsAmount,
          calculatedAmount: tonAmount,
          isFinite: isFinite(tonAmount),
          isNaN: isNaN(tonAmount)
        }
      }, { status: 400 });
    }

    console.log('[CONVERT] Converting TON amount to nano:', tonAmount);
    let tonNano;
    try {
      // Убеждаемся что число имеет разумную точность для TON (не более 9 знаков после запятой)
      const roundedTonAmount = Math.round(tonAmount * 1000000000) / 1000000000;
      tonNano = toNano(roundedTonAmount.toString());
      console.log('[CONVERT] TON nano conversion successful:', { tonAmount, roundedTonAmount, tonNano: tonNano.toString() });
    } catch (error) {
      console.error('[CONVERT] Error converting to nano:', error);
      return NextResponse.json({
        error: 'Ошибка при конвертации суммы TON',
        debug: {
          tonAmount,
          error: error instanceof Error ? error.message : 'Unknown error'
        }
      }, { status: 400 });
    }

    // Проверяем настройки TON кошелька
    console.log('[CONVERT] Checking TON wallet configuration...');
    const tonMnemonic = process.env.TON_WALLET_MNEMONIC;
    if (!tonMnemonic) {
      console.log('[CONVERT] TON wallet not configured');
      return NextResponse.json({ error: 'TON wallet not configured' }, { status: 500 });
    }

    // Инициализируем TON клиент
    const isTestnet = process.env.TON_NETWORK === 'testnet';
    const endpoint = isTestnet
      ? 'https://testnet.toncenter.com/api/v2/jsonRPC'
      : 'https://toncenter.com/api/v2/jsonRPC';

    const tonClient = new TonClient({
      endpoint,
      apiKey: process.env.TON_API_KEY
    });

    // Получаем ключи кошелька
    const keyPair = await mnemonicToWalletKey(tonMnemonic.split(' '));
    const wallet = WalletContractV4.create({
      workchain: 0,
      publicKey: keyPair.publicKey
    });

    const contract = tonClient.open(wallet);

    // Начинаем транзакцию в базе данных
    console.log('[CONVERT] Starting database transaction...');
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      // Списываем Stars с баланса пользователя
      await client.query(
        'UPDATE users SET stars_balance = stars_balance - $1 WHERE id = $2',
        [starsAmount, user.id]
      );

      // Определяем финальную сумму TON для отправки
      const amountToSend = withdrawalType === 'accelerated'
        ? (finalTonAmount || tonAmount)
        : tonAmount; // Для стандартного вывода отправляем полную сумму, комиссия не взимается

      // Записываем транзакцию конвертации с новыми полями
      const conversionResult = await client.query(
        `INSERT INTO conversion_transactions
         (user_id, stars_amount, ton_amount, ton_wallet_address, status, withdrawal_type,
          commission_rate, commission_amount, final_ton_amount, user_agreement_accepted,
          agreement_accepted_at, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), NOW())
         RETURNING id`,
        [
          user.id,
          starsAmount,
          tonAmount,
          tonWalletAddress,
          withdrawalType === 'standard' ? 'pending' : 'pending',
          withdrawalType,
          commissionRate,
          commissionAmount,
          amountToSend,
          agreementAccepted
        ]
      );

      const conversionId = conversionResult.rows[0].id;

      // Отправляем TON только для ускоренной обработки
      if (withdrawalType === 'accelerated') {
        // Пересчитываем nano для финальной суммы
        const finalTonNano = toNano(amountToSend.toString());

        const seqno = await contract.getSeqno();

        await contract.sendTransfer({
          seqno,
          secretKey: keyPair.secretKey,
          messages: [internal({
            to: tonWalletAddress,
            value: finalTonNano,
            body: beginCell()
              .storeUint(0, 32)
              .storeStringTail(`Ускоренная конвертация ${starsAmount} Stars в ${amountToSend} TON`)
              .endCell(),
            bounce: false
          })]
        });

        // Обновляем статус на completed для ускоренной обработки
        await client.query(
          'UPDATE conversion_transactions SET status = $1, processed_at = NOW() WHERE id = $2',
          ['completed', conversionId]
        );
      } else {
        // Для стандартной обработки оставляем статус pending
        console.log('[CONVERT] Standard withdrawal scheduled for 21 days');
      }

      await client.query('COMMIT');

      return NextResponse.json({
        success: true,
        conversionId,
        starsAmount,
        tonAmount,
        finalTonAmount: amountToSend,
        tonWalletAddress,
        withdrawalType,
        commissionAmount,
        message: withdrawalType === 'accelerated'
          ? `Успешно конвертировано ${starsAmount} Stars в ${amountToSend} TON (ускоренная обработка)`
          : `Конвертация ${starsAmount} Stars запланирована. TON будут отправлены через 21 день.`
      });

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error converting Stars to TON:', error);

    // Более подробная информация об ошибке
    let errorDetails = 'Unknown error';
    let errorMessage = 'Internal server error';

    if (error instanceof Error) {
      errorDetails = error.message;
      errorMessage = error.message;
      console.error('Error stack:', error.stack);
    }

    return NextResponse.json({
      error: errorMessage,
      details: errorDetails,
      timestamp: new Date().toISOString(),
      requestData: {
        starsAmount,
        tonWalletAddress: tonWalletAddress ? `${tonWalletAddress.slice(0, 8)}...` : 'not provided',
        expectedTonAmount
      }
    }, { status: 500 });
  }
}

// GET endpoint для получения курса конвертации и истории
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const telegramId = searchParams.get('telegramId');

  // Если нет telegramId, возвращаем только курс конвертации
  if (!telegramId) {
    try {
      const tonToUsdRate = await getTonToUsdRate();
      return NextResponse.json({
        starsToUsd: STARS_TO_USD,
        tonToUsd: tonToUsdRate,
        minConversionAmount: MIN_CONVERSION_AMOUNT,
        description: `1 Star = ${STARS_TO_USD} | 1 TON = ${tonToUsdRate.toFixed(2)}`
      });
    } catch (error) {
      return NextResponse.json({
        starsToUsd: STARS_TO_USD,
        tonToUsd: 5.1,
        minConversionAmount: MIN_CONVERSION_AMOUNT,
        description: `1 Star = ${STARS_TO_USD} | 1 TON = $5.10 (fallback)`
      });
    }
  }

  try {
    console.log('[CONVERT-TO-TON GET] Querying for telegramId:', telegramId);

    // Получаем историю конвертаций для пользователя с новыми полями
    const historyResult = await pool.query(
      `SELECT
        ct.id,
        ct.user_id,
        ct.stars_amount,
        ct.ton_amount::text as ton_amount_text,
        ct.ton_amount::float as ton_amount_float,
        ct.final_ton_amount::float as final_ton_amount,
        ct.ton_wallet_address,
        ct.status,
        ct.withdrawal_type,
        ct.commission_rate,
        ct.commission_amount::float as commission_amount,
        ct.standard_release_date,
        ct.created_at,
        u.telegram_id,
        u.username,
        u.first_name,
        CASE
          WHEN ct.withdrawal_type = 'standard' AND ct.status = 'pending' THEN
            EXTRACT(EPOCH FROM (ct.standard_release_date - NOW())) / 86400.0
          ELSE 0
        END as days_remaining,
        CASE
          WHEN ct.withdrawal_type = 'standard' AND ct.status = 'pending' THEN
            (ct.standard_release_date > NOW())
          ELSE false
        END as is_locked
       FROM conversion_transactions ct
       LEFT JOIN users u ON ct.user_id = u.id
       WHERE u.telegram_id = $1
       ORDER BY ct.created_at DESC`,
      [telegramId]
    );

    console.log('[CONVERT-TO-TON GET] Found rows:', historyResult.rows.length);
    console.log('[CONVERT-TO-TON GET] Sample data:', historyResult.rows[0]);

    const tonToUsdRate = await getTonToUsdRate();

    return NextResponse.json({
      starsToUsd: STARS_TO_USD,
      tonToUsd: tonToUsdRate,
      minConversionAmount: MIN_CONVERSION_AMOUNT,
      description: `1 Star = ${STARS_TO_USD} | 1 TON = ${tonToUsdRate.toFixed(2)}`,
      history: historyResult.rows,
      found: historyResult.rows.length,
      telegramId
    });

  } catch (error) {
    console.error('Error fetching conversion history:', error);
    return NextResponse.json({
      starsToUsd: STARS_TO_USD,
      tonToUsd: 5.1,
      minConversionAmount: MIN_CONVERSION_AMOUNT,
      description: `1 Star = ${STARS_TO_USD} | 1 TON = $5.10 (fallback)`,
      history: []
    });
  }
}
