import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

// GET - получить текущую минимальную сумму в долларах
export async function GET() {
  try {
    // Ищем настройку минимальной суммы в долларах
    const result = await query(
      `SELECT setting_value FROM app_settings WHERE setting_key = $1`,
      ['minimum_usd_amount']
    );

    if (result.rows.length === 0) {
      // Если настройка не существует, создаем её с дефолтным значением 10$
      await query(
        `INSERT INTO app_settings (setting_key, setting_value, description, created_at, updated_at)
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
        ['minimum_usd_amount', '10', 'Минимальная сумма для создания ставки в долларах США']
      );
      return NextResponse.json({
        success: true,
        minimumUsdAmount: 10,
        message: 'Создана новая настройка с дефолтным значением 10$'
      });
    }

    const minimumUsdAmount = parseFloat(result.rows[0].setting_value);
    return NextResponse.json({
      success: true,
      minimumUsdAmount
    });

  } catch (error) {
    console.error('Ошибка при получении минимальной суммы в USD:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка при получении настроек' },
      { status: 500 }
    );
  }
}

// POST - обновить минимальную сумму в долларах
export async function POST(request: NextRequest) {
  try {
    const { minimumUsdAmount, adminPassword } = await request.json();

    // Простая проверка админ пароля
    if (adminPassword !== process.env.ADMIN_PASSWORD) {
      return NextResponse.json(
        { success: false, error: 'Неверный пароль администратора' },
        { status: 401 }
      );
    }

    // Валидация суммы
    const amount = parseFloat(minimumUsdAmount);
    if (isNaN(amount) || amount < 0.1) {
      return NextResponse.json(
        { success: false, error: 'Неверная сумма. Должно быть число больше 0.1$' },
        { status: 400 }
      );
    }

    // Проверяем, существует ли настройка
    const checkResult = await query(
      `SELECT id FROM app_settings WHERE setting_key = $1`,
      ['minimum_usd_amount']
    );

    if (checkResult.rows.length === 0) {
      // Создаем новую настройку
      await query(
        `INSERT INTO app_settings (setting_key, setting_value, description, created_at, updated_at)
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
        ['minimum_usd_amount', minimumUsdAmount.toString(), 'Минимальная сумма для создания ставки в долларах США']
      );
    } else {
      // Обновляем существующую настройку
      await query(
        `UPDATE app_settings
         SET setting_value = $1, updated_at = CURRENT_TIMESTAMP
         WHERE setting_key = $2`,
        [minimumUsdAmount.toString(), 'minimum_usd_amount']
      );
    }

    // Логируем изменение
    console.log(`Админ изменил минимальную сумму ставки на: $${minimumUsdAmount}`);

    return NextResponse.json({
      success: true,
      minimumUsdAmount: parseFloat(minimumUsdAmount),
      message: `Минимальная сумма ставки успешно обновлена на $${minimumUsdAmount}`
    });

  } catch (error) {
    console.error('Ошибка при обновлении минимальной суммы в USD:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка при обновлении настроек' },
      { status: 500 }
    );
  }
}
