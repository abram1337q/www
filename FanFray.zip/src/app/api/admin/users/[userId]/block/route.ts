import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'your_admin_password_here';

interface BlockUserRequest {
  adminPassword: string;
  blockType: 'app' | 'chat' | 'both';
  action: 'block' | 'unblock';
  reason?: string;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    const { adminPassword, blockType, action, reason }: BlockUserRequest = await request.json();

    // Проверяем пароль администратора
    if (adminPassword !== ADMIN_PASSWORD) {
      return NextResponse.json({
        success: false,
        error: 'Неверный пароль администратора'
      }, { status: 401 });
    }

    const { userId } = await params;

    // Проверяем существование пользователя
    const userCheck = await query('SELECT id FROM users WHERE id = $1', [userId]);
    if (userCheck.rows.length === 0) {
      return NextResponse.json({
        success: false,
        error: 'Пользователь не найден'
      }, { status: 404 });
    }

    if (action === 'block') {
      // Блокируем пользователя
      let updateQuery = '';
      let updateParams: (string | number)[] = [];

      if (blockType === 'app') {
        updateQuery = `
          UPDATE users
          SET is_blocked_app = TRUE,
              blocked_at = CURRENT_TIMESTAMP,
              blocked_by_admin = $2,
              block_reason = $3
          WHERE id = $1
        `;
        updateParams = [userId, 'admin', reason || 'Блокировка приложения'];
      } else if (blockType === 'chat') {
        updateQuery = `
          UPDATE users
          SET is_blocked_chat = TRUE,
              blocked_at = CURRENT_TIMESTAMP,
              blocked_by_admin = $2,
              block_reason = $3
          WHERE id = $1
        `;
        updateParams = [userId, 'admin', reason || 'Блокировка чата'];
      } else if (blockType === 'both') {
        updateQuery = `
          UPDATE users
          SET is_blocked_app = TRUE,
              is_blocked_chat = TRUE,
              blocked_at = CURRENT_TIMESTAMP,
              blocked_by_admin = $2,
              block_reason = $3
          WHERE id = $1
        `;
        updateParams = [userId, 'admin', reason || 'Полная блокировка'];
      }

      await query(updateQuery, updateParams);

      return NextResponse.json({
        success: true,
        message: `Пользователь заблокирован (${blockType})`
      });

    } else if (action === 'unblock') {
      // Разблокируем пользователя
      let updateQuery = '';

      if (blockType === 'app') {
        updateQuery = `
          UPDATE users
          SET is_blocked_app = FALSE,
              blocked_at = NULL,
              blocked_by_admin = NULL,
              block_reason = NULL
          WHERE id = $1
        `;
      } else if (blockType === 'chat') {
        updateQuery = `
          UPDATE users
          SET is_blocked_chat = FALSE
          WHERE id = $1
        `;
      } else if (blockType === 'both') {
        updateQuery = `
          UPDATE users
          SET is_blocked_app = FALSE,
              is_blocked_chat = FALSE,
              blocked_at = NULL,
              blocked_by_admin = NULL,
              block_reason = NULL
          WHERE id = $1
        `;
      }

      await query(updateQuery, [userId]);

      return NextResponse.json({
        success: true,
        message: `Пользователь разблокирован (${blockType})`
      });
    }

    return NextResponse.json({
      success: false,
      error: 'Неверное действие'
    }, { status: 400 });

  } catch (error) {
    console.error('Ошибка при блокировке/разблокировке пользователя:', error);
    return NextResponse.json({
      success: false,
      error: 'Внутренняя ошибка сервера'
    }, { status: 500 });
  }
}
