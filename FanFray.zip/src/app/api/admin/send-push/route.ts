import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/db';

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

// Функция для отправки сообщения пользователю
async function sendMessage(chatId: number, text: string) {
  if (!TELEGRAM_BOT_TOKEN) {
    throw new Error('TELEGRAM_BOT_TOKEN не настроен');
  }

  try {
    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: text,
        parse_mode: 'HTML'
      }),
    });

    const result = await response.json();

    if (!response.ok || !result.ok) {
      // Классифицируем типы ошибок
      const errorType = classifyTelegramError(result.description || 'Unknown error');
      throw new Error(`${errorType}: ${result.description || 'Unknown error'}`);
    }

    return result;
  } catch (error) {
    throw error;
  }
}

// Функция для классификации ошибок Telegram
function classifyTelegramError(description: string): string {
  if (description.includes('chat not found')) {
    return 'Чат не найден';
  }
  if (description.includes('bot was blocked by the user')) {
    return 'Бот заблокирован пользователем';
  }
  if (description.includes('user is deactivated')) {
    return 'Аккаунт пользователя деактивирован';
  }
  if (description.includes('Too Many Requests')) {
    return 'Превышен лимит запросов';
  }
  return 'Неизвестная ошибка';
}

export async function POST(request: NextRequest) {
  try {
    const { message, adminPassword } = await request.json();

    // Проверяем авторизацию администратора
    if (adminPassword !== ADMIN_PASSWORD) {
      return NextResponse.json(
        { success: false, error: 'Неверный пароль администратора' },
        { status: 401 }
      );
    }

    // Проверяем наличие сообщения
    if (!message || message.trim().length === 0) {
      return NextResponse.json(
        { success: false, error: 'Текст сообщения не может быть пустым' },
        { status: 400 }
      );
    }

    // Получаем всех пользователей
    const usersResult = await query(
      'SELECT telegram_id, username, first_name FROM users WHERE is_blocked_app IS NOT TRUE ORDER BY id'
    );

    const users = usersResult.rows;

    if (users.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Пользователи не найдены' },
        { status: 404 }
      );
    }

    console.log(`Начинаем отправку push-уведомлений ${users.length} пользователям...`);

    // Счетчики для статистики
    let successCount = 0;
    let errorCount = 0;
    const errorStats = {
      chatNotFound: 0,
      botBlocked: 0,
      userDeactivated: 0,
      rateLimited: 0,
      other: 0
    };
    const detailedErrors: string[] = [];

    // Отправляем сообщения всем пользователям
    for (const user of users) {
      try {
        await sendMessage(parseInt(user.telegram_id), message);
        successCount++;
        console.log(`✅ Отправлено пользователю ${user.first_name || user.username || user.telegram_id}`);
      } catch (error) {
        errorCount++;
        const errorMessage = error instanceof Error ? error.message : String(error);
        const userName = user.first_name || user.username || user.telegram_id;
        const detailedError = `${userName}: ${errorMessage}`;
        detailedErrors.push(detailedError);

        // Подсчитываем типы ошибок для статистики
        if (errorMessage.includes('Чат не найден')) {
          errorStats.chatNotFound++;
        } else if (errorMessage.includes('Бот заблокирован')) {
          errorStats.botBlocked++;
        } else if (errorMessage.includes('деактивирован')) {
          errorStats.userDeactivated++;
        } else if (errorMessage.includes('лимит запросов')) {
          errorStats.rateLimited++;
        } else {
          errorStats.other++;
        }

        console.error(`❌ ${detailedError}`);
      }

      // Небольшая задержка между отправками, чтобы не превысить лимиты Telegram API
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    // Сохраняем рассылку в базу данных для истории
    try {
      await query(
        `INSERT INTO push_history (message, sent_at, success_count, error_count, total_users, admin_user)
         VALUES ($1, CURRENT_TIMESTAMP, $2, $3, $4, $5)`,
        [message, successCount, errorCount, users.length, 'admin']
      );
    } catch (dbError) {
      console.error('Ошибка сохранения рассылки в БД:', dbError);
    }

    return NextResponse.json({
      success: true,
      message: 'Push-уведомления отправлены',
      statistics: {
        totalUsers: users.length,
        successCount,
        errorCount,
        errorBreakdown: errorStats,
        errors: detailedErrors.slice(0, 10) // Показываем только первые 10 ошибок
      }
    });

  } catch (error) {
    console.error('Ошибка отправки push-уведомлений:', error);
    return NextResponse.json(
      { success: false, error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    );
  }
}
