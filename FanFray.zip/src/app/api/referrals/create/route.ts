import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { referred_telegram_id, referral_code } = body;

    if (!referred_telegram_id || !referral_code) {
      return NextResponse.json({
        error: 'referred_telegram_id and referral_code are required'
      }, { status: 400 });
    }

    // Проверяем, что реферальный код существует
    const referrerQuery = `
      SELECT id, telegram_id, username, first_name
      FROM users
      WHERE referral_code = $1
    `;

    const referrerResult = await query(referrerQuery, [referral_code]);

    if (referrerResult.rows.length === 0) {
      return NextResponse.json({ error: 'Invalid referral code' }, { status: 400 });
    }

    const referrer = referrerResult.rows[0];

    // Проверяем, что пользователь не пытается сослаться на самого себя
    if (referrer.telegram_id.toString() === referred_telegram_id.toString()) {
      return NextResponse.json({ error: 'Cannot refer yourself' }, { status: 400 });
    }

    // Проверяем, что реферируемый пользователь существует
    const referredQuery = `
      SELECT id, telegram_id, username, first_name, referred_by_code
      FROM users
      WHERE telegram_id = $1
    `;

    const referredResult = await query(referredQuery, [referred_telegram_id]);

    if (referredResult.rows.length === 0) {
      return NextResponse.json({ error: 'Referred user not found' }, { status: 404 });
    }

    const referred = referredResult.rows[0];

    // Проверяем, что пользователь еще не был рефералом
    if (referred.referred_by_code) {
      return NextResponse.json({
        error: 'User is already referred by someone else'
      }, { status: 400 });
    }

    // Проверяем, что такая связь еще не существует
    const existingReferralQuery = `
      SELECT id FROM referrals
      WHERE referred_telegram_id = $1
    `;

    const existingResult = await query(existingReferralQuery, [referred_telegram_id]);

    if (existingResult.rows.length > 0) {
      return NextResponse.json({
        error: 'Referral relationship already exists'
      }, { status: 400 });
    }

    // Начинаем транзакцию
    await query('BEGIN');

    try {
      // Обновляем пользователя - добавляем реферальный код
      const updateUserQuery = `
        UPDATE users
        SET referred_by_code = $1, updated_at = CURRENT_TIMESTAMP
        WHERE telegram_id = $2
      `;

      await query(updateUserQuery, [referral_code, referred_telegram_id]);

      // Создаем запись в таблице referrals
      const createReferralQuery = `
        INSERT INTO referrals (
          referrer_id,
          referred_id,
          referrer_telegram_id,
          referred_telegram_id,
          referral_code,
          status,
          created_at
        ) VALUES ($1, $2, $3, $4, $5, 'active', CURRENT_TIMESTAMP)
        RETURNING id
      `;

      const referralResult = await query(createReferralQuery, [
        referrer.id,
        referred.id,
        referrer.telegram_id,
        referred_telegram_id,
        referral_code
      ]);

      const referralId = referralResult.rows[0].id;

      // Получаем настройки приветственного бонуса
      const settingsQuery = `
        SELECT setting_value
        FROM referral_settings
        WHERE setting_key IN ('referral_welcome_bonus', 'referral_activation_bonus')
      `;

      const settingsResult = await query(settingsQuery);
      const settings: { welcome_bonus?: number; activation_bonus?: number } = {};
      settingsResult.rows.forEach(row => {
        if (row.setting_key === 'referral_welcome_bonus') {
          settings.welcome_bonus = parseFloat(row.setting_value);
        } else if (row.setting_key === 'referral_activation_bonus') {
          settings.activation_bonus = parseFloat(row.setting_value);
        }
      });

      // Начисляем приветственный бонус новому рефералу
      if (settings.welcome_bonus && settings.welcome_bonus > 0) {
        const addBonusQuery = `
          UPDATE users
          SET stars_balance = stars_balance + $1
          WHERE telegram_id = $2
        `;

        await query(addBonusQuery, [settings.welcome_bonus, referred_telegram_id]);

        // Записываем в историю баланса
        const balanceHistoryQuery = `
          INSERT INTO balance_history (
            telegram_id, type, amount, balance_type, description
          ) VALUES ($1, 'bonus', $2, 'stars', 'Приветственный бонус по реферальной программе')
        `;

        await query(balanceHistoryQuery, [referred_telegram_id, settings.welcome_bonus]);
      }

      // Начисляем бонус реферру за активацию
      if (settings.activation_bonus && settings.activation_bonus > 0) {
        const addActivationBonusQuery = `
          UPDATE users
          SET stars_balance = stars_balance + $1
          WHERE telegram_id = $2
        `;

        await query(addActivationBonusQuery, [settings.activation_bonus, referrer.telegram_id]);

        // Записываем в историю баланса
        const referrerBalanceHistoryQuery = `
          INSERT INTO balance_history (
            telegram_id, type, amount, balance_type, description
          ) VALUES ($1, 'referral', $2, 'stars', 'Бонус за приглашение нового пользователя')
        `;

        await query(referrerBalanceHistoryQuery, [referrer.telegram_id, settings.activation_bonus]);
      }

      // Обновляем статистику реферра
      const updateStatsQuery = `
        SELECT update_referral_stats($1)
      `;

      await query(updateStatsQuery, [referrer.telegram_id]);

      // Подтверждаем транзакцию
      await query('COMMIT');

      return NextResponse.json({
        success: true,
        referral_id: referralId,
        message: 'Referral relationship created successfully',
        bonuses: {
          welcome_bonus: settings.welcome_bonus || 0,
          activation_bonus: settings.activation_bonus || 0
        },
        referrer: {
          telegram_id: referrer.telegram_id,
          username: referrer.username,
          first_name: referrer.first_name
        }
      });

    } catch (error) {
      // Откатываем транзакцию в случае ошибки
      await query('ROLLBACK');
      throw error;
    }

  } catch (error) {
    console.error('Error creating referral:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
