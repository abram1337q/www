import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

export async function POST(request: NextRequest) {
  try {
    const telegramId = request.headers.get('x-telegram-user-id');
    if (!telegramId) {
      return NextResponse.json({ error: 'User not authenticated' }, { status: 401 });
    }

    const body = await request.json();
    const { currency } = body;

    if (!currency || !['TON', 'STARS'].includes(currency)) {
      return NextResponse.json({
        error: 'Currency is required and must be TON or STARS'
      }, { status: 400 });
    }

    // Вызываем функцию базы данных для перевода накопленных отчислений
    const transferQuery = `
      SELECT transfer_pending_earnings_to_balance($1, $2) as result
    `;

    const result = await query(transferQuery, [telegramId, currency]);
    const transferResult = result.rows[0].result;

    if (!transferResult.success) {
      return NextResponse.json({
        success: false,
        message: transferResult.message
      }, { status: 400 });
    }

    // Получаем обновленный баланс пользователя
    const balanceColumn = currency === 'TON' ? 'ton_balance' : 'stars_balance';
    const pendingColumn = currency === 'TON' ? 'pending_ton_earnings' : 'pending_stars_earnings';

    const balanceQuery = `
      SELECT ${balanceColumn} as balance, ${pendingColumn} as pending_earnings
      FROM users
      WHERE telegram_id = $1
    `;

    const balanceResult = await query(balanceQuery, [telegramId]);
    const userBalance = balanceResult.rows[0];

    return NextResponse.json({
      success: true,
      transferred_amount: transferResult.transferred_amount,
      currency: currency,
      new_balance: parseFloat(userBalance.balance),
      remaining_pending: parseFloat(userBalance.pending_earnings),
      message: transferResult.message
    });

  } catch (error) {
    console.error('Error transferring earnings:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
