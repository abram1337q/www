import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // Получаем курс TON через CoinGecko API
    const response = await fetch(
      'https://api.coingecko.com/api/v3/simple/price?ids=the-open-network&vs_currencies=usd',
      {
        headers: {
          'Accept': 'application/json',
        },
        next: { revalidate: 30 } // Кэшируем на 30 секунд
      }
    );

    if (!response.ok) {
      throw new Error('Failed to fetch exchange rates');
    }

    const data = await response.json();

    const tonToUsd = data['the-open-network']?.usd || 5.1; // Fallback значение
    const starsToUsd = 0.015; // 1 Star = $0.015 (по курсу Fragment: 1000 Stars = $15)

    const rates = {
      TON_TO_USD: tonToUsd,
      STARS_TO_USD: starsToUsd,
      timestamp: Date.now()
    };

    return NextResponse.json({
      success: true,
      rates
    });

  } catch (error) {
    console.error('Error fetching exchange rates:', error);

    // Возвращаем fallback значения при ошибке
    const fallbackTonToUsd = 5.1;
    const fallbackStarsToUsd = 0.015; // 1 Star = $0.015 (стабильный курс к доллару)

    return NextResponse.json({
      success: false,
      rates: {
        TON_TO_USD: fallbackTonToUsd,
        STARS_TO_USD: fallbackStarsToUsd,
        timestamp: Date.now()
      },
      error: 'Failed to fetch live rates, using fallback values'
    });
  }
}
