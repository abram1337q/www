import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/db';

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;

// Функция для получения и сохранения фотографии пользователя
async function saveUserPhoto(userId: number) {
  if (!TELEGRAM_BOT_TOKEN) return false;

  try {
    // Получаем фотографии профиля пользователя
    const response = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getUserProfilePhotos?user_id=${userId}&limit=1`
    );

    if (!response.ok) {
      console.error('Failed to get user photos:', response.status);
      return false;
    }

    const data = await response.json();

    if (!data.ok || !data.result?.photos?.length) {
      console.log('User', userId, 'has no profile photos');
      // Сохраняем запись с null фотографией
      await query(
        `INSERT INTO user_photos (user_id, photo_url, file_id)
         VALUES ($1, NULL, NULL)
         ON CONFLICT (user_id) DO NOTHING`,
        [userId]
      );
      return true;
    }

    // Берем первую (самую большую) фотографию
    const photo = data.result.photos[0];
    const largestPhoto = photo[photo.length - 1]; // Последний элемент - самое большое разрешение

    // Получаем файл
    const fileResponse = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getFile?file_id=${largestPhoto.file_id}`
    );

    if (!fileResponse.ok) {
      console.error('Failed to get file info:', fileResponse.status);
      return false;
    }

    const fileData = await fileResponse.json();

    if (!fileData.ok) {
      console.error('Telegram getFile API error:', fileData.description);
      return false;
    }

    // Формируем URL для фотографии
    const photoUrl = `https://api.telegram.org/file/bot${TELEGRAM_BOT_TOKEN}/${fileData.result.file_path}`;

    // Сохраняем в базу данных
    await query(
      `INSERT INTO user_photos (user_id, photo_url, file_id)
       VALUES ($1, $2, $3)
       ON CONFLICT (user_id)
       DO UPDATE SET
         photo_url = EXCLUDED.photo_url,
         file_id = EXCLUDED.file_id,
         updated_at = CURRENT_TIMESTAMP`,
      [userId, photoUrl, largestPhoto.file_id]
    );

    console.log('Saved photo for user', userId);
    return photoUrl;

  } catch (error) {
    console.error('Error saving user photo:', error);
    return false;
  }
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const userId = searchParams.get('userId');
  const telegramId = searchParams.get('telegramId');

  // Поддерживаем оба варианта: userId (внутренний ID) и telegramId
  if (!userId && !telegramId) {
    return NextResponse.json({ error: 'userId or telegramId is required' }, { status: 400 });
  }

  try {
    let finalTelegramId;

    if (telegramId) {
      // Используем telegramId напрямую, но сначала проверим, что пользователь существует
      finalTelegramId = parseInt(telegramId);

      const userCheckResult = await query(
        'SELECT telegram_id FROM users WHERE telegram_id = $1',
        [finalTelegramId]
      );

      if (userCheckResult.rows.length === 0) {
        return NextResponse.json({
          photo_url: null,
          need_authorization: true,
          message: 'Пользователь не зарегистрирован в системе'
        });
      }
    } else if (userId) {
      // В user_photos.user_id хранится telegram_id, поэтому сначала получаем telegram_id по внутреннему user_id
      const userResult = await query(
        'SELECT telegram_id FROM users WHERE id = $1',
        [parseInt(userId)]
      );

      if (userResult.rows.length === 0) {
        return NextResponse.json({
          photo_url: null,
          need_authorization: true,
          message: 'Пользователь не зарегистрирован в системе'
        });
      }

      finalTelegramId = userResult.rows[0].telegram_id;
    } else {
      return NextResponse.json({
        photo_url: null,
        need_authorization: true,
        message: 'Не указан ни userId, ни telegramId'
      });
    }

    // Получаем фотографию из user_photos по telegram_id
    const result = await query(
      'SELECT photo_url FROM user_photos WHERE user_id = $1',
      [finalTelegramId]
    );

    if (result.rows.length === 0) {
      // Пользователя нет в user_photos, но он есть в users
      // Пытаемся автоматически загрузить и сохранить фото
      console.log('User', finalTelegramId, 'not found in user_photos, attempting to fetch photo automatically');

      try {
        const photoUrl = await saveUserPhoto(finalTelegramId);
        if (photoUrl) {
          console.log('Successfully fetched and saved photo for user', finalTelegramId);
          return NextResponse.json({
            photo_url: photoUrl,
            need_authorization: false
          });
        } else {
          // Фото загрузилось, но пользователь не имеет фото в профиле
          console.log('User', finalTelegramId, 'has no profile photo');
          return NextResponse.json({
            photo_url: null,
            need_authorization: false
          });
        }
      } catch (error) {
        console.error('Error auto-fetching photo for user', finalTelegramId, ':', error);
        // Если не удалось загрузить фото автоматически, возвращаем null но без need_authorization
        return NextResponse.json({
          photo_url: null,
          need_authorization: false,
          message: 'Не удалось загрузить фото автоматически'
        });
      }
    }

    const photoUrl = result.rows[0].photo_url;

    return NextResponse.json({
      photo_url: photoUrl,
      need_authorization: false
    });

  } catch (error) {
    console.error('Error fetching user photo from database:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
