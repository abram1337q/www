import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const telegramId = searchParams.get('telegramId');

    if (!telegramId) {
      return NextResponse.json({
        success: false,
        error: 'Telegram ID не предоставлен'
      }, { status: 400 });
    }

    // Получаем информацию о блокировке пользователя
    const result = await query(`
      SELECT
        id,
        telegram_id,
        is_blocked_app,
        is_blocked_chat,
        blocked_at,
        block_reason,
        first_name,
        username
      FROM users
      WHERE telegram_id = $1
    `, [telegramId]);

    if (result.rows.length === 0) {
      return NextResponse.json({
        success: false,
        error: 'Пользователь не найден'
      }, { status: 404 });
    }

    const user = result.rows[0];

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        telegram_id: user.telegram_id,
        is_blocked_app: user.is_blocked_app,
        is_blocked_chat: user.is_blocked_chat,
        blocked_at: user.blocked_at,
        block_reason: user.block_reason,
        first_name: user.first_name,
        username: user.username
      }
    });

  } catch (error) {
    console.error('Ошибка при проверке статуса блокировки:', error);
    return NextResponse.json({
      success: false,
      error: 'Внутренняя ошибка сервера'
    }, { status: 500 });
  }
}
