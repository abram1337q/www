import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

// GET - получить количество онлайн пользователей
export async function GET(request: NextRequest) {
  try {
    const client = await pool.connect();

    try {
      // Считаем пользователей, которые были активны в последние 5 минут
      // Можно настроить этот интервал в зависимости от требований
      const result = await client.query(`
        SELECT COUNT(DISTINCT user_id) as online_count
        FROM chat_messages
        WHERE created_at > NOW() - INTERVAL '5 minutes'
      `);

      const onlineCount = Number.parseInt(result.rows[0]?.online_count || '0');

      return NextResponse.json({
        success: true,
        data: {
          onlineCount,
          lastUpdated: new Date().toISOString()
        }
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error fetching online users:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка получения онлайн пользователей' },
      { status: 500 }
    );
  }
}
