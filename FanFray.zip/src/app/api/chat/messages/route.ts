import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';
import { checkUserBlockStatus } from '@/lib/chat-middleware';

// POST - отправить сообщение
export async function POST(request: NextRequest) {
  try {
    const { roomId, userId, message, replyToId } = await request.json();

    // Валидация
    if (!roomId || !userId || !message) {
      return NextResponse.json(
        { success: false, error: 'room_id, user_id и message обязательны' },
        { status: 400 }
      );
    }

    if (message.length > 1000) {
      return NextResponse.json(
        { success: false, error: 'Сообщение слишком длинное (максимум 1000 символов)' },
        { status: 400 }
      );
    }

    // Базовая фильтрация нецензурных слов
    const badWords = ['мат', 'плохоеслово', 'нецензурно'];
    let filteredMessage = message;

    for (const word of badWords) {
      const regex = new RegExp(word, 'gi');
      filteredMessage = filteredMessage.replace(regex, '***');
    }

    const client = await pool.connect();

    try {
      // Проверяем, существует ли комната
      const roomCheck = await client.query('SELECT id FROM chat_rooms WHERE id = $1', [roomId]);
      if (roomCheck.rows.length === 0) {
        return NextResponse.json(
          { success: false, error: 'Комната не найдена' },
          { status: 404 }
        );
      }

      // Проверяем, существует ли пользователь
      const userCheck = await client.query('SELECT id FROM users WHERE id = $1', [userId]);
      if (userCheck.rows.length === 0) {
        return NextResponse.json(
          { success: false, error: 'Пользователь не найден' },
          { status: 404 }
        );
      }

      // Проверяем статус блокировки пользователя
      const blockStatus = await checkUserBlockStatus(userId);
      if (blockStatus.isBlockedChat) {
        return NextResponse.json(
          {
            success: false,
            error: 'Ваш доступ к чату ограничен администратором',
            blocked: true,
            blockReason: blockStatus.blockReason
          },
          { status: 403 }
        );
      }

      // Вставляем сообщение
      const result = await client.query(`
        INSERT INTO chat_messages (room_id, user_id, message, reply_to_id)
        VALUES ($1, $2, $3, $4)
        RETURNING id, created_at
      `, [roomId, userId, filteredMessage.trim(), replyToId || null]);

      // Получаем полную информацию о сообщении
      const messageResult = await client.query(`
        SELECT
          cm.id,
          cm.room_id,
          cm.user_id,
          u.username,
          u.first_name,
          u.last_name,
          cm.message,
          cm.is_system,
          cm.reply_to_id,
          cm.created_at
        FROM chat_messages cm
        JOIN users u ON cm.user_id = u.id
        WHERE cm.id = $1
      `, [result.rows[0].id]);

      return NextResponse.json({
        success: true,
        data: messageResult.rows[0]
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error sending message:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка отправки сообщения' },
      { status: 500 }
    );
  }
}

// DELETE - удалить сообщение (только для авторов или админов)
export async function DELETE(request: NextRequest) {
  try {
    const { messageId, userId, isAdmin } = await request.json();

    if (!messageId || !userId) {
      return NextResponse.json(
        { success: false, error: 'message_id и user_id обязательны' },
        { status: 400 }
      );
    }

    const client = await pool.connect();

    try {
      // Используем функцию soft_delete_message из базы данных
      const result = await client.query(
        'SELECT soft_delete_message($1, $2, $3) as success',
        [messageId, userId, isAdmin || false]
      );

      const deleteSuccess = result.rows[0]?.success;

      if (!deleteSuccess) {
        return NextResponse.json(
          { success: false, error: 'Сообщение не найдено или нет прав на удаление' },
          { status: 404 }
        );
      }

      return NextResponse.json({
        success: true,
        message: 'Сообщение удалено'
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error deleting message:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка удаления сообщения' },
      { status: 500 }
    );
  }
}
