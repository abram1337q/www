import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

// GET - получить сообщения комнаты
export async function GET(
  request: NextRequest,
  context: { params: Promise<{ roomId: string }> }
) {
  try {
    const params = await context.params;
    const roomId = Number.parseInt(params.roomId);

    if (isNaN(roomId)) {
      return NextResponse.json(
        { success: false, error: 'Неверный ID комнаты' },
        { status: 400 }
      );
    }

    const { searchParams } = new URL(request.url);
    const limit = Number.parseInt(searchParams.get('limit') || '50');
    const offset = Number.parseInt(searchParams.get('offset') || '0');

    const client = await pool.connect();

    try {
      // Используем функцию из SQL схемы
      const result = await client.query(`
        SELECT * FROM get_recent_messages($1, $2)
        OFFSET $3
      `, [roomId, limit, offset]);

      return NextResponse.json({
        success: true,
        data: result.rows.reverse() // Реверсируем для правильного порядка (старые сверху)
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error fetching messages:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка получения сообщений' },
      { status: 500 }
    );
  }
}
