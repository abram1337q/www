import { NextResponse } from 'next/server';
import pool from '@/lib/database';
import { footballApi } from '@/lib/football-api';

export async function GET() {
  try {
    const client = await pool.connect();

    try {
      // Получаем несколько споров со статусом 'closed'
      const result = await client.query(`
        SELECT
          b.id as bet_id,
          b.status as bet_status,
          b.match_id,
          b.prediction_type,
          m.api_fixture_id,
          m.home_team,
          m.away_team,
          m.league,
          m.start_time,
          m.status as match_status,
          m.home_score,
          m.away_score
        FROM bets b
        JOIN matches m ON b.match_id = m.id
        WHERE b.status = 'closed'
        ORDER BY m.start_time DESC
        LIMIT 3
      `);

      const bets = result.rows;
      const debugInfo = [];

      for (const bet of bets) {
        console.log(`🔍 Testing bet ${bet.bet_id} with fixture ${bet.api_fixture_id}`);

        const betInfo: {
          bet_id: number;
          bet_status: string;
          match: string;
          league: string;
          match_time: string;
          db_match_status: string;
          db_score: string;
          api_fixture_id: number;
          api_response: null | {
            status: string;
            full_status: string;
            home_goals: number | null;
            away_goals: number | null;
            finished: boolean;
          };
          api_error: null | string;
        } = {
          bet_id: bet.bet_id,
          bet_status: bet.bet_status,
          match: `${bet.home_team} vs ${bet.away_team}`,
          league: bet.league,
          match_time: bet.start_time,
          db_match_status: bet.match_status,
          db_score: bet.home_score !== null ? `${bet.home_score}-${bet.away_score}` : 'No score',
          api_fixture_id: bet.api_fixture_id,
          api_response: null,
          api_error: null
        };

        try {
          // Тестируем запрос к API
          const apiResponse = await footballApi.getFixtureById(bet.api_fixture_id);

          if (apiResponse && apiResponse.response && apiResponse.response.length > 0) {
            const fixture = apiResponse.response[0];
            betInfo.api_response = {
              status: fixture.fixture.status.short,
              full_status: fixture.fixture.status.long,
              home_goals: fixture.goals.home,
              away_goals: fixture.goals.away,
              finished: ['FT', 'AET', 'PEN'].includes(fixture.fixture.status.short)
            };
          } else {
            betInfo.api_error = 'No data returned from API';
          }
        } catch (error) {
          betInfo.api_error = error instanceof Error ? error.message : 'Unknown API error';
        }

        debugInfo.push(betInfo);
      }

      return NextResponse.json({
        success: true,
        total_closed_bets: bets.length,
        debug_info: debugInfo,
        football_api_config: {
          base_url: process.env.FOOTBALL_API_URL || 'Not configured',
          has_api_key: !!process.env.FOOTBALL_API_KEY
        }
      });

    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Debug error:', error);
    return NextResponse.json(
      {
        error: 'Debug failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
