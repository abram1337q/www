import { NextResponse } from 'next/server';

export async function GET() {
  try {
    console.log('🚀 Starting automatic bet completion cron job...');

    // Используем localhost для внутренних вызовов в production, чтобы избежать внешних запросов
    const internalUrl = process.env.NODE_ENV === 'production'
      ? 'http://localhost:3000'
      : (process.env.APP_URL || 'http://localhost:3000');

    // Вызываем улучшенный check-finished endpoint
    const response = await fetch(`${internalUrl}/api/bets/check-finished`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'CronJob/1.0'
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result = await response.json();

    console.log('✅ Cron job check-matches completed:', {
      checked: result.checked,
      completed: result.completed,
      refunded: result.refunded || 0,
      timestamp: new Date().toISOString()
    });

    // Логируем результаты
    if (result.results && result.results.length > 0) {
      console.log('📊 Detailed results:');
      result.results.forEach((r: { status: string; bet_id: number; match?: string; score?: string; method?: string; error?: string; amount?: number; currency?: string }) => {
        if (r.status === 'completed') {
          console.log(`  ✅ Bet ${r.bet_id}: ${r.match} - ${r.score} (${r.method})`);
        } else if (r.status === 'refunded') {
          console.log(`  💸 Bet ${r.bet_id}: ${r.match} - Refunded ${r.amount} ${r.currency} (${r.method})`);
        } else if (r.status === 'error') {
          console.log(`  ❌ Bet ${r.bet_id}: ${r.error}`);
        } else {
          console.log(`  ⏳ Bet ${r.bet_id}: ${r.status}`);
        }
      });
    }

    return NextResponse.json({
      success: true,
      timestamp: new Date().toISOString(),
      summary: {
        checked: result.checked,
        completed: result.completed,
        refunded: result.refunded || 0,
        pending: result.checked - result.completed - (result.refunded || 0)
      },
      result
    });

  } catch (error) {
    console.error('❌ Cron job check-matches failed:', error);

    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}

// Поддерживаем POST запросы
export async function POST() {
  return GET();
}
