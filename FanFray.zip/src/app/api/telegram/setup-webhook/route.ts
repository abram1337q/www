import { type NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL;

    if (!botToken) {
      return NextResponse.json({ error: 'Bot token not configured' }, { status: 500 });
    }

    if (!appUrl) {
      return NextResponse.json({ error: 'App URL not configured' }, { status: 500 });
    }

    const webhookUrl = `${appUrl}/api/stars/webhook`;

    // Устанавливаем webhook
    const response = await fetch(`https://api.telegram.org/bot${botToken}/setWebhook`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url: webhookUrl,
        allowed_updates: ['pre_checkout_query', 'message']
      })
    });

    const result = await response.json();

    if (!result.ok) {
      console.error('Failed to set webhook:', result);
      return NextResponse.json({
        error: 'Failed to set webhook',
        details: result.description
      }, { status: 500 });
    }

    // Проверяем текущие настройки webhook
    const infoResponse = await fetch(`https://api.telegram.org/bot${botToken}/getWebhookInfo`);
    const webhookInfo = await infoResponse.json();

    return NextResponse.json({
      success: true,
      message: 'Webhook configured successfully',
      webhookUrl,
      webhookInfo: webhookInfo.result
    });

  } catch (error) {
    console.error('Error setting up webhook:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const botToken = process.env.TELEGRAM_BOT_TOKEN;

    if (!botToken) {
      return NextResponse.json({ error: 'Bot token not configured' }, { status: 500 });
    }

    // Получаем информацию о текущем webhook
    const response = await fetch(`https://api.telegram.org/bot${botToken}/getWebhookInfo`);
    const result = await response.json();

    return NextResponse.json({
      success: true,
      webhookInfo: result.result
    });

  } catch (error) {
    console.error('Error getting webhook info:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
