import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const walletAddress = process.env.TON_WALLET_ADDRESS;

    if (!walletAddress) {
      return NextResponse.json(
        { error: 'Wallet address not configured' },
        { status: 500 }
      );
    }

    return NextResponse.json({ address: walletAddress });
  } catch (error) {
    console.error('Error getting wallet address:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
