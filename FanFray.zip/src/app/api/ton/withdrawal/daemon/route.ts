import { type NextRequest, NextResponse } from 'next/server';
import { withdrawalDaemon } from '@/lib/withdrawal-daemon';

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const action = searchParams.get('action');

    switch (action) {
      case 'status':
        const status = withdrawalDaemon.getStatus();
        return NextResponse.json({ status });

      case 'start':
        withdrawalDaemon.start();
        return NextResponse.json({
          success: true,
          message: 'Withdrawal daemon started',
          status: withdrawalDaemon.getStatus()
        });

      case 'stop':
        withdrawalDaemon.stop();
        return NextResponse.json({
          success: true,
          message: 'Withdrawal daemon stopped',
          status: withdrawalDaemon.getStatus()
        });

      case 'process':
        await withdrawalDaemon.processWithdrawals();
        return NextResponse.json({
          success: true,
          message: 'Manual withdrawal processing triggered'
        });

      case 'auto-check':
        const result = await withdrawalDaemon.triggerAutoWithdrawalCheck();
        return NextResponse.json(result);

      default:
        return NextResponse.json({
          status: withdrawalDaemon.getStatus(),
          availableActions: ['status', 'start', 'stop', 'process', 'auto-check']
        });
    }
  } catch (error) {
    console.error('Error in withdrawal daemon API:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    switch (action) {
      case 'start':
        withdrawalDaemon.start();
        return NextResponse.json({
          success: true,
          message: 'Withdrawal daemon started',
          status: withdrawalDaemon.getStatus()
        });

      case 'stop':
        withdrawalDaemon.stop();
        return NextResponse.json({
          success: true,
          message: 'Withdrawal daemon stopped',
          status: withdrawalDaemon.getStatus()
        });

      case 'process':
        await withdrawalDaemon.processWithdrawals();
        return NextResponse.json({
          success: true,
          message: 'Manual withdrawal processing completed'
        });

      case 'auto-check':
        const result = await withdrawalDaemon.triggerAutoWithdrawalCheck();
        return NextResponse.json(result);

      default:
        return NextResponse.json(
          { error: 'Invalid action. Available actions: start, stop, process, auto-check' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Error in withdrawal daemon API:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
