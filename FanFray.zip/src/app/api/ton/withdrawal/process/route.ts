import { type NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

export async function POST(req: NextRequest) {
  try {
    console.log('TMA API: Processing withdrawal request');
    const body = await req.json();
    const { telegramId, amount, targetWallet, isManual = true } = body;

    console.log('TMA API: Request data:', { telegramId, amount, targetWallet, isManual });

    if (!telegramId || !amount || !targetWallet) {
      console.error('TMA API: Missing required fields');
      return NextResponse.json(
        { error: 'Missing required fields', success: false },
        { status: 400 }
      );
    }

    // Проверяем баланс пользователя
    const balanceResult = await query(`
      SELECT ton_balance FROM users WHERE telegram_id = $1
    `, [telegramId]);

    if (balanceResult.rows.length === 0) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const currentBalance = Number.parseFloat(balanceResult.rows[0].ton_balance);

    if (currentBalance < amount) {
      return NextResponse.json(
        { error: 'Insufficient balance' },
        { status: 400 }
      );
    }

    // Проверяем, нет ли уже активных запросов на вывод
    const activeRequestsResult = await query(`
      SELECT COUNT(*) as count FROM withdrawal_requests
      WHERE telegram_id = $1 AND status IN ('pending', 'processing')
    `, [telegramId]);

    if (Number.parseInt(activeRequestsResult.rows[0].count) > 0) {
      return NextResponse.json(
        { error: 'You already have an active withdrawal request' },
        { status: 400 }
      );
    }

    // Создаем запрос на вывод
    const requestResult = await query(`
      SELECT create_withdrawal_request($1, $2, $3, $4) as request_id
    `, [telegramId, amount, targetWallet, !isManual]);

    const requestId = requestResult.rows[0].request_id;

    // Списываем средства с баланса пользователя
    await query(`
      UPDATE users
      SET ton_balance = ton_balance - $1
      WHERE telegram_id = $2
    `, [amount, telegramId]);

    console.log('TMA API: Withdrawal request created successfully with ID:', requestId);

    const response = NextResponse.json({
      success: true,
      requestId,
      message: 'Withdrawal request created successfully'
    });

    response.headers.set('Cache-Control', 'no-cache, no-store, must-revalidate');
    response.headers.set('Pragma', 'no-cache');
    response.headers.set('Expires', '0');

    return response;
  } catch (error) {
    console.error('TMA API: Error processing withdrawal:', error);
    return NextResponse.json(
      {
        error: 'Failed to process withdrawal',
        success: false,
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

// Получение списка запросов на вывод
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const telegramId = searchParams.get('telegramId');
    const status = searchParams.get('status') || 'all';
    const limit = Number.parseInt(searchParams.get('limit') || '10');

    console.log('TMA API: Fetching withdrawal history for telegramId:', telegramId);

    if (!telegramId) {
      console.error('TMA API: Missing telegram ID');
      return NextResponse.json(
        { error: 'Telegram ID is required' },
        { status: 400 }
      );
    }

    let statusCondition = '';
    const params = [telegramId, limit];

    if (status !== 'all') {
      statusCondition = 'AND status = $3';
      params.push(status);
    }

    console.log('TMA API: Query params:', params);

    const result = await query(`
      SELECT
        id, amount, commission, net_amount, target_wallet,
        status, transaction_hash, created_at, processed_at,
        auto_generated, error_message
      FROM withdrawal_requests
      WHERE telegram_id = $1 ${statusCondition}
      ORDER BY created_at DESC
      LIMIT $2
    `, params);

    console.log('TMA API: Found', result.rows.length, 'withdrawal records');

    // Добавляем заголовки для совместимости с TMA
    const response = NextResponse.json({
      requests: result.rows,
      success: true,
      count: result.rows.length
    });

    response.headers.set('Cache-Control', 'no-cache, no-store, must-revalidate');
    response.headers.set('Pragma', 'no-cache');
    response.headers.set('Expires', '0');

    return response;
  } catch (error) {
    console.error('TMA API: Error fetching withdrawal requests:', error);
    return NextResponse.json(
      {
        error: 'Failed to fetch withdrawal requests',
        success: false,
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
