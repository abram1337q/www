import { type NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

export async function POST(req: NextRequest) {
  try {
    console.log('Starting auto-withdrawal check...');

    // Получаем пользователей, готовых к автовыводу
    const usersToWithdraw = await query(`
      SELECT user_id, current_balance, withdrawal_amount, target_wallet
      FROM check_auto_withdrawal()
    `);

    const processedRequests = [];

    for (const user of usersToWithdraw.rows) {
      try {
        console.log(`Processing auto-withdrawal for user ${user.user_id}, amount: ${user.withdrawal_amount}`);

        // Создаем запрос на автовывод
        const requestResult = await query(`
          SELECT create_withdrawal_request($1, $2, $3, $4) as request_id
        `, [user.user_id, user.withdrawal_amount, user.target_wallet, true]);

        const requestId = requestResult.rows[0].request_id;

        // Списываем средства с баланса
        await query(`
          UPDATE users
          SET ton_balance = ton_balance - $1
          WHERE telegram_id = $2
        `, [user.withdrawal_amount, user.user_id]);

        // Обновляем время последнего вывода
        await query(`
          UPDATE withdrawal_settings
          SET last_withdrawal_at = CURRENT_TIMESTAMP
          WHERE telegram_id = $1
        `, [user.user_id]);

        processedRequests.push({
          userId: user.user_id,
          requestId,
          amount: user.withdrawal_amount,
          wallet: user.target_wallet
        });

        console.log(`Auto-withdrawal request created: ${requestId} for user ${user.user_id}`);
      } catch (error) {
        console.error(`Error processing auto-withdrawal for user ${user.user_id}:`, error);
      }
    }

    console.log(`Auto-withdrawal check completed. Processed ${processedRequests.length} requests.`);

    return NextResponse.json({
      success: true,
      processedCount: processedRequests.length,
      requests: processedRequests
    });
  } catch (error) {
    console.error('Error in auto-withdrawal check:', error);
    return NextResponse.json(
      { error: 'Failed to process auto-withdrawal check' },
      { status: 500 }
    );
  }
}

// Получение статистики автовыводов
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const period = searchParams.get('period') || '24h';

    let timeCondition = '';
    switch (period) {
      case '1h':
        timeCondition = "created_at > NOW() - INTERVAL '1 hour'";
        break;
      case '24h':
        timeCondition = "created_at > NOW() - INTERVAL '24 hours'";
        break;
      case '7d':
        timeCondition = "created_at > NOW() - INTERVAL '7 days'";
        break;
      default:
        timeCondition = "created_at > NOW() - INTERVAL '24 hours'";
    }

    const stats = await query(`
      SELECT
        COUNT(*) as total_requests,
        COUNT(*) FILTER (WHERE auto_generated = true) as auto_requests,
        COUNT(*) FILTER (WHERE status = 'completed') as completed_requests,
        COUNT(*) FILTER (WHERE status = 'failed') as failed_requests,
        COUNT(*) FILTER (WHERE status = 'pending') as pending_requests,
        COALESCE(SUM(amount) FILTER (WHERE status = 'completed'), 0) as total_withdrawn,
        COALESCE(SUM(commission) FILTER (WHERE status = 'completed'), 0) as total_commission
      FROM withdrawal_requests
      WHERE ${timeCondition}
    `);

    const activeSettings = await query(`
      SELECT COUNT(*) as active_users
      FROM withdrawal_settings
      WHERE enabled = true
    `);

    return NextResponse.json({
      period,
      stats: stats.rows[0],
      activeUsers: activeSettings.rows[0].active_users
    });
  } catch (error) {
    console.error('Error fetching auto-withdrawal stats:', error);
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    );
  }
}
