import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { TelegramProvider } from "@/components/providers/TelegramProvider";
import { ThemeProvider } from "@/components/providers/ThemeProvider";
import { TonConnectProvider } from "@/components/providers/TonConnectProvider";
import { GlobalErrorHandler } from "@/components/providers/ErrorHandler";
import { ErrorBoundary } from "@/components/providers/ErrorBoundary";
import { I18nProvider } from "@/components/providers/I18nProvider";
import { BlockStatusProvider } from "@/components/providers/BlockStatusProvider";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Fanfray — Футбольные споры в Telegram",
  description: "Fanfray — это Telegram Mini App для P2P-споров на футбольные матчи. Спорь с друзьями или другими фанатами на исход игр — мы выступаем гарантом и берём минимальную комиссию.",
  keywords: ["fanfray", "футбол", "футбольные споры", "спортивные споры", "Telegram Mini App", "фанаты футбола", "челленджи"],
  openGraph: {
    type: "website",
    url: "https://fanfray.pro/",
    title: "Fanfray — Футбольные споры в Telegram",
    description: "Fanfray — Mini App для футбольных споров. Договаривайся с друзьями о результатах матчей и решай, кто был прав.",
    images: [
      {
        url: "https://fanfray.pro/preview.jpg",
        width: 1200,
        height: 630,
        alt: "Fanfray — Футбольные споры"
      }
    ],
  },
  twitter: {
    card: "summary_large_image",
    site: "https://fanfray.pro/",
    title: "Fanfray — Футбольные споры в Telegram",
    description: "Футбольные споры с друзьями. Это не букмекерство — спорь с людьми, а не с конторой.",
    images: ["https://fanfray.pro/preview.jpg"],
  },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover"
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <script src="https://telegram.org/js/telegram-web-app.js" async></script>
      </head>
      <body className={inter.className}>
        <GlobalErrorHandler />
        <ErrorBoundary>
          <TelegramProvider>
            <I18nProvider>
              <ThemeProvider
                attribute="class"
                defaultTheme="dark"
                enableSystem={false}
                disableTransitionOnChange
              >
                <TonConnectProvider>
                  <BlockStatusProvider>
                    {children}
                  </BlockStatusProvider>
                </TonConnectProvider>
              </ThemeProvider>
            </I18nProvider>
          </TelegramProvider>
        </ErrorBoundary>
      </body>
    </html>
  );
}
