interface VisualViewport extends EventTarget {
  readonly offsetLeft: number;
  readonly offsetTop: number;
  readonly pageLeft: number;
  readonly pageTop: number;
  readonly width: number;
  readonly height: number;
  readonly scale: number;
  onresize: ((this: VisualViewport, ev: Event) => unknown) | null;
  onscroll: ((this: VisualViewport, ev: Event) => unknown) | null;
}

interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
}

interface TelegramWebApp {
  openInvoice?: (url: string, callback?: (status: string) => void) => void;
  showPopup?: (params: object, callback?: (buttonId: string) => void) => void;
  showAlert?: (message: string, callback?: () => void) => void;
  showConfirm?: (message: string, callback?: (confirmed: boolean) => void) => void;
  close?: () => void;
  ready?: () => void;
  expand?: () => void;
  // Данные инициализации
  initDataUnsafe?: {
    user?: TelegramUser;
    start_param?: string;
  };
  // Методы для работы с буфером обмена (Bot API 6.4+)
  readTextFromClipboard?: (callback?: (text: string) => void) => void;
  writeTextToClipboard?: (text: string, callback?: () => void) => void;
  isVersionAtLeast?: (version: string) => boolean;
  // События
  onEvent?: (eventType: string, eventHandler: (eventData?: unknown) => void) => void;
  offEvent?: (eventType: string, eventHandler?: (eventData?: unknown) => void) => void;
  openLink?: (url: string) => void;
  version?: string;
  [key: string]: unknown;
}

interface Window {
  visualViewport?: VisualViewport;
  Telegram?: {
    WebApp: TelegramWebApp;
  };
}
