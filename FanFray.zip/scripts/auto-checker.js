#!/usr/bin/env node

const https = require('https');
const http = require('http');

class AutoChecker {
  constructor() {
    this.interval = 20000; // 20 секунд
    this.isRunning = false;
    this.baseUrl = process.env.APP_URL || 'http://localhost:3000';
    this.intervalId = null;

    console.log('🤖 Автоматический чекер ставок инициализирован');
    console.log(`📡 URL: ${this.baseUrl}`);
    console.log(`⏰ Интервал: ${this.interval/1000} секунд`);
  }

  async makeRequest(url, method = 'POST') {
    return new Promise((resolve, reject) => {
      const urlObj = new URL(url);
      const options = {
        hostname: urlObj.hostname,
        port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
        path: urlObj.pathname,
        method: method,
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'AutoChecker/1.0'
        }
      };

      const client = urlObj.protocol === 'https:' ? https : http;

      const req = client.request(options, (res) => {
        let data = '';

        res.on('data', (chunk) => {
          data += chunk;
        });

        res.on('end', () => {
          try {
            const jsonData = JSON.parse(data);
            resolve(jsonData);
          } catch (error) {
            reject(new Error(`JSON Parse Error: ${error.message}`));
          }
        });
      });

      req.on('error', (error) => {
        reject(error);
      });

      req.setTimeout(30000, () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      req.end();
    });
  }

  async runCheck() {
    try {
      console.log(`🔄 [${new Date().toLocaleString('ru')}] Запуск автопроверки...`);

      const result = await this.makeRequest(`${this.baseUrl}/api/cron/check-matches`, 'POST');

      if (result.success) {
        const { checked = 0, completed = 0, pending = 0 } = result.summary || {};

        if (completed > 0) {
          console.log(`✅ [${new Date().toLocaleString('ru')}] Проверено: ${checked}, Завершено: ${completed}, Ожидают: ${pending}`);

          // Логируем детали завершенных ставок
          if (result.result?.results) {
            result.result.results.forEach(r => {
              if (r.status === 'completed') {
                console.log(`   💰 Ставка ${r.bet_id}: ${r.match} - ${r.score} (${r.method})`);
              }
            });
          }
        } else {
          console.log(`⏳ [${new Date().toLocaleString('ru')}] Проверено: ${checked}, новых завершений нет`);
        }
      } else {
        console.error(`❌ [${new Date().toLocaleString('ru')}] Ошибка проверки:`, result.error);
      }

    } catch (error) {
      console.error(`💥 [${new Date().toLocaleString('ru')}] Критическая ошибка:`, error.message);
    }
  }

  start() {
    if (this.isRunning) {
      console.log('⚠️ Автопроверка уже запущена');
      return;
    }

    console.log(`🚀 Запуск автоматической проверки каждые ${this.interval/1000} секунд...`);
    this.isRunning = true;

    // Сразу выполняем первую проверку
    this.runCheck();

    // Настраиваем периодическое выполнение
    this.intervalId = setInterval(() => {
      this.runCheck();
    }, this.interval);
  }

  stop() {
    if (!this.isRunning) {
      console.log('⚠️ Автопроверка не запущена');
      return;
    }

    console.log('🛑 Остановка автоматической проверки...');

    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    this.isRunning = false;
    console.log('✅ Автопроверка остановлена');
  }

  getStatus() {
    return {
      isRunning: this.isRunning,
      interval: this.interval,
      baseUrl: this.baseUrl
    };
  }
}

// Создаем экземпляр и запускаем
const checker = new AutoChecker();

// Обработка сигналов для корректного завершения
process.on('SIGINT', () => {
  console.log('\n🔄 Получен сигнал завершения...');
  checker.stop();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n🔄 Получен сигнал SIGTERM...');
  checker.stop();
  process.exit(0);
});

// Запускаем автопроверку
checker.start();

// Экспортируем для использования в других модулях
module.exports = AutoChecker;
