#!/usr/bin/env node

/**
 * Демон для автоматической проверки ставок
 * Запуск: node auto-checker-daemon.js
 * Остановка: Ctrl+C или kill процесс
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

class BetCheckerDaemon {
  constructor() {
    this.interval = 20000; // 20 секунд
    this.isRunning = false;
    this.intervalId = null;
    this.consecutiveErrors = 0;
    this.maxErrors = 10;
    this.logFile = path.join(__dirname, 'auto-checker.log');

    // Читаем конфигурацию
    this.loadConfig();

    this.log('🤖 Bet Checker Daemon инициализирован');
    this.log(`📡 URL: ${this.baseUrl}`);
    this.log(`⏰ Интервал: ${this.interval/1000} секунд`);
  }

  loadConfig() {
    try {
      // Пробуем загрузить .env файл
      if (fs.existsSync('.env')) {
        const envContent = fs.readFileSync('.env', 'utf8');
        const envLines = envContent.split('\n');

        envLines.forEach(line => {
          const [key, value] = line.split('=');
          if (key && value) {
            process.env[key.trim()] = value.trim();
          }
        });
      }
    } catch (error) {
      this.log(`⚠️ Не удалось загрузить .env: ${error.message}`);
    }

    // Устанавливаем базовый URL
    this.baseUrl = process.env.APP_URL ||
                   process.env.NEXTAUTH_URL ||
                   'http://localhost:3000';

    // Если URL не содержит протокол, добавляем http://
    if (!this.baseUrl.startsWith('http')) {
      this.baseUrl = `http://${this.baseUrl}`;
    }
  }

  log(message) {
    const timestamp = new Date().toLocaleString('ru');
    const logMessage = `[${timestamp}] ${message}`;

    console.log(logMessage);

    // Записываем в лог файл
    try {
      fs.appendFileSync(this.logFile, logMessage + '\n');
    } catch (error) {
      console.error('Ошибка записи в лог:', error.message);
    }
  }

  async makeRequest() {
    return new Promise((resolve, reject) => {
      const url = `${this.baseUrl}/api/cron/check-matches`;
      const urlObj = new URL(url);

      const options = {
        hostname: urlObj.hostname,
        port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
        path: urlObj.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'BetCheckerDaemon/1.0'
        },
        timeout: 30000
      };

      const client = urlObj.protocol === 'https:' ? https : http;

      const req = client.request(options, (res) => {
        let data = '';

        res.on('data', (chunk) => {
          data += chunk;
        });

        res.on('end', () => {
          try {
            const jsonData = JSON.parse(data);
            resolve(jsonData);
          } catch (error) {
            reject(new Error(`JSON Parse Error: ${error.message}. Response: ${data}`));
          }
        });
      });

      req.on('error', (error) => {
        reject(error);
      });

      req.on('timeout', () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      req.end();
    });
  }

  async runCheck() {
    try {
      this.log('🔄 Выполнение автопроверки...');

      const result = await this.makeRequest();

      if (result.success) {
        this.consecutiveErrors = 0;

        const { checked = 0, completed = 0, refunded = 0, pending = 0 } = result.summary || {};

        if (completed > 0 || refunded > 0) {
          this.log(`✅ Проверено: ${checked} | Завершено: ${completed} | Возвращено: ${refunded} | Ожидают: ${pending}`);

          // Логируем детали завершенных и возвращенных ставок
          if (result.result?.results) {
            const completedBets = result.result.results.filter(r => r.status === 'completed');
            const refundedBets = result.result.results.filter(r => r.status === 'refunded');

            completedBets.forEach(bet => {
              this.log(`   💰 Ставка #${bet.bet_id}: ${bet.match} → ${bet.score} (${bet.method})`);
            });

            refundedBets.forEach(bet => {
              const reason = bet.method === 'auto_refund' ? 'нет участников (1/3)' : bet.method;
              this.log(`   💸 Возврат #${bet.bet_id}: ${bet.match} → ${bet.amount || 'N/A'} ${bet.currency || 'N/A'} (${reason})`);
            });
          }
        } else if (checked > 0) {
          this.log(`⏳ Проверено ставок: ${checked}, новых завершений нет`);
        } else {
          this.log(`💤 Нет активных ставок для проверки`);
        }
      } else {
        this.handleError(`API ошибка: ${result.error}`);
      }

    } catch (error) {
      this.handleError(`Ошибка запроса: ${error.message}`);
    }
  }

  handleError(errorMessage) {
    this.consecutiveErrors++;
    this.log(`❌ ${errorMessage}`);
    this.log(`⚠️ Ошибок подряд: ${this.consecutiveErrors}/${this.maxErrors}`);

    if (this.consecutiveErrors >= this.maxErrors) {
      this.log(`🚨 Критическое количество ошибок! Останавливаю демон.`);
      this.stop();
      process.exit(1);
    }
  }

  start() {
    if (this.isRunning) {
      this.log('⚠️ Демон уже запущен');
      return;
    }

    this.log(`🚀 Запуск демона автопроверки каждые ${this.interval/1000} секунд`);
    this.isRunning = true;
    this.consecutiveErrors = 0;

    // Создаем PID файл
    this.createPidFile();

    // Сразу выполняем первую проверку
    this.runCheck();

    // Настраиваем периодическое выполнение
    this.intervalId = setInterval(() => {
      this.runCheck();
    }, this.interval);
  }

  stop() {
    if (!this.isRunning) {
      this.log('⚠️ Демон не запущен');
      return;
    }

    this.log('🛑 Остановка демона...');

    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    this.isRunning = false;
    this.removePidFile();
    this.log('✅ Демон остановлен');
  }

  createPidFile() {
    const pidFile = path.join(__dirname, 'auto-checker.pid');
    try {
      fs.writeFileSync(pidFile, process.pid.toString());
      this.log(`📝 PID файл создан: ${pidFile} (PID: ${process.pid})`);
    } catch (error) {
      this.log(`⚠️ Не удалось создать PID файл: ${error.message}`);
    }
  }

  removePidFile() {
    const pidFile = path.join(__dirname, 'auto-checker.pid');
    try {
      if (fs.existsSync(pidFile)) {
        fs.unlinkSync(pidFile);
        this.log('🗑️ PID файл удален');
      }
    } catch (error) {
      this.log(`⚠️ Не удалось удалить PID файл: ${error.message}`);
    }
  }

  getStatus() {
    return {
      isRunning: this.isRunning,
      intervalSeconds: this.interval / 1000,
      baseUrl: this.baseUrl,
      consecutiveErrors: this.consecutiveErrors,
      maxErrors: this.maxErrors,
      pid: process.pid
    };
  }
}

// Создаем и запускаем демон
const daemon = new BetCheckerDaemon();

// Обработка сигналов для корректного завершения
process.on('SIGINT', () => {
  daemon.log('\n🔄 Получен SIGINT (Ctrl+C)');
  daemon.stop();
  process.exit(0);
});

process.on('SIGTERM', () => {
  daemon.log('\n🔄 Получен SIGTERM');
  daemon.stop();
  process.exit(0);
});

process.on('uncaughtException', (error) => {
  daemon.log(`💥 Критическая ошибка: ${error.message}`);
  daemon.log(error.stack);
  daemon.stop();
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  daemon.log(`💥 Необработанное отклонение: ${reason}`);
  daemon.stop();
  process.exit(1);
});

// Запускаем демон
daemon.start();

// Статус каждые 5 минут
setInterval(() => {
  const status = daemon.getStatus();
  daemon.log(`📊 Статус: запущен=${status.isRunning}, ошибок=${status.consecutiveErrors}/${status.maxErrors}`);
}, 5 * 60 * 1000);

module.exports = BetCheckerDaemon;
