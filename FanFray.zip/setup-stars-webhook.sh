#!/bin/bash

# Скрипт для настройки webhook Stars после деплоя

DOMAIN="https://fanfray.pro/"

echo "🚀 Настройка webhook для Telegram бота (включая Stars платежи)..."

# Настройка webhook для Telegram бота
curl -X POST "${DOMAIN}/api/telegram/setup-webhook" \
  -H "Content-Type: application/json" \
  -w "\nHTTP Status: %{http_code}\n" \
  -s | jq '.'

echo "✅ Проверка текущего статуса webhook..."

# Проверка статуса webhook
curl -X GET "${DOMAIN}/api/telegram/setup-webhook" \
  -H "Content-Type: application/json" \
  -w "\nHTTP Status: %{http_code}\n" \
  -s | jq '.'

echo "🔍 Тестирование создания инвойса..."

# Тестируем создание инвойса (нужен telegram_id пользователя)
# curl -X POST "${DOMAIN}/api/stars/create-invoice" \
#   -H "Content-Type: application/json" \
#   -H "x-telegram-user-id: YOUR_TELEGRAM_ID" \
#   -d '{"amount": 10}' \
#   -w "\nHTTP Status: %{http_code}\n" \
#   -s | jq '.'

echo "🎯 Webhook настроен. Теперь Stars платежи должны работать!"
echo "📝 Для тестирования замените YOUR_TELEGRAM_ID на ваш Telegram ID и раскомментируйте тестовый запрос."
