#!/bin/bash

# Скрипт для запуска демона стандартных выводов
# Использование: ./start-standard-daemon.sh

DAEMON_NAME="standard-withdrawal-daemon"
DAEMON_FILE="./standard-withdrawal-daemon.js"
PID_FILE="/tmp/${DAEMON_NAME}.pid"
LOG_FILE="/tmp/${DAEMON_NAME}.log"

# Функция для проверки, запущен ли демон
is_running() {
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE")
        if ps -p "$pid" > /dev/null 2>&1; then
            return 0
        else
            rm -f "$PID_FILE"
            return 1
        fi
    fi
    return 1
}

# Функция для запуска демона
start_daemon() {
    if is_running; then
        echo "❌ $DAEMON_NAME уже запущен (PID: $(cat $PID_FILE))"
        return 1
    fi

    echo "🚀 Запускаем $DAEMON_NAME..."

    # Проверяем существование файла демона
    if [ ! -f "$DAEMON_FILE" ]; then
        echo "❌ Файл демона не найден: $DAEMON_FILE"
        return 1
    fi

    # Запускаем демон в фоне
    nohup node "$DAEMON_FILE" > "$LOG_FILE" 2>&1 &
    local pid=$!

    # Сохраняем PID
    echo "$pid" > "$PID_FILE"

    # Проверяем, что процесс действительно запустился
    sleep 2
    if ps -p "$pid" > /dev/null 2>&1; then
        echo "✅ $DAEMON_NAME успешно запущен (PID: $pid)"
        echo "📝 Логи: $LOG_FILE"
        return 0
    else
        echo "❌ Не удалось запустить $DAEMON_NAME"
        rm -f "$PID_FILE"
        return 1
    fi
}

# Функция для остановки демона
stop_daemon() {
    if ! is_running; then
        echo "❌ $DAEMON_NAME не запущен"
        return 1
    fi

    local pid=$(cat "$PID_FILE")
    echo "🛑 Останавливаем $DAEMON_NAME (PID: $pid)..."

    # Отправляем SIGTERM
    kill "$pid" 2>/dev/null

    # Ждем завершения (максимум 10 секунд)
    local count=0
    while [ $count -lt 10 ] && ps -p "$pid" > /dev/null 2>&1; do
        sleep 1
        count=$((count + 1))
    done

    # Если процесс все еще работает, отправляем SIGKILL
    if ps -p "$pid" > /dev/null 2>&1; then
        echo "⚠️  Принудительное завершение процесса..."
        kill -9 "$pid" 2>/dev/null
    fi

    rm -f "$PID_FILE"
    echo "✅ $DAEMON_NAME остановлен"
}

# Функция для перезапуска демона
restart_daemon() {
    stop_daemon
    sleep 2
    start_daemon
}

# Функция для проверки статуса
status_daemon() {
    if is_running; then
        local pid=$(cat "$PID_FILE")
        echo "✅ $DAEMON_NAME работает (PID: $pid)"

        # Показываем последние строки лога
        if [ -f "$LOG_FILE" ]; then
            echo ""
            echo "📝 Последние записи лога:"
            tail -n 5 "$LOG_FILE"
        fi
    else
        echo "❌ $DAEMON_NAME не запущен"
    fi
}

# Функция для просмотра логов
logs_daemon() {
    if [ -f "$LOG_FILE" ]; then
        echo "📝 Показ логов $DAEMON_NAME (Ctrl+C для выхода):"
        tail -f "$LOG_FILE"
    else
        echo "❌ Файл логов не найден: $LOG_FILE"
    fi
}

# Обработка аргументов командной строки
case "${1:-start}" in
    start)
        start_daemon
        ;;
    stop)
        stop_daemon
        ;;
    restart)
        restart_daemon
        ;;
    status)
        status_daemon
        ;;
    logs)
        logs_daemon
        ;;
    *)
        echo "Использование: $0 {start|stop|restart|status|logs}"
        echo ""
        echo "Команды:"
        echo "  start   - Запустить демон"
        echo "  stop    - Остановить демон"
        echo "  restart - Перезапустить демон"
        echo "  status  - Показать статус демона"
        echo "  logs    - Показать логи в реальном времени"
        exit 1
        ;;
esac
