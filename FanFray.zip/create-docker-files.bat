@echo off
chcp 65001 >nul
echo ========================================
echo 🐋 Создание Docker файлов для проекта
echo ========================================
echo.

REM Удаляем старые файлы если есть
if exist Dockerfile del Dockerfile
if exist Dockerfile.daemon del Dockerfile.daemon
if exist .dockerignore del .dockerignore
if exist docker-compose.yml del docker-compose.yml
if exist nginx.conf del nginx.conf

echo 📝 Создаём Dockerfile...
(
echo FROM node:18-alpine AS base
echo.
echo # Install dependencies only when needed
echo FROM base AS deps
echo RUN apk add --no-cache libc6-compat
echo WORKDIR /app
echo.
echo # Install dependencies based on the preferred package manager
echo COPY package.json package-lock.json* ./
echo RUN npm ci
echo.
echo # Rebuild the source code only when needed
echo FROM base AS builder
echo WORKDIR /app
echo COPY --from=deps /app/node_modules ./node_modules
echo COPY . .
echo.
echo # Set environment to production
echo ENV NODE_ENV=production
echo ENV NEXT_TELEMETRY_DISABLED=1
echo.
echo # Build Next.js
echo RUN npm run build
echo.
echo # Production image, copy all the files and run next
echo FROM base AS runner
echo WORKDIR /app
echo.
echo ENV NODE_ENV=production
echo ENV NEXT_TELEMETRY_DISABLED=1
echo.
echo RUN addgroup --system --gid 1001 nodejs
echo RUN adduser --system --uid 1001 nextjs
echo.
echo # Copy built application
echo COPY --from=builder /app/public ./public
echo COPY --from=builder /app/.next/standalone ./
echo COPY --from=builder /app/.next/static ./.next/static
echo.
echo # Copy daemons and scripts
echo COPY --from=builder /app/standalone-withdrawal-daemon.js ./
echo COPY --from=builder /app/auto-checker-daemon.cjs ./
echo COPY --from=builder /app/scripts ./scripts
echo COPY --from=builder /app/.env* ./
echo.
echo # Install PM2 globally for process management
echo RUN npm install -g pm2
echo.
echo USER nextjs
echo.
echo EXPOSE 3000
echo.
echo ENV PORT=3000
echo ENV HOSTNAME="0.0.0.0"
echo.
echo # Start script will be managed by docker-compose
echo CMD ["node", "server.js"]
) > Dockerfile

echo ✅ Dockerfile создан
echo.

echo 📝 Создаём Dockerfile.daemon...
(
echo FROM node:18-alpine
echo.
echo ARG DAEMON_SCRIPT
echo ENV DAEMON_SCRIPT=${DAEMON_SCRIPT}
echo.
echo WORKDIR /app
echo.
echo # Install dependencies
echo COPY package*.json ./
echo RUN npm ci --only=production
echo.
echo # Copy environment files
echo COPY .env* ./
echo.
echo # Copy source code
echo COPY src ./src
echo.
echo # Copy scripts folder if exists
echo COPY scripts ./scripts
echo.
echo # Copy the daemon script based on build arg
echo COPY ${DAEMON_SCRIPT} ./daemon.js
echo.
echo # Make script executable
echo RUN chmod +x daemon.js
echo.
echo # Health check
echo HEALTHCHECK --interval=60s --timeout=10s --start-period=30s --retries=3 \
echo   CMD node -e "process.exit(0)"
echo.
echo CMD ["node", "daemon.js"]
) > Dockerfile.daemon

echo ✅ Dockerfile.daemon создан
echo.

echo 📝 Создаём .dockerignore...
(
echo node_modules
echo npm-debug.log
echo .next
echo .git
echo .gitignore
echo README.md
echo .env.local
echo .env.development
echo .env.test
echo *.md
echo .vscode
echo .idea
echo coverage
echo .DS_Store
echo *.log
echo .github
echo Dockerfile
echo docker-compose.yml
echo .dockerignore
echo FanFray.zip
echo *.pid
echo nohup.out
) > .dockerignore

echo ✅ .dockerignore создан
echo.

echo 📝 Создаём docker-compose.yml...
(
echo version: '3.8'
echo.
echo services:
echo   # Next.js приложение
echo   app:
echo     build:
echo       context: .
echo       dockerfile: Dockerfile
echo     container_name: fanfray-app
echo     restart: unless-stopped
echo     environment:
echo       - NODE_ENV=production
echo     env_file:
echo       - .env
echo     ports:
echo       - "3000:3000"
echo     networks:
echo       - fanfray-network
echo     healthcheck:
echo       test: ["CMD", "node", "-e", "require('http'^).get('http://localhost:3000/api/user/balance', (r^) =^> {process.exit(r.statusCode === 200 ? 0 : 1^)}^)"]
echo       interval: 30s
echo       timeout: 10s
echo       retries: 3
echo       start_period: 40s
echo.
echo   # Демон автопроверки ставок
echo   auto-checker:
echo     build:
echo       context: .
echo       dockerfile: Dockerfile.daemon
echo       args:
echo         DAEMON_SCRIPT: auto-checker-daemon.cjs
echo     container_name: fanfray-auto-checker
echo     restart: unless-stopped
echo     env_file:
echo       - .env
echo     environment:
echo       - APP_URL=http://app:3000
echo       - NODE_ENV=production
echo     networks:
echo       - fanfray-network
echo     depends_on:
echo       app:
echo         condition: service_healthy
echo.
echo   # Демон обработки выводов TON
echo   withdrawal-daemon:
echo     build:
echo       context: .
echo       dockerfile: Dockerfile.daemon
echo       args:
echo         DAEMON_SCRIPT: standalone-withdrawal-daemon.js
echo     container_name: fanfray-withdrawal-daemon
echo     restart: unless-stopped
echo     env_file:
echo       - .env
echo     environment:
echo       - NODE_ENV=production
echo     networks:
echo       - fanfray-network
echo     depends_on:
echo       app:
echo         condition: service_healthy
echo.
echo   # Nginx reverse proxy
echo   nginx:
echo     image: nginx:alpine
echo     container_name: fanfray-nginx
echo     restart: unless-stopped
echo     ports:
echo       - "80:80"
echo       - "443:443"
echo     volumes:
echo       - ./nginx.conf:/etc/nginx/conf.d/default.conf:ro
echo       - ./ssl:/etc/nginx/ssl:ro
echo     networks:
echo       - fanfray-network
echo     depends_on:
echo       - app
echo     healthcheck:
echo       test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost/api/user/balance"]
echo       interval: 30s
echo       timeout: 10s
echo       retries: 3
echo.
echo networks:
echo   fanfray-network:
echo     driver: bridge
) > docker-compose.yml

echo ✅ docker-compose.yml создан
echo.

echo 📝 Создаём nginx.conf...
(
echo server {
echo     listen 80;
echo     server_name _;
echo.
echo     # Logging
echo     access_log /var/log/nginx/access.log;
echo     error_log /var/log/nginx/error.log warn;
echo.
echo     # Security headers for TMA
echo     add_header X-Frame-Options "ALLOWALL" always;
echo     add_header X-Content-Type-Options "nosniff" always;
echo     add_header X-XSS-Protection "1; mode=block" always;
echo     add_header Content-Security-Policy "frame-ancestors *; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://telegram.org;" always;
echo.
echo     # Max body size for uploads
echo     client_max_body_size 10M;
echo.
echo     # Telegram webhooks - специальная обработка
echo     location ~ ^^/api/(telegram^|stars^)/webhook {
echo         proxy_pass http://app:3000;
echo         proxy_http_version 1.1;
echo         proxy_set_header Host $host;
echo         proxy_set_header X-Real-IP $remote_addr;
echo         proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
echo         proxy_set_header X-Forwarded-Proto $scheme;
echo.
echo         # Таймауты для webhook
echo         proxy_read_timeout 30s;
echo         proxy_connect_timeout 10s;
echo         proxy_send_timeout 30s;
echo.
echo         # Буферизация
echo         proxy_buffering off;
echo     }
echo.
echo     # API routes
echo     location /api/ {
echo         proxy_pass http://app:3000;
echo         proxy_http_version 1.1;
echo         proxy_set_header Host $host;
echo         proxy_set_header X-Real-IP $remote_addr;
echo         proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
echo         proxy_set_header X-Forwarded-Proto $scheme;
echo.
echo         # Таймауты для API
echo         proxy_read_timeout 60s;
echo         proxy_connect_timeout 10s;
echo         proxy_send_timeout 60s;
echo     }
echo.
echo     # Proxy to Next.js app
echo     location / {
echo         proxy_pass http://app:3000;
echo         proxy_http_version 1.1;
echo         proxy_set_header Upgrade $http_upgrade;
echo         proxy_set_header Connection 'upgrade';
echo         proxy_set_header Host $host;
echo         proxy_set_header X-Real-IP $remote_addr;
echo         proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
echo         proxy_set_header X-Forwarded-Proto $scheme;
echo         proxy_cache_bypass $http_upgrade;
echo         proxy_read_timeout 86400;
echo         proxy_connect_timeout 60s;
echo         proxy_send_timeout 60s;
echo     }
echo.
echo     # Optimize static files
echo     location /_next/static/ {
echo         proxy_pass http://app:3000;
echo         add_header Cache-Control "public, max-age=31536000, immutable";
echo     }
echo.
echo     # Favicon and other static assets
echo     location ~* \.(ico^|css^|js^|gif^|jpe?g^|png^|svg^|woff^|woff2^|ttf^|eot^)$ {
echo         proxy_pass http://app:3000;
echo         add_header Cache-Control "public, max-age=31536000";
echo     }
echo }
echo.
echo # SSL configuration (uncomment and configure when you have SSL certificates^)
echo # server {
echo #     listen 443 ssl http2;
echo #     server_name your-domain.com;
echo #
echo #     ssl_certificate /etc/nginx/ssl/fullchain.pem;
echo #     ssl_certificate_key /etc/nginx/ssl/privkey.pem;
echo #     ssl_protocols TLSv1.2 TLSv1.3;
echo #     ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384;
echo #     ssl_prefer_server_ciphers off;
echo #
echo #     add_header X-Frame-Options "ALLOWALL" always;
echo #     add_header Content-Security-Policy "frame-ancestors *; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://telegram.org;" always;
echo #
echo #     location / {
echo #         proxy_pass http://app:3000;
echo #         proxy_http_version 1.1;
echo #         proxy_set_header Upgrade $http_upgrade;
echo #         proxy_set_header Connection 'upgrade';
echo #         proxy_set_header Host $host;
echo #         proxy_set_header X-Real-IP $remote_addr;
echo #         proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
echo #         proxy_set_header X-Forwarded-Proto $scheme;
echo #         proxy_cache_bypass $http_upgrade;
echo #     }
echo # }
) > nginx.conf

echo ✅ nginx.conf создан
echo.

echo ========================================
echo ✅ Все Docker файлы успешно созданы!
echo ========================================
echo.
echo Созданные файлы:
dir /B Dockerfile 2>nul && echo   ✓ Dockerfile
dir /B Dockerfile.daemon 2>nul && echo   ✓ Dockerfile.daemon
dir /B .dockerignore 2>nul && echo   ✓ .dockerignore
dir /B docker-compose.yml 2>nul && echo   ✓ docker-compose.yml
dir /B nginx.conf 2>nul && echo   ✓ nginx.conf
echo.
echo 📖 Следующие шаги:
echo    1. Убедитесь что файл .env настроен
echo    2. Запустите: docker-compose build
echo    3. Запустите: docker-compose up -d
echo.
pause
