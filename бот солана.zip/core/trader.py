"""
Layer 3: Trade Executor (Paper Trading)
Executes paper trades based on AI recommendations.
"""
import asyncio
from typing import Optional, Callable
from dataclasses import dataclass

from core.wallet import get_wallet, Position
from core.analyzer import AnalysisResult
from integrations import helius
from config.settings import settings
from config.constants import DEFAULT_SOL_PRICE_USD
from utils.logger import logger
from utils.helpers import timestamp_now


@dataclass
class TradeResult:
    """Result of a trade execution."""
    success: bool
    message: str
    position: Optional[Position] = None
    pnl_usd: float = 0
    pnl_percent: float = 0


class PaperTrader:
    """
    Paper trading executor.
    Simulates trades without real money.
    """

    def __init__(self):
        self._price_monitor_running = False
        self._on_tp_sl_callback: Optional[Callable] = None

    async def execute_buy(
        self,
        user_id: int,
        analysis: AnalysisResult,
        amount_usd: float = None,
        take_profit: float = None,
        stop_loss: float = None
    ) -> TradeResult:
        """
        Execute a paper buy order.

        Args:
            user_id: Telegram user ID
            analysis: AI analysis result
            amount_usd: Investment amount (uses suggested if None)
            take_profit: TP percentage (uses suggested if None)
            stop_loss: SL percentage (uses suggested if None)
        """
        wallet = get_wallet(user_id)

        # Determine position size
        if amount_usd is None:
            size_map = {
                "small": 25,
                "medium": 50,
                "large": 100
            }
            amount_usd = size_map.get(
                analysis.suggested_position_size,
                wallet.settings.get("default_position_size_usd", 50)
            )

        # Parse TP/SL from analysis
        if take_profit is None:
            tp_str = analysis.take_profit.replace("%", "").replace("+", "")
            take_profit = float(tp_str) if tp_str else 100

        if stop_loss is None:
            sl_str = analysis.stop_loss.replace("%", "").replace("-", "")
            stop_loss = float(sl_str) if sl_str else 40

        # Get current prices
        sol_price = helius.sol_price_usd or DEFAULT_SOL_PRICE_USD

        # Get token price
        token_price = await helius.get_token_price(analysis.token_address)

        if token_price <= 0:
            # Estimate from liquidity (very rough)
            liquidity = analysis.rugcheck_data.get("liquidity_usd", 0)
            if liquidity > 0:
                # Assume ~50% of liquidity is token value, estimate supply
                token_price = 0.0000001  # Default micro price
            else:
                return TradeResult(
                    success=False,
                    message="Не удалось получить цену токена"
                )

        # Execute paper trade
        success, message, position = wallet.open_position(
            token_address=analysis.token_address,
            symbol=analysis.symbol,
            name=analysis.name,
            token_price=token_price,
            amount_usd=amount_usd,
            sol_price=sol_price,
            take_profit=take_profit,
            stop_loss=stop_loss
        )

        if success:
            logger.info(f"✅ Paper trade executed: BUY {analysis.symbol} | ${amount_usd}")

        return TradeResult(
            success=success,
            message=message,
            position=position
        )

    async def execute_sell(
        self,
        user_id: int,
        token_address: str,
        percent: float = 100,
        reason: str = "manual"
    ) -> TradeResult:
        """
        Execute a paper sell order.

        Args:
            user_id: Telegram user ID
            token_address: Token to sell
            percent: Percentage to sell (100 = all)
            reason: Reason for selling
        """
        wallet = get_wallet(user_id)

        # Get current prices
        sol_price = helius.sol_price_usd or DEFAULT_SOL_PRICE_USD
        token_price = await helius.get_token_price(token_address)

        if token_price <= 0:
            # Use last known price
            position = wallet.positions.get(token_address)
            if position:
                token_price = position.current_price or position.entry_price
            else:
                return TradeResult(
                    success=False,
                    message="Позиция не найдена"
                )

        success, message, pnl_usd, pnl_percent = wallet.close_position(
            token_address=token_address,
            current_price=token_price,
            sol_price=sol_price,
            reason=reason,
            percent=percent
        )

        return TradeResult(
            success=success,
            message=message,
            pnl_usd=pnl_usd,
            pnl_percent=pnl_percent
        )

    async def start_price_monitor(
        self,
        user_ids: list[int],
        on_tp_sl: Callable[[int, Position, str], None],
        interval: int = 5
    ):
        """
        Start monitoring prices for TP/SL triggers.

        Args:
            user_ids: List of user IDs to monitor
            on_tp_sl: Callback when TP/SL triggers
            interval: Check interval in seconds
        """
        self._price_monitor_running = True
        self._on_tp_sl_callback = on_tp_sl

        logger.info("📊 Price monitor started")

        while self._price_monitor_running:
            try:
                sol_price = helius.sol_price_usd or DEFAULT_SOL_PRICE_USD

                for user_id in user_ids:
                    wallet = get_wallet(user_id)

                    if not wallet.positions:
                        continue

                    # Get current prices for all positions
                    prices = {}
                    for token_address in wallet.positions:
                        price = await helius.get_token_price(token_address)
                        if price > 0:
                            prices[token_address] = price

                    # Update positions
                    wallet.update_position_prices(prices, sol_price)

                    # Check TP/SL
                    triggers = wallet.check_tp_sl(sol_price)

                    for position, trigger_type in triggers:
                        logger.info(f"🎯 {trigger_type.upper()}: {position.symbol} | {position.pnl_percent:.1f}%")

                        # Auto-close
                        result = await self.execute_sell(
                            user_id=user_id,
                            token_address=position.token_address,
                            percent=100,
                            reason=trigger_type
                        )

                        if on_tp_sl:
                            await on_tp_sl(user_id, position, trigger_type)

                await asyncio.sleep(interval)

            except Exception as e:
                logger.error(f"Price monitor error: {e}")
                await asyncio.sleep(interval)

    def stop_price_monitor(self):
        """Stop the price monitor."""
        self._price_monitor_running = False
        logger.info("📊 Price monitor stopped")


# Global trader instance
paper_trader = PaperTrader()
