"""
Paper Trading Wallet Manager
Simulates a Solana wallet for testing without real money.
"""
import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
from pathlib import Path

from config.settings import settings
from config.constants import DEFAULT_SOL_PRICE_USD
from utils.logger import logger
from utils.helpers import load_json, save_json, timestamp_now


@dataclass
class Position:
    """Represents an open position."""
    token_address: str
    symbol: str
    name: str
    amount: float  # Token amount
    entry_price: float  # Price per token in USD
    entry_sol_price: float  # SOL price at entry
    investment_usd: float  # Total invested in USD
    investment_sol: float  # Total invested in SOL
    take_profit_percent: float
    stop_loss_percent: float
    opened_at: str
    current_price: float = 0
    current_value_usd: float = 0
    pnl_usd: float = 0
    pnl_percent: float = 0
    status: str = "open"  # open, closed, stopped_out, take_profit

    def to_dict(self) -> dict:
        return {
            "token_address": self.token_address,
            "symbol": self.symbol,
            "name": self.name,
            "amount": self.amount,
            "entry_price": self.entry_price,
            "entry_sol_price": self.entry_sol_price,
            "investment_usd": self.investment_usd,
            "investment_sol": self.investment_sol,
            "take_profit_percent": self.take_profit_percent,
            "stop_loss_percent": self.stop_loss_percent,
            "opened_at": self.opened_at,
            "current_price": self.current_price,
            "current_value_usd": self.current_value_usd,
            "pnl_usd": self.pnl_usd,
            "pnl_percent": self.pnl_percent,
            "status": self.status
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Position":
        return cls(**data)


@dataclass
class Trade:
    """Represents a completed trade."""
    id: str
    token_address: str
    symbol: str
    name: str
    side: str  # buy, sell
    amount: float
    price: float
    total_usd: float
    total_sol: float
    pnl_usd: float = 0
    pnl_percent: float = 0
    reason: str = ""  # manual, take_profit, stop_loss
    timestamp: str = ""

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "token_address": self.token_address,
            "symbol": self.symbol,
            "name": self.name,
            "side": self.side,
            "amount": self.amount,
            "price": self.price,
            "total_usd": self.total_usd,
            "total_sol": self.total_sol,
            "pnl_usd": self.pnl_usd,
            "pnl_percent": self.pnl_percent,
            "reason": self.reason,
            "timestamp": self.timestamp
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Trade":
        return cls(**data)


class PaperWallet:
    """
    Paper trading wallet - simulates trading without real money.
    Stores state in JSON file.
    """

    def __init__(self, user_id: int):
        self.user_id = user_id
        self.data_file = f"wallet_{user_id}.json"

        # Load or initialize
        self._load()

    def _load(self):
        """Load wallet state from file."""
        data = load_json(self.data_file)

        if not data:
            # Initialize new wallet
            self.balance_sol = settings.initial_balance_sol
            self.initial_balance_sol = settings.initial_balance_sol
            self.positions: dict[str, Position] = {}
            self.trades: list[Trade] = []
            self.settings = {
                "default_position_size_usd": settings.default_position_size_usd,
                "max_positions": settings.max_positions,
                "default_take_profit": settings.default_take_profit,
                "default_stop_loss": settings.default_stop_loss,
                "auto_mode": False
            }
            self._save()
        else:
            self.balance_sol = data.get("balance_sol", settings.initial_balance_sol)
            self.initial_balance_sol = data.get("initial_balance_sol", settings.initial_balance_sol)
            self.positions = {
                k: Position.from_dict(v)
                for k, v in data.get("positions", {}).items()
            }
            self.trades = [Trade.from_dict(t) for t in data.get("trades", [])]
            self.settings = data.get("settings", {})

    def _save(self):
        """Save wallet state to file."""
        data = {
            "user_id": self.user_id,
            "balance_sol": self.balance_sol,
            "initial_balance_sol": self.initial_balance_sol,
            "positions": {k: v.to_dict() for k, v in self.positions.items()},
            "trades": [t.to_dict() for t in self.trades],
            "settings": self.settings,
            "updated_at": timestamp_now()
        }
        save_json(self.data_file, data)

    def get_balance_usd(self, sol_price: float = DEFAULT_SOL_PRICE_USD) -> float:
        """Get balance in USD."""
        return self.balance_sol * sol_price

    def can_open_position(self, amount_sol: float) -> tuple[bool, str]:
        """Check if can open new position."""
        if len(self.positions) >= self.settings.get("max_positions", 5):
            return False, f"Максимум позиций ({self.settings['max_positions']}) достигнут"

        if amount_sol > self.balance_sol:
            return False, f"Недостаточно SOL. Баланс: {self.balance_sol:.4f}"

        return True, "OK"

    def open_position(
        self,
        token_address: str,
        symbol: str,
        name: str,
        token_price: float,
        amount_usd: float,
        sol_price: float,
        take_profit: float = None,
        stop_loss: float = None
    ) -> tuple[bool, str, Optional[Position]]:
        """
        Open a new paper position.

        Args:
            token_address: Token mint address
            symbol: Token symbol
            name: Token name
            token_price: Current token price in USD
            amount_usd: Investment amount in USD
            sol_price: Current SOL price in USD
            take_profit: Take profit percentage (e.g., 100 for +100%)
            stop_loss: Stop loss percentage (e.g., 40 for -40%)

        Returns:
            (success, message, position)
        """
        amount_sol = amount_usd / sol_price

        # Check if can open
        can_open, reason = self.can_open_position(amount_sol)
        if not can_open:
            return False, reason, None

        # Check if already have position
        if token_address in self.positions:
            return False, f"Позиция по {symbol} уже открыта", None

        # Calculate tokens bought
        if token_price <= 0:
            return False, "Невалидная цена токена", None

        token_amount = amount_usd / token_price

        # Create position
        position = Position(
            token_address=token_address,
            symbol=symbol,
            name=name,
            amount=token_amount,
            entry_price=token_price,
            entry_sol_price=sol_price,
            investment_usd=amount_usd,
            investment_sol=amount_sol,
            take_profit_percent=take_profit or self.settings.get("default_take_profit", 100),
            stop_loss_percent=stop_loss or self.settings.get("default_stop_loss", 40),
            opened_at=timestamp_now(),
            current_price=token_price,
            current_value_usd=amount_usd
        )

        # Deduct from balance
        self.balance_sol -= amount_sol
        self.positions[token_address] = position

        # Record trade
        trade = Trade(
            id=f"T{len(self.trades)+1:06d}",
            token_address=token_address,
            symbol=symbol,
            name=name,
            side="buy",
            amount=token_amount,
            price=token_price,
            total_usd=amount_usd,
            total_sol=amount_sol,
            reason="manual",
            timestamp=timestamp_now()
        )
        self.trades.append(trade)

        self._save()

        logger.info(f"📈 Position opened: {symbol} | ${amount_usd:.2f} | {token_amount:.2f} tokens")

        return True, f"Куплено {token_amount:.2f} {symbol}", position

    def close_position(
        self,
        token_address: str,
        current_price: float,
        sol_price: float,
        reason: str = "manual",
        percent: float = 100  # Can sell partial
    ) -> tuple[bool, str, float, float]:
        """
        Close a position.

        Args:
            token_address: Token to sell
            current_price: Current token price
            sol_price: Current SOL price
            reason: Why closing (manual, take_profit, stop_loss)
            percent: Percentage to sell (100 = full close)

        Returns:
            (success, message, pnl_usd, pnl_percent)
        """
        if token_address not in self.positions:
            return False, "Позиция не найдена", 0, 0

        position = self.positions[token_address]

        # Calculate sell amount
        sell_percent = min(100, max(0, percent)) / 100
        sell_amount = position.amount * sell_percent

        # Calculate value
        sell_value_usd = sell_amount * current_price
        sell_value_sol = sell_value_usd / sol_price

        # Calculate PnL
        invested_usd = position.investment_usd * sell_percent
        pnl_usd = sell_value_usd - invested_usd
        pnl_percent = ((sell_value_usd / invested_usd) - 1) * 100 if invested_usd > 0 else 0

        # Update balance
        self.balance_sol += sell_value_sol

        # Record trade
        trade = Trade(
            id=f"T{len(self.trades)+1:06d}",
            token_address=token_address,
            symbol=position.symbol,
            name=position.name,
            side="sell",
            amount=sell_amount,
            price=current_price,
            total_usd=sell_value_usd,
            total_sol=sell_value_sol,
            pnl_usd=pnl_usd,
            pnl_percent=pnl_percent,
            reason=reason,
            timestamp=timestamp_now()
        )
        self.trades.append(trade)

        # Update or remove position
        if sell_percent >= 1:
            position.status = "closed"
            del self.positions[token_address]
        else:
            position.amount -= sell_amount
            position.investment_usd -= invested_usd
            position.investment_sol -= (position.investment_sol * sell_percent)

        self._save()

        sign = "+" if pnl_usd >= 0 else ""
        logger.info(f"📉 Position closed: {position.symbol} | {sign}${pnl_usd:.2f} ({sign}{pnl_percent:.1f}%)")

        return True, f"Продано {sell_amount:.2f} {position.symbol}", pnl_usd, pnl_percent

    def update_position_prices(self, prices: dict[str, float], sol_price: float):
        """Update current prices for all positions."""
        for token_address, position in self.positions.items():
            if token_address in prices:
                current_price = prices[token_address]
                position.current_price = current_price
                position.current_value_usd = position.amount * current_price
                position.pnl_usd = position.current_value_usd - position.investment_usd
                position.pnl_percent = ((position.current_value_usd / position.investment_usd) - 1) * 100

        self._save()

    def check_tp_sl(self, sol_price: float) -> list[tuple[Position, str]]:
        """Check positions for take profit / stop loss triggers."""
        triggers = []

        for position in list(self.positions.values()):
            pnl_percent = position.pnl_percent

            if pnl_percent >= position.take_profit_percent:
                triggers.append((position, "take_profit"))
            elif pnl_percent <= -position.stop_loss_percent:
                triggers.append((position, "stop_loss"))

        return triggers

    def get_stats(self, sol_price: float = DEFAULT_SOL_PRICE_USD) -> dict:
        """Get wallet statistics."""
        # Calculate positions value
        positions_value_usd = sum(p.current_value_usd for p in self.positions.values())
        positions_invested_usd = sum(p.investment_usd for p in self.positions.values())
        positions_pnl = positions_value_usd - positions_invested_usd

        # Calculate closed trades PnL
        closed_pnl = sum(t.pnl_usd for t in self.trades if t.side == "sell")

        # Total portfolio value
        balance_usd = self.balance_sol * sol_price
        total_value_usd = balance_usd + positions_value_usd
        initial_value_usd = self.initial_balance_sol * sol_price

        total_pnl_usd = total_value_usd - initial_value_usd
        total_pnl_percent = ((total_value_usd / initial_value_usd) - 1) * 100 if initial_value_usd > 0 else 0

        # Win rate
        sell_trades = [t for t in self.trades if t.side == "sell"]
        winning_trades = [t for t in sell_trades if t.pnl_usd > 0]
        win_rate = (len(winning_trades) / len(sell_trades) * 100) if sell_trades else 0

        return {
            "balance_sol": self.balance_sol,
            "balance_usd": balance_usd,
            "positions_count": len(self.positions),
            "positions_value_usd": positions_value_usd,
            "positions_pnl_usd": positions_pnl,
            "total_value_usd": total_value_usd,
            "total_pnl_usd": total_pnl_usd,
            "total_pnl_percent": total_pnl_percent,
            "realized_pnl_usd": closed_pnl,
            "total_trades": len(self.trades),
            "win_rate": win_rate,
            "winning_trades": len(winning_trades),
            "losing_trades": len(sell_trades) - len(winning_trades)
        }

    def reset(self):
        """Reset wallet to initial state."""
        self.balance_sol = settings.initial_balance_sol
        self.initial_balance_sol = settings.initial_balance_sol
        self.positions = {}
        self.trades = []
        self._save()
        logger.info(f"Wallet reset for user {self.user_id}")


# Cache of wallet instances
_wallets: dict[int, PaperWallet] = {}


def get_wallet(user_id: int) -> PaperWallet:
    """Get or create wallet for user."""
    if user_id not in _wallets:
        _wallets[user_id] = PaperWallet(user_id)
    return _wallets[user_id]
