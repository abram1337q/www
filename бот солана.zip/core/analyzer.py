"""
Layer 2: AI Analyst (1-3 seconds)
Deep analysis using AI to evaluate token potential.
"""
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime

from integrations import helius, rugcheck, openrouter
from config.constants import AI_SCORE_AUTO_BUY, AI_SCORE_WATCH
from utils.logger import logger
from utils.helpers import timestamp_now


@dataclass
class AnalysisResult:
    """Result of Layer 2 AI analysis."""
    passed: bool
    token_address: str
    symbol: str
    name: str

    # AI Analysis
    ai_score: int
    risk_level: str
    recommendation: str  # buy, skip, watch
    confidence: int

    # Details
    technical_analysis: str
    security_analysis: str
    creator_analysis: str
    red_flags: list[str]
    green_flags: list[str]

    # Suggestions
    suggested_position_size: str
    take_profit: str
    stop_loss: str
    reasoning: str

    # Metadata
    model_used: str
    analyzed_at: str

    # Raw data for reference
    rugcheck_data: dict = field(default_factory=dict)
    creator_data: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "passed_layer2": self.passed,
            "token_address": self.token_address,
            "symbol": self.symbol,
            "name": self.name,
            "ai_score": self.ai_score,
            "risk_level": self.risk_level,
            "recommendation": self.recommendation,
            "confidence": self.confidence,
            "analysis": {
                "technical": self.technical_analysis,
                "security": self.security_analysis,
                "creator": self.creator_analysis,
                "red_flags": self.red_flags,
                "green_flags": self.green_flags
            },
            "suggested_action": {
                "position_size": self.suggested_position_size,
                "take_profit": self.take_profit,
                "stop_loss": self.stop_loss
            },
            "reasoning": self.reasoning,
            "model_used": self.model_used,
            "analyzed_at": self.analyzed_at
        }


class Layer2Analyzer:
    """
    AI-powered token analyzer.
    Performs deep analysis on tokens that pass Layer 1.
    """

    def __init__(self, auto_buy_threshold: int = AI_SCORE_AUTO_BUY):
        self.auto_buy_threshold = auto_buy_threshold

    async def analyze(
        self,
        token_address: str,
        rugcheck_data: dict,
        token_info: dict = None
    ) -> AnalysisResult:
        """
        Perform full AI analysis on a token.

        Args:
            token_address: Token mint address
            rugcheck_data: Data from Layer 1 / RugCheck
            token_info: Optional additional token info

        Returns:
            AnalysisResult with AI assessment
        """
        logger.info(f"🧠 Layer 2: Analyzing {rugcheck_data.get('symbol', token_address[:8])}")

        try:
            # Get creator history
            creator_address = rugcheck_data.get("creator", "")
            creator_data = {}

            if creator_address:
                creator_data = await helius.get_creator_history(creator_address)

                # Get previous tokens by creator (if available from rugcheck)
                prev_tokens = await rugcheck.get_creator_tokens(creator_address)
                creator_data["previous_tokens"] = len(prev_tokens)
                creator_data["previous_token_list"] = prev_tokens[:5]  # Last 5

            # Prepare token data for AI
            token_data = {
                "mint": token_address,
                "symbol": rugcheck_data.get("symbol", "???"),
                "name": rugcheck_data.get("name", "Unknown"),
                "liquidity_usd": rugcheck_data.get("liquidity_usd", 0),
            }

            # Call AI for analysis
            ai_result = await openrouter.analyze_token(
                token_data=token_data,
                rugcheck_data=rugcheck_data,
                creator_data=creator_data
            )

            # Parse AI result
            score = ai_result.get("score", 0)
            recommendation = ai_result.get("recommendation", "skip")

            # Determine if passed based on score threshold
            passed = score >= self.auto_buy_threshold and recommendation == "buy"

            analysis = ai_result.get("analysis", {})

            result = AnalysisResult(
                passed=passed,
                token_address=token_address,
                symbol=rugcheck_data.get("symbol", "???"),
                name=rugcheck_data.get("name", "Unknown"),
                ai_score=score,
                risk_level=ai_result.get("risk_level", "high"),
                recommendation=recommendation,
                confidence=ai_result.get("confidence", 0),
                technical_analysis=analysis.get("technical", ""),
                security_analysis=analysis.get("security", ""),
                creator_analysis=analysis.get("creator", ""),
                red_flags=analysis.get("red_flags", []),
                green_flags=analysis.get("green_flags", []),
                suggested_position_size=ai_result.get("suggested_position_size", "small"),
                take_profit=ai_result.get("take_profit_suggestion", "100%"),
                stop_loss=ai_result.get("stop_loss_suggestion", "-40%"),
                reasoning=ai_result.get("reasoning", ""),
                model_used=ai_result.get("model_used", "unknown"),
                analyzed_at=timestamp_now(),
                rugcheck_data=rugcheck_data,
                creator_data=creator_data
            )

            if passed:
                logger.info(f"✅ Layer 2 PASSED: {result.symbol} | Score: {score} | {recommendation.upper()}")
            else:
                logger.info(f"⏸️ Layer 2: {result.symbol} | Score: {score} | {recommendation.upper()}")

            return result

        except Exception as e:
            logger.error(f"Layer 2 analysis error: {e}")

            # Return failed result
            return AnalysisResult(
                passed=False,
                token_address=token_address,
                symbol=rugcheck_data.get("symbol", "???"),
                name=rugcheck_data.get("name", "Unknown"),
                ai_score=0,
                risk_level="critical",
                recommendation="skip",
                confidence=0,
                technical_analysis="Ошибка анализа",
                security_analysis="",
                creator_analysis="",
                red_flags=[f"Ошибка AI анализа: {str(e)}"],
                green_flags=[],
                suggested_position_size="small",
                take_profit="50%",
                stop_loss="-30%",
                reasoning="Анализ не выполнен из-за ошибки",
                model_used="none",
                analyzed_at=timestamp_now(),
                rugcheck_data=rugcheck_data,
                creator_data={}
            )

    def update_threshold(self, new_threshold: int):
        """Update auto-buy score threshold."""
        self.auto_buy_threshold = new_threshold
        logger.info(f"Auto-buy threshold updated to {new_threshold}")


# Default analyzer instance
layer2_analyzer = Layer2Analyzer()
