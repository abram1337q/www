"""
Token Monitor
Orchestrates the full pipeline: Monitor -> Filter -> Analyze -> Trade
"""
import asyncio
from typing import Callable, Optional
from dataclasses import dataclass

from core.filters import layer1_filter, FilterResult
from core.analyzer import layer2_analyzer, AnalysisResult
from core.trader import paper_trader, TradeResult
from core.wallet import get_wallet
from integrations import helius, rugcheck, openrouter
from config.constants import AI_SCORE_AUTO_BUY
from utils.logger import logger
from utils.helpers import timestamp_now


@dataclass
class TokenAlert:
    """Complete token alert with all analysis."""
    token_address: str
    symbol: str
    name: str

    # Layer 1
    filter_result: FilterResult

    # Layer 2
    analysis_result: Optional[AnalysisResult]

    # Trade result (if auto-mode)
    trade_result: Optional[TradeResult] = None

    # Metadata
    discovered_at: str = ""

    def should_buy(self, threshold: int = AI_SCORE_AUTO_BUY) -> bool:
        """Check if token should be bought based on analysis."""
        if not self.analysis_result:
            return False
        return (
            self.analysis_result.ai_score >= threshold and
            self.analysis_result.recommendation == "buy"
        )


class TokenMonitor:
    """
    Main monitor that watches for new tokens and processes them.
    """

    def __init__(self):
        self._running = False
        self._on_alert_callback: Optional[Callable] = None
        self._processed_tokens: set = set()
        self._active_users: set = set()

    async def start(self):
        """Initialize all integrations."""
        logger.info("🚀 Starting Token Monitor...")

        await helius.start()
        await rugcheck.start()
        await openrouter.start()

        logger.info("✅ All integrations initialized")

    async def stop(self):
        """Shutdown all integrations."""
        self._running = False

        await helius.close()
        await rugcheck.close()
        await openrouter.close()

        logger.info("🛑 Token Monitor stopped")

    def register_user(self, user_id: int):
        """Register user for monitoring."""
        self._active_users.add(user_id)
        logger.info(f"User {user_id} registered for monitoring")

    def unregister_user(self, user_id: int):
        """Unregister user from monitoring."""
        self._active_users.discard(user_id)
        logger.info(f"User {user_id} unregistered from monitoring")

    async def process_token(
        self,
        token_address: str,
        user_id: int = None,
        auto_buy: bool = False
    ) -> TokenAlert:
        """
        Process a single token through the full pipeline.

        Args:
            token_address: Token mint address to analyze
            user_id: User ID for trading (if auto_buy)
            auto_buy: Whether to auto-execute trades

        Returns:
            TokenAlert with complete analysis
        """
        logger.info(f"🔍 Processing token: {token_address[:12]}...")

        # Get RugCheck data
        rugcheck_data = await rugcheck.check_token(token_address)

        if "error" in rugcheck_data:
            logger.warning(f"RugCheck error for {token_address}: {rugcheck_data['error']}")
            # Create failed filter result
            filter_result = FilterResult(
                passed=False,
                token_address=token_address,
                symbol="???",
                name="Unknown",
                liquidity_usd=0,
                lp_burned=False,
                mint_disabled=False,
                freeze_disabled=False,
                top10_holders_percent=100,
                creator_wallet="",
                created_at=timestamp_now(),
                rejection_reasons=[f"RugCheck error: {rugcheck_data['error']}"]
            )
            return TokenAlert(
                token_address=token_address,
                symbol="???",
                name="Unknown",
                filter_result=filter_result,
                analysis_result=None,
                discovered_at=timestamp_now()
            )

        # Layer 1: Fast Filter
        filter_result = layer1_filter.apply(rugcheck_data, timestamp_now())

        alert = TokenAlert(
            token_address=token_address,
            symbol=filter_result.symbol,
            name=filter_result.name,
            filter_result=filter_result,
            analysis_result=None,
            discovered_at=timestamp_now()
        )

        if not filter_result.passed:
            logger.info(f"❌ Token {filter_result.symbol} rejected by Layer 1")
            return alert

        # Layer 2: AI Analysis
        analysis_result = await layer2_analyzer.analyze(
            token_address=token_address,
            rugcheck_data=rugcheck_data
        )
        alert.analysis_result = analysis_result

        # Layer 3: Auto-trade if enabled
        if auto_buy and user_id and alert.should_buy():
            wallet = get_wallet(user_id)

            if wallet.settings.get("auto_mode", False):
                trade_result = await paper_trader.execute_buy(
                    user_id=user_id,
                    analysis=analysis_result
                )
                alert.trade_result = trade_result
                logger.info(f"🤖 Auto-buy executed: {trade_result.message}")

        self._processed_tokens.add(token_address)
        return alert

    async def start_monitoring(
        self,
        on_alert: Callable[[TokenAlert], None],
        auto_buy_for_users: list[int] = None
    ):
        """
        Start real-time monitoring for new tokens.

        Args:
            on_alert: Callback when new token is found
            auto_buy_for_users: List of user IDs with auto-buy enabled
        """
        self._running = True
        self._on_alert_callback = on_alert
        auto_buy_users = set(auto_buy_for_users or [])

        logger.info("👁️ Starting real-time token monitoring...")

        async def on_new_pool(pool_data: dict):
            """Handle new pool detection."""
            token_address = pool_data.get("token_mint")

            if not token_address or token_address in self._processed_tokens:
                return

            logger.info(f"🆕 New token detected: {token_address[:12]}...")

            # Process for each active user
            for user_id in self._active_users:
                auto_buy = user_id in auto_buy_users

                try:
                    alert = await self.process_token(
                        token_address=token_address,
                        user_id=user_id,
                        auto_buy=auto_buy
                    )

                    # Send alert if passed filters or has analysis
                    if alert.filter_result.passed or alert.analysis_result:
                        await on_alert(user_id, alert)

                except Exception as e:
                    logger.error(f"Error processing token for user {user_id}: {e}")

        # Start WebSocket monitoring
        await helius.subscribe_new_pools(on_new_pool)

    def stop_monitoring(self):
        """Stop real-time monitoring."""
        self._running = False
        logger.info("👁️ Real-time monitoring stopped")


# Global monitor instance
token_monitor = TokenMonitor()
