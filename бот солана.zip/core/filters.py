"""
Layer 1: Fast Filters (< 50ms target)
Filters out 99% of obvious scams before AI analysis.
"""
from dataclasses import dataclass
from typing import Optional
from config.constants import (
    MIN_LIQUIDITY_USD,
    MAX_TOP10_HOLDERS_PERCENT,
    MAX_TOKEN_AGE_SECONDS
)
from utils.logger import logger
from utils.helpers import seconds_ago


@dataclass
class FilterResult:
    """Result of Layer 1 filtering."""
    passed: bool
    token_address: str
    symbol: str
    name: str
    liquidity_usd: float
    lp_burned: bool
    mint_disabled: bool
    freeze_disabled: bool
    top10_holders_percent: float
    creator_wallet: str
    created_at: str
    rejection_reasons: list[str]

    def to_dict(self) -> dict:
        return {
            "passed_layer1": self.passed,
            "token_address": self.token_address,
            "symbol": self.symbol,
            "name": self.name,
            "liquidity_usd": self.liquidity_usd,
            "lp_burned": self.lp_burned,
            "mint_disabled": self.mint_disabled,
            "freeze_disabled": self.freeze_disabled,
            "top10_holders_percent": self.top10_holders_percent,
            "creator_wallet": self.creator_wallet,
            "created_at": self.created_at,
            "rejection_reasons": self.rejection_reasons
        }


class Layer1Filter:
    """
    Fast filter for new tokens.
    Applies hard rules to quickly eliminate obvious scams.
    """

    def __init__(
        self,
        min_liquidity: float = MIN_LIQUIDITY_USD,
        max_top10_percent: float = MAX_TOP10_HOLDERS_PERCENT,
        require_lp_burned: bool = False,  # Отключено по умолчанию для мем-токенов
        require_mint_disabled: bool = True,
        require_freeze_disabled: bool = True,
        max_age_seconds: int = MAX_TOKEN_AGE_SECONDS
    ):
        self.min_liquidity = min_liquidity
        self.max_top10_percent = max_top10_percent
        self.require_lp_burned = require_lp_burned
        self.require_mint_disabled = require_mint_disabled
        self.require_freeze_disabled = require_freeze_disabled
        self.max_age_seconds = max_age_seconds

    def apply(self, rugcheck_data: dict, created_at: str = None) -> FilterResult:
        """
        Apply all filters to token data.

        Args:
            rugcheck_data: Data from RugCheck API
            created_at: ISO timestamp of token creation

        Returns:
            FilterResult with pass/fail status and details
        """
        rejection_reasons = []

        # Extract data
        liquidity = rugcheck_data.get("liquidity_usd", 0)
        lp_burned = rugcheck_data.get("lp_burned", False)
        mint_disabled = rugcheck_data.get("mint_disabled", False)
        freeze_disabled = rugcheck_data.get("freeze_disabled", False)
        top10_percent = rugcheck_data.get("top10_holders_percent", 100)

        # Apply filters

        # 1. Liquidity check (CRITICAL)
        if liquidity < self.min_liquidity:
            rejection_reasons.append(
                f"❌ Ликвидность ${liquidity:,.0f} < ${self.min_liquidity:,.0f}"
            )

        # 2. LP Burned check (CRITICAL)
        if self.require_lp_burned and not lp_burned:
            rejection_reasons.append("❌ LP не сожжена")

        # 3. Mint Authority check (CRITICAL)
        if self.require_mint_disabled and not mint_disabled:
            rejection_reasons.append("❌ Mint Authority активен (могут напечатать токены)")

        # 4. Freeze Authority check (CRITICAL)
        if self.require_freeze_disabled and not freeze_disabled:
            rejection_reasons.append("❌ Freeze Authority активен (могут заморозить)")

        # 5. Holder concentration check (IMPORTANT)
        if top10_percent > self.max_top10_percent:
            rejection_reasons.append(
                f"⚠️ Top 10 холдеров владеют {top10_percent:.1f}% > {self.max_top10_percent}%"
            )

        # 6. Token age check (OPTIONAL)
        if created_at:
            age_seconds = seconds_ago(created_at)
            if age_seconds > self.max_age_seconds:
                rejection_reasons.append(
                    f"⏰ Токен слишком старый ({age_seconds}s > {self.max_age_seconds}s)"
                )

        # Determine if passed
        # Critical filters must all pass
        critical_passed = (
            liquidity >= self.min_liquidity and
            (not self.require_lp_burned or lp_burned) and
            (not self.require_mint_disabled or mint_disabled) and
            (not self.require_freeze_disabled or freeze_disabled)
        )

        passed = critical_passed and top10_percent <= self.max_top10_percent

        result = FilterResult(
            passed=passed,
            token_address=rugcheck_data.get("mint", ""),
            symbol=rugcheck_data.get("symbol", "???"),
            name=rugcheck_data.get("name", "Unknown"),
            liquidity_usd=liquidity,
            lp_burned=lp_burned,
            mint_disabled=mint_disabled,
            freeze_disabled=freeze_disabled,
            top10_holders_percent=top10_percent,
            creator_wallet=rugcheck_data.get("creator", ""),
            created_at=created_at or "",
            rejection_reasons=rejection_reasons
        )

        if passed:
            logger.info(f"✅ Layer 1 PASSED: {result.symbol} ({result.token_address[:8]}...)")
        else:
            logger.info(f"❌ Layer 1 FAILED: {result.symbol} - {rejection_reasons}")

        return result

    def update_settings(self, **kwargs):
        """Update filter settings."""
        if "min_liquidity" in kwargs:
            self.min_liquidity = kwargs["min_liquidity"]
        if "max_top10_percent" in kwargs:
            self.max_top10_percent = kwargs["max_top10_percent"]
        if "require_lp_burned" in kwargs:
            self.require_lp_burned = kwargs["require_lp_burned"]
        if "require_mint_disabled" in kwargs:
            self.require_mint_disabled = kwargs["require_mint_disabled"]
        if "require_freeze_disabled" in kwargs:
            self.require_freeze_disabled = kwargs["require_freeze_disabled"]
        if "max_age_seconds" in kwargs:
            self.max_age_seconds = kwargs["max_age_seconds"]


# Default filter instance
layer1_filter = Layer1Filter()
