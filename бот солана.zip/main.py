"""
SolanaSniper Bot - Main Entry Point
Paper Trading Bot for Solana Token Sniping
"""
import asyncio
import sys
from pathlib import Path

# Ensure data directory exists
Path("data").mkdir(exist_ok=True)

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

from config.settings import settings
from bot.handlers import commands_router, callbacks_router
from bot.handlers.notifications import format_token_alert, format_tp_sl_notification
from bot.handlers.callbacks import store_pending_token
from core import token_monitor, paper_trader, get_wallet
from utils.logger import logger


async def send_token_alert(bot: Bot, user_id: int, alert):
    """Send token alert to user."""
    try:
        text, keyboard = format_token_alert(alert)

        # Store token data for buy actions
        token_prefix = alert.token_address[:16]
        store_pending_token(token_prefix, {
            "address": alert.token_address,
            "symbol": alert.filter_result.symbol,
            "name": alert.filter_result.name,
            "score": alert.analysis_result.ai_score if alert.analysis_result else 0,
            "rugcheck_data": alert.analysis_result.rugcheck_data if alert.analysis_result else {}
        })

        await bot.send_message(
            chat_id=user_id,
            text=text,
            reply_markup=keyboard,
            parse_mode=ParseMode.HTML
        )
        logger.info(f"Alert sent to user {user_id}: {alert.filter_result.symbol}")

    except Exception as e:
        logger.error(f"Failed to send alert to {user_id}: {e}")


async def send_tp_sl_notification(bot: Bot, user_id: int, position, trigger_type: str):
    """Send TP/SL trigger notification."""
    try:
        text = format_tp_sl_notification(
            position=position,
            trigger_type=trigger_type,
            pnl_usd=position.pnl_usd,
            pnl_percent=position.pnl_percent
        )

        await bot.send_message(
            chat_id=user_id,
            text=text,
            parse_mode=ParseMode.HTML
        )
        logger.info(f"TP/SL notification sent to {user_id}: {trigger_type}")

    except Exception as e:
        logger.error(f"Failed to send TP/SL notification to {user_id}: {e}")


async def start_background_tasks(bot: Bot, dp: Dispatcher):
    """Start background monitoring tasks."""

    async def on_alert(user_id: int, alert):
        """Handle new token alert."""
        await send_token_alert(bot, user_id, alert)

    async def on_tp_sl(user_id: int, position, trigger_type: str):
        """Handle TP/SL trigger."""
        await send_tp_sl_notification(bot, user_id, position, trigger_type)

    # Start real-time token monitoring via WebSocket
    logger.info("Starting real-time token monitoring...")
    asyncio.create_task(
        token_monitor.start_monitoring(
            on_alert=on_alert,
            auto_buy_for_users=[]  # No auto-buy by default
        )
    )

    # Start price monitor for TP/SL (will start when users register)
    async def start_price_monitor_when_users():
        """Wait for users to register, then start price monitor."""
        while True:
            await asyncio.sleep(30)  # Check every 30 seconds
            active_users = list(token_monitor._active_users)
            if active_users:
                await paper_trader.start_price_monitor(
                    user_ids=active_users,
                    on_tp_sl=on_tp_sl,
                    interval=10
                )
                logger.info("Price monitor started")
                break

    asyncio.create_task(start_price_monitor_when_users())


async def main():
    """Main entry point."""
    logger.info("=" * 50)
    logger.info("🚀 Starting SolanaSniper Bot")
    logger.info("=" * 50)

    # Validate settings
    try:
        if not settings.telegram_bot_token or settings.telegram_bot_token == "your_telegram_bot_token_here":
            logger.error("❌ TELEGRAM_BOT_TOKEN not configured!")
            logger.info("Please set TELEGRAM_BOT_TOKEN in .env file")
            sys.exit(1)

        if not settings.openrouter_api_key or settings.openrouter_api_key == "your_openrouter_api_key_here":
            logger.warning("⚠️ OPENROUTER_API_KEY not configured - AI analysis will be limited")

        if not settings.helius_api_key or settings.helius_api_key == "your_helius_api_key_here":
            logger.warning("⚠️ HELIUS_API_KEY not configured - some features will be limited")

    except Exception as e:
        logger.error(f"Configuration error: {e}")
        logger.info("Copy .env.example to .env and fill in your API keys")
        sys.exit(1)

    # Initialize bot
    bot = Bot(
        token=settings.telegram_bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )

    dp = Dispatcher()

    # Register routers
    dp.include_router(commands_router)
    dp.include_router(callbacks_router)

    # Initialize integrations
    logger.info("📡 Initializing integrations...")
    await token_monitor.start()

    # Start background tasks
    await start_background_tasks(bot, dp)

    logger.info("✅ Bot initialized successfully")
    logger.info("=" * 50)
    logger.info("📱 Bot is running! Press Ctrl+C to stop.")
    logger.info("=" * 50)

    try:
        # Start polling
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        # Cleanup
        logger.info("🛑 Shutting down...")
        await token_monitor.stop()
        await bot.session.close()
        logger.info("👋 Bot stopped")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)
