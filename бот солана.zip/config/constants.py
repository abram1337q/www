# Raydium AMM Program ID
RAYDIUM_AMM_PROGRAM = "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8"

# Orca Whirlpool Program ID
ORCA_WHIRLPOOL_PROGRAM = "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc"

# Meteora DLMM Program ID
METEORA_DLMM_PROGRAM = "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo"

# Jupiter Aggregator
JUPITER_V6_PROGRAM = "JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4"

# Token Programs
TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
TOKEN_2022_PROGRAM = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"

# Native SOL
NATIVE_SOL_MINT = "So11111111111111111111111111111111111111112"

# Minimum liquidity for Layer 1 filter (USD)
MIN_LIQUIDITY_USD = 10000

# Maximum top 10 holders percentage
MAX_TOP10_HOLDERS_PERCENT = 20

# Maximum token age in seconds for sniping
MAX_TOKEN_AGE_SECONDS = 300  # 5 minutes

# AI Score thresholds
AI_SCORE_AUTO_BUY = 75
AI_SCORE_WATCH = 50

# Price update interval (seconds)
PRICE_UPDATE_INTERVAL = 5

# SOL price (will be updated dynamically)
DEFAULT_SOL_PRICE_USD = 100.0
