from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional


class Settings(BaseSettings):
    # Telegram
    telegram_bot_token: str = Field(..., env="TELEGRAM_BOT_TOKEN")

    # Helius
    helius_api_key: str = Field(..., env="HELIUS_API_KEY")
    helius_rpc_url: str = Field(
        default="https://mainnet.helius-rpc.com/?api-key=",
        env="HELIUS_RPC_URL"
    )

    # OpenRouter
    openrouter_api_key: str = Field(..., env="OPENROUTER_API_KEY")

    # Trading
    initial_balance_sol: float = Field(default=10.0, env="INITIAL_BALANCE_SOL")
    default_position_size_usd: float = Field(default=50.0, env="DEFAULT_POSITION_SIZE_USD")
    max_positions: int = Field(default=5, env="MAX_POSITIONS")
    default_slippage: float = Field(default=15.0, env="DEFAULT_SLIPPAGE")
    default_take_profit: float = Field(default=100.0, env="DEFAULT_TAKE_PROFIT")
    default_stop_loss: float = Field(default=40.0, env="DEFAULT_STOP_LOSS")

    # AI
    ai_model: str = Field(
        default="deepseek/deepseek-chat-v3-0324",
        env="AI_MODEL"
    )
    ai_fallback_model: str = Field(
        default="openai/gpt-4o-mini",
        env="AI_FALLBACK_MODEL"
    )

    @property
    def helius_full_url(self) -> str:
        return f"{self.helius_rpc_url}{self.helius_api_key}"

    @property
    def helius_ws_url(self) -> str:
        return f"wss://mainnet.helius-rpc.com/?api-key={self.helius_api_key}"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
