import logging
import sys
import io
from datetime import datetime


class SafeStreamHandler(logging.StreamHandler):
    """Custom handler that safely encodes messages for Windows console."""

    def emit(self, record):
        try:
            msg = self.format(record)
            # Try to write normally first
            try:
                self.stream.write(msg + self.terminator)
                self.stream.flush()
            except UnicodeEncodeError:
                # Replace emojis and special characters with ASCII alternatives
                safe_msg = msg.encode('ascii', 'replace').decode('ascii')
                self.stream.write(safe_msg + self.terminator)
                self.stream.flush()
        except Exception:
            self.handleError(record)


def setup_logger(name: str = "sniper") -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    # Avoid adding duplicate handlers
    if logger.handlers:
        return logger

    # Console handler with safe encoding
    console_handler = SafeStreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)

    # File handler with UTF-8 encoding
    file_handler = logging.FileHandler(
        f"data/logs_{datetime.now().strftime('%Y%m%d')}.log",
        encoding='utf-8'
    )
    file_handler.setLevel(logging.DEBUG)

    # Formatter
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger


logger = setup_logger()
