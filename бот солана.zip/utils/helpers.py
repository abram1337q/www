import json
import os
from datetime import datetime
from typing import Any, Optional
from pathlib import Path


DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)


def load_json(filename: str) -> dict:
    """Load JSON file from data directory."""
    filepath = DATA_DIR / filename
    if filepath.exists():
        with open(filepath, "r") as f:
            return json.load(f)
    return {}


def save_json(filename: str, data: dict) -> None:
    """Save data to JSON file in data directory."""
    filepath = DATA_DIR / filename
    with open(filepath, "w") as f:
        json.dump(data, f, indent=2, default=str)


def format_number(num: float, decimals: int = 2) -> str:
    """Format number with K/M/B suffix."""
    if num >= 1_000_000_000:
        return f"{num/1_000_000_000:.{decimals}f}B"
    if num >= 1_000_000:
        return f"{num/1_000_000:.{decimals}f}M"
    if num >= 1_000:
        return f"{num/1_000:.{decimals}f}K"
    return f"{num:.{decimals}f}"


def format_price(price: float) -> str:
    """Format crypto price with appropriate decimals."""
    if price >= 1:
        return f"${price:.2f}"
    if price >= 0.01:
        return f"${price:.4f}"
    if price >= 0.0001:
        return f"${price:.6f}"
    return f"${price:.10f}"


def format_percent(value: float) -> str:
    """Format percentage."""
    sign = "+" if value > 0 else ""
    return f"{sign}{value:.1f}%"


def shorten_address(address: str, chars: int = 4) -> str:
    """Shorten Solana address for display."""
    if len(address) <= chars * 2 + 3:
        return address
    return f"{address[:chars]}...{address[-chars:]}"


def timestamp_now() -> str:
    """Get current timestamp as ISO string."""
    return datetime.utcnow().isoformat() + "Z"


def seconds_ago(iso_timestamp: str) -> int:
    """Calculate seconds since timestamp."""
    try:
        dt = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
        return int((datetime.now(dt.tzinfo) - dt).total_seconds())
    except:
        return 0
