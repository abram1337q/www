"""
Inline keyboards for Telegram bot.
"""
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def main_menu_keyboard() -> InlineKeyboardMarkup:
    """Main menu keyboard."""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(text="💰 Кошелёк", callback_data="wallet"),
        InlineKeyboardButton(text="📊 Позиции", callback_data="positions")
    )
    builder.row(
        InlineKeyboardButton(text="📈 Статистика", callback_data="stats"),
        InlineKeyboardButton(text="📜 История", callback_data="history")
    )
    builder.row(
        InlineKeyboardButton(text="⚙️ Настройки", callback_data="settings"),
        InlineKeyboardButton(text="ℹ️ Помощь", callback_data="help")
    )

    return builder.as_markup()


def wallet_keyboard() -> InlineKeyboardMarkup:
    """Wallet management keyboard."""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(text="🔄 Обновить", callback_data="wallet_refresh"),
        InlineKeyboardButton(text="🔄 Сбросить", callback_data="wallet_reset")
    )
    builder.row(
        InlineKeyboardButton(text="◀️ Назад", callback_data="menu")
    )

    return builder.as_markup()


def positions_keyboard(positions: dict) -> InlineKeyboardMarkup:
    """Positions list keyboard."""
    builder = InlineKeyboardBuilder()

    for token_address, position in list(positions.items())[:5]:
        btn_text = f"{position.symbol} | {position.pnl_percent:+.1f}%"
        builder.row(
            InlineKeyboardButton(
                text=btn_text,
                callback_data=f"pos_{token_address[:16]}"
            )
        )

    builder.row(
        InlineKeyboardButton(text="🔄 Обновить", callback_data="positions"),
        InlineKeyboardButton(text="◀️ Назад", callback_data="menu")
    )

    return builder.as_markup()


def position_detail_keyboard(token_address: str) -> InlineKeyboardMarkup:
    """Single position detail keyboard."""
    builder = InlineKeyboardBuilder()

    short_addr = token_address[:16]

    builder.row(
        InlineKeyboardButton(text="💰 Продать 25%", callback_data=f"sell_25_{short_addr}"),
        InlineKeyboardButton(text="💰 Продать 50%", callback_data=f"sell_50_{short_addr}")
    )
    builder.row(
        InlineKeyboardButton(text="💰 Продать 100%", callback_data=f"sell_100_{short_addr}")
    )
    builder.row(
        InlineKeyboardButton(text="◀️ К позициям", callback_data="positions")
    )

    return builder.as_markup()


def settings_keyboard(settings: dict) -> InlineKeyboardMarkup:
    """Settings keyboard."""
    builder = InlineKeyboardBuilder()

    auto_mode = settings.get("auto_mode", False)
    auto_text = "🟢 Auto: ВКЛ" if auto_mode else "🔴 Auto: ВЫКЛ"

    builder.row(
        InlineKeyboardButton(text=auto_text, callback_data="toggle_auto")
    )
    builder.row(
        InlineKeyboardButton(text="💵 Размер позиции", callback_data="set_position_size"),
        InlineKeyboardButton(text="📊 Max позиций", callback_data="set_max_positions")
    )
    builder.row(
        InlineKeyboardButton(text="🎯 Take Profit", callback_data="set_tp"),
        InlineKeyboardButton(text="🛑 Stop Loss", callback_data="set_sl")
    )
    builder.row(
        InlineKeyboardButton(text="◀️ Назад", callback_data="menu")
    )

    return builder.as_markup()


def position_size_keyboard() -> InlineKeyboardMarkup:
    """Position size selection keyboard."""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(text="$25", callback_data="size_25"),
        InlineKeyboardButton(text="$50", callback_data="size_50"),
        InlineKeyboardButton(text="$100", callback_data="size_100")
    )
    builder.row(
        InlineKeyboardButton(text="$200", callback_data="size_200"),
        InlineKeyboardButton(text="$500", callback_data="size_500")
    )
    builder.row(
        InlineKeyboardButton(text="◀️ Назад", callback_data="settings")
    )

    return builder.as_markup()


def tp_sl_keyboard(param: str) -> InlineKeyboardMarkup:
    """Take profit / Stop loss selection keyboard."""
    builder = InlineKeyboardBuilder()

    if param == "tp":
        values = [50, 100, 150, 200, 300]
        prefix = "tp"
    else:
        values = [20, 30, 40, 50, 70]
        prefix = "sl"

    row = []
    for val in values:
        text = f"+{val}%" if param == "tp" else f"-{val}%"
        row.append(InlineKeyboardButton(text=text, callback_data=f"{prefix}_{val}"))

    builder.row(*row[:3])
    builder.row(*row[3:])
    builder.row(
        InlineKeyboardButton(text="◀️ Назад", callback_data="settings")
    )

    return builder.as_markup()


def alert_keyboard(token_address: str, passed_layer2: bool = False) -> InlineKeyboardMarkup:
    """New token alert keyboard."""
    builder = InlineKeyboardBuilder()

    short_addr = token_address[:16]

    if passed_layer2:
        builder.row(
            InlineKeyboardButton(text="🟢 Buy $25", callback_data=f"buy_25_{short_addr}"),
            InlineKeyboardButton(text="🟢 Buy $50", callback_data=f"buy_50_{short_addr}"),
            InlineKeyboardButton(text="🟢 Buy $100", callback_data=f"buy_100_{short_addr}")
        )

    builder.row(
        InlineKeyboardButton(text="⏭ Skip", callback_data=f"skip_{short_addr}"),
        InlineKeyboardButton(text="👁 Watch", callback_data=f"watch_{short_addr}"),
        InlineKeyboardButton(text="🔍 Details", callback_data=f"details_{short_addr}")
    )

    return builder.as_markup()


def trade_result_keyboard(token_address: str) -> InlineKeyboardMarkup:
    """Trade result keyboard."""
    builder = InlineKeyboardBuilder()

    short_addr = token_address[:16]

    builder.row(
        InlineKeyboardButton(text="📊 Позиция", callback_data=f"pos_{short_addr}"),
        InlineKeyboardButton(text="💰 Продать 50%", callback_data=f"sell_50_{short_addr}")
    )
    builder.row(
        InlineKeyboardButton(text="🔴 Закрыть", callback_data=f"sell_100_{short_addr}")
    )

    return builder.as_markup()


def confirm_keyboard(action: str, data: str = "") -> InlineKeyboardMarkup:
    """Confirmation keyboard."""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(text="✅ Да", callback_data=f"confirm_{action}_{data}"),
        InlineKeyboardButton(text="❌ Нет", callback_data="cancel")
    )

    return builder.as_markup()


def history_keyboard(page: int = 0, total_pages: int = 1) -> InlineKeyboardMarkup:
    """Trade history pagination keyboard."""
    builder = InlineKeyboardBuilder()

    nav_buttons = []
    if page > 0:
        nav_buttons.append(
            InlineKeyboardButton(text="◀️", callback_data=f"history_{page-1}")
        )
    nav_buttons.append(
        InlineKeyboardButton(text=f"{page+1}/{total_pages}", callback_data="noop")
    )
    if page < total_pages - 1:
        nav_buttons.append(
            InlineKeyboardButton(text="▶️", callback_data=f"history_{page+1}")
        )

    builder.row(*nav_buttons)
    builder.row(
        InlineKeyboardButton(text="◀️ Назад", callback_data="menu")
    )

    return builder.as_markup()
