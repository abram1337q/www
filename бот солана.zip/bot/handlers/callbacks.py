"""
Callback handlers for inline buttons.
"""
from aiogram import Router, F
from aiogram.types import CallbackQuery

from core import get_wallet, paper_trader, token_monitor, layer2_analyzer
from integrations import helius
from bot.keyboards import (
    main_menu_keyboard,
    wallet_keyboard,
    positions_keyboard,
    position_detail_keyboard,
    settings_keyboard,
    position_size_keyboard,
    tp_sl_keyboard,
    history_keyboard,
    confirm_keyboard
)
from bot.handlers.notifications import format_trade_notification
from utils.helpers import format_number, format_percent, shorten_address
from config.constants import DEFAULT_SOL_PRICE_USD

router = Router()


# Store pending token data for buy actions
_pending_tokens: dict = {}


@router.callback_query(F.data == "menu")
async def cb_menu(callback: CallbackQuery):
    """Return to main menu."""
    await callback.message.edit_text(
        "🏠 <b>Главное меню</b>\n\nВыберите действие:",
        reply_markup=main_menu_keyboard(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "wallet")
@router.callback_query(F.data == "wallet_refresh")
async def cb_wallet(callback: CallbackQuery):
    """Show wallet."""
    wallet = get_wallet(callback.from_user.id)
    sol_price = helius.sol_price_usd or DEFAULT_SOL_PRICE_USD
    stats = wallet.get_stats(sol_price)

    pnl_emoji = "📈" if stats["total_pnl_usd"] >= 0 else "📉"

    text = f"""
💰 <b>Кошелёк</b>

<b>Баланс:</b>
├ {wallet.balance_sol:.4f} SOL
└ ${stats['balance_usd']:.2f}

<b>В позициях:</b>
├ {stats['positions_count']} позиций
├ ${stats['positions_value_usd']:.2f} стоимость
└ ${stats['positions_pnl_usd']:+.2f} unrealized P&L

<b>Общий портфель:</b>
├ ${stats['total_value_usd']:.2f}
└ {pnl_emoji} {format_percent(stats['total_pnl_percent'])} (${stats['total_pnl_usd']:+.2f})

<b>💱 SOL/USD:</b> ${sol_price:.2f}
"""

    await callback.message.edit_text(
        text,
        reply_markup=wallet_keyboard(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "wallet_reset")
async def cb_wallet_reset_confirm(callback: CallbackQuery):
    """Confirm wallet reset."""
    await callback.message.edit_text(
        "⚠️ <b>Сбросить кошелёк?</b>\n\n"
        "Все позиции будут закрыты, история очищена.\n"
        "Баланс вернётся к начальному.",
        reply_markup=confirm_keyboard("reset_wallet"),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "confirm_reset_wallet_")
async def cb_wallet_reset(callback: CallbackQuery):
    """Reset wallet."""
    wallet = get_wallet(callback.from_user.id)
    wallet.reset()

    await callback.message.edit_text(
        "✅ Кошелёк сброшен!\n\n"
        f"Баланс: {wallet.balance_sol} SOL",
        reply_markup=wallet_keyboard(),
        parse_mode="HTML"
    )
    await callback.answer("Кошелёк сброшен")


@router.callback_query(F.data == "cancel")
async def cb_cancel(callback: CallbackQuery):
    """Cancel action."""
    await callback.message.edit_text(
        "❌ Отменено",
        reply_markup=main_menu_keyboard()
    )
    await callback.answer()


@router.callback_query(F.data == "positions")
async def cb_positions(callback: CallbackQuery):
    """Show positions."""
    wallet = get_wallet(callback.from_user.id)

    if not wallet.positions:
        await callback.message.edit_text(
            "📊 <b>Позиции</b>\n\nУ вас нет открытых позиций.",
            reply_markup=main_menu_keyboard(),
            parse_mode="HTML"
        )
        await callback.answer()
        return

    text = "📊 <b>Открытые позиции</b>\n\n"

    for position in wallet.positions.values():
        pnl_emoji = "🟢" if position.pnl_percent >= 0 else "🔴"

        text += f"""<b>{position.symbol}</b> | {pnl_emoji} {position.pnl_percent:+.1f}%
├ Вложено: ${position.investment_usd:.2f}
├ Текущая: ${position.current_value_usd:.2f}
└ P&L: ${position.pnl_usd:+.2f}

"""

    await callback.message.edit_text(
        text,
        reply_markup=positions_keyboard(wallet.positions),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("pos_"))
async def cb_position_detail(callback: CallbackQuery):
    """Show position details."""
    token_prefix = callback.data.replace("pos_", "")
    wallet = get_wallet(callback.from_user.id)

    # Find position by prefix
    position = None
    full_address = None
    for addr, pos in wallet.positions.items():
        if addr.startswith(token_prefix):
            position = pos
            full_address = addr
            break

    if not position:
        await callback.answer("Позиция не найдена", show_alert=True)
        return

    pnl_emoji = "📈" if position.pnl_percent >= 0 else "📉"

    text = f"""
📊 <b>Позиция: {position.symbol}</b>

📛 {position.name}
📍 <code>{full_address}</code>

<b>Детали:</b>
├ Токенов: {format_number(position.amount)}
├ Цена входа: ${position.entry_price:.10f}
├ Текущая цена: ${position.current_price:.10f}
├ Вложено: ${position.investment_usd:.2f}
├ Текущая стоимость: ${position.current_value_usd:.2f}
└ {pnl_emoji} P&L: ${position.pnl_usd:+.2f} ({position.pnl_percent:+.1f}%)

<b>Настройки:</b>
├ Take Profit: +{position.take_profit_percent}%
└ Stop Loss: -{position.stop_loss_percent}%

<b>Открыта:</b> {position.opened_at[:16]}
"""

    await callback.message.edit_text(
        text,
        reply_markup=position_detail_keyboard(full_address),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sell_"))
async def cb_sell(callback: CallbackQuery):
    """Sell position."""
    parts = callback.data.split("_")
    percent = int(parts[1])
    token_prefix = parts[2]

    wallet = get_wallet(callback.from_user.id)

    # Find full address
    full_address = None
    for addr in wallet.positions:
        if addr.startswith(token_prefix):
            full_address = addr
            break

    if not full_address:
        await callback.answer("Позиция не найдена", show_alert=True)
        return

    result = await paper_trader.execute_sell(
        user_id=callback.from_user.id,
        token_address=full_address,
        percent=percent,
        reason="manual"
    )

    if result.success:
        position = wallet.positions.get(full_address)
        symbol = position.symbol if position else "TOKEN"

        pnl_emoji = "📈" if result.pnl_usd >= 0 else "📉"

        await callback.message.edit_text(
            f"{'🟢' if result.pnl_usd >= 0 else '🔴'} <b>Продано {percent}% {symbol}</b>\n\n"
            f"{pnl_emoji} P&L: ${result.pnl_usd:+.2f} ({result.pnl_percent:+.1f}%)",
            reply_markup=main_menu_keyboard(),
            parse_mode="HTML"
        )
        await callback.answer(f"Продано! P&L: ${result.pnl_usd:+.2f}")
    else:
        await callback.answer(f"Ошибка: {result.message}", show_alert=True)


@router.callback_query(F.data == "stats")
async def cb_stats(callback: CallbackQuery):
    """Show statistics."""
    wallet = get_wallet(callback.from_user.id)
    sol_price = helius.sol_price_usd or DEFAULT_SOL_PRICE_USD
    stats = wallet.get_stats(sol_price)

    pnl_emoji = "📈" if stats["total_pnl_usd"] >= 0 else "📉"

    text = f"""
📈 <b>Статистика</b>

<b>Общий P&L:</b>
├ {pnl_emoji} ${stats['total_pnl_usd']:+.2f}
└ {format_percent(stats['total_pnl_percent'])}

<b>Реализованный P&L:</b>
└ ${stats['realized_pnl_usd']:+.2f}

<b>Сделки:</b>
├ Всего: {stats['total_trades']}
├ Прибыльных: {stats['winning_trades']}
├ Убыточных: {stats['losing_trades']}
└ Win Rate: {stats['win_rate']:.1f}%

<b>Портфель:</b>
├ Начальный: ${wallet.initial_balance_sol * sol_price:.2f}
└ Текущий: ${stats['total_value_usd']:.2f}
"""

    await callback.message.edit_text(
        text,
        reply_markup=main_menu_keyboard(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "settings")
async def cb_settings(callback: CallbackQuery):
    """Show settings."""
    wallet = get_wallet(callback.from_user.id)
    s = wallet.settings

    auto_status = "🟢 ВКЛ" if s.get("auto_mode") else "🔴 ВЫКЛ"

    text = f"""
⚙️ <b>Настройки</b>

<b>Режим:</b> {auto_status}

<b>Торговые параметры:</b>
├ Размер позиции: ${s.get('default_position_size_usd', 50)}
├ Max позиций: {s.get('max_positions', 5)}
├ Take Profit: +{s.get('default_take_profit', 100)}%
└ Stop Loss: -{s.get('default_stop_loss', 40)}%
"""

    await callback.message.edit_text(
        text,
        reply_markup=settings_keyboard(wallet.settings),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "toggle_auto")
async def cb_toggle_auto(callback: CallbackQuery):
    """Toggle auto mode."""
    wallet = get_wallet(callback.from_user.id)
    wallet.settings["auto_mode"] = not wallet.settings.get("auto_mode", False)
    wallet._save()

    status = "включен 🟢" if wallet.settings["auto_mode"] else "выключен 🔴"
    await callback.answer(f"Auto режим {status}")

    # Refresh settings
    await cb_settings(callback)


@router.callback_query(F.data == "set_position_size")
async def cb_set_position_size(callback: CallbackQuery):
    """Show position size options."""
    await callback.message.edit_text(
        "💵 <b>Размер позиции</b>\n\n"
        "Выберите размер по умолчанию:",
        reply_markup=position_size_keyboard(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("size_"))
async def cb_size_selected(callback: CallbackQuery):
    """Set position size."""
    size = int(callback.data.replace("size_", ""))
    wallet = get_wallet(callback.from_user.id)
    wallet.settings["default_position_size_usd"] = size
    wallet._save()

    await callback.answer(f"Размер позиции: ${size}")
    await cb_settings(callback)


@router.callback_query(F.data == "set_tp")
async def cb_set_tp(callback: CallbackQuery):
    """Show TP options."""
    await callback.message.edit_text(
        "🎯 <b>Take Profit</b>\n\n"
        "При каком росте продавать:",
        reply_markup=tp_sl_keyboard("tp"),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "set_sl")
async def cb_set_sl(callback: CallbackQuery):
    """Show SL options."""
    await callback.message.edit_text(
        "🛑 <b>Stop Loss</b>\n\n"
        "При каком падении продавать:",
        reply_markup=tp_sl_keyboard("sl"),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("tp_"))
async def cb_tp_selected(callback: CallbackQuery):
    """Set take profit."""
    tp = int(callback.data.replace("tp_", ""))
    wallet = get_wallet(callback.from_user.id)
    wallet.settings["default_take_profit"] = tp
    wallet._save()

    await callback.answer(f"Take Profit: +{tp}%")
    await cb_settings(callback)


@router.callback_query(F.data.startswith("sl_"))
async def cb_sl_selected(callback: CallbackQuery):
    """Set stop loss."""
    sl = int(callback.data.replace("sl_", ""))
    wallet = get_wallet(callback.from_user.id)
    wallet.settings["default_stop_loss"] = sl
    wallet._save()

    await callback.answer(f"Stop Loss: -{sl}%")
    await cb_settings(callback)


@router.callback_query(F.data.startswith("buy_"))
async def cb_buy(callback: CallbackQuery):
    """Buy token from alert."""
    parts = callback.data.split("_")
    amount = int(parts[1])
    token_prefix = parts[2]

    # Get token data from pending
    if token_prefix not in _pending_tokens:
        await callback.answer("Токен устарел. Используйте /analyze", show_alert=True)
        return

    token_data = _pending_tokens[token_prefix]

    # Create minimal analysis for trade
    from core import AnalysisResult
    from utils.helpers import timestamp_now

    analysis = AnalysisResult(
        passed=True,
        token_address=token_data["address"],
        symbol=token_data["symbol"],
        name=token_data["name"],
        ai_score=token_data.get("score", 75),
        risk_level="medium",
        recommendation="buy",
        confidence=80,
        technical_analysis="",
        security_analysis="",
        creator_analysis="",
        red_flags=[],
        green_flags=[],
        suggested_position_size="medium",
        take_profit="100%",
        stop_loss="-40%",
        reasoning="Manual buy",
        model_used="manual",
        analyzed_at=timestamp_now(),
        rugcheck_data=token_data.get("rugcheck_data", {})
    )

    result = await paper_trader.execute_buy(
        user_id=callback.from_user.id,
        analysis=analysis,
        amount_usd=amount
    )

    if result.success:
        await callback.message.edit_text(
            f"✅ <b>Куплено ${amount} {token_data['symbol']}</b>\n\n"
            f"{result.message}",
            parse_mode="HTML"
        )
        await callback.answer(f"Куплено за ${amount}!")
    else:
        await callback.answer(f"Ошибка: {result.message}", show_alert=True)


@router.callback_query(F.data.startswith("skip_"))
async def cb_skip(callback: CallbackQuery):
    """Skip token."""
    token_prefix = callback.data.replace("skip_", "")
    _pending_tokens.pop(token_prefix, None)

    await callback.message.edit_text(
        "⏭ Токен пропущен",
        reply_markup=main_menu_keyboard()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("watch_"))
async def cb_watch(callback: CallbackQuery):
    """Add token to watchlist."""
    await callback.answer("👁 Функция в разработке")


@router.callback_query(F.data.startswith("details_"))
async def cb_details(callback: CallbackQuery):
    """Show token details."""
    token_prefix = callback.data.replace("details_", "")

    if token_prefix not in _pending_tokens:
        await callback.answer("Токен устарел", show_alert=True)
        return

    data = _pending_tokens[token_prefix]
    rugcheck = data.get("rugcheck_data", {})

    text = f"""
🔍 <b>Детали: {data['symbol']}</b>

📍 <code>{data['address']}</code>

<b>RugCheck анализ:</b>
├ Risk Score: {rugcheck.get('risk_score', 'N/A')}/100
├ Risk Level: {rugcheck.get('risk_level', 'N/A')}
└ Создатель: {shorten_address(rugcheck.get('creator', 'N/A'))}

<b>Top 10 холдеров:</b>
"""

    for i, holder in enumerate(rugcheck.get("top_holders", [])[:5], 1):
        text += f"  {i}. {shorten_address(holder.get('address', ''))} — {holder.get('percent', 0):.1f}%\n"

    text += f"""
<b>Рынки:</b>
"""
    for market in rugcheck.get("markets", [])[:3]:
        text += f"  • {market.get('name', 'Unknown')}: ${format_number(market.get('liquidity_usd', 0))}\n"

    await callback.message.edit_text(text, parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "history")
@router.callback_query(F.data.startswith("history_"))
async def cb_history(callback: CallbackQuery):
    """Show trade history."""
    wallet = get_wallet(callback.from_user.id)

    if not wallet.trades:
        await callback.message.edit_text(
            "📜 <b>История</b>\n\nНет сделок.",
            reply_markup=main_menu_keyboard(),
            parse_mode="HTML"
        )
        await callback.answer()
        return

    # Get page number
    if callback.data.startswith("history_"):
        page = int(callback.data.replace("history_", ""))
    else:
        page = 0

    page_size = 5
    total_pages = (len(wallet.trades) + page_size - 1) // page_size

    # Get trades for page
    trades = list(reversed(wallet.trades))
    start = page * page_size
    end = start + page_size
    page_trades = trades[start:end]

    text = "📜 <b>История сделок</b>\n\n"

    for trade in page_trades:
        side_emoji = "🟢" if trade.side == "buy" else "🔴"
        pnl_text = ""
        if trade.side == "sell":
            pnl_emoji = "📈" if trade.pnl_usd >= 0 else "📉"
            pnl_text = f"\n└ {pnl_emoji} ${trade.pnl_usd:+.2f} ({trade.pnl_percent:+.1f}%)"

        text += f"""{side_emoji} <b>{trade.side.upper()}</b> {trade.symbol}
├ {format_number(trade.amount)} токенов
├ ${trade.total_usd:.2f}{pnl_text}
└ {trade.timestamp[:16]}

"""

    await callback.message.edit_text(
        text,
        reply_markup=history_keyboard(page, total_pages),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "help")
async def cb_help(callback: CallbackQuery):
    """Show help."""
    text = """
ℹ️ <b>Помощь</b>

<b>SolanaSniper Bot</b> — paper trading на Solana.

<b>Режимы:</b>
• <b>Manual</b> — вы решаете о покупке
• <b>Auto</b> — бот покупает при score > 75

<b>Фильтры Layer 1:</b>
• Ликвидность > $10K
• LP сожжена
• Mint/Freeze отключены
• Top 10 холдеров < 20%

<b>ИИ Layer 2:</b>
• Анализ безопасности
• История создателя
• Рекомендация buy/skip

⚠️ Это симуляция без реальных денег!
"""

    await callback.message.edit_text(
        text,
        reply_markup=main_menu_keyboard(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "noop")
async def cb_noop(callback: CallbackQuery):
    """No operation."""
    await callback.answer()


def store_pending_token(token_prefix: str, data: dict):
    """Store token data for buy actions."""
    _pending_tokens[token_prefix] = data

    # Clean old entries (keep last 50)
    if len(_pending_tokens) > 50:
        keys = list(_pending_tokens.keys())
        for key in keys[:20]:
            _pending_tokens.pop(key, None)
