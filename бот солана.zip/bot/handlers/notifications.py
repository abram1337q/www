"""
Notification formatting for token alerts.
"""
from typing import Tuple
from aiogram.types import InlineKeyboardMarkup

from core import TokenAlert, Position
from bot.keyboards import alert_keyboard, trade_result_keyboard
from utils.helpers import format_number, format_price, shorten_address


def format_token_alert(alert: TokenAlert) -> Tuple[str, InlineKeyboardMarkup]:
    """
    Format token alert for Telegram message.

    Returns:
        (text, keyboard)
    """
    fr = alert.filter_result
    ar = alert.analysis_result

    # Header
    text = f"""
🔔 <b>НОВЫЙ ТОКЕН ОБНАРУЖЕН</b>

━━━━━━━━━━━━━━━━━━━━━━━━
📛 <b>${fr.symbol}</b> | {fr.name}
📍 <code>{fr.token_address}</code>
━━━━━━━━━━━━━━━━━━━━━━━━

📊 <b>ТЕХНИЧЕСКИЕ МЕТРИКИ</b>
├ Ликвидность: ${format_number(fr.liquidity_usd)}
├ LP Burned: {'✅' if fr.lp_burned else '❌'}
├ Mint: {'Отключён ✅' if fr.mint_disabled else 'Активен ❌'}
├ Freeze: {'Отключён ✅' if fr.freeze_disabled else 'Активен ❌'}
└ Top 10 Holders: {fr.top10_holders_percent:.1f}%
"""

    # Layer 1 rejection reasons
    if not fr.passed and fr.rejection_reasons:
        text += "\n⚠️ <b>ПРИЧИНЫ ОТКЛОНЕНИЯ:</b>\n"
        for reason in fr.rejection_reasons:
            text += f"└ {reason}\n"

    # AI Analysis (Layer 2)
    if ar:
        risk_emoji = {
            "low": "🟢",
            "medium": "🟡",
            "high": "🟠",
            "critical": "🔴"
        }.get(ar.risk_level, "⚪")

        rec_emoji = {
            "buy": "🟢 BUY",
            "watch": "👁 WATCH",
            "skip": "⏭ SKIP"
        }.get(ar.recommendation, "❓")

        text += f"""
🧠 <b>ИИ-АНАЛИЗ</b> ({ar.model_used.split('/')[-1]})
├ Score: <b>{ar.ai_score}/100</b>
├ Риск: {risk_emoji} {ar.risk_level.upper()}
├ Уверенность: {ar.confidence}%
"""

        # Green flags
        if ar.green_flags:
            text += "│\n"
            for flag in ar.green_flags[:3]:
                text += f"├ ✅ {flag}\n"

        # Red flags
        if ar.red_flags:
            text += "│\n"
            for flag in ar.red_flags[:3]:
                text += f"├ ⚠️ {flag}\n"

        text += f"""│
└ {ar.reasoning[:100]}{'...' if len(ar.reasoning) > 100 else ''}

📈 <b>РЕКОМЕНДАЦИЯ:</b> {rec_emoji}
├ Размер: ${{'small': '25', 'medium': '50', 'large': '100'}}.get(ar.suggested_position_size, '50')
├ Take Profit: {ar.take_profit}
└ Stop Loss: {ar.stop_loss}
"""

    text += "\n━━━━━━━━━━━━━━━━━━━━━━━━"

    # Trade result
    if alert.trade_result and alert.trade_result.success:
        tr = alert.trade_result
        text += f"""

✅ <b>ПОКУПКА ВЫПОЛНЕНА</b>
└ {tr.message}
"""

    passed_layer2 = ar and ar.passed if ar else False
    keyboard = alert_keyboard(alert.token_address, passed_layer2)

    return text, keyboard


def format_trade_notification(
    side: str,
    symbol: str,
    token_address: str,
    amount: float,
    total_usd: float,
    price: float,
    pnl_usd: float = 0,
    pnl_percent: float = 0,
    take_profit: float = 100,
    stop_loss: float = 40
) -> Tuple[str, InlineKeyboardMarkup]:
    """Format trade execution notification."""

    if side == "buy":
        text = f"""
✅ <b>ПОКУПКА ВЫПОЛНЕНА</b>

📛 <b>${symbol}</b>
💰 Куплено: {format_number(amount)} токенов
💵 Потрачено: ${total_usd:.2f}
📈 Цена входа: {format_price(price)}

🎯 <b>Цели:</b>
├ TP (+{take_profit}%): {format_price(price * (1 + take_profit/100))}
└ SL (-{stop_loss}%): {format_price(price * (1 - stop_loss/100))}
"""
    else:
        pnl_emoji = "📈" if pnl_usd >= 0 else "📉"
        text = f"""
{'🟢' if pnl_usd >= 0 else '🔴'} <b>ПРОДАЖА ВЫПОЛНЕНА</b>

📛 <b>${symbol}</b>
💰 Продано: {format_number(amount)} токенов
💵 Получено: ${total_usd:.2f}
📈 Цена продажи: {format_price(price)}

{pnl_emoji} <b>P&L:</b> ${pnl_usd:+.2f} ({pnl_percent:+.1f}%)
"""

    keyboard = trade_result_keyboard(token_address) if side == "buy" else None
    return text, keyboard


def format_tp_sl_notification(
    position: Position,
    trigger_type: str,
    pnl_usd: float,
    pnl_percent: float
) -> str:
    """Format TP/SL trigger notification."""

    if trigger_type == "take_profit":
        emoji = "🎯"
        title = "TAKE PROFIT"
    else:
        emoji = "🛑"
        title = "STOP LOSS"

    pnl_emoji = "📈" if pnl_usd >= 0 else "📉"

    return f"""
{emoji} <b>{title} СРАБОТАЛ</b>

📛 <b>${position.symbol}</b>
└ {position.name}

💰 Продано: {format_number(position.amount)} токенов
💵 Вложено: ${position.investment_usd:.2f}
💵 Получено: ${position.current_value_usd:.2f}

{pnl_emoji} <b>P&L:</b> ${pnl_usd:+.2f} ({pnl_percent:+.1f}%)
"""
