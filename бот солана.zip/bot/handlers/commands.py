"""
Command handlers for Telegram bot.
"""
from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command, CommandStart

from core import get_wallet, token_monitor
from integrations import helius
from bot.keyboards import (
    main_menu_keyboard,
    wallet_keyboard,
    positions_keyboard,
    settings_keyboard,
    history_keyboard
)
from utils.helpers import format_number, format_price, format_percent, shorten_address
from config.constants import DEFAULT_SOL_PRICE_USD

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    """Handle /start command."""
    user_id = message.from_user.id

    # Initialize wallet
    wallet = get_wallet(user_id)

    # Register for monitoring
    token_monitor.register_user(user_id)

    text = f"""
🚀 <b>SolanaSniper Bot</b>

Добро пожаловать! Это бот для paper trading на Solana.

<b>💰 Ваш виртуальный баланс:</b>
{wallet.balance_sol:.4f} SOL (~${wallet.get_balance_usd():.2f})

<b>📋 Режим работы:</b> {'🤖 Auto' if wallet.settings.get('auto_mode') else '👆 Manual'}

<b>Доступные команды:</b>
/wallet — Баланс и кошелёк
/positions — Открытые позиции
/stats — Статистика P&L
/history — История сделок
/settings — Настройки
/analyze &lt;адрес&gt; — Анализ токена
/pause — Приостановить мониторинг
/resume — Возобновить мониторинг

Выберите действие:
"""

    await message.answer(text, reply_markup=main_menu_keyboard(), parse_mode="HTML")


@router.message(Command("wallet"))
async def cmd_wallet(message: Message):
    """Handle /wallet command."""
    user_id = message.from_user.id
    wallet = get_wallet(user_id)

    sol_price = helius.sol_price_usd or DEFAULT_SOL_PRICE_USD
    stats = wallet.get_stats(sol_price)

    pnl_emoji = "📈" if stats["total_pnl_usd"] >= 0 else "📉"

    text = f"""
💰 <b>Кошелёк</b>

<b>Баланс:</b>
├ {wallet.balance_sol:.4f} SOL
└ ${stats['balance_usd']:.2f}

<b>В позициях:</b>
├ {stats['positions_count']} позиций
├ ${stats['positions_value_usd']:.2f} стоимость
└ {format_percent(stats['positions_pnl_usd'])} unrealized P&L

<b>Общий портфель:</b>
├ ${stats['total_value_usd']:.2f}
└ {pnl_emoji} {format_percent(stats['total_pnl_percent'])} ({format_number(stats['total_pnl_usd'], 2)} USD)

<b>💱 SOL/USD:</b> ${sol_price:.2f}
"""

    await message.answer(text, reply_markup=wallet_keyboard(), parse_mode="HTML")


@router.message(Command("positions"))
async def cmd_positions(message: Message):
    """Handle /positions command."""
    user_id = message.from_user.id
    wallet = get_wallet(user_id)

    if not wallet.positions:
        text = "📊 <b>Позиции</b>\n\nУ вас нет открытых позиций."
        await message.answer(text, reply_markup=main_menu_keyboard(), parse_mode="HTML")
        return

    text = "📊 <b>Открытые позиции</b>\n\n"

    for position in wallet.positions.values():
        pnl_emoji = "🟢" if position.pnl_percent >= 0 else "🔴"

        text += f"""<b>{position.symbol}</b> | {pnl_emoji} {position.pnl_percent:+.1f}%
├ Куплено: {format_number(position.amount)} токенов
├ Вложено: ${position.investment_usd:.2f}
├ Текущая стоимость: ${position.current_value_usd:.2f}
├ P&L: ${position.pnl_usd:+.2f}
├ TP: +{position.take_profit_percent}% | SL: -{position.stop_loss_percent}%
└ {shorten_address(position.token_address)}

"""

    await message.answer(
        text,
        reply_markup=positions_keyboard(wallet.positions),
        parse_mode="HTML"
    )


@router.message(Command("stats"))
async def cmd_stats(message: Message):
    """Handle /stats command."""
    user_id = message.from_user.id
    wallet = get_wallet(user_id)

    sol_price = helius.sol_price_usd or DEFAULT_SOL_PRICE_USD
    stats = wallet.get_stats(sol_price)

    pnl_emoji = "📈" if stats["total_pnl_usd"] >= 0 else "📉"

    text = f"""
📈 <b>Статистика</b>

<b>Общий P&L:</b>
├ {pnl_emoji} ${stats['total_pnl_usd']:+.2f}
└ {format_percent(stats['total_pnl_percent'])}

<b>Реализованный P&L:</b>
└ ${stats['realized_pnl_usd']:+.2f}

<b>Сделки:</b>
├ Всего: {stats['total_trades']}
├ Прибыльных: {stats['winning_trades']}
├ Убыточных: {stats['losing_trades']}
└ Win Rate: {stats['win_rate']:.1f}%

<b>Портфель:</b>
├ Начальный: ${wallet.initial_balance_sol * sol_price:.2f}
└ Текущий: ${stats['total_value_usd']:.2f}
"""

    await message.answer(text, reply_markup=main_menu_keyboard(), parse_mode="HTML")


@router.message(Command("history"))
async def cmd_history(message: Message):
    """Handle /history command."""
    user_id = message.from_user.id
    wallet = get_wallet(user_id)

    if not wallet.trades:
        text = "📜 <b>История</b>\n\nНет сделок."
        await message.answer(text, reply_markup=main_menu_keyboard(), parse_mode="HTML")
        return

    # Paginate (5 trades per page)
    page_size = 5
    total_pages = (len(wallet.trades) + page_size - 1) // page_size

    # Show last trades first
    trades = list(reversed(wallet.trades))[:page_size]

    text = "📜 <b>История сделок</b>\n\n"

    for trade in trades:
        side_emoji = "🟢" if trade.side == "buy" else "🔴"
        pnl_text = ""
        if trade.side == "sell":
            pnl_emoji = "📈" if trade.pnl_usd >= 0 else "📉"
            pnl_text = f"\n└ {pnl_emoji} ${trade.pnl_usd:+.2f} ({trade.pnl_percent:+.1f}%)"

        text += f"""{side_emoji} <b>{trade.side.upper()}</b> {trade.symbol}
├ {format_number(trade.amount)} токенов
├ ${trade.total_usd:.2f} ({trade.total_sol:.4f} SOL){pnl_text}
└ {trade.timestamp[:16]}

"""

    await message.answer(
        text,
        reply_markup=history_keyboard(0, total_pages),
        parse_mode="HTML"
    )


@router.message(Command("settings"))
async def cmd_settings(message: Message):
    """Handle /settings command."""
    user_id = message.from_user.id
    wallet = get_wallet(user_id)

    s = wallet.settings
    auto_status = "🟢 ВКЛ" if s.get("auto_mode") else "🔴 ВЫКЛ"

    text = f"""
⚙️ <b>Настройки</b>

<b>Режим:</b> {auto_status}

<b>Торговые параметры:</b>
├ Размер позиции: ${s.get('default_position_size_usd', 50)}
├ Max позиций: {s.get('max_positions', 5)}
├ Take Profit: +{s.get('default_take_profit', 100)}%
└ Stop Loss: -{s.get('default_stop_loss', 40)}%

Нажмите на кнопку для изменения:
"""

    await message.answer(
        text,
        reply_markup=settings_keyboard(wallet.settings),
        parse_mode="HTML"
    )


@router.message(Command("analyze"))
async def cmd_analyze(message: Message):
    """Handle /analyze <token_address> command."""
    user_id = message.from_user.id

    # Parse token address from message
    parts = message.text.split()
    if len(parts) < 2:
        await message.answer(
            "❌ Укажите адрес токена:\n<code>/analyze TokenAddressHere</code>",
            parse_mode="HTML"
        )
        return

    token_address = parts[1]

    if len(token_address) < 32:
        await message.answer("❌ Неверный адрес токена")
        return

    await message.answer("🔍 Анализирую токен...")

    from core import token_monitor

    alert = await token_monitor.process_token(token_address, user_id, auto_buy=False)

    # Format response
    from bot.handlers.notifications import format_token_alert
    text, keyboard = format_token_alert(alert)

    await message.answer(text, reply_markup=keyboard, parse_mode="HTML")


@router.message(Command("pause"))
async def cmd_pause(message: Message):
    """Handle /pause command."""
    user_id = message.from_user.id
    token_monitor.unregister_user(user_id)

    await message.answer(
        "⏸️ Мониторинг приостановлен.\n\nИспользуйте /resume для возобновления.",
        reply_markup=main_menu_keyboard()
    )


@router.message(Command("resume"))
async def cmd_resume(message: Message):
    """Handle /resume command."""
    user_id = message.from_user.id
    token_monitor.register_user(user_id)

    await message.answer(
        "▶️ Мониторинг возобновлён.\n\nВы будете получать уведомления о новых токенах.",
        reply_markup=main_menu_keyboard()
    )


@router.message(Command("help"))
async def cmd_help(message: Message):
    """Handle /help command."""
    text = """
ℹ️ <b>Помощь</b>

<b>SolanaSniper Bot</b> — бот для paper trading на Solana.

<b>🔍 Как это работает:</b>

1️⃣ <b>Layer 1</b> — Быстрая фильтрация
   Отсеивает 99% скам-токенов по:
   • Ликвидность > $10K
   • LP сожжена
   • Mint Authority отключён
   • Freeze Authority отключён
   • Top 10 холдеров < 20%

2️⃣ <b>Layer 2</b> — ИИ-анализ
   DeepSeek анализирует:
   • Безопасность токена
   • Историю создателя
   • Паттерны скама

3️⃣ <b>Layer 3</b> — Исполнение
   Paper trading:
   • Виртуальные покупки/продажи
   • Автоматический TP/SL

<b>📋 Режимы:</b>
• <b>Manual</b> — бот присылает алерт, вы решаете
• <b>Auto</b> — бот покупает автоматически при score > 75

<b>⚠️ Это симуляция!</b>
Реальные деньги не используются.

<b>🔗 Полезные ссылки:</b>
• Solscan: solscan.io
• RugCheck: rugcheck.xyz
• Jupiter: jup.ag
"""

    await message.answer(text, reply_markup=main_menu_keyboard(), parse_mode="HTML")
