import json
import aiohttp
from typing import Optional
from config.settings import settings
from utils.logger import logger


AI_SYSTEM_PROMPT = """Ты — эксперт-аналитик криптовалютных токенов на Solana.
Твоя задача — оценить потенциал нового токена и риск скама.

## Входные данные:
- Технические метрики токена (JSON)
- Данные RugCheck о безопасности
- История кошелька создателя

## Выходной формат (строго JSON, без markdown):

{
  "score": <число 0-100>,
  "risk_level": "<low|medium|high|critical>",
  "recommendation": "<buy|skip|watch>",
  "confidence": <число 0-100>,
  "analysis": {
    "technical": "<краткий анализ технических метрик>",
    "security": "<анализ безопасности токена>",
    "creator": "<анализ истории создателя>",
    "red_flags": ["<список красных флагов>"],
    "green_flags": ["<список зелёных флагов>"]
  },
  "suggested_position_size": "<small|medium|large>",
  "take_profit_suggestion": "<50%|100%|200%>",
  "stop_loss_suggestion": "<-30%|-40%|-50%>",
  "reasoning": "<краткое обоснование решения>"
}

## Критерии оценки:

### Score 80-100 (BUY):
- LP сожжена, mint отключён
- Создатель с чистой историей
- Органичный интерес
- Низкая концентрация у топ-холдеров (<20%)
- Достаточная ликвидность (>$10K)

### Score 50-79 (WATCH):
- Часть критериев не выполнена
- Недостаточно данных для уверенного решения

### Score 0-49 (SKIP):
- Признаки скама (mint enabled, freeze enabled)
- Плохая история создателя
- Высокая концентрация токенов
- Низкая ликвидность

ВАЖНО: Отвечай ТОЛЬКО валидным JSON без markdown-разметки и пояснений."""


class OpenRouterClient:
    """Client for OpenRouter AI API."""

    BASE_URL = "https://openrouter.ai/api/v1/chat/completions"

    def __init__(self):
        self.session: Optional[aiohttp.ClientSession] = None
        self.api_key = settings.openrouter_api_key
        self.primary_model = settings.ai_model
        self.fallback_model = settings.ai_fallback_model

    async def start(self):
        self.session = aiohttp.ClientSession()

    async def close(self):
        if self.session:
            await self.session.close()

    async def analyze_token(
        self,
        token_data: dict,
        rugcheck_data: dict,
        creator_data: dict
    ) -> dict:
        """
        Analyze token using AI model.

        Args:
            token_data: Token technical info
            rugcheck_data: RugCheck security report
            creator_data: Creator wallet history

        Returns:
            AI analysis result
        """

        # Prepare context for AI
        context = f"""
## Токен: {token_data.get('symbol', '???')} ({token_data.get('name', 'Unknown')})
Адрес: {token_data.get('mint', 'N/A')}

## Технические метрики:
- Ликвидность: ${rugcheck_data.get('liquidity_usd', 0):,.0f}
- LP Burned: {'✅ Да' if rugcheck_data.get('lp_burned') else '❌ Нет'}
- Mint Authority: {'✅ Отключён' if rugcheck_data.get('mint_disabled') else '❌ Активен'}
- Freeze Authority: {'✅ Отключён' if rugcheck_data.get('freeze_disabled') else '❌ Активен'}
- Top 10 Holders: {rugcheck_data.get('top10_holders_percent', 0):.1f}%

## RugCheck анализ:
- Risk Score: {rugcheck_data.get('risk_score', 'N/A')}/100
- Risk Level: {rugcheck_data.get('risk_level', 'N/A')}
- Флаги: {', '.join(rugcheck_data.get('risk_flags', [])) or 'Нет'}

## История создателя:
- Адрес: {creator_data.get('address', 'N/A')}
- Всего транзакций: {creator_data.get('total_transactions', 0)}
- Предыдущие токены: {creator_data.get('previous_tokens', 'N/A')}

Проанализируй этот токен и дай рекомендацию."""

        # Try primary model first
        result = await self._call_model(self.primary_model, context)

        if not result or "error" in result:
            logger.warning(f"Primary model failed, trying fallback")
            result = await self._call_model(self.fallback_model, context)

        if not result or "error" in result:
            return self._get_default_analysis()

        return result

    async def _call_model(self, model: str, context: str) -> Optional[dict]:
        """Make API call to OpenRouter."""
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://solana-sniper-bot.local",
                "X-Title": "Solana Sniper Bot"
            }

            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": AI_SYSTEM_PROMPT},
                    {"role": "user", "content": context}
                ],
                "temperature": 0.3,
                "max_tokens": 1000,
                "response_format": {"type": "json_object"}
            }

            async with self.session.post(
                self.BASE_URL,
                headers=headers,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    logger.error(f"OpenRouter API error: {resp.status} - {error_text}")
                    return {"error": f"API error: {resp.status}"}

                data = await resp.json()
                content = data.get("choices", [{}])[0].get("message", {}).get("content", "")

                # Parse JSON response
                try:
                    result = json.loads(content)
                    result["model_used"] = model
                    result["tokens_used"] = data.get("usage", {})
                    return result
                except json.JSONDecodeError:
                    logger.error(f"Failed to parse AI response: {content[:200]}")
                    return {"error": "Invalid JSON response"}

        except asyncio.TimeoutError:
            logger.error(f"OpenRouter timeout for model {model}")
            return {"error": "Timeout"}
        except Exception as e:
            logger.error(f"OpenRouter error: {e}")
            return {"error": str(e)}

    def _get_default_analysis(self) -> dict:
        """Return default analysis when AI fails."""
        return {
            "score": 0,
            "risk_level": "critical",
            "recommendation": "skip",
            "confidence": 0,
            "analysis": {
                "technical": "Не удалось провести анализ",
                "security": "Нет данных",
                "creator": "Нет данных",
                "red_flags": ["AI анализ недоступен"],
                "green_flags": []
            },
            "suggested_position_size": "small",
            "take_profit_suggestion": "50%",
            "stop_loss_suggestion": "-30%",
            "reasoning": "Автоматический анализ не выполнен",
            "model_used": "none",
            "error": "AI analysis failed"
        }


# Import asyncio for timeout
import asyncio

openrouter = OpenRouterClient()
