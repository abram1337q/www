import aiohttp
from typing import Optional
from utils.logger import logger


class RugCheckClient:
    """Client for RugCheck.xyz API - token security analysis."""

    BASE_URL = "https://api.rugcheck.xyz/v1"

    def __init__(self):
        self.session: Optional[aiohttp.ClientSession] = None

    async def start(self):
        self.session = aiohttp.ClientSession()

    async def close(self):
        if self.session:
            await self.session.close()

    async def check_token(self, mint_address: str) -> dict:
        """
        Get comprehensive token security report.

        Returns:
            dict with risk assessment and detailed metrics
        """
        try:
            url = f"{self.BASE_URL}/tokens/{mint_address}/report"

            async with self.session.get(url) as resp:
                if resp.status == 404:
                    return {"error": "Token not found", "mint": mint_address}

                if resp.status != 200:
                    return {"error": f"API error: {resp.status}"}

                data = await resp.json()

                # Parse the response
                return self._parse_report(data, mint_address)

        except Exception as e:
            logger.error(f"RugCheck API error: {e}")
            return {"error": str(e), "mint": mint_address}

    def _parse_report(self, data: dict, mint_address: str) -> dict:
        """Parse RugCheck report into our format."""

        risks = data.get("risks", [])
        token_meta = data.get("tokenMeta", {})

        # Calculate risk score (0-100, lower is safer)
        risk_score = 0
        risk_flags = []

        for risk in risks:
            level = risk.get("level", "").lower()
            name = risk.get("name", "")

            if level == "critical":
                risk_score += 30
                risk_flags.append(f"🔴 {name}")
            elif level == "high":
                risk_score += 20
                risk_flags.append(f"🟠 {name}")
            elif level == "medium":
                risk_score += 10
                risk_flags.append(f"🟡 {name}")
            elif level == "low":
                risk_score += 5
                risk_flags.append(f"🟢 {name}")

        risk_score = min(100, risk_score)

        # Check critical flags
        mint_disabled = not data.get("mintAuthority")
        freeze_disabled = not data.get("freezeAuthority")
        lp_burned = data.get("lpBurned", False)

        # Top holders analysis
        top_holders = data.get("topHolders", [])
        top10_percent = sum(h.get("pct", 0) for h in top_holders[:10])

        # Market data
        markets = data.get("markets", [])
        total_liquidity = sum(m.get("lp", {}).get("usd", 0) for m in markets)

        return {
            "mint": mint_address,
            "name": token_meta.get("name", "Unknown"),
            "symbol": token_meta.get("symbol", "???"),

            # Security flags
            "mint_disabled": mint_disabled,
            "freeze_disabled": freeze_disabled,
            "lp_burned": lp_burned,

            # Risk assessment
            "risk_score": risk_score,
            "risk_level": self._get_risk_level(risk_score),
            "risk_flags": risk_flags,

            # Holder distribution
            "top10_holders_percent": round(top10_percent, 2),
            "top_holders": [
                {
                    "address": h.get("address"),
                    "percent": round(h.get("pct", 0), 2),
                    "is_insider": h.get("isInsider", False)
                }
                for h in top_holders[:10]
            ],

            # Liquidity
            "liquidity_usd": total_liquidity,
            "markets": [
                {
                    "name": m.get("marketType", "Unknown"),
                    "liquidity_usd": m.get("lp", {}).get("usd", 0)
                }
                for m in markets
            ],

            # Creator
            "creator": data.get("creator"),

            # Raw data for AI analysis
            "raw_risks": risks
        }

    def _get_risk_level(self, score: int) -> str:
        """Convert risk score to level."""
        if score >= 60:
            return "critical"
        if score >= 40:
            return "high"
        if score >= 20:
            return "medium"
        return "low"

    async def get_creator_tokens(self, creator_address: str) -> list:
        """Get list of tokens created by an address."""
        try:
            url = f"{self.BASE_URL}/creators/{creator_address}/tokens"

            async with self.session.get(url) as resp:
                if resp.status != 200:
                    return []

                data = await resp.json()
                return data.get("tokens", [])

        except Exception as e:
            logger.error(f"Failed to get creator tokens: {e}")
            return []


rugcheck = RugCheckClient()
