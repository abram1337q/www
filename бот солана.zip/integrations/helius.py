import asyncio
import json
import ssl
from typing import Optional, Callable, Any
import aiohttp
import websockets

# Try to use certifi for SSL certificates (fixes Windows SSL issues)
try:
    import certifi
    SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where())
except ImportError:
    # Fallback: disable SSL verification (not recommended for production)
    SSL_CONTEXT = ssl.create_default_context()
    SSL_CONTEXT.check_hostname = False
    SSL_CONTEXT.verify_mode = ssl.CERT_NONE

from config.settings import settings
from config.constants import (
    RAYDIUM_AMM_PROGRAM,
    ORCA_WHIRLPOOL_PROGRAM,
    METEORA_DLMM_PROGRAM,
    NATIVE_SOL_MINT,
    DEFAULT_SOL_PRICE_USD
)
from utils.logger import logger


class HeliusClient:
    def __init__(self):
        self.rpc_url = settings.helius_full_url
        self.ws_url = settings.helius_ws_url
        self.session: Optional[aiohttp.ClientSession] = None
        self.sol_price_usd = DEFAULT_SOL_PRICE_USD
        self._ws_connection = None
        self._running = False

    async def start(self):
        """Initialize HTTP session with SSL support."""
        connector = aiohttp.TCPConnector(ssl=SSL_CONTEXT)
        self.session = aiohttp.ClientSession(connector=connector)
        await self._update_sol_price()

    async def close(self):
        """Close HTTP session."""
        self._running = False
        if self._ws_connection:
            await self._ws_connection.close()
        if self.session:
            await self.session.close()

    async def _rpc_call(self, method: str, params: list = None) -> dict:
        """Make RPC call to Helius."""
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params or []
        }
        async with self.session.post(self.rpc_url, json=payload) as resp:
            result = await resp.json()
            if "error" in result:
                logger.error(f"RPC Error: {result['error']}")
                return {}
            return result.get("result", {})

    async def _update_sol_price(self):
        """Fetch current SOL price from CoinGecko/Binance (free APIs)."""
        try:
            # Try CoinGecko first (free, no auth required)
            url = "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd"
            async with self.session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    price = data.get("solana", {}).get("usd")
                    if price:
                        self.sol_price_usd = float(price)
                        logger.info(f"SOL price updated: ${self.sol_price_usd:.2f}")
                        return

            # Fallback to Binance API
            url = "https://api.binance.com/api/v3/ticker/price?symbol=SOLUSDT"
            async with self.session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    price = data.get("price")
                    if price:
                        self.sol_price_usd = float(price)
                        logger.info(f"SOL price updated: ${self.sol_price_usd:.2f}")
                        return

            logger.warning(f"Could not fetch SOL price, using default: ${DEFAULT_SOL_PRICE_USD}")
        except Exception as e:
            logger.error(f"Failed to fetch SOL price: {e}")

    async def get_token_info(self, mint_address: str) -> dict:
        """Get token metadata and supply info."""
        try:
            # Get token supply
            supply_result = await self._rpc_call("getTokenSupply", [mint_address])

            # Get token metadata via Helius DAS API
            das_url = f"https://mainnet.helius-rpc.com/?api-key={settings.helius_api_key}"
            payload = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getAsset",
                "params": {"id": mint_address}
            }

            async with self.session.post(das_url, json=payload) as resp:
                das_result = await resp.json()
                asset = das_result.get("result", {})

            return {
                "mint": mint_address,
                "name": asset.get("content", {}).get("metadata", {}).get("name", "Unknown"),
                "symbol": asset.get("content", {}).get("metadata", {}).get("symbol", "???"),
                "decimals": supply_result.get("value", {}).get("decimals", 9),
                "supply": float(supply_result.get("value", {}).get("uiAmount", 0)),
                "mint_authority": asset.get("authorities", [{}])[0].get("address") if asset.get("authorities") else None,
                "freeze_authority": asset.get("ownership", {}).get("frozen", False),
            }
        except Exception as e:
            logger.error(f"Failed to get token info: {e}")
            return {}

    async def get_token_holders(self, mint_address: str, limit: int = 10) -> list:
        """Get top token holders."""
        try:
            result = await self._rpc_call(
                "getTokenLargestAccounts",
                [mint_address]
            )
            holders = result.get("value", [])
            return [
                {
                    "address": h.get("address"),
                    "amount": float(h.get("uiAmount", 0))
                }
                for h in holders[:limit]
            ]
        except Exception as e:
            logger.error(f"Failed to get token holders: {e}")
            return []

    async def get_pool_liquidity(self, pool_address: str) -> dict:
        """Get liquidity info for a pool."""
        try:
            result = await self._rpc_call("getAccountInfo", [
                pool_address,
                {"encoding": "jsonParsed"}
            ])

            # Parse pool data (simplified - real implementation needs pool-specific parsing)
            data = result.get("value", {}).get("data", {})

            return {
                "pool_address": pool_address,
                "liquidity_sol": 0,  # Would need pool-specific parsing
                "liquidity_usd": 0
            }
        except Exception as e:
            logger.error(f"Failed to get pool liquidity: {e}")
            return {}

    async def check_lp_burned(self, pool_address: str) -> bool:
        """Check if LP tokens are burned (sent to null address)."""
        # Simplified check - would need pool-specific logic
        return True

    async def get_creator_history(self, creator_address: str) -> dict:
        """Get transaction history of token creator."""
        try:
            result = await self._rpc_call("getSignaturesForAddress", [
                creator_address,
                {"limit": 100}
            ])

            signatures = result if isinstance(result, list) else []

            return {
                "address": creator_address,
                "total_transactions": len(signatures),
                "first_tx_time": signatures[-1].get("blockTime") if signatures else None,
                "last_tx_time": signatures[0].get("blockTime") if signatures else None,
            }
        except Exception as e:
            logger.error(f"Failed to get creator history: {e}")
            return {}

    async def subscribe_new_pools(self, callback: Callable[[dict], Any]):
        """Subscribe to new pool creation events via WebSocket."""
        self._running = True
        logger.info(f"Connecting to WebSocket: {self.ws_url[:50]}...")

        while self._running:
            try:
                async with websockets.connect(self.ws_url, ssl=SSL_CONTEXT) as ws:
                    self._ws_connection = ws
                    logger.info("WebSocket connected successfully!")

                    # Subscribe to Raydium program logs
                    subscribe_msg = {
                        "jsonrpc": "2.0",
                        "id": 1,
                        "method": "logsSubscribe",
                        "params": [
                            {"mentions": [RAYDIUM_AMM_PROGRAM]},
                            {"commitment": "confirmed"}
                        ]
                    }
                    await ws.send(json.dumps(subscribe_msg))
                    logger.info("Subscribed to Raydium pool events")

                    async for message in ws:
                        try:
                            data = json.loads(message)
                            if "params" in data:
                                logs = data["params"]["result"]["value"]["logs"]
                                signature = data["params"]["result"]["value"]["signature"]

                                # Check if this is a pool initialization
                                if any("initialize" in log.lower() for log in logs):
                                    pool_data = await self._parse_pool_creation(signature)
                                    if pool_data:
                                        await callback(pool_data)
                        except Exception as e:
                            logger.error(f"Error processing WS message: {e}")

            except Exception as e:
                logger.error(f"WebSocket error: {e}")
                if self._running:
                    await asyncio.sleep(5)  # Reconnect delay

    async def _parse_pool_creation(self, signature: str) -> Optional[dict]:
        """Parse pool creation transaction."""
        try:
            result = await self._rpc_call("getTransaction", [
                signature,
                {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0}
            ])

            if not result:
                return None

            # Extract token mint from transaction
            # This is simplified - real implementation needs detailed parsing
            meta = result.get("meta", {})

            # Look for token accounts in post balances
            post_token_balances = meta.get("postTokenBalances", [])

            for balance in post_token_balances:
                mint = balance.get("mint")
                if mint and mint != NATIVE_SOL_MINT:
                    return {
                        "signature": signature,
                        "token_mint": mint,
                        "timestamp": result.get("blockTime"),
                    }

            return None
        except Exception as e:
            logger.error(f"Failed to parse pool creation: {e}")
            return None

    async def get_token_price(self, mint_address: str) -> float:
        """Get token price in USD via DexScreener (free API)."""
        try:
            # Use DexScreener API (free, no auth required)
            url = f"https://api.dexscreener.com/latest/dex/tokens/{mint_address}"
            async with self.session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    pairs = data.get("pairs", [])
                    if pairs:
                        # Get price from first pair
                        return float(pairs[0].get("priceUsd", 0))
            return 0
        except:
            return 0


helius = HeliusClient()
